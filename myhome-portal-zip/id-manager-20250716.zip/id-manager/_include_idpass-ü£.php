<?php
function id_pass_view($rec) {
	for ($ix = 1; $ix <= ID_MANAGER_ITEM_NUMBER; $ix++) {
		if ($rec['c_item'.$ix]<>"" or $rec['c_val'.$ix]<>"") {
			$val = ang2str($rec['c_val'.$ix], $rec['c_updatetime']);
?>
	<table class="id_manager_id_box" cellspacing="0">
	<tr>
	<td class="id_item_name"><?= my_htmlspecialchars($rec['c_item'.$ix]) ?>：<br /></td>
		<td class="id_item_val_data"><?= $val ?><br /></td>
		<td><input type="button" id="button<?= $rec['id_pass'] ?>_<?= $ix ?>" value="C" onmouseover="clipSetBtn('<?= $rec['id_pass'] ?>_<?= $ix ?>','<?= $val ?>');"></td>
<?php
			if (strpos($val, '-') !== False or strpos($val, ' ') !== False) {
				$sep_ary = preg_split("[\x20|\x2d]", $val);
				$sepchr = ' ';
				$iy = 0;
				foreach ($sep_ary as $sep) {
?>
			<td class="id_item_space"><?= $sepchr ?><br /></td>
			<td class="id_item_val_data_sep"><?= $sep ?><br /></td>
			<td><input type="button" id="button<?= $rec['id_pass'] ?>_<?= $ix ?>_<?= $iy ?>" value="C" onmouseover="clipSetBtn('<?= $rec['id_pass'] ?>_<?= $ix ?>_<?= $iy++ ?>','<?= $sep ?>');"></td>
<?php
					$sepchr = '-';
				}
?>
			<td class="id_item_space"><br /></td>
<?php
				$sep_cat = '';
				foreach ($sep_ary as $sep) {
					$sep_cat .= $sep;
				}
?>
			<td class="id_item_val_data"><?= $sep_cat ?><br /></td><td><br /></td>
			<td><input type="button" id="button<?= $rec['id_pass'] ?>_<?= $ix ?>_z" value="C" onmouseover="clipSetBtn('<?= $rec['id_pass'] ?>_<?= $ix ?>_z','<?= $sep_cat ?>');"></td>
<?php
			}
?>
	</tr>
	</table>
<?php
		}
	}
}
?>
