<?php
	require("__include-common.php");
	require("../account/__logincheck.php");
	require("__include-im-login.php");
	require("im-logincheck.php");
	require("../__common__/include-common-mp-list.php");

	$mp_list_arg = array();
	$mp_list_arg['account_id']	= $_SESSION['current_id'];
	$mp_list_arg['table_name_view']	= "m_category";
	$mp_list_arg['table_name_edit']	= "m_category";
	$mp_list_arg['id_item']		= "id_category";
	$mp_list_arg['must_item']	= "c_categoryName";
	$mp_list_arg['input_new']	= "no";
	$mp_list_arg['list_filter']	= "no";

	$item_tbl = array();
	$item_tbl[] = array(	"表示名"=>"カテゴリ", "列名"=>"c_categoryName",
				"type"=>"text", "size"=>20, "ime-mode"=>"active", "文字検索"=>"Y");
	$item_tbl[] = array(	"表示名"=>"表示順", "列名"=>"c_categoryDisplayOrder",
				"type"=>"text", "size"=>6, "ime-mode"=>"disabled", "toInt"=>"Y");

	$order_tbl = array();
	$order_tbl[] = array(	"表示名"=>"表示順", "get_order_name"=>"cate",
				"order_by"=>"c_categoryDisplayOrder asc");		/* default */
	$order_tbl[] = array(	"表示名"=>"カテゴリ名順", "get_order_name"=>"date",
				"order_by"=>"c_categoryName asc");

	$http_arg = array();
	$http_arg['pl'] = PAGE_LINE_DEFAULT;		// mp_list 必須
	$http_arg['sort'] = '';				// mp_list 必須
	$http_arg['cat'] = '';				// mp_list 必須
	$http_arg['key'] = '';				// mp_list 必須

	if (isset($_POST['登録'])) {
		check_post_account($_POST['login_id'], $_POST['current_id']);
		mp_list_update($mp_list_arg, $item_tbl, $order_tbl, $http_arg);
	} else {
		_GET_to_http_arg_pool($http_arg, '');
		html_header(HTML_TITLE);
		page_header();
		contents_header();
		if ($_GET['edit'] == "y") {
			mp_list_edit($mp_list_arg, $item_tbl, $order_tbl, $http_arg);
		} else {
			mp_list_view($mp_list_arg, $item_tbl, $order_tbl, $http_arg);
		}
		page_footer();
		html_footer();
	}
	exit();
