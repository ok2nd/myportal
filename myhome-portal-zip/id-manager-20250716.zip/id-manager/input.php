<?php
	require("__include-common.php");
	require("../account/__logincheck.php");
//	require("../account/__logincheck_write_permit.php");
	require("__include-im-login.php");
	require("im-logincheck.php");

	if ($_POST) {
		check_post_account($_POST['login_id']);
		post_done_proc();
	} else {
		html_header(HTML_TITLE, '', '#ffffff', ' onload="document.form0.c_subject.focus()"');
		page_header();
		input_form();
		page_footer();
		html_footer();
	}
	exit();
?>
<?php
function post_done_proc() {
	if ($_POST['user_id']."" <> "") {
		$user_id = $_POST['user_id'];
	} else {
		error_exit("不正アクセス：ユーザーIDなし", True);
	}
	if (check_permit_id($_SESSION['login_id'], $user_id) != "w") {
		error_exit("不正アクセス：書き込み権限がありません。", True);
	}
	if ($_POST['update_id']) {
		if (!is_numeric($_POST['update_id'])) {
			error_exit("不正アクセス", True);
		}
		$id = intval($_POST['update_id']);
	} else {
		$id = 0;
	}
	if (isset($_POST['削除'])) {
		//	if ($_POST['削除する'] <> "YES") {
		//		error_exit("削除するにチェックしてください。", True);
		//	}
	}
	if ($_POST['c_subject'] == "") {
		error_exit("件名なし", True);
	}
	$con = my_mysqli_connect(_DB_SCHEMA);
	$updateD = date("Y/m/d H:i:s");
	for ($ix=1; $ix<=ID_MANAGER_ITEM_NUMBER; $ix++) {
		if ($_POST['c_val'.$ix] <> "") {
			//$c_val[$ix] = str2ang($_POST['c_val'.$ix], $updateD);
			$c_val[$ix] = str2ang(form_str_adjust($_POST['c_val'.$ix]), $updateD);
		} else {
			$c_val[$ix] = "";
		}
	}
	if ($id == 0) {
		$sql = "insert into m_pass (c_subject, c_body, id_category, c_homepageUrl, id_account";
		for ($ix=1; $ix<=ID_MANAGER_ITEM_NUMBER; $ix++) {
			$sql .= ", c_item".$ix;
		}
		if ($_SESSION['current_id'] == $_SESSION['login_id']) {
			$sql .= ", c_privacy";
		}
		$sql .= ", c_updatetime, c_registtime)";
		$sql .= " values (";
		$sql .= "'" . post_to_mysql("c_subject") . "'";
		$sql .= ", '" . post_to_mysql("c_body") . "'";
		$sql .= ", '" . post_to_mysql("id_category") . "'";
		$sql .= ", '" . post_to_mysql_strip_tags("c_homepageUrl") . "'";
		$sql .= ", '" . $user_id . "'";
		for ($ix=1; $ix<=ID_MANAGER_ITEM_NUMBER; $ix++) {
			$sql .= ", '" . post_to_mysql("c_item".$ix) . "'";
		}
		if ($_SESSION['current_id'] == $_SESSION['login_id']) {
			if ($_POST['c_privacy'] == '444') {
				$sql .= ", 444";
			} else {
				$sql .= ", 0";
			}
		}
		$sql .= ", '" . $updateD . "'";
		$sql .= ", '" . $updateD . "'";
		$sql .= ")";
		$ret = my_mysqli_query($sql, "追加 失敗。(1)");
		$id = mysqli_insert_id($con);	//自動採番ID
		mysqli_close($con);
		$con = my_mysqli_connect(_DB_SCHEMA_2);
		$sql = "insert into m_pass2 (id_pass";
		for ($ix=1; $ix<=ID_MANAGER_ITEM_NUMBER; $ix++) {
			$sql .= ", c_val".$ix;
		}
		$sql .= ") values (";
		$sql .= $id;
		for ($ix=1; $ix<=ID_MANAGER_ITEM_NUMBER; $ix++) {
			$sql .= ", '" . str_for_mysql($c_val[$ix]) . "'";
		}
		$sql .= ")";
		$ret = my_mysqli_query($sql, "追加 失敗。(2)");
		mysqli_close($con);
	} elseif ($_POST['削除'] <> "") {
		$sql = "update m_pass set c_delete = 999";
		$sql .= ", c_updatetime = '". $updateD . "'";
		$sql .= " where id_pass = " . $id;
		$sql .= " and id_account = '" . $user_id . "'";
		$ret = my_mysqli_query($sql, "削除 失敗。");
		mysqli_close($con);
	} else {
		$sql = "update m_pass set";
		$sql .= " c_subject = '" . post_to_mysql("c_subject") . "'";
		$sql .= ", c_body = '" . post_to_mysql("c_body") . "'";
		$sql .= ", id_category = '" . post_to_mysql("id_category") . "'";
		$sql .= ", c_homepageUrl = '" . post_to_mysql_strip_tags("c_homepageUrl") . "'";
		for ($ix=1; $ix<=ID_MANAGER_ITEM_NUMBER; $ix++) {
			$sql .= ", c_item" . $ix . " = '" . post_to_mysql("c_item".$ix) . "'";
		}
		if ($_SESSION['current_id'] == $_SESSION['login_id']) {
			if ($_POST['c_privacy'] == '444') {
				$sql .= ", c_privacy = 444";
			} else {
				$sql .= ", c_privacy = 0";
			}
		}
		$sql .= ", c_updatetime = '". $updateD . "'";
		$sql .= " where id_pass = " . $id;
		$sql .= " and id_account = '" . $user_id . "'";
		$ret = my_mysqli_query($sql, "更新 失敗。(1)");
		mysqli_close($con);
		$con = my_mysqli_connect(_DB_SCHEMA_2);
		$sql = "update m_pass2 set";
		$sql .= " c_val1 = '" . str_for_mysql($c_val[1]) . "'";
		for ($ix=2; $ix<=ID_MANAGER_ITEM_NUMBER; $ix++) {
			$sql .= ", c_val" . $ix ." = '" . str_for_mysql($c_val[$ix]) . "'";
		}
		$sql .= " where id_pass = " . $id;
		$ret = my_mysqli_query($sql, "更新 失敗。(2)");
		mysqli_close($con);
	}
	//if ($_POST['削除'] <> "") {
	//	redirect("list.php");
	//} else {
		redirect("list.php?".$_SERVER['QUERY_STRING']);
		//redirect("list.php?".$_SERVER['QUERY_STRING']."#id_".$id);	// javascript:window.scroll(0, y)に変更
	//}
	exit;
}
function input_form() {
	if ($_GET['id'] <> "") {
		$id = $_GET['id'];
		if ($_GET['page'] <> "") {
			$page = $_GET['page'];
		}
	} else {
		$id = 0;
	}
	$con = my_mysqli_connect(_DB_SCHEMA);
	$sql = "select * from v_pass where id_pass = ".$id." and c_delete = 0";
	$sql .= " and id_account = ".$_SESSION['current_id'];
	$rs = my_mysqli_query($sql);
	$rec = mysqli_fetch_array($rs);
?>
<div class="input_form">
<h3><?= $_SESSION['current_handle'] ?><a class="a_cancel_back" href='javascript:history.back();'>戻る</a></h3>
<script>
function formCheck(form) {
	if (form.c_subject.value == '') {
		window.alert('件名を入れてください。');
		return false;		// 送信を中止
	}
	return true;	// 送信を実行
}
</script>
<form name="form0" method="POST" action="<?= $_SERVER['SCRIPT_NAME'] ?>?<?= $_SERVER['QUERY_STRING'] ?>" onSubmit="return formCheck(this)">
	<input type="hidden" name="user_id" value="<?= $_SESSION['current_id'] ?>">
	<input type="hidden" name="update_id" value="<?= $id ?>">
	<input type="hidden" name="page" value="<?= $page ?>">
	<input type="hidden" name="login_id" value="<?= $_SESSION['login_id'] ?>">
	<input type="hidden" name="current_id" value="<?= $_SESSION['current_id'] ?>">
<table>
<tr>
	<td nowrap>カテゴリ</td>
	<td nowrap>
<?php
	$sqlsel = "select * from m_category where id_account = '".$_SESSION['current_id']."'";
	$sqlsel = $sqlsel . " and c_delete = 0";
	$sqlsel = $sqlsel . " order by c_categoryDisplayOrder";
	$rs_sel = my_mysqli_query($sqlsel);
?>
	<select name="id_category">
<?php
		if ($id == 0) {
			$category = (int)$_GET['cat'];
		} else {
			$category = $rec['id_category'];
		}
		while ($rec_sel=mysqli_fetch_array($rs_sel)) {
?>
		<option value="<?= $rec_sel['id_category'] ?>"<?= $rec_sel['id_category'] == $category ? " selected" : "" ?>><?= my_htmlspecialchars($rec_sel['c_categoryName']) ?>
<?php
		}
?>
	</select>
	</td>
</tr>
<tr>
	<td nowrap>件名</td>
	<td nowrap>
		<input class="text" type="text" name="c_subject" value="<?= my_htmlspecialchars($rec['c_subject']) ?>" style="width:300px; ime-mode: active;">
		<?php if ($_SESSION['current_id'] == $_SESSION['login_id']) { ?>
			&nbsp;&nbsp;<label><input type="checkbox" name="c_privacy" value="444" <?= $rec['c_privacy'] == 444 ? ' checked' : '' ?>>非公開</label>
		<?php } ?>
		<br>
	</td>
</tr>
<tr>
	<td nowrap>URL</td>
	<td nowrap>
		<input class="text" type="text" name="c_homepageUrl" value="<?= my_htmlspecialchars($rec['c_homepageUrl']) ?>" style="width:500px; ime-mode: inactive;"><br>
	</td>
</tr>
<tr>
	<td nowrap>項目</td>
	<td nowrap>
<?php
	if ($id == 0) {
		$rec['c_item1'] = "ID";
		$rec['c_item2'] = "PW";
	}
	for ($ix=1; $ix<=ID_MANAGER_ITEM_NUMBER; $ix++) {
?>
		(<?= $ix ?>)&nbsp;<input class="text" type="text" name="c_item<?= $ix ?>" value="<?= my_htmlspecialchars($rec['c_item'.$ix]) ?>" style="ime-mode: active;width: 140px; ">
			<?php $val = ang2str($rec['c_val'.$ix], $rec['c_updatetime']); ?>
		<input class="text" type="text" name="c_val<?= $ix ?>" value="<?= $val ?>" style="width: 300px; ime-mode: inactive;"><br>
<?php
	}
?>
	</td>
</tr>
<tr>
	<td nowrap>備考</td>
	<td nowrap>
		<div class="block">
		<div class="block_left">
		<?php
			$str = my_htmlspecialchars($rec['c_body']);
			$rows = textarea_rows($str, 400) + 1;
			if ($rows < 10) {
				$rows = 10;
			} elseif (strstr($_SERVER['HTTP_USER_AGENT'], "MSIE") and $rows > 30) {
				$rows = 30;
			}
		?>
		<textarea id="c_body" name="c_body" style="width:450px;" rows="<?= $rows ?>" wrap="soft"><?= $str ?></textarea>
		</div>
		<?php	if (strstr($_SERVER['HTTP_USER_AGENT'], "MSIE")) { ?>
			<div class="block_left">
			<input type="button" value="小" OnClick="textareaBigSmall('c_body','小')"><br>
			<input type="button" value="大" OnClick="textareaBigSmall('c_body','大')">
			</div>
		<?php	} ?>
		</div>
	</td>
	</tr>
</table>
<?php
	if ($id == 0) {
?>
	<input class="input_form_button" type="submit" name="登録" value="登録">
<?php
	} else {
?>
	<input class="input_form_button" type="submit" name="登録" value="修正">
	<input class="input_form_button" type="submit" name="削除" value="削除" onClick="return delete_check();" style="margin-left:20px;">
<?php
	}
?>
	</form>
<script>
function delete_check() {
	if (window.confirm('このデータを削除しますか？')) {
		return true;
	} else {
		return false;
	}
}
</script>
</div>
<?php	if (!strstr($_SERVER['HTTP_USER_AGENT'], "MSIE")) { ?>
<script src="../scripts/autoresize.jquery.min.js"></script>
<script>
$('textarea#c_body').autoResize({
	onResize : function() {
		$(this).css({opacity:0.8});
	},
	animateCallback : function() {
		$(this).css({opacity:1});
	},
	animateDuration : 300,
	extraSpace : 20
});
$('textarea#c_body').trigger('change'); // 初期表示時に自動リサイズさせるためchangeイベント実行
</script>
<?php	} ?>
<?
}
?>
