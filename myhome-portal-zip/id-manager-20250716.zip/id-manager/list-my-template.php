<script>
function openwin(url, id) {
	target = 't'+(new Date()).getTime();
	w1 = window.open(url, target, 'left=<?=POP_WIN2_LEFT?>,top=<?=POP_WIN2_TOP?>,width=<?=POP_WIN2_WIDTH?>,height=<?=POP_WIN2_HEIGHT?>,toolbar=yes,location=yes,directories=yes,status=yes,menubar=yes,scrollbars=yes,resizable=yes');
	w2 = window.open('view-idpass.php?id='+id, 'im_w1', 'screenX=<?=POP_WIN1_LEFT?>,screenY=<?=POP_WIN1_TOP?>,left=<?=POP_WIN1_LEFT?>,top=<?=POP_WIN1_TOP?>,width=<?=POP_WIN1_WIDTH?>,height=<?=POP_WIN1_HEIGHT?>,toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes');
}
</script>
<script src="../scripts/zeroclipboard/ZeroClipboard-ok2nd.js"></script>
<script>
function clipSetBtn(id, text) {
	var e = document.createElement('textarea');
//	e.classList.add('hidden');
	e.textContent = text;
	document.body.appendChild(e);
	e.select();
	document.execCommand('copy');
	e.remove();
}
function clipSetBtn_OLD(id, text) {
	var clip = new ZeroClipboard.Client();
	clip.setText(text);
	clip.glue('button'+id);
}
</script>
<table id="id_manager_table">
<?php
	mysqli_data_seek($rs, $startline);			//テーブル内の指定行に移動
	$line = $startline;					//$lineに$startlineを代入
	while ($rec=mysqli_fetch_array($rs) and $line<=$endline) {
		if ($rec['c_privacy'] == 444) {
			$view_class_privacy = 'id_manager_privacy';
		} else {
			$view_class_privacy = '';
		}
		if ($line <> $startline) {
?>
	<a name="id_<?= $rec['id_pass'] ?>"></a>
	</td>
	</tr>
<?php
		}
?>
	<tr>
	<td class="id_manager_td id_manager_category <?= $view_class_privacy ?>"><?= my_htmlspecialchars($rec['c_categoryName']) ?></td>
	<td class="id_manager_td <?= $view_class_privacy ?>">
	<p>	<span class="id_manager_subject">
	<?php if ($rec['c_homepageUrl'] <> "") { ?>
		<a href="<?= $rec['c_homepageUrl'] ?>" target="_blank"><?= my_htmlspecialchars($rec['c_subject']) ?></a>
		</span>
		<span class="id_manager_wpop">
		<a href="javascript:openwin('<?= $rec['c_homepageUrl'] ?>', '<?= $rec['id_pass'] ?>')">W↑</a>
		</span>
	<?php } else { ?>
		<?= my_htmlspecialchars($rec['c_subject']) ?>
		</span>
	<?php } ?>
<?
// ***************************************
//				↓↓↓↓　　　& query_from_http_arg_pool($http_arg)
// ***************************************
?>
	<? if (is_write_permit() == True) { ?>
	<button style="font-size:10px;background:#ffe700;margin-left:3px;" onClick="input_memo('<?= $rec['id_pass'] ?>','<?= $page ?>','<?= query_from_http_arg_pool($http_arg) ?>')">修正</button>
	<? } ?>
	</p>
	<?php
		id_pass_view($rec);
	?>
	<p class="id_manager_body"><?= ins_atag_br($rec['c_body']) ?></p>
<?php
		$line++;
	}
?>
	</td>
	</tr>
	</table>
<script>
function input_memo(id, page, opt) {
	var sclTop = document.body.scrollTop || document.documentElement.scrollTop;
	location.href='input.php?id='+id+'&page='+page+'&'+opt+'&scroll='+sclTop;
}
function window_scroll(y) {
	window.scroll(0, y);
}
</script>
<?php
	jquery_highlight('.id_manager_subject', keystr_and_or($keystring));
	jquery_highlight('.id_manager_body', keystr_and_or($keystring));
?>
