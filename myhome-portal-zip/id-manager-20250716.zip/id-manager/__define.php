<?php
	if (defined("HTML_TITLE_idmanager")) {
		define("HTML_TITLE", HTML_TITLE_idmanager);
	} else {
		define("HTML_TITLE", "MyHome ID管理");
	}
	define("SESSION_PREFIX", "id_manager");

	if (defined("_DB_SCHEMA_zid_mgr_a")) {
		define("_DB_SCHEMA", _DB_SCHEMA_zid_mgr_a);
	} else {
		define("_DB_SCHEMA", "_db_zid_mgr_a");
	}
	if (defined("_DB_SCHEMA_zid_mgr_b")) {
		define("_DB_SCHEMA_2", _DB_SCHEMA_zid_mgr_b);
	} else {
		define("_DB_SCHEMA_2", "_db_zid_mgr_b");
	}
	if (defined("POP_WIN1_LEFT_id_manager")) {
		define("POP_WIN1_LEFT", POP_WIN1_LEFT_id_manager);
		define("POP_WIN1_TOP", POP_WIN1_TOP_id_manager);
		define("POP_WIN1_WIDTH", POP_WIN1_WIDTH_id_manager);
		define("POP_WIN1_HEIGHT", POP_WIN1_HEIGHT_id_manager);
		define("POP_WIN2_LEFT", POP_WIN2_LEFT_id_manager);
		define("POP_WIN2_TOP", POP_WIN2_TOP_id_manager);
		define("POP_WIN2_WIDTH", POP_WIN2_WIDTH_id_manager);
		define("POP_WIN2_HEIGHT", POP_WIN2_HEIGHT_id_manager);
	} else {
		define("POP_WIN1_LEFT", 10);
		define("POP_WIN1_TOP", 10);
		define("POP_WIN1_WIDTH", 600);
		define("POP_WIN1_HEIGHT", 130);
		define("POP_WIN2_LEFT", 100);
		define("POP_WIN2_TOP", 160);
		define("POP_WIN2_WIDTH", 900);
		define("POP_WIN2_HEIGHT", 560);
	}
	if (!defined("ID_MANAGER_ITEM_NUMBER")) {
		define("ID_MANAGER_ITEM_NUMBER", 6);
	}
	define("PAGE_LINE_SELECT", "5,10,20,50,100,1000");	//頁内に表示する行数
	define("PAGE_LINE_DEFAULT", "10");			//頁内に表示する行数（デフォルト）
?>
