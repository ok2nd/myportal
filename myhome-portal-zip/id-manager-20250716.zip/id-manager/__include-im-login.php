<?php
function id_mgr_account_login($account_id, $password, $change_current_id="") {
	// $password: 暗号化済
	$_SESSION['_id_mgr_logincheck'] = "";
	if ($password == "") {
		return("パスワードを入力してください。");
	}
	$con = my_mysqli_connect(_DB_ACCOUNT_SCHEMA);
	$sql = "select * from m_account where id_account = '" . $account_id . "' and c_delete = 0";
	$rs_account = my_mysqli_query($sql);
	$row = mysqli_num_rows($rs_account);
	if ($row == 0) {
		$sql = "insert into z_loginlog (id_account,c_account,c_id_mgr_pass,c_status)";
		$sql .= " VALUES ('" . $account_id . "','" . $account . "','" . $password . "','ERROR IM ACCOUNT')";
		$ret = my_mysqli_query($sql);
		mysqli_close($con);
		return("ログイン情報が無効です。");
	}
	$rec_account = mysqli_fetch_array($rs_account);
	if (my_hash($rec_account['c_id_mgr_pass']) <> $password) {
		$sql = "insert into z_loginlog (id_account,c_account,c_id_mgr_pass,c_status)";
		$sql .= " VALUES ('" . $rec_account['id_account'] . "','" . $rec_account['c_account'] . "','" . $password . "','ERROR IM PASSWORD')";
		$ret = my_mysqli_query($sql);
		mysqli_close($con);
		return("パスワードが無効です。");
	}

	// ***** ログイン記録 *****
	if ($change_current_id == "") {
		$change_current_id = 0;
	}
	$sql = "insert into z_loginlog (id_account,c_account,c_id_mgr_pass,c_status,c_change_id) VALUES ('" . $_SESSION['login_id'] . "','" . $_SESSION['login_account'] . "','" . $password . "','IM LOGIN','" . $change_current_id . "')";
	$ret = my_mysqli_query($sql);
	mysqli_close($con);
	return("OK");	// 正常
}
?>
