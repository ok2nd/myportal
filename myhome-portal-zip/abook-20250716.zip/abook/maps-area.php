<?php
	require("__include-common.php");
	require("../account/__logincheck.php");

	$category = $_GET['cat'];
	$ne_lat = $_GET['ne_lat'];
	$sw_lat = $_GET['sw_lat'];
	$ne_lng = $_GET['ne_lng'];
	$sw_lng = $_GET['sw_lng'];

	$con = my_mysqli_connect(_DB_SCHEMA_abook);
	$sql = 'select id_abook from m_abook';
	$sql .= ' where id_category = '.$category;
	if ($sw_lat < $ne_lat) {
		$sql .= ' and SUBSTRING(c_address1,1,LOCATE(",",c_address1)-1) BETWEEN '.$sw_lat.' and '.$ne_lat;
	} else {
		$sql .= ' and SUBSTRING(c_address1,1,LOCATE(",",c_address1)-1) BETWEEN '.$sw_lat.' and '.$ne_lat;
	}
	if (($ne_lng >= 0 and $sw_lng >= 0) or ($ne_lng < 0 and $sw_lng < 0)) {
		if ($ne_lng < $sw_lng) {
			$sql .= ' and SUBSTRING(c_address1,LOCATE(",",c_address1)+1) BETWEEN '.$ne_lng.' and '.$sw_lng;
		} else {
			$sql .= ' and SUBSTRING(c_address1,LOCATE(",",c_address1)+1) BETWEEN '.$sw_lng.' and '.$ne_lng;
		}
	} else {	/* 経度が0度、180度を跨る場合 */
		if ($ne_lng < 0) {
			$sql .= ' and ( SUBSTRING(c_address1,LOCATE(",",c_address1)+1) BETWEEN '.$sw_lng.' and 180.0';
			$sql .= ' or SUBSTRING(c_address1,LOCATE(",",c_address1)+1) BETWEEN -180.0 and '.$ne_lng. ' )';
		} else {
			$sql .= ' and ( SUBSTRING(c_address1,LOCATE(",",c_address1)+1) BETWEEN '.$sw_lng.' and 0.0';
			$sql .= ' or SUBSTRING(c_address1,LOCATE(",",c_address1)+1) BETWEEN 0.0 and '.$ne_lng. ' )';
		}
	}
	$rs = my_mysqli_query($sql);
	$row = mysqli_num_rows($rs);
	if ($row == 0) {
		error_exit('該当する場所がみつかりません。',True,False);
	}
	$id_list = '';
	while ($rec=mysqli_fetch_array($rs)) {
		if ($id_list <> '') {
			$id_list .= ',';
		}
		$id_list .= $rec['id_abook'];
	}
	if ($category == HYAKUMEIZAN_CATEGORY_ID.'') {		/* 百名山 */
		$opt = 'hm';
		$so = 'c_yomi1';
	} elseif ($category == TETSUDO_EKI_CATEGORY_ID.'') {	/* 鉄道駅 */
		$opt = 'ts';
		$so = 'c_yomi1';
	} elseif ($category == SAKURA_MEISHO_CATEGORY_ID.'') {	/* 桜名所 */
		$opt = 'sk';
		$so = 'c_yomi1';
	} elseif ($category == HYAKUSEN_CATEGORY_ID.'') {	/* 日本百選 */
		$opt = 'hs';
		$so = 'c_yomi1';
	} elseif ($category == SEKAI_ISAN_CATEGORY_ID.'') {	/* 世界遺産 */
		$opt = 'wh';
		$so = 'c_name1';
	}
	header('Location: maps-abook-v3.php?id='.$id_list.'&so='.$so.'&opt='.$opt);
?>
