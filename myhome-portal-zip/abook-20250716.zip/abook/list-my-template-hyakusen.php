<script>
function updateCheck(id, no, chkd) {
	var d = new Date();	// キャッシュを利用されないため
	if (chkd) {
		chk = 1;
	} else {
		chk = 0;
	}
	$.get("check-update.php?time="+d.getTime().toString(), {id:id,no:no,chk:chk});
	if (chkd) {
		color = "<?= CHECKED_BGCOLOR ?>";
	} else {
		color = "<?= UNCHECK_BGCOLOR ?>";
	}
	$("#ck"+id+"_"+no).css("background-color",color);
}
function checkOnAll() {
	$("input:checkbox[name^='check']").attr('checked', true);
	return false;
}
function checkOffAll() {
	$("input:checkbox[name^='check']").attr('checked', false);
	return false;
}
function winOpen(){
//	Chrome,Safariでも別ウンドウで何回でも開くため
	target = 't'+(new Date()).getTime();
	w = window.open("do-proc.php?<?= $_SERVER['QUERY_STRING'] ?>", target);
	document.frm0.target = target;
}
</script>
	<form id="abook_form" name="frm0" method="POST" action="do-proc.php?<?= $_SERVER['QUERY_STRING'] ?>" onSubmit="winOpen()">
<?php	if (strstr($_SERVER['HTTP_USER_AGENT'], "MSIE")) { ?>
	<input class="" type="button" onClick="return checkOnAll()" value="全てチェック">
	<input class="" type="button" onClick="return checkOffAll()" value="チェッククリア">
	<input class="" type="submit" name="Maps" value="マップ">
	<input class="" type="submit" name="MapsV3" value="マップ(V3)">
<?php	} else { ?>
	<input class="" type="button" onClick="return checkOnAll()" value="全てチェック">
	<input class="" type="button" onClick="return checkOffAll()" value="チェッククリア">
	<input class="" type="submit" name="Maps" value="マップ">
	<input class="" type="submit" name="MapsV3" value="マップ(V3)">
<?php	} ?>
	<input type="hidden" name="option" value="hs">
<?php
	foreach ($order_tbl as $id=>$item) {
		if ($item['get_order_name'] == $_GET['sort']) {
			$sortorder = $item['order_by'];
			break;
		}
	}
	if ($sortorder == '') {
		$sortorder  = 'id_abook desc';
	}
?>
	<input type="hidden" name="sortOrder" value="<?= $sortorder ?>">
<?php
	global $chk_use;	// list-my-add-filter.phpでセット
?>
	<table id="abook_list_table">
	<tr>
		<th></th>
		<?php
			for ($ix=1; $ix<=CHECK_ITEM_NUMBER; $ix++) {
				if ($chk_use[$ix]) {
		?>
			<th><?= roman_number($ix) ?></th>
		<?php
				}
			}
		?>
		<th></th>
		<th>種類</th>
		<th>名前</th>
		<th>都道府県</th>
		<th>場所</th>
		<th>緯度・経度</th>
	</tr>
	<tbody id="abook_list_tbody">
<?php
	mysqli_data_seek($rs, $startline);
	$line = $startline;
	while ($rec=mysqli_fetch_array($rs) and $line<=$endline) {
		if ($rec['c_privacy'] == 444) {
			$list_tr = 'abook_list_privacy';
		} else {
			$list_tr = '';
		}
?>
	<tr class="<?= $list_tr ?>">
	<td class="abook_list_td a_check">
		<input type="checkbox" name="check[]" value="<?= $rec['id_abook'] ?>">
	</td>
	<?php
		for ($ix=1; $ix<=CHECK_ITEM_NUMBER; $ix++) {
			if ($chk_use[$ix]) {
	?>
		<td class="abook_list_mycheck" nowrap>
		<?php if (strstr($_SERVER['HTTP_USER_AGENT'], "MSIE")) { //IE ?>
		<input id="ck<?= $rec['id_abook'] ?>_<?= $ix ?>" class="abook_list_mycheck_chk_ie" style="background-color:<?= $rec['c_check'.$ix] == 1 ? CHECKED_BGCOLOR : UNCHECK_BGCOLOR ?>" type="checkbox" value="1"<?= $rec['c_check'.$ix] == 1 ? ' checked' : '' ?> OnClick="updateCheck(<?= $rec['id_abook'] ?>,<?= $ix ?>,this.checked)">
		<?php } else { ?>
		<span id="ck<?= $rec['id_abook'] ?>_<?= $ix ?>" class="abook_list_mycheck_span" style="background-color:<?= $rec['c_check'.$ix] == 1 ? CHECKED_BGCOLOR : UNCHECK_BGCOLOR ?>">
		<input class="abook_list_mycheck_chk" type="checkbox" value="1"<?= $rec['c_check'.$ix] == 1 ? ' checked' : '' ?> OnClick="updateCheck(<?= $rec['id_abook'] ?>,<?= $ix ?>,this.checked)"></span>
		<?php }  ?>
		</td>
	<?php
			}
		}
	?>
	<td class="abook_list_td marker_icon">
		<?php
			if ($rec['c_markericon'] <> '') {
				$icon = $rec['c_markericon'];
			} else {
				$icon = $rec['c_categoryIcon'];
			}
		?>
		<?php	if ($icon <> '') { ?>
			<img src="<?= DIARY_MAPS_ICON_FOLDER ?><?= $icon ?>">
		<?php	} ?>
	</td>
	<td class="abook_list_td hs_kubun" nowrap>
		<p><a href="?<?= query_from_http_arg_pool($http_arg) ?>&hs_kubun=<?= urlencode($rec['c_memo']) ?>" style="color:#0060c0;"><?= my_htmlspecialchars($rec['c_memo']) ?></a>&nbsp;<a href="http://www.google.com/search?q=<?= urlencode($rec['c_memo']) ?>" target="_blank" style="margin-left:2px;color:#008000;font-size:10px;">→G</a></p>
	</td>
	<td class="abook_list_td hs_name" nowrap>
		<?php
			$s_key = preg_replace("/(\(|（).+?(\)|）)/", ' ', $rec['c_name1']);
		?>
		<p><a href="http://www.google.com/search?q=<?= urlencode($s_key) ?>" target="_blank"><?= my_htmlspecialchars($rec['c_name1']) ?></a>
		<?php if (check_permit_id($_SESSION['login_id'], $_SESSION['current_id']) == "w") { ?>
<a href="input.php?id=<?= $rec[$id_item] ?>&page=<?= $page ?>&pl=<?= $pageline ?>&cat=<?= $http_arg['cat'] ?>&ken=<?= $http_arg['ken'] ?>" class="edit_data">修正</a>
		<?php } ?></p>
		<p style="color:#404040;"><?= my_htmlspecialchars($rec['c_yomi1']) ?></p>
	</td>
	<td class="abook_list_td hs_ken" nowrap>
		<p><a class="kenmei" href="?cat=<?= $_GET['cat'] ?>&ken=<?= $rec['c_kenid'] ?>"><?= my_htmlspecialchars($rec['c_kenmei']) ?></a></p>
	</td>
	<td class="abook_list_td hs_ken2" nowrap>
		<p><?= my_htmlspecialchars($rec['c_address2']) ?></p>
	</td>
	<td class="abook_list_td hs_address">
	<?php
		$address = my_htmlspecialchars($rec['c_address1']);
		$addr_enc = urlencode($address);
	?>
		<p><?= my_htmlspecialchars($rec['c_address1']) ?>
	<?php
		if ($address <> '') {
			$link = '&nbsp;<a href="http://maps.google.co.jp/maps?q='.$addr_enc.'" target="_blank" class="map_href">→地図</a>';
			$link .= '&nbsp;<a href="../tools/google-maps-earth-v3.php?addr='.$addr_enc.'" target="_blank" class="map_href">→●</a>';
			$link .= '&nbsp;<a href="http://maps.google.co.jp/maps?ie=UTF8&f=d&ttype=dep&dirflg=r&saddr='.urlencode($_SESSION['login_friends_home_address_'.$_SESSION['current_id']]).'&daddr='.$addr_enc.'" target="_blank" class="route_href">→経路</a>';
			echo $link;
		}
	?>
		</p>
	</td>
	</tr>
<?php
		$line++;
	}
?>
	</tbody>
	</table>
	</form>
