<?php
	require("__include-common.php");
	require("../account/__logincheck.php");
	require("../__common__/include-common-mp-list.php");

	$mp_list_arg = array();
	$mp_list_arg['account_id']	= $_SESSION['current_id'];
	$mp_list_arg['table_name_view']	= "m_mailfrom";
	$mp_list_arg['table_name_edit']	= "m_mailfrom";
	$mp_list_arg['id_item']		= "id_mailfrom";
	$mp_list_arg['must_item']	= "c_name";
	$mp_list_arg['edit_button_item'] = "c_name";
	$mp_list_arg['input_php']	= "mailfrom-input.php";
//	$mp_list_arg['input_new']	= "no";
	$mp_list_arg['list_filter']	= "no";
	$item_tbl = array();
	$item_tbl[] = array(	"表示名"=>"登録名", "列名"=>"c_name",
				"type"=>"text", "size"=>30, "ime-mode"=>"active", "文字検索"=>"Y");
	$item_tbl[] = array(	"表示名"=>"表示順", "列名"=>"c_displayOrder",
				"type"=>"text", "size"=>5, "ime-mode"=>"disabled", "toInt"=>"Y");
	$item_tbl[] = array(	"表示名"=>"ホスト", "列名"=>"c_host", "初期値"=>"localhost",
				"type"=>"no_edit", "size"=>20, "ime-mode"=>"disabled");
	$item_tbl[] = array(	"表示名"=>"ユーザー名", "列名"=>"c_username",
				"type"=>"no_edit", "size"=>30, "ime-mode"=>"active", "文字検索"=>"Y");
	$item_tbl[] = array(	"表示名"=>"ポート", "列名"=>"c_port", "初期値"=>"25",
				"type"=>"no_edit", "size"=>5, "ime-mode"=>"disabled", "toInt"=>"Y");
	$item_tbl[] = array(	"表示名"=>"認証", "列名"=>"c_auth", "初期値"=>"False",
				"type"=>"no_edit", "size"=>10, "ime-mode"=>"disabled");
	$item_tbl[] = array(	"表示名"=>"From", "列名"=>"c_from",
				"type"=>"no_edit", "size"=>30, "ime-mode"=>"active");
/*
	$item_tbl[] = array(	"表示名"=>"Cc", "列名"=>"c_cc",
				"type"=>"no_edit", "size"=>25, "ime-mode"=>"active");
	$item_tbl[] = array(	"表示名"=>"Bcc", "列名"=>"c_bcc",
				"type"=>"no_edit", "size"=>25, "ime-mode"=>"active");
	$item_tbl[] = array(	"表示名"=>"Reply-to", "列名"=>"c_reply_to",
				"type"=>"no_edit", "size"=>25, "ime-mode"=>"active");
*/
	$order_tbl = array();
	$order_tbl[] = array(	"表示名"=>"表示順", "get_order_name"=>"id",
				"order_by"=>"c_displayOrder asc");		/* default */
	$order_tbl[] = array(	"表示名"=>"登録名順", "get_order_name"=>"name",
				"order_by"=>"c_username asc");
	$http_arg = array();
	$http_arg['pl'] = PAGE_LINE_DEFAULT;		// mp_list 必須
	$http_arg['sort'] = '';				// mp_list 必須
	$http_arg['cat'] = '';				// mp_list 必須
	$http_arg['key'] = '';				// mp_list 必須
	if (isset($_POST['登録'])) {
		check_post_account($_POST['login_id'], $_POST['current_id']);
		mp_list_update($mp_list_arg, $item_tbl, $order_tbl, $http_arg);
	} else {
		_GET_to_http_arg_pool($http_arg, $table_name);
		html_header(HTML_TITLE);
		page_header();
		contents_header();
		if ($_GET['edit'] == "y") {
			mp_list_edit($mp_list_arg, $item_tbl, $order_tbl, $http_arg);
		} else {
			mp_list_view($mp_list_arg, $item_tbl, $order_tbl, $http_arg);
		}
		page_footer();
		html_footer();
	}
	exit();
