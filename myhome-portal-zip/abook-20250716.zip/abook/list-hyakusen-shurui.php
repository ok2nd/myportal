<?php
	require("__include-common.php");
	require("../account/__logincheck.php");
	require("../__common__/include-common-mp-list.php");

	html_header(HTML_TITLE);
	page_header();
	contents_header();
	$http_arg = http_arg_from_session_pool("m_abook");
	$sql = "select distinct c_memo,c_markericon from m_abook where id_category = ".HYAKUSEN_CATEGORY_ID." order by c_memo";
	$con = my_mysqli_connect(_DB_SCHEMA);
	$rs = my_mysqli_query($sql);
?>
	<table><tr><td>
	<table id="abook_list_table" style="width:auto;">
<?php
	$line = 0;
	while ($rec=mysqli_fetch_array($rs)) {
		if (intval($line/16)*16 == $line) {
			echo '</table></td><td><table id="abook_list_table" style="width:auto;">';
		}
?>
	<tr>
	<td class="abook_list_hyakusenshurui_td marker_icon" style="width:40px;">
		<?php	if ($rec['c_markericon'] <> '') { ?>
			<img src="<?= DIARY_MAPS_ICON_FOLDER ?><?= $rec['c_markericon'] ?>">
		<?php	} ?>
	</td>
	<td class="abook_list_hyakusenshurui_td" style="padding-right:10px;" nowrap>
		<p><a href="list.php?cat=<?= HYAKUSEN_CATEGORY_ID ?>&ken=<?= $http_arg['ken'] ?>&key=<?= $http_arg['key'] ?>&hs_kubun=<?= urlencode($rec['c_memo']) ?>" style="color:#0060c0;"><?= my_htmlspecialchars($rec['c_memo']) ?></a>
		<a href="http://www.google.com/search?q=<?= urlencode($rec['c_memo']) ?>" target="_blank" style="margin-left:2px;color:#008000;font-size:10px;">→G</a></p></p>
		<p style="margin-left:30px;"><?= $rec['c_markericon'] ?></p>
	</td>
	</tr>
<?php
		$line++;
	}
?>
	</table>
	</td></tr></table>
<?php
	page_footer();
	html_footer();
?>
