<?php
	require("__include-common.php");
	require("../account/__logincheck.php");
	if ($_POST) {
		check_post_account($_POST['login_id'], $_POST['current_id']);
		post_done_proc();
	} else {
		html_header(HTML_TITLE, '', '', ' onload="document.form0.c_name.focus()"');
		page_header();
		input_form();
		page_footer();
		html_footer();
	}
	exit();
?>
<?php
function post_done_proc() {
	if ($_POST['user_id']."" <> "") {
		$user_id = $_POST['user_id'];
	} else {
		error_exit("不正アクセス：ユーザーIDなし", True);
	}
	if (check_permit_id($_SESSION['login_id'], $user_id) != "w") {
		error_exit("不正アクセス：書き込み権限がありません。", True);
	}
	if ($_POST['update_id']) {
		if (!is_numeric($_POST['update_id'])) {
			error_exit("不正アクセス", True);
		}
		$id = intval($_POST['update_id']);
	} else {
		$id = 0;
	}
	if (isset($_POST['削除'])) {
		//	if ($_POST['削除する'] <> "YES") {
		//		error_exit("削除するにチェックしてください。", True);
		//	}
	} elseif ($_POST['c_name'] == "") {
		error_exit("登録名なし", True);
	}
	$con = my_mysqli_connect(_DB_SCHEMA);
	if ($id == 0) {
		$sql = "insert into m_mailfrom";
		$sql .= " (id_account";
		$sql .= ", c_name";
		$sql .= ", c_username";
		$sql .= ", c_password";
		$sql .= ", c_host";
		$sql .= ", c_port";
		$sql .= ", c_auth";
		$sql .= ", c_from";
		$sql .= ", c_cc";
		$sql .= ", c_bcc";
		$sql .= ", c_reply_to";
		$sql .= ", c_body";
		$sql .= ", c_registtime";
		$sql .= ", c_updatetime";
		$sql .= ") values ";
		$sql .= "( '".$user_id."'";
		$sql .= ", '".post_to_mysql("c_name")."'";
		$sql .= ", '".post_to_mysql("c_username")."'";
		$sql .= ", '".post_to_mysql("c_password")."'";
		$sql .= ", '".post_to_mysql("c_host")."'";
		$sql .= ", '".post_to_mysql("c_port")."'";
		$sql .= ", '".post_to_mysql("c_auth")."'";
		$sql .= ", '".post_to_mysql("c_from")."'";
		$sql .= ", '".post_to_mysql("c_cc")."'";
		$sql .= ", '".post_to_mysql("c_bcc")."'";
		$sql .= ", '".post_to_mysql("c_reply_to")."'";
		$sql .= ", '".post_to_mysql("c_body")."'";
		$sql .= ", '". date("Y/m/d H:i:s") . "'";
		$sql .= ", '". date("Y/m/d H:i:s") . "'";
		$sql .= ")";
		$ret = my_mysqli_query($sql, "登録できませんでした。");
	} elseif ($_POST['削除'] <> "") {
		$sql = "update m_mailfrom set";
		$sql .= " c_delete = 999";
		$sql .= ", c_updatetime = '". date("Y/m/d H:i:s") . "'";
		$sql .= " where id_mailfrom = ".$id;
		$sql .= " and id_account = ".$user_id;
		$ret = my_mysqli_query($sql, "削除できませんでした。");
	} else {
		$sql = "update m_mailfrom set";
		$sql .= " c_name = '".post_to_mysql("c_name")."'";
		$sql .= ", c_username = '".post_to_mysql("c_username")."'";
		$sql .= ", c_password = '".post_to_mysql("c_password")."'";
		$sql .= ", c_host = '".post_to_mysql("c_host")."'";
		$sql .= ", c_port = '".post_to_mysql("c_port")."'";
		$sql .= ", c_auth = '".post_to_mysql("c_auth")."'";
		$sql .= ", c_from = '".post_to_mysql("c_from")."'";
		$sql .= ", c_cc = '".post_to_mysql("c_cc")."'";
		$sql .= ", c_bcc = '".post_to_mysql("c_bcc")."'";
		$sql .= ", c_reply_to = '".post_to_mysql("c_reply_to")."'";
		$sql .= ", c_body = '".post_to_mysql("c_body")."'";
		$sql .= ", c_updatetime = '". date("Y/m/d H:i:s") . "'";
		$sql .= " where id_mailfrom = ".$id;
		$sql .= " and id_account = ".$user_id;
		$ret = my_mysqli_query($sql, "更新できませんでした。");
	}
	mysqli_close($con);
	redirect("mailfrom.php?".$_SERVER['QUERY_STRING']);
}
function input_form() {
	if (check_permit_id($_SESSION['login_id'], $_SESSION['current_id']) != "w") {
		error_exit("書き込み権限がありません。", True);
	}
	if ($_GET['id'] <> "") {
		$id = $_GET['id'];
		if ($_GET['page'] <> "") {
			$page = $_GET['page'];
		}
	} else {
		$id = 0;
	}
	$con = my_mysqli_connect(_DB_SCHEMA);
	$sql = "select * from m_mailfrom where id_mailfrom = ".$id." and c_delete = 0";
	$sql .= " and id_account = ".$_SESSION['current_id'];
	$rs = my_mysqli_query($sql);
	$rec = mysqli_fetch_array($rs);
?>
<div class="input_form">
<h3><?= $_SESSION['current_handle'] ?><a class="a_cancel_back" href='mailfrom.php?<?=$_SERVER['QUERY_STRING'] ?>'>戻る</a></h3>
<script>
function formCheck(form) {
	if (form.c_name.value == '') {
		window.alert('「登録名」を入れてください。');
		return false;		// 送信を中止
	}
	return true;	// 送信を実行
}
</script>
<script src="../scripts/valueconvertor.js"></script>
<script src="../scripts/jqKey.js"></script>
<script>
$(function() {
	$('table#form_table td').jqKey({
		Enter:true
	})
});
</script>
<form name="form0" method="POST" action="<?= $_SERVER['SCRIPT_NAME'] ?>?<?= $_SERVER['QUERY_STRING'] ?>" onSubmit="return formCheck(this)">
	<input type="hidden" name="user_id" value="<?= $_SESSION['current_id'] ?>">
	<input type="hidden" name="update_id" value="<?= $id ?>">
	<input type="hidden" name="login_id" value="<?= $_SESSION['login_id'] ?>">
	<input type="hidden" name="current_id" value="<?= $_SESSION['current_id'] ?>">
<table id="form_table">
<tr>
	<td>登録名</td>
	<td>
		<input class="text" type="text" name="c_name" size=40 value="<?= my_htmlspecialchars($rec['c_name']) ?>" style="ime-mode: active;">
		OneToOneメールの送信者プルダウン選択名
	</td>
</tr>
<tr>
	<td>SMTPホスト名</td>
	<td>
		<input class="text ascii" type="text" name="c_host" size=40 value="<?= my_htmlspecialchars($rec['c_host']) ?>" style="ime-mode: disabled;">
		例)  localhost, smtp.gmail.com
	</td>
</tr>
<tr>
	<td>SMTPポート番号</td>
	<td>
		<input class="text ascii" type="text" name="c_port" size=40 value="<?= my_htmlspecialchars($rec['c_port']) ?>" style="ime-mode: disabled;">
		例)  25, 465, 587
	</td>
</tr>
<tr>
	<td>SMTP認証</td>
	<td>
		<label><input type="radio" name="c_auth" value="True"<? if ($rec['c_auth'].'' == 'True') echo ' checked' ?>>True</label>
		<label><input type="radio" name="c_auth" value="False"<? if ($rec['c_auth'].'' <> 'True') echo ' checked' ?>>False</label>
	</td>
</tr>
<tr>
	<td>SMTPユーザー名</td>
	<td>
		<input class="text ascii" type="text" name="c_username" size=40 value="<?= my_htmlspecialchars($rec['c_username']) ?>" style="ime-mode: disabled;">
	</td>
</tr>
<tr>
	<td>SMTPパスワード</td>
	<td>
		※ 本システムを個人で利用されている場合を除いて、パスワードは、ここでは登録しないでください。<br>
		<input class="text ascii" type="text" name="c_password" size=40 value="<?= my_htmlspecialchars($rec['c_password']) ?>" style="ime-mode: disabled;">
		登録されたパスワードは、他のユーザーから閲覧されます。
	</td>
</tr>
<tr>
	<td>From</td>
	<td>
		<input class="text ascii" type="text" name="c_from" size=60 value="<?= my_htmlspecialchars($rec['c_from']) ?>" style="ime-mode: inactive;">
		例) TAROU &lt;xxx@xxx.com&gt; (日本語不可)
	</td>
</tr>
<tr>
	<td>Cc</td>
	<td>
		<input class="text ascii" type="text" name="c_cc" size=40 value="<?= my_htmlspecialchars($rec['c_cc']) ?>" style="ime-mode: disabled;">
		例) xxx@xxx.xxx.com
	</td>
</tr>
<tr>
	<td>Bcc</td>
	<td>
		<input class="text ascii" type="text" name="c_bcc" size=40 value="<?= my_htmlspecialchars($rec['c_bcc']) ?>" style="ime-mode: disabled;">
		例) xxx@xxx.xxx.com
	</td>
</tr>
<tr>
	<td>Reply-to</td>
	<td>
		<input class="text ascii" type="text" name="c_reply_to" size=40 value="<?= my_htmlspecialchars($rec['c_reply_to']) ?>" style="ime-mode: disabled;">
		例) xxx@xxx.xxx.com
	</td>
</tr>
<tr>
	<td>本文</td>
	<td>
		<div class="block_left">
		<p>「@@ TO @@」は、OneToOneメール送信時に、住所録の姓・名で置き換えられます。</p>
<?php
	if ($id == 0) {
		$body = "@@ TO @@ 様\n";
	} else {
		$body = my_htmlspecialchars($rec['c_body']);
	}
?>
		<textarea id="c_body" name="c_body" style="width:500px;" rows="10" wrap="soft" style="ime-mode: active;"><?= $body ?></textarea>
		</div>
	</td>
</tr>
</table>
<?php
	if ($id == 0) {
?>
	<input class="input_form_button" type="submit" name="登録" value="登録">
<?php
	} else {
?>
	<input class="input_form_button" type="submit" name="登録" value="修正">
	<input class="input_form_button" type="submit" name="削除" value="削除" onClick="return delete_check();" style="margin-left:20px;">
<?php
	}
?>
</form>
<script>
function delete_check() {
	if (window.confirm('このデータを削除しますか？')) {
		return true;
	} else {
		return false;
	}
}
</script>
<?
}
?>
