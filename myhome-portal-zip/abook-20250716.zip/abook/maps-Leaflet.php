<?php
//	Leaflet + OpenStreetMap 版
	require("__include-common.php");
	require("../account/__logincheck.php");
	if (!defined("MAPS_FIX_HEIGHT")) {
		define("MAPS_FIX_HEIGHT", 15);
	}
	if (!defined("MAPS_SIDE_BAR_WIDTH")) {
		define("MAPS_SIDE_BAR_WIDTH", "120px");
	}
	if (!defined("MAPS_SIDE_BAR_WIDTH_WORLD_HERITAGE")) {
		define("MAPS_SIDE_BAR_WIDTH_WORLD_HERITAGE", "160px");
	}
	if (!defined("MAPS_SIDE_BAR_HEIGHT")) {
		define("MAPS_SIDE_BAR_HEIGHT", "70%");
	}
	if (!defined("MAPS_LINEPATH_COLOR")) {
		define("MAPS_LINEPATH_COLOR", "#ff4500");
	}
	if (!defined("MAPS_LINEPATH_WEIGHT")) {
		define("MAPS_LINEPATH_WEIGHT", 3);
	}
?>
<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="utf-8">
<meta name="author" content="ok.2nd">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>MyHome 住所録 マップ（Leaflet + OpenStreetMap 版）</title>
<link rel="shortcut icon" href="favicon/earth.ico" type="image/ico">
<link rel="stylesheet" href="//unpkg.com/leaflet@1.7.1/dist/leaflet.css" integrity="sha512-xodZBNTC5n17Xt2atTPuE1HxjVMSvLVW9ocqUKLsCC5CXdbqCmblAshOMAS6/keqq/sMZMZ19scR4PsZChSR7A==" crossorigin=""/>
<script src="//unpkg.com/leaflet@1.7.1/dist/leaflet.js" integrity="sha512-XQoYMqMTK8LvdxXYG3nZ448hOEQiglfqkJs1NOQV44cWnUrBc8PkAOcXy20w0vlaXaVUearIOBhiXZ5V3ynxwA==" crossorigin=""></script>
<link rel="stylesheet" href="//use.fontawesome.com/releases/v5.6.3/css/all.css"/>
<link rel="stylesheet" href="css/easy-button.css"/>
<script src="js/easy-button.js"></script>
<link rel="stylesheet" href="css/leaflet.fullscreen.css"/>
<script src="js/Leaflet.fullscreen.min.js"></script>
<link rel="stylesheet" href="css/my-leaflet.css">
</head>
<body>
<div class="container"><div id="map"></div></div>
<?
	$con = my_mysqli_connect(_DB_SCHEMA);
	$sql = "select * from v_abook where id_abook in (".$_GET['id'].')';
	if ($_GET['so'] <> '') {
		$sql .= ' order by '.my_GET('so');
	}
	$rs = my_mysqli_query($sql);
	$row = mysqli_num_rows($rs);
	if ($row <> 0) {
		google_maps($rs, $row);
	} else {
		echo "<script type='text/javascript'>function initialize(){}</script>\n";
		error_msg('該当するデータがありません。');
	}
	mysqli_close($con);
//	exit();
function google_maps($rs, $row) {
	if (!defined("GETLATLNG_SLEEP_TIME")) {
		define("GETLATLNG_SLEEP_TIME", 200000);	// 0.2秒
	}
?>
<script>
var place = Array();
<?php
	$popstr = '';
	$address = '';
	$point_tbl = array();
	while ($rec=mysqli_fetch_array($rs)) {
		if (($address <> '' and $address <> $rec['c_address1'])) {
			$point_tbl[] = array($address, $popstr, $name, $icon);
			$popstr = '';
		} else {
			$popstr .= '<br>';
		}
		if ($_GET['opt'] == 'wh') {	// 世界遺産
			$name = quote_chg($rec['c_name1']);
			$name_left = explode('(', $rec['c_name1']);
			$popstr .= '≪<a href="https://www.google.com/search?q='.urlencode($name_left[0]).'" target="_blank" style="color:#000080;font-weight:bold;">'.quote_chg($name).'</a>≫<br>';
			$popstr .= quote_chg($rec['c_name2']).'<br>';
			$popstr .= 'Ref.'.quote_chg($rec['c_phone1']).'&nbsp;&nbsp;';
			$popstr .= '<a href="https://maps.google.com/maps?q=' . urlencode($rec['c_address1']);
			$popstr .= '" target="_blank">' . quote_chg($rec['c_address1']) . '</a><br>';
		//	$popstr .= '<a href="../tools/google-maps-earth-v3.php?addr=' . urlencode($rec['c_address1']);
		//	$popstr .= '" target="_blank">→ MAP V3</a><br>';
			$popstr .= '<p><a href="https://whc.unesco.org/en/list/'. my_htmlspecialchars($rec['c_phone1']) . '" target="_blank">UNESCO</a>&nbsp;&nbsp;';
		//	$popstr .= '<a href="http://translate.google.com/translate?prev=hp&hl=ja&js=y&u=http://whc.unesco.org/en/list/' . my_htmlspecialchars($rec['c_phone1']) . '" class="unesco_translate" target="_blank">→日本語</a>';
			$popstr .= '</p>';
			$popstr .= quote_chg($rec['c_memo']).'<br>';
			$popstr .= quote_chg($rec['c_address2']).'<br>';
		} elseif ($_GET['opt'] == 'hm') {	// 百名山
			if ($rec['c_name2'] == '百名山') {
				$kbn = '◎';
			} elseif ($rec['c_name2'] == '二百名山') {
				$kbn = '○';
			} elseif ($rec['c_name2'] == '三百名山') {
				$kbn = '△';
			}
			$name = quote_chg($kbn.$rec['c_name1']);
			$name_left = explode('(', $rec['c_name1']);
			$popstr .= '≪<a href="http://www.google.com/search?q='.urlencode($name_left[0]).'" target="_blank" style="color:#000080;font-weight:bold;">'.quote_chg($name_left[0]).'</a>≫ <span style="color:#000080;">'.quote_chg($rec['c_name2']).'</span><br>';
			$popstr .= '<a href="http://maps.google.com/maps?q=' . urlencode($rec['c_address1']);
			$popstr .= '" target="_blank">' . quote_chg($rec['c_address1']) . '</a><br>';
		//	$popstr .= '<a href="../tools/google-maps-earth-v3.php?addr=' . urlencode($rec['c_address1']);
		//	$popstr .= '" target="_blank">→ MAP V3</a><br>';
			$popstr .= quote_chg($rec['c_address2']).'<br>';
			$popstr .= '標高：'.quote_chg($rec['c_memo']).'m<br>';
		} elseif ($_GET['opt'] == 'sk') {	// 桜名木
			$name = quote_chg($rec['c_name1']);
			$name_left = explode('(', $rec['c_name1']);
			$popstr .= '≪<a href="http://www.google.com/search?q='.urlencode($name_left[0]).'" target="_blank" style="color:#000080;font-weight:bold;">'.quote_chg($name).'</a>≫ <span style="color:#000080;">'.quote_chg($rec['c_name2']).'</span><br>';
			$popstr .= '<a href="http://maps.google.com/maps?q=' . urlencode($rec['c_address1']);
			$popstr .= '" target="_blank">' . quote_chg($rec['c_address1']) . '</a><br>';
		//	$popstr .= '<a href="../tools/google-maps-earth-v3.php?addr=' . urlencode($rec['c_address1']);
		//	$popstr .= '" target="_blank">→ MAP V3</a><br>';
			$popstr .= quote_chg($rec['c_kenmei']).'<br>';
			$popstr .= quote_chg($rec['c_address2']).'<br>';
			if ($rec['c_phone1'] <> '') {
				$popstr .= '樹齢：'.quote_chg($rec['c_phone1']).'年<br>';
			}
			if ($rec['c_memo'] <> '') {
				$popstr .= '見頃：'.quote_chg($rec['c_memo']).'<br>';
			}
		} elseif ($_GET['opt'] == 'hs') {	// 日本百選
			$name = quote_chg($rec['c_name1']);
			$popstr .= '<a href="http://www.google.com/search?q='.urlencode($rec['c_memo']).'" target="_blank" style="color:#0080E0;">'.quote_chg($rec['c_memo']).'</a><br>';
			$popstr .= '<a href="http://www.google.com/search?q='.urlencode($rec['c_name1']).'" target="_blank" style="color:#000080;text-decoration:none;">≪<b>'.$name.'</b>≫</a><br>';
			$popstr .= '<a href="http://maps.google.com/maps?q=' . urlencode($rec['c_address1']);
			$popstr .= '" target="_blank">' . quote_chg($rec['c_address1']) . '</a><br>';
		//	$popstr .= '<a href="../tools/google-maps-earth-v3.php?addr=' . urlencode($rec['c_address1']);
		//	$popstr .= '" target="_blank">→ MAP V3</a><br>';
			$popstr .= quote_chg($rec['c_address2']).'<br>';
		} elseif ($_GET['opt'] == 'ts') {	// 鉄道駅
			$rail = quote_chg($rec['c_memo']);
			$rail_left = explode('(', $rec['c_memo']);
			$popstr .= '<a href="http://www.google.com/search?q='.urlencode($rail_left[0]).'" target="_blank" style="color:#080;">'.$rail.'</a><br>';
			$name = quote_chg($rec['c_name1']);
			$name_left = explode('(', $rec['c_name1']);
			$popstr .= '≪<a href="http://www.google.com/search?q='.urlencode($name_left[0]).'" target="_blank" style="color:#000080;font-weight:bold;">'.quote_chg($name).'</a>≫<br>';
			$popstr .= quote_chg($rec['c_kenmei']).'<br>';
			$popstr .= '<a href="http://maps.google.com/maps?q=' . urlencode($rec['c_address1']);
			$popstr .= '" target="_blank">' . quote_chg($rec['c_address1']) . '</a><br>';
		//	$popstr .= '<a href="../tools/google-maps-earth-v3.php?addr=' . urlencode($rec['c_address1']);
		//	$popstr .= '" target="_blank">→ MAP V3</a><br>';
			$popstr .= quote_chg($rec['c_address2']).'<br>';
		} else {
			$name = quote_chg($rec['c_name1']).' '.quote_chg($rec['c_name2']);
			$popstr .= '<font color=#000080>≪<b>'.$name.'</b>≫</font><br>';
			$popstr .= quote_chg($rec['c_kenmei']).'<br>';
			$popstr .= '<a href="http://maps.google.com/maps?q=' . urlencode($rec['c_address1']);
			$popstr .= '" target="_blank">' . quote_chg($rec['c_address1']) . '</a><br>';
			if ($rec['c_address2'] <> '') {
				$popstr .= quote_chg($rec['c_address2']).'<br>';
			}
		//	$popstr .= '<a href="../tools/google-maps-earth-v3.php?addr=' . urlencode($rec['c_address1']);
		//	$popstr .= '" target="_blank">→ MAP V3</a><br>';
			if ($rec['c_memo'] <> '') {
				$popstr .= quote_chg($rec['c_memo']).'<br>';
			}
		}
		if ($rec['c_markericon'] <> '') {
			$icon = $rec['c_markericon'];
		} else {
			$icon = $rec['c_categoryIcon'];
		}
		$address = $rec['c_address1'];
	}
	$point_tbl[] = array($address, $popstr, $name, $icon);
	$adr_cnt = 0;
	foreach ($point_tbl as $point) {
		$p_ary = explode(',', $point[0]);
		if (count($p_ary) == 2 && is_numeric($p_ary[0]) && is_numeric($p_ary[1])) {
?>
place[<?= $adr_cnt ?>] = Array();
place[<?= $adr_cnt ?>]["name"] = '<?= $point[2] ?>';
place[<?= $adr_cnt ?>]["lat"] = <?= $p_ary[0] ?>;
place[<?= $adr_cnt ?>]["lng"] = <?= $p_ary[1] ?>;
place[<?= $adr_cnt ?>]["popstr"] = '<?= $point[1] ?>';
<?php
		} else {
			$status = getLatLng($point[0], $lat, $lng);
?>
place[<?= $adr_cnt ?>] = Array();
place[<?= $adr_cnt ?>]["name"] = '<?= $point[2] ?>';
place[<?= $adr_cnt ?>]["lat"] = <?= $lat ?>;
place[<?= $adr_cnt ?>]["lng"] = <?= $lng ?>;
place[<?= $adr_cnt ?>]["popstr"] = '<?= $point[1] ?>';
<?php
		//	usleep(GETLATLNG_SLEEP_TIME);
		}
		++$adr_cnt;
	}
}
?>
</script>
<script src="js/my-leaflet-1.3.js"></script>
</body>
</html>
