<?php
	require("__include-common.php");
	require("../account/__logincheck.php");
	require('__define-pdf.php');
	if (!defined("MAILTO_CONCATENATE_CHR")) {
		define("MAILTO_CONCATENATE_CHR", ",");		// mailto:で複数メールアドレスの結合文字
								// Thunderbird："," Outlook用：";"
	}
	setcookie("abook_print_sender", $_POST['差出人'], time() + LOGIN_COOKIE_EXPIRE, MY_SESSION_PATH);
	setcookie("abook_print_sender_name", $_POST['差出人名'], time() + LOGIN_COOKIE_EXPIRE, MY_SESSION_PATH);
	setcookie("abook_print_sender_renmei", $_POST['連名'], time() + LOGIN_COOKIE_EXPIRE, MY_SESSION_PATH);
	$chks = $_POST['check'];
	if (!$chks) {
		error_exit('1件以上、選択してください。', True, False);
	}
	$chk_id = '';
	foreach($chks as $chk){
		if ($chk_id <> '') $chk_id .= ',';
		$chk_id .= $chk;
	}
	if (isset($_POST['Maps'])) {
		if ($_POST['sortOrder'] <> '') {
			$sortOrder = urlencode(form_str_adjust($_POST['sortOrder']));
		}
	//	header('Location: maps-abook.php?id='.$chk_id.'&so='.$sortOrder.'&opt='.$_POST['option']);
		header('Location: maps-Leaflet.php?id='.$chk_id.'&so='.$sortOrder.'&opt='.$_POST['option']);
	}
	if (isset($_POST['MapsV3'])) {
		if ($_POST['sortOrder'] <> '') {
			$sortOrder = urlencode(form_str_adjust($_POST['sortOrder']));
		}
		header('Location: maps-abook-v3.php?id='.$chk_id.'&so='.$sortOrder.'&opt='.$_POST['option']);
	}
	$con = my_mysqli_connect(_DB_SCHEMA);
	$sql = "select * from v_abook where id_abook in (".$chk_id.')';
	if ($_POST['sortOrder'] <> '') {
		$sql .= ' order by '.$_POST['sortOrder'];
	}
	$rs = my_mysqli_query($sql);
	$row = mysqli_num_rows($rs);
	if ($row == 0) {
		error_exit('該当するレコードがみつかりません。', True);
	}
	if (isset($_POST['PDF'])) {
		pdf_cretate_all($rs, PDF_CREATE_FILE, PDF_SOURCE_FILE);
	} elseif (isset($_POST['Email'])) {
		email_all($rs);
	}
	mysqli_close($con);
function email_all($rs) {
	$mailto = '';
	$mailto_href = '';
	while ($rec=mysqli_fetch_array($rs)) {
		if ($rec['c_email'] <> '') {
			if ($mailto <> '') $mailto .= ',';
			if ($mailto_href <> '') $mailto_href .= ',';
			$mailto .= $rec['c_email']."\t".$rec['c_name1'].' '.$rec['c_name2'];
			$mailto_href .= $rec['c_name1'].' '.$rec['c_name2'].' <'.$rec['c_email'].'>';
		}
	}
?>
<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="utf-8">
<title>OneToOneメール</title>
<link rel="stylesheet" href="<?= _STYLE_SHEET_FOLDER_COMMON ?>/common.css?20131130">
<link rel="stylesheet" href="<?= _STYLE_SHEET_BUTTON ?>">
<script src="../scripts/jquery.js"></script>
<script src="../scripts/valueconvertor.js"></script>
<script>
function formCheck(form) {
	if (form.subject.value == '') {
		window.alert('「件名」を入れてください。');
		return false;		// 送信を中止
	}
	return true;	// 送信を実行
}
</script>
</head>
<body>
<div class="input_form">
<h3>OneToOneメール<a class="a_cancel_back" href='list.php?<?=$_SERVER['QUERY_STRING'] ?>'>戻る</a></h3>
<form method="POST" action="mail-one2one.php" onSubmit="return formCheck(this)">
	<table>
	<tr>
		<td>送信者</td>
		<td nowrap>
<?php
	$sqlsel = "select * from m_mailfrom where id_account = '".$_SESSION['current_id']."'";
	$sqlsel = $sqlsel . " and c_delete = 0";
	$sqlsel = $sqlsel . " order by c_displayOrder";
	$rs_sel = my_mysqli_query($sqlsel);
?>
<script>
var mailfrom = new Array();
<?php
	$cnt = 0;
	$mailfrom = array();
	while ($rec_sel=mysqli_fetch_array($rs_sel)) {
		$mailfrom[] = array('id' => $rec_sel['id_mailfrom'], 'name' => $rec_sel['c_name']);
?>
		mailfrom[<?= $cnt ?>] = new Object();
		mailfrom[<?= $cnt ?>]['name'] = '<?= str_replace("'","’",$rec_sel['c_name']) ?>';
		mailfrom[<?= $cnt ?>]['username'] = '<?= str_replace("'","’",$rec_sel['c_username']) ?>';
		mailfrom[<?= $cnt ?>]['password'] = '<?= str_replace("'","’",$rec_sel['c_password']) ?>';
		mailfrom[<?= $cnt ?>]['host'] = '<?= str_replace("'","’",$rec_sel['c_host']) ?>';
		mailfrom[<?= $cnt ?>]['port'] = '<?= str_replace("'","’",$rec_sel['c_port']) ?>';
		mailfrom[<?= $cnt ?>]['auth'] = '<?= str_replace("'","’",$rec_sel['c_auth']) ?>';
		mailfrom[<?= $cnt ?>]['from'] = '<?= str_replace("'","’",$rec_sel['c_from']) ?>';
		mailfrom[<?= $cnt ?>]['cc'] = '<?= str_replace("'","’",$rec_sel['c_cc']) ?>';
		mailfrom[<?= $cnt ?>]['bcc'] = '<?= str_replace("'","’",$rec_sel['c_bcc']) ?>';
		mailfrom[<?= $cnt ?>]['reply_to'] = '<?= str_replace("'","’",$rec_sel['c_reply_to']) ?>';
		mailfrom[<?= $cnt ?>]['body'] = '<?= str_replace("\n","￥ｎ",str_replace("\r",'',str_replace("'","’@’",$rec_sel['c_body']))) ?>';
<?php
		$cnt++;
	}
?>
function SelectionMailfrom() {
	setMailfrom(parseInt($("#id_mailfrom").val()));
}
function setMailfrom(ix) {
	$("#c_name").val(mailfrom[ix]['name'].replace(/’/g,"'"));
	$("#c_username").val(mailfrom[ix]['username'].replace(/’/g,"'"));
	$("#c_password").val(mailfrom[ix]['password'].replace(/’/g,"'"));
	$("#c_host").text(mailfrom[ix]['host'].replace(/’/g,"'"));
	$("#c_host_h").val(mailfrom[ix]['host'].replace(/’/g,"'"));
	$("#c_port").text(mailfrom[ix]['port'].replace(/’/g,"'"));
	$("#c_port_h").val(mailfrom[ix]['port'].replace(/’/g,"'"));
	$("#c_auth").text(mailfrom[ix]['auth'].replace(/’/g,"'"));
	$("#c_auth_h").val(mailfrom[ix]['auth'].replace(/’/g,"'"));
	$("#c_from").val(mailfrom[ix]['from'].replace(/’/g,"'"));
	$("#c_cc").val(mailfrom[ix]['cc'].replace(/’/g,"'"));
	$("#c_bcc").val(mailfrom[ix]['bcc'].replace(/’/g,"'"));
	$("#c_reply_to").val(mailfrom[ix]['reply_to'].replace(/’/g,"'"));
	$("#c_body").val(mailfrom[ix]['body'].replace(/’@’/g,"'").replace(/￥ｎ/g,'\n'));
}
$(function(){
	setMailfrom(0);
});
</script>
		<select id="id_mailfrom" name="id_mailfrom" onChange="SelectionMailfrom()">
<?php
		$ix = 0;
		foreach ($mailfrom as $mfrom) {
?>
		<option value="<?= $ix ?>"><?= my_htmlspecialchars($mfrom['name']) ?>
<?php
			$ix++;
		}
?>
		</select>
		<span>送信者を変更すると、本文もリセットされます。</span>
		</td>
	</tr>
	<tr>
		<td>ホスト名</td>
		<td style="padding:5px;">
		<span id="c_host" style="font-weight:bold;"></span>
		<span style="margin-left:10px;">ポート番号：</span><span id="c_port" style="font-weight:bold;"></span>
		<span style="margin-left:10px;">認証：</span><span id="c_auth" style="font-weight:bold;"></span>
		<input type="hidden" id="c_host_h" name="host" value="">
		<input type="hidden" id="c_port_h" name="port" value="">
		<input type="hidden" id="c_auth_h" name="auth" value="">
		</td>
	</tr>
	<tr>
		<td>ユーザー名</td>
		<td>
			<input class="text ascii" type="text" id="c_username" name="username" size=40 value="" style="ime-mode: disabled;">
		</td>
	</tr>
	<tr>
		<td>パスワード</td>
		<td>
			<input class="text ascii" type="text" id="c_password" name="password" size=40 value="" style="ime-mode: disabled;">
		</td>
	</tr>
	<tr>
		<td>From</td>
		<td>
			<input class="text ascii" type="text" id="c_from" name="from" size=60 value="" style="ime-mode: inactive;">
			日本語不可
		</td>
	</tr>
	<tr>
		<td>Cc</td>
		<td>
			<input class="text ascii" type="text" id="c_cc" name="cc" size=40 value="" style="ime-mode: disabled;">
		</td>
	</tr>
	<tr>
		<td>Bcc</td>
		<td>
			<input class="text ascii" type="text" id="c_bcc" name="bcc" size=40 value="" style="ime-mode: disabled;">
		</td>
	</tr>
	<tr>
		<td>Reply-to</td>
		<td>
			<input class="text ascii" type="text" id="c_reply_to" name="reply_to" size=40 value="" style="ime-mode: disabled;">
		</td>
	</tr>
	<tr>
		<td>件名</td>
		<td><input class="text" type="text" name="subject" value="" size=80 style="ime-mode: active;"></td>
	</tr>
	<tr>
		<td>本文</td>
		<td><textarea  id="c_body" name="body" name="text" style="width:560px;" rows="10" style="ime-mode: active;"></textarea></td>
	</tr>
	</table>
	<input class="input_form_button" type="submit" name="sendmail" value="メール送信">
	<input type="hidden" name="mailto" value="<?= my_htmlspecialchars($mailto) ?>">
</form>
</div>
<table style="margin:0 0 40px 20px;">
<tr>
<td>メール送信先：</td>
<td>
<a href="mailto:<?= my_htmlspecialchars(str_replace(',', MAILTO_CONCATENATE_CHR, $mailto_href)) ?>"><?= str_replace(',', '<br>', my_htmlspecialchars($mailto_href)) ?></a></p>
</td>
</tr>
</table>
</body>
</html>
<?php
}
?>
<?php
function pdf_cretate_all($rs, $pdf_out_file, $pdf_src_file) {
	$pdf_foder = ATTACH_FILE_FOLDER_abook.$_SESSION['current_id'];
	if (!myfile_is_dir($pdf_foder)) {
		myfile_mkdir($pdf_foder, '0777', true);
	}
	$pdf_out_path = $pdf_foder.'/'.$pdf_out_file;
	$pdf = new my_class_pdf("P", "mm", "Postcard", array(MINCHO, GOTHIC));
	while ($rec=mysqli_fetch_array($rs)) {
		pdf_cretate($pdf, $pdf_src_file, $rec['c_name1'], $rec['c_name2'], $rec['c_zip1'], $rec['c_zip2'], $rec['c_address1'], $rec['c_address2'], $rec['c_renmei']);
	}
	$pdf->output($pdf_out_path, "real", 'F');
?>
<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="utf-8">
<title>宛名書き葉書(PDF文書)</title>
<style>
body {
	margin: 10px;
}
a { color: blue; }
a.a_cancel_back {
	font-size: 84%;
	color: #ff8000;
}
</style>
</head>
<body>
<p><a href="<?= $pdf_out_path ?>">宛名書き葉書(PDF文書)</a></p>
</body>
</html>
<?php
}
?>
<?php
function pdf_cretate($pdf, $pdf_src_file, $name1, $name2, $zip1, $zip2, $addr1, $addr2, $renmei) {
	$pdf->add_page(HAGAKI_FONT, $pdf_src_file);

	// 水平 $x, $y, $size, $text, $max_width=0, $align="left", $space=0, $style="", $family=""
	$pdf->text_horizontal(HAGAKI_ZIP_X, HAGAKI_ZIP_Y, HAGAKI_ZIP_SIZE, $zip1, 0, "left", 4.3, '', GOTHIC);
	$pdf->text_horizontal(HAGAKI_ZIP_X+21.5, HAGAKI_ZIP_Y, HAGAKI_ZIP_SIZE, $zip2, 0, "left", 4.3, '', GOTHIC);

	// 垂直 $x, $y, $size, $text, $max_height=0, $valign="top", $space=0, $style="", $family=""
	list($size) = $pdf->text_vertical(HAGAKI_ADDR_X, HAGAKI_ADDR_Y, HAGAKI_ADDR_SIZE, sjis($addr1), 95);
	if ($addr2 <> '') {
		$pdf->text_vertical(HAGAKI_ADDR_X-6, HAGAKI_ADDR_Y+20, $size, sjis($addr2), 80, "top");
	}
	if ($renmei <> '') {
		$name_x = HAGAKI_NAME_X+4;
	} else {
		$name_x = HAGAKI_NAME_X;
	}
	list($size, $y) = $pdf->text_vertical($name_x, HAGAKI_NAME_Y, HAGAKI_NAME_SIZE, sjis($name1.' '.$name2.'様'), 100, "middle", 2, "B");
	if ($renmei <> '') {
		$pdf->text_vertical($name_x-12, HAGAKI_RENMEI_Y, $size, sjis($renmei.'様'), 50, "top", 2, "B");
	}
	if ($_POST['差出人'] == '印刷') {
		$con = my_mysqli_connect(_DB_ACCOUNT_SCHEMA);
		$sql = "select * from m_account where id_account = " . $_SESSION['current_id'];
		$rs = my_mysqli_query($sql);
		$rec = mysqli_fetch_array($rs);
		$home_address2 = $rec['c_home_address2'];
		if ($home_address2 <> '') {
			$address_x = HAGAKI_S_ADDR_X+2;
		} else {
			$address_x = HAGAKI_S_ADDR_X;
		}
		if ($rec['c_home_address'] <> '') {
			list($size) = $pdf->text_vertical($address_x, HAGAKI_S_ADDR_Y, HAGAKI_S_ADDR_SIZE, sjis($rec['c_home_address']), 76);
		}
		if ($home_address2 <> '') {
			$pdf->text_vertical($address_x-4, HAGAKI_S_ADDR_Y+10, $size, sjis($rec['c_home_address2']), 56);
		}
		if ($_POST['差出人名'] <> '') {
			$pdf->text_vertical(HAGAKI_S_NAME_X, HAGAKI_S_NAME_Y, HAGAKI_S_NAME_SIZE, sjis($_POST['差出人名']), 60);
		} elseif ($rec['c_fullname'] <> '') {
			$pdf->text_vertical(HAGAKI_S_NAME_X, HAGAKI_S_NAME_Y, HAGAKI_S_NAME_SIZE, sjis($rec['c_fullname']), 60);
		}
		if ($_POST['連名'] <> '') {
			$pdf->text_vertical(HAGAKI_S_RENMEI_X, HAGAKI_S_RENMEI_Y, HAGAKI_S_RENMEI_SIZE, sjis($_POST['連名']), 60);
		}
		if ($rec['c_zip1'] <> '') {
			$pdf->text_horizontal(HAGAKI_S_ZIP_X, HAGAKI_S_ZIP_Y, HAGAKI_S_ZIP_SIZE, $rec['c_zip1'], 0, "left", 2.2, '', GOTHIC);
			$pdf->text_horizontal(HAGAKI_S_ZIP_X+13, HAGAKI_S_ZIP_Y, HAGAKI_S_ZIP_SIZE, $rec['c_zip2'], 0, "left", 2.2, '', GOTHIC);
		}
	}
}
function sjis($str) {
	return mb_convert_encoding($str, 'SJIS-win', 'UTF-8');
}
?>
