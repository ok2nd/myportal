<?php
	require("__include-common.php");
	require("../account/__logincheck.php");
	$updateD = date("Y/m/d H:i:s");
	$con = my_mysqli_connect(_DB_SCHEMA);
	$sql = "update m_abook";
	$sql .= " set c_check".$_GET['no']." = ".$_GET['chk'];
	$sql .= ", c_updatetime = '" . $updateD . "'";
	$sql .= " where id_abook = " . $_GET['id'];
	mysqli_query($con, $sql);
	mysqli_close($con);
?>
