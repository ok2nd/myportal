<?php
define("_DEFINE_ABOOK_PDF_MY", "../../_myhome_myset/__define_abook_pdf_my.php");
if (file_exists(_DEFINE_ABOOK_PDF_MY)) {
	require(_DEFINE_ABOOK_PDF_MY);
} else {
	define('MY_FPDF_PATH', 'fpdf');
	define('MY_ENCODING', 'SJIS');
	define('MM_PER_POINT', '0.5');
	define('PDF_PATH', '../pdf/');
	define('PDF_SOURCE_FILE', 'hagaki-form.pdf');
	define('PDF_CREATE_FILE', 'hagaki-atena.pdf');
	define("ATTACH_FILE_FOLDER_abook", "../_attach/abook/");

	require(PDF_PATH.MY_FPDF_PATH.'/pdf-inc.php');

	// ＊＊＊＊＊ 葉書宛名 フォント 指定 ＊＊＊＊＊
	define('HAGAKI_FONT', GOTHIC);		// GOTHIC, MINCHO

	// ＊＊＊＊＊ 葉書宛名 位置 フォントサイズ 指定 ＊＊＊＊＊
	// 宛名 〒番号
	define('HAGAKI_ZIP_X', 46.5);
	define('HAGAKI_ZIP_Y', 15.0);
	define('HAGAKI_ZIP_SIZE', 16);
	// 宛名 住所
	define('HAGAKI_ADDR_X', 90);
	define('HAGAKI_ADDR_Y', 26);
	define('HAGAKI_ADDR_SIZE', 12);
	// 宛名 名前
	define('HAGAKI_NAME_X', 64);	//連名なし
	define('HAGAKI_NAME_Y', 23);
	define('HAGAKI_NAME_SIZE', 24);
	// 宛名 連名
	define('HAGAKI_RENMEI_Y', 67);
	// 差出人 住所
	define('HAGAKI_S_ADDR_X', 28);	//住所2行目なし
	define('HAGAKI_S_ADDR_Y', 50);
	define('HAGAKI_S_ADDR_SIZE', 9);
	// 差出人 名前
	define('HAGAKI_S_NAME_X', 22);
	define('HAGAKI_S_NAME_Y', 80);
	define('HAGAKI_S_NAME_SIZE', 16);
	// 差出人 連名
	define('HAGAKI_S_RENMEI_X', 16);
	define('HAGAKI_S_RENMEI_Y', 95);
	define('HAGAKI_S_RENMEI_SIZE', 16);
	// 差出人 〒番号
	define('HAGAKI_S_ZIP_X', 4.0);
	define('HAGAKI_S_ZIP_Y', 133.0);
	define('HAGAKI_S_ZIP_SIZE', 12);
}
?>
