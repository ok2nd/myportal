<?php
	require("__include-common.php");
	require("../account/__logincheck.php");
	if ($_POST) {
		check_post_account($_POST['login_id'], $_POST['current_id']);
		post_done_proc();
	} else {
		html_header(HTML_TITLE, '', '', ' onload="document.form0.c_name1.focus()"');
		page_header();
		input_form();
		page_footer();
		html_footer();
	}
	exit();
?>
<?php
function post_done_proc() {
	if ($_POST['user_id']."" <> "") {
		$user_id = $_POST['user_id'];
	} else {
		error_exit("不正アクセス：ユーザーIDなし", True);
	}
	if (check_permit_id($_SESSION['login_id'], $user_id) != "w") {
		error_exit("不正アクセス：書き込み権限がありません。", True);
	}
	if ($_POST['update_id']) {
		if (!is_numeric($_POST['update_id'])) {
			error_exit("不正アクセス", True);
		}
		$id = intval($_POST['update_id']);
	} else {
		$id = 0;
	}
	if (isset($_POST['削除'])) {
		//	if ($_POST['削除する'] <> "YES") {
		//		error_exit("削除するにチェックしてください。", True);
		//	}
	} elseif ($_POST['c_name1'] == "") {
		error_exit("姓なし", True);
	}
	$con = my_mysqli_connect(_DB_SCHEMA);
	if ($id == 0) {
		$sql = "insert into m_abook";
		$sql .= " (id_account";
		$sql .= ", id_category";
		if ($_SESSION['current_id'] == $_SESSION['login_id']) {
			$sql .= ", c_privacy";
		}
		$sql .= ", c_name1";
		$sql .= ", c_name2";
		$sql .= ", c_yomi1";
		$sql .= ", c_address1";
		$sql .= ", c_address2";
		$sql .= ", c_phone1";
		$sql .= ", c_memo";
		if ($_GET['cat'] <> SEKAI_ISAN_CATEGORY_ID) {	//世界遺産
			$sql .= ", c_yomi2";
			$sql .= ", c_renmei";
			$sql .= ", c_zip1";
			$sql .= ", c_zip2";
			$sql .= ", c_kenid";
			$sql .= ", c_phone2";
			$sql .= ", c_email";
			$sql .= ", c_markericon";
		}
		$sql .= ", c_registtime";
		$sql .= ", c_updatetime";
		$sql .= ") values ";
		$sql .= "( '".$user_id."'";
		$sql .= ", '" . $_POST['id_category'] . "'";
		if ($_SESSION['current_id'] == $_SESSION['login_id']) {
			if ($_POST['c_privacy'] == '444') {
				$sql .= ", 444";
			} else {
				$sql .= ", 0";
			}
		}
		$sql .= ", '".post_to_mysql("c_name1")."'";
		$sql .= ", '".post_to_mysql("c_name2")."'";
		$sql .= ", '".post_to_mysql("c_yomi1")."'";
		$sql .= ", '".post_to_mysql("c_address1")."'";
		$sql .= ", '".post_to_mysql("c_address2")."'";
		$sql .= ", '".post_to_mysql("c_phone1")."'";
		$sql .= ", '".post_to_mysql("c_memo")."'";
		if ($_GET['cat'] <> SEKAI_ISAN_CATEGORY_ID) {	//世界遺産
			$sql .= ", '".post_to_mysql("c_yomi2")."'";
			$sql .= ", '".post_to_mysql("c_renmei")."'";
			$sql .= ", '".post_to_mysql("c_zip1")."'";
			$sql .= ", '".post_to_mysql("c_zip2")."'";
			$sql .= ", '".post_to_mysql("c_kenid")."'";
			$sql .= ", '".post_to_mysql("c_phone2")."'";
			$sql .= ", '".post_to_mysql("c_email")."'";
			$sql .= ", '".post_to_mysql("c_markericon")."'";
		}
		$sql .= ", '". date("Y/m/d H:i:s") . "'";
		$sql .= ", '". date("Y/m/d H:i:s") . "'";
		$sql .= ")";
		$ret = my_mysqli_query($sql, "登録できませんでした。");
	} elseif ($_POST['削除'] <> "") {
		$sql = "update m_abook set";
		$sql .= " c_delete = 999";
		$sql .= ", c_updatetime = '". date("Y/m/d H:i:s") . "'";
		$sql .= " where id_abook = ".$id;
		$sql .= " and id_account = ".$user_id;
		$ret = my_mysqli_query($sql, "削除できませんでした。");
	} else {
		$sql = "update m_abook set";
		$sql .= " id_category = '".$_POST['id_category']."'";
		if ($_SESSION['current_id'] == $_SESSION['login_id']) {
			if ($_POST['c_privacy'] == '444') {
				$sql .= ", c_privacy = 444";
			} else {
				$sql .= ", c_privacy = 0";
			}
		}
		$sql .= ", c_name1 = '".post_to_mysql("c_name1")."'";
		$sql .= ", c_name2 = '".post_to_mysql("c_name2")."'";
		$sql .= ", c_yomi1 = '".post_to_mysql("c_yomi1")."'";
		$sql .= ", c_address1 = '".post_to_mysql("c_address1")."'";
		$sql .= ", c_address2 = '".post_to_mysql("c_address2")."'";
		$sql .= ", c_phone1 = '".post_to_mysql("c_phone1")."'";
		$sql .= ", c_memo = '".post_to_mysql("c_memo")."'";
		if ($_GET['cat'] <> SEKAI_ISAN_CATEGORY_ID) {	//世界遺産
			$sql .= ", c_yomi2 = '".post_to_mysql("c_yomi2")."'";
			$sql .= ", c_renmei = '".post_to_mysql("c_renmei")."'";
			$sql .= ", c_zip1 = '".post_to_mysql("c_zip1")."'";
			$sql .= ", c_zip2 = '".post_to_mysql("c_zip2")."'";
			$sql .= ", c_kenid = '".post_to_mysql("c_kenid")."'";
			$sql .= ", c_phone2 = '".post_to_mysql("c_phone2")."'";
			$sql .= ", c_email = '".post_to_mysql("c_email")."'";
			$sql .= ", c_markericon = '".post_to_mysql("c_markericon")."'";
		}
		$sql .= ", c_updatetime = '". date("Y/m/d H:i:s") . "'";
		$sql .= " where id_abook = ".$id;
		$sql .= " and id_account = ".$user_id;
		$ret = my_mysqli_query($sql, "更新できませんでした。");
	}
	mysqli_close($con);
	redirect("list.php?".$_SERVER['QUERY_STRING']);
}
function input_form() {
	if (check_permit_id($_SESSION['login_id'], $_SESSION['current_id']) != "w") {
		error_exit("書き込み権限がありません。", True);
	}
	if ($_GET['id'] <> "") {
		$id = $_GET['id'];
		if ($_GET['page'] <> "") {
			$page = $_GET['page'];
		}
	} else {
		$id = 0;
	}
	$con = my_mysqli_connect(_DB_SCHEMA);
	$sql = "select * from v_abook where id_abook = ".$id." and c_delete = 0";
	$sql .= " and id_account = ".$_SESSION['current_id'];
	$rs = my_mysqli_query($sql);
	$rec = mysqli_fetch_array($rs);
?>
<div class="input_form">
<h3><?= $_SESSION['current_handle'] ?><a class="a_cancel_back" href='list.php?<?=$_SERVER['QUERY_STRING'] ?>'>戻る</a></h3>
<script>
function formCheck(form) {
	if (form.c_name1.value == '') {
		window.alert('姓名の「姓」を入れてください。');
		return false;		// 送信を中止
	}
	return true;	// 送信を実行
}
</script>
<script src="../scripts/valueconvertor.js"></script>
<script src="../scripts/jqKey.js"></script>
<script>
$(function() {
	$('table#form_table td').jqKey({
		Enter:true
	})
});
</script>
<form name="form0" method="POST" action="<?= $_SERVER['SCRIPT_NAME'] ?>?<?= $_SERVER['QUERY_STRING'] ?>" onSubmit="return formCheck(this)">
	<input type="hidden" name="user_id" value="<?= $_SESSION['current_id'] ?>">
	<input type="hidden" name="update_id" value="<?= $id ?>">
	<input type="hidden" name="login_id" value="<?= $_SESSION['login_id'] ?>">
	<input type="hidden" name="current_id" value="<?= $_SESSION['current_id'] ?>">
<table id="form_table">
<tr>
	<td nowrap>カテゴリ</td>
	<td nowrap>
<?php
	$sqlsel = "select * from m_category where id_account = '".$_SESSION['current_id']."'";
	$sqlsel = $sqlsel . " and c_delete = 0";
	$sqlsel = $sqlsel . " order by c_categoryDisplayOrder";
	$rs_sel = my_mysqli_query($sqlsel);
?>
		<select name="id_category">
<?php
		if ($id == 0) {
			$category = (int)$_GET['cat'];
		} else {
			$category = $rec['id_category'];
		}
		while ($rec_sel=mysqli_fetch_array($rs_sel)) {
?>
		<option value="<?= $rec_sel['id_category'] ?>"<?= $rec_sel['id_category'] == $category ? ' selected' : '' ?>><?= my_htmlspecialchars($rec_sel['c_categoryName']) ?>
<?php
		}
?>
		</select>
	<?php if ($_SESSION['current_id'] == $_SESSION['login_id']) { ?>
		&nbsp;&nbsp;<label><input type="checkbox" name="c_privacy" value="444" <?= $rec['c_privacy'] == 444 ? ' checked' : '' ?>>非公開</label>
	<?php } ?>
	</td>
</tr>
<?php	if ($_GET['cat'] == SEKAI_ISAN_CATEGORY_ID) {	//世界遺産	?>
<tr>
	<td>Ref番号</td>
	<td><input class="text ascii" type="text" name="c_phone1" size=20 value="<?= my_htmlspecialchars($rec['c_phone1']) ?>" style="ime-mode: inactive;">
	</td>
</tr>
<tr>
	<td>遺産名</td>
	<td><input class="text ascii" type="text" name="c_name2" size=100 value="<?= my_htmlspecialchars($rec['c_name2']) ?>" style="ime-mode: active;">
	</td>
</tr>
<tr>
	<td>日本語</td>
	<td><input class="text fullwidth-kana" type="text" name="c_name1" size=100 value="<?= my_htmlspecialchars($rec['c_name1']) ?>" style="ime-mode: active;">
	</td>
</tr>
<tr>
	<td>よみ</td>
	<td><input class="text hiragana" type="text" name="c_yomi1" size=100 value="<?= my_htmlspecialchars($rec['c_yomi1']) ?>" style="ime-mode: active;">
	</td>
</tr>
<tr>
	<td>国名</td>
	<td><input class="text ascii" type="text" name="c_address2" size=80 value="<?= my_htmlspecialchars($rec['c_address2']) ?>" style="ime-mode: active;">
	</td>
	</tr>
</tr>
<tr>
	<td>国名・日本語</td>
	<td><input class="text fullwidth-kana" type="text" name="c_memo" size=80 value="<?= my_htmlspecialchars($rec['c_memo']) ?>" style="ime-mode: active;">
	</td>
	</tr>
</tr>
<tr>
	<td>緯度・経度</td>
	<td><input class="text ascii" type="text" id="c_address1" name="c_address1" size=40 value="<?= my_htmlspecialchars($rec['c_address1']) ?>" style="ime-mode: inactive;">
	</td>
	</tr>
</tr>
<?php	} else {	?>

<tr>
	<td>姓名</td>
	<td>
		<input class="text fullwidth-kana" type="text" name="c_name1" size=40 value="<?= my_htmlspecialchars($rec['c_name1']) ?>" style="ime-mode: active;">
		<input class="text fullwidth-kana" type="text" name="c_name2" size=40 value="<?= my_htmlspecialchars($rec['c_name2']) ?>" style="ime-mode: active;">
	</td>
</tr>
<tr>
	<td>よみ</td>
	<td>
		<input class="text hiragana" type="text" name="c_yomi1" size=40 value="<?= my_htmlspecialchars($rec['c_yomi1']) ?>" style="ime-mode: active;">
		<input class="text hiragana" type="text" name="c_yomi2" size=40 value="<?= my_htmlspecialchars($rec['c_yomi2']) ?>" style="ime-mode: active;">
	</td>
</tr>
<tr>
	<td>連名</td>
	<td>
		<input class="text fullwidth-kana" type="text" name="c_renmei" size=40 value="<?= my_htmlspecialchars($rec['c_renmei']) ?>" style="ime-mode: active;">
	</td>
</tr>
<tr>
	<td>電話</td>
	<td>
		固定：<input class="text ascii" type="text" name="c_phone1" size=20 value="<?= my_htmlspecialchars($rec['c_phone1']) ?>" style="ime-mode: inactive;">
		携帯：<input class="text ascii" type="text" name="c_phone2" size=20 value="<?= my_htmlspecialchars($rec['c_phone2']) ?>" style="ime-mode: inactive;">
	</td>
</tr>
<tr>
	<td>Email</td>
	<td>
		<input class="text ascii" type="text" name="c_email" size=70 value="<?= my_htmlspecialchars($rec['c_email']) ?>" style="ime-mode: inactive;">
	</td>
</tr>
<tr>
	<td>メモ</td>
	<td>
		<textarea id="c_body" name="c_memo" style="width:450px;" rows="10" wrap="soft"><?= my_htmlspecialchars($rec['c_memo']) ?></textarea>

<!--
		<input class="text fullwidth-kana" type="text" name="c_memo" size=70 value="<?= my_htmlspecialchars($rec['c_memo']) ?>" style="ime-mode: active;">
-->
	</td>
	</tr>
</tr>
<tr>
	<td>住所</td>
	<td>
<script src='../scripts/hokaccha/zip2address.js'></script>
<script>
var todofuken = new Array();
<?php
	$sqlsel = "select * from r_kenmei";
	$rs_sel = my_mysqli_query($sqlsel);
	$ix = 0;
	while ($rec_sel=mysqli_fetch_array($rs_sel)) {
?>
		todofuken[<?= $ix ?>] = ['<?= $rec_sel['c_kenid'] ?>', '<?=  $rec_sel['c_kenmei'] ?>'];
<?php
		++$ix;
	}
?>
function zipCheck() {
	$('#check_addr').html('');
	if ($('#c_zip1').val() && $('#c_zip2').val()) {
		zip2address($('#c_zip1').val()+'-'+$('#c_zip2').val(), function(address) {
			if (address) {
				$('#check_addr').html('<p style="padding:3px 0;"><span style="color:red;">'+address.pref+' </span><span style="color:#0080e0;">'+address.city+'</span></p>');
			} else {
				$('#check_addr').html('<p style="padding:3px 0;"><span style="color:red;">※ 住所がみつかりませんでした。</span></p>');
			}
		});
	} else {
		alert('郵便番号を入れてください。');
	}
};
function zipToAddress() {
	$('#check_addr').html('');
	if ($('#c_zip1').val() && $('#c_zip2').val()) {
		zip2address($('#c_zip1').val()+'-'+$('#c_zip2').val(), function(address) {
			if (address) {
				$('#c_address1').val(address.city);
				for (i=0; i<<?= $ix; ?>; i++) {
					if (address.pref == todofuken[i][1]) {
						$('#c_kenid').val(todofuken[i][0]);
					}
				}
			} else {
				alert('住所がみつかりませんでした。');
				$('#c_address1').val('(不明)');
			}
		});
	} else {
		alert('郵便番号を入れてください。');
	}
};
function set_zip_addr(zip1,zip2,ken,addr) {
	$('#c_zip1').val(zip1);
	$('#c_zip2').val(zip2);
	$('#c_address1').val(addr);
	for (i=0; i<<?= $ix; ?>; i++) {
		if (ken == todofuken[i][1]) {
			$('#c_kenid').val(todofuken[i][0]);
		}
	}
}
</script>
		〒：<input class="text ascii" type="text" id="c_zip1" name="c_zip1" size=5 value="<?= my_htmlspecialchars($rec['c_zip1']) ?>" style="ime-mode: inactive;"> -
		<input class="text ascii" type="text" id="c_zip2" name="c_zip2" size=8 value="<?= my_htmlspecialchars($rec['c_zip2']) ?>" style="ime-mode: inactive;">
<input type="button" value="Check" onClick="zipCheck();false;">
<input type="button" value="住所取得" onClick="zipToAddress();false;">
		都道府県：
		<select name="c_kenid" id="c_kenid">
		<option value="">
<?php
	$sqlsel = "select * from r_kenmei order by c_kenid";
	$rs_sel = my_mysqli_query($sqlsel);
	$optgroup = '';
	while ($rec_sel=mysqli_fetch_array($rs_sel)) {
		if ($optgroup <> $rec_sel['c_area']) {
?>
		</optgroup>
		<optgroup label="<?= $rec_sel['c_area'] ?>">
<?php
		}
?>
		<option value="<?= $rec_sel['c_kenid'] ?>"<?= $rec['c_kenid'] == $rec_sel['c_kenid'] ? ' selected' : '' ?>><?= $rec_sel['c_kenmei'] ?></option>
<?php
		$optgroup = $rec_sel['c_area'];
	}
?>
		</optgroup>
		<option value="">
		</select><br>
		<span id="check_addr"></span>
		住所：<input class="text fullwidth-kana" type="text" id="c_address1" name="c_address1" size=70 value="<?= my_htmlspecialchars($rec['c_address1']) ?>" style="ime-mode: active;">
<script>
function search_open() {
	tp = window.screenTop + 40;
	lp = window.screenLeft + 460
		w01 = window.open("zip-search.php","","toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes,width=340,height=400,left="+lp+",top="+tp);
}
</script>
		&nbsp;<a href="javascript:search_open()">住所検索</a></span><br>
		ビル・マンション名：<input class="text fullwidth-kana" type="text" name="c_address2" size=70 value="<?= my_htmlspecialchars($rec['c_address2']) ?>" style="ime-mode: active;">
	</td>
</tr>
<tr>
	<td>アイコン</td>
	<td>
		<input class="text ascii" type="text" name="c_markericon" size=30 value="<?= my_htmlspecialchars($rec['c_markericon']) ?>" style="ime-mode: inactive;">
		<a href="icon-images.php" target="_blank" style="margin-left:20px;">アイコン一覧</a>
	</td>
</tr>
<?php	}	?>
</table>
<?php
	if ($id == 0) {
?>
	<input class="input_form_button" type="submit" name="登録" value="登録">
<?php
	} else {
?>
	<input class="input_form_button" type="submit" name="登録" value="修正">
	<input class="input_form_button" type="submit" name="削除" value="削除" onClick="return delete_check();" style="margin-left:20px;">
<?php
	}
?>
</form>
<script>
function delete_check() {
	if (window.confirm('このデータを削除しますか？')) {
		return true;
	} else {
		return false;
	}
}
</script>
<?
}
?>
