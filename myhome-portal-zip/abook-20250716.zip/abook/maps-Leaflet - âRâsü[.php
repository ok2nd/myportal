<?php
//	Leaflet + OpenStreetMap 版
	require("__include-common.php");
	require("../account/__logincheck.php");
	if (!defined("MAPS_FIX_HEIGHT")) {
		define("MAPS_FIX_HEIGHT", 15);
	}
	if (!defined("MAPS_SIDE_BAR_WIDTH")) {
		define("MAPS_SIDE_BAR_WIDTH", "120px");
	}
	if (!defined("MAPS_SIDE_BAR_WIDTH_WORLD_HERITAGE")) {
		define("MAPS_SIDE_BAR_WIDTH_WORLD_HERITAGE", "160px");
	}
	if (!defined("MAPS_SIDE_BAR_HEIGHT")) {
		define("MAPS_SIDE_BAR_HEIGHT", "70%");
	}
	if (!defined("MAPS_LINEPATH_COLOR")) {
		define("MAPS_LINEPATH_COLOR", "#ff4500");
	}
	if (!defined("MAPS_LINEPATH_WEIGHT")) {
		define("MAPS_LINEPATH_WEIGHT", 3);
	}
?>
<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="utf-8">
<meta name="author" content="ok.2nd">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>MyHome 住所録 マップ（Leaflet + OpenStreetMap 版）</title>
<link rel="stylesheet" href="//unpkg.com/leaflet@1.7.1/dist/leaflet.css" integrity="sha512-xodZBNTC5n17Xt2atTPuE1HxjVMSvLVW9ocqUKLsCC5CXdbqCmblAshOMAS6/keqq/sMZMZ19scR4PsZChSR7A==" crossorigin=""/>
<script src="//unpkg.com/leaflet@1.7.1/dist/leaflet.js" integrity="sha512-XQoYMqMTK8LvdxXYG3nZ448hOEQiglfqkJs1NOQV44cWnUrBc8PkAOcXy20w0vlaXaVUearIOBhiXZ5V3ynxwA==" crossorigin=""></script>
<!-- Font Awesome アイコン -->
<link rel="stylesheet" href="//use.fontawesome.com/releases/v5.6.3/css/all.css"/>
<!-- メニューボタン（現在地表示、マーカーすべて表示） -->
<link rel='stylesheet' href='css/easy-button.css'/>
<script src='js/easy-button.js'></script>
<style>
body { margin:0; padding:0; }
#map { position:absolute; top:0; bottom:0; right:0; left:0; }
.divicon {	/* 文字ラベル */
	display: table-cell;
	color: #f00;
	background-color: #ff4;
	opacity: 0.7;
	white-space: nowrap;
	font-size: 12px;
	font-weight: bold;
}
</style>
</head>
<body>
<div class="container"><div id="map"></div></div>
<?
	$con = my_mysqli_connect(_DB_SCHEMA);
	$sql = "select * from v_abook where id_abook in (".$_GET['id'].')';
	if ($_GET['so'] <> '') {
		$sql .= ' order by '.my_GET('so');
	}
	$rs = my_mysqli_query($sql);
	$row = mysqli_num_rows($rs);
	if ($row <> 0) {
		google_maps($rs, $row);
	} else {
		echo "<script type='text/javascript'>function initialize(){}</script>\n";
		error_msg('該当するデータがありません。');
	}
	mysqli_close($con);
//	exit();
function google_maps($rs, $row) {
	if (!defined("GETLATLNG_SLEEP_TIME")) {
		define("GETLATLNG_SLEEP_TIME", 200000);	// 0.2秒
	}
?>
<script>
var map = L.map('map');
var tileLayer = L.tileLayer('//{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
	attribution: 'c <a href="//osm.org/copyright">OpenStreetMap</a> contributors, <a href="//creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>',
});
tileLayer.addTo(map);
// ---------------------------
var place = Array();
<?php
	$popstr = '';
	$address = '';
	$point_tbl = array();
	while ($rec=mysqli_fetch_array($rs)) {
		if (($address <> '' and $address <> $rec['c_address1'])) {
			$point_tbl[] = array($address, $popstr, $name, $icon);
			$popstr = '';
		} else {
			$popstr .= '<br>';
		}
		if ($_GET['opt'] == 'wh') {	// 世界遺産
			$name = quote_chg($rec['c_name1']);
			$name_left = explode('(', $rec['c_name1']);
			$popstr .= '≪<a href="http://www.google.com/search?q='.urlencode($name_left[0]).'" target="_blank" style="color:#000080;font-weight:bold;">'.quote_chg($name).'</a>≫<br>';
			$popstr .= quote_chg($rec['c_name2']).'<br>';
			$popstr .= 'Ref.'.quote_chg($rec['c_phone1']).'&nbsp;&nbsp;';
			$popstr .= '<a href="http://maps.google.com/maps?q=' . urlencode($rec['c_address1']);
			$popstr .= '" target="_blank">' . quote_chg($rec['c_address1']) . '</a><br>';
		//	$popstr .= '<a href="../tools/google-maps-earth-v3.php?addr=' . urlencode($rec['c_address1']);
		//	$popstr .= '" target="_blank">→ MAP V3</a><br>';
			$popstr .= '<p><a href="http://whc.unesco.org/en/list/'. my_htmlspecialchars($rec['c_phone1']) . '" target="_blank">UNESCO</a>&nbsp;&nbsp;';
			$popstr .= '<a href="http://translate.google.com/translate?prev=hp&hl=ja&js=y&u=http://whc.unesco.org/en/list/' . my_htmlspecialchars($rec['c_phone1']) . '" class="unesco_translate" target="_blank">→日本語</a>';
			$popstr .= '</p>';
			$popstr .= quote_chg($rec['c_memo']).'<br>';
			$popstr .= quote_chg($rec['c_address2']).'<br>';
		} elseif ($_GET['opt'] == 'hm') {	// 百名山
			if ($rec['c_name2'] == '百名山') {
				$kbn = '◎';
			} elseif ($rec['c_name2'] == '二百名山') {
				$kbn = '○';
			} elseif ($rec['c_name2'] == '三百名山') {
				$kbn = '△';
			}
			$name = quote_chg($kbn.$rec['c_name1']);
			$name_left = explode('(', $rec['c_name1']);
			$popstr .= '≪<a href="http://www.google.com/search?q='.urlencode($name_left[0]).'" target="_blank" style="color:#000080;font-weight:bold;">'.quote_chg($name_left[0]).'</a>≫ <span style="color:#000080;">'.quote_chg($rec['c_name2']).'</span><br>';
			$popstr .= '<a href="http://maps.google.com/maps?q=' . urlencode($rec['c_address1']);
			$popstr .= '" target="_blank">' . quote_chg($rec['c_address1']) . '</a><br>';
		//	$popstr .= '<a href="../tools/google-maps-earth-v3.php?addr=' . urlencode($rec['c_address1']);
		//	$popstr .= '" target="_blank">→ MAP V3</a><br>';
			$popstr .= quote_chg($rec['c_address2']).'<br>';
			$popstr .= '標高：'.quote_chg($rec['c_memo']).'m<br>';
		} elseif ($_GET['opt'] == 'sk') {	// 桜名木
			$name = quote_chg($rec['c_name1']);
			$name_left = explode('(', $rec['c_name1']);
			$popstr .= '≪<a href="http://www.google.com/search?q='.urlencode($name_left[0]).'" target="_blank" style="color:#000080;font-weight:bold;">'.quote_chg($name).'</a>≫ <span style="color:#000080;">'.quote_chg($rec['c_name2']).'</span><br>';
			$popstr .= '<a href="http://maps.google.com/maps?q=' . urlencode($rec['c_address1']);
			$popstr .= '" target="_blank">' . quote_chg($rec['c_address1']) . '</a><br>';
		//	$popstr .= '<a href="../tools/google-maps-earth-v3.php?addr=' . urlencode($rec['c_address1']);
		//	$popstr .= '" target="_blank">→ MAP V3</a><br>';
			$popstr .= quote_chg($rec['c_kenmei']).'<br>';
			$popstr .= quote_chg($rec['c_address2']).'<br>';
			if ($rec['c_phone1'] <> '') {
				$popstr .= '樹齢：'.quote_chg($rec['c_phone1']).'年<br>';
			}
			if ($rec['c_memo'] <> '') {
				$popstr .= '見頃：'.quote_chg($rec['c_memo']).'<br>';
			}
		} elseif ($_GET['opt'] == 'hs') {	// 日本百選
			$name = quote_chg($rec['c_name1']);
			$popstr .= '<a href="http://www.google.com/search?q='.urlencode($rec['c_memo']).'" target="_blank" style="color:#0080E0;">'.quote_chg($rec['c_memo']).'</a><br>';
			$popstr .= '<a href="http://www.google.com/search?q='.urlencode($rec['c_name1']).'" target="_blank" style="color:#000080;text-decoration:none;">≪<b>'.$name.'</b>≫</a><br>';
			$popstr .= '<a href="http://maps.google.com/maps?q=' . urlencode($rec['c_address1']);
			$popstr .= '" target="_blank">' . quote_chg($rec['c_address1']) . '</a><br>';
		//	$popstr .= '<a href="../tools/google-maps-earth-v3.php?addr=' . urlencode($rec['c_address1']);
		//	$popstr .= '" target="_blank">→ MAP V3</a><br>';
			$popstr .= quote_chg($rec['c_address2']).'<br>';
		} elseif ($_GET['opt'] == 'ts') {	// 鉄道駅
			$rail = quote_chg($rec['c_memo']);
			$rail_left = explode('(', $rec['c_memo']);
			$popstr .= '<a href="http://www.google.com/search?q='.urlencode($rail_left[0]).'" target="_blank" style="color:#080;">'.$rail.'</a><br>';
			$name = quote_chg($rec['c_name1']);
			$name_left = explode('(', $rec['c_name1']);
			$popstr .= '≪<a href="http://www.google.com/search?q='.urlencode($name_left[0]).'" target="_blank" style="color:#000080;font-weight:bold;">'.quote_chg($name).'</a>≫<br>';
			$popstr .= quote_chg($rec['c_kenmei']).'<br>';
			$popstr .= '<a href="http://maps.google.com/maps?q=' . urlencode($rec['c_address1']);
			$popstr .= '" target="_blank">' . quote_chg($rec['c_address1']) . '</a><br>';
		//	$popstr .= '<a href="../tools/google-maps-earth-v3.php?addr=' . urlencode($rec['c_address1']);
		//	$popstr .= '" target="_blank">→ MAP V3</a><br>';
			$popstr .= quote_chg($rec['c_address2']).'<br>';
		} else {
			$name = quote_chg($rec['c_name1']).' '.quote_chg($rec['c_name2']);
			$popstr .= '<font color=#000080>≪<b>'.$name.'</b>≫</font><br>';
			$popstr .= quote_chg($rec['c_kenmei']).'<br>';
			$popstr .= '<a href="http://maps.google.com/maps?q=' . urlencode($rec['c_address1']);
			$popstr .= '" target="_blank">' . quote_chg($rec['c_address1']) . '</a><br>';
			if ($rec['c_address2'] <> '') {
				$popstr .= quote_chg($rec['c_address2']).'<br>';
			}
		//	$popstr .= '<a href="../tools/google-maps-earth-v3.php?addr=' . urlencode($rec['c_address1']);
		//	$popstr .= '" target="_blank">→ MAP V3</a><br>';
			if ($rec['c_memo'] <> '') {
				$popstr .= quote_chg($rec['c_memo']).'<br>';
			}
		}
		if ($rec['c_markericon'] <> '') {
			$icon = $rec['c_markericon'];
		} else {
			$icon = $rec['c_categoryIcon'];
		}
		$address = $rec['c_address1'];
	}
	$point_tbl[] = array($address, $popstr, $name, $icon);
	$adr_cnt = 0;
	foreach ($point_tbl as $point) {
		$p_ary = explode(',', $point[0]);
		if (count($p_ary) == 2 && is_numeric($p_ary[0]) && is_numeric($p_ary[1])) {
?>
place[<?= $adr_cnt ?>] = Array();
place[<?= $adr_cnt ?>]["name"] = '<?= $point[2] ?>';
place[<?= $adr_cnt ?>]["lat"] = <?= $p_ary[0] ?>;
place[<?= $adr_cnt ?>]["lng"] = <?= $p_ary[1] ?>;
place[<?= $adr_cnt ?>]["popstr"] = '<?= $point[1] ?>';
<?php
		} else {
			$status = getLatLng($point[0], $lat, $lng);
?>
place[<?= $adr_cnt ?>] = Array();
place[<?= $adr_cnt ?>]["name"] = '<?= $point[2] ?>';
place[<?= $adr_cnt ?>]["lat"] = <?= $lat ?>;
place[<?= $adr_cnt ?>]["lng"] = <?= $lng ?>;
place[<?= $adr_cnt ?>]["popstr"] = '<?= $point[1] ?>';
<?php
		//	usleep(GETLATLNG_SLEEP_TIME);
		}
		++$adr_cnt;
	}
}
?>
// ---------------------------
var myIcon = L.icon({	/* アイコン */
	iconUrl: 'icon/marker-small.png',
	iconRetinaUrl: 'icon/marker-small.png',
	iconSize: [16, 27],
	iconAnchor: [7, 27],
	popupAnchor: [1, -22],
});
iconMarkers = L.featureGroup();		// 全マーカーを画面内に収めるため
for (var i = 0; i < place.length; i++) {
	// 文字ラベルを表示
	var divIcon = L.divIcon({
		html: '<div class="divicon">' + place[i].name + '</div>',
		iconSize: [0,0]
	});
	iconMarkers.addLayer( L.marker([place[i].lat, place[i].lng], {icon: myIcon}).addTo(map).bindPopup(place[i].popstr) );
	L.marker([place[i].lat, place[i].lng], {icon: divIcon}).addTo(map);
}
map.fitBounds(iconMarkers.getBounds());	// 全マーカーを画面内に収める
var Basic_Map = new Array();
Basic_Map[ 0 ] = L.tileLayer('https://mt1.google.com/vt/lyrs=r&x={x}&y={y}&z={z}', {
	attribution: "<a href='https://developers.google.com/maps/documentation' target='_blank'>Google Map</a>"
});
Basic_Map[ 1 ] = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
	attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
	continuousWorld: false
});
Basic_Map[ 2 ] = L.tileLayer('https://cyberjapandata.gsi.go.jp/xyz/std/{z}/{x}/{y}.png', {
	attribution: "<a href='https://maps.gsi.go.jp/development/ichiran.html' target='_blank'>地理院タイル</a>"
});
Basic_Map[ 3 ] = L.tileLayer('https://cyberjapandata.gsi.go.jp/xyz/seamlessphoto/{z}/{x}/{y}.jpg', {
	attribution: "<a href='https://maps.gsi.go.jp/development/ichiran.html' target='_blank'>地理院タイル</a>"
});
Basic_Map[ 4 ] = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Topo_Map/MapServer/tile/{z}/{y}/{x}', {
	attribution: 'Tiles &copy; <a href="http://www.esrij.com/"> Esri Japan </a>'
});
var baseMap = {
	"Google マップ": Basic_Map[ 0 ],
	"OpenStreetMap": Basic_Map[ 1 ],
	"国土地理院 標準地図": Basic_Map[ 2 ],
	"国土地理院 写真": Basic_Map[ 3 ],
	"Esri World Topo Map": Basic_Map[ 4 ]
};
L.control.layers(baseMap).addTo(map);
// 現在地表示ボタン
var watch_id = 0;
var curMarker = null;	// 現在地マーカー
var currentWatchBtn = null;
L.easyButton({		// 現在地表示ボタン
	states: [{
		stateName: 'current-watch',
		icon:	'fas fa-map-marker-alt',
		title:	 '現在地',
		onClick: function(btn, map) {
			currentWatch();
			btn.state('current-watch-reset');
			currentWatchBtn = btn;
		}
	}, {
		stateName: 'current-watch-reset',
		icon:	'fa fa-user',
		title:	 '現在地オフ',
		onClick: function(btn, map) {
			currentWatchReset();
			btn.state('current-watch');
		}
	}]
}).addTo( map );
// マーカーすべて表示画面に戻るボタン
L.easyButton('fa fa-reply-all', function(btn, easyMap) {
	currentWatchReset();
	if (currentWatchBtn) {
		currentWatchBtn.state('current-watch');
		currentWatchBtn = null;
	}
	map.fitBounds(iconMarkers.getBounds());	// 全マーカー画面に戻る
}).addTo(map);
// クリックした地点の緯度・経度、標高を表示
map.on('click', onMapClick);
var clickMarker = null;
function onMapClick(e) {
	if (clickMarker) {
		map.removeLayer(clickMarker);
	}
	lat = e.latlng.lat;
	lng = e.latlng.lng;
	// 地理院地図サーバから標高を求める
	// http://maps.gsi.go.jp/development/elevation_s.html
	var src = 'https://cyberjapandata2.gsi.go.jp/general/dem/scripts/getelevation.php?lon=' + lng + '&lat=' + lat ;
	var req = new XMLHttpRequest();
	req.onreadystatechange = function() {
		if(req.readyState == 4 && req.status == 200) {
			var json = req.responseText;
			var results = JSON.parse(json);
		//	var popStr = '緯度：' + lat + '<br>経度：' + lng + '<br>標高：' + results.elevation + 'm';
			var popStr = '<a href="http://maps.google.com/maps?q=' + lat + '%2C' + lng + '" target="_blank">' + '緯度：' + lat + '<br>経度：' + lng + '</a><br>標高：' + '' + results.elevation + 'm';
			clickMarker = L.marker(e.latlng).on('click', onMarkerClick).addTo(map).bindPopup(popStr).openPopup();
		}
	};
	req.open("GET", src, false);
	req.send(null)
}
function onMarkerClick(e) {
	map.removeLayer(clickMarker);
}
function currentWatch() {
	function success(pos) {
		var lat = pos.coords.latitude;
		var lng = pos.coords.longitude;
			// 東京タワー
			// var lat = 35.65837719526223;
			// var lng = 139.7423601150513;
		map.setView([ lat,lng ]);
			// 現在地に表示するマーカー：Awesomeアイコン版
			//	var curIcon = L.divIcon({
			//		html: '<div class="fa fa-user" style="color: #FF7F50; font-size: 20px;"></div>',
			//		iconSize: [20, 20],
			//		className: 'myDivIcon'
			//	});
		// 現在地に表示するマーカー
		if (curMarker) {
			map.removeLayer(curMarker);
		}
		var curIcon = L.icon({	/* アイコン */
			iconUrl: 'icon/hiking.png',
			iconRetinaUrl: 'icon/hiking.png',
			iconAnchor: [15, 34]
		});
		curMarker = L.marker([lat, lng], {icon: curIcon}).addTo(map);
	}
	function error(err) {
		alert('位置情報を取得できませんでした。');
	}
	var options = {
		enableHighAccuracy: true,
		timeout: 5000,
		maximumAge: 0
	};
//	navigator.geolocation.getCurrentPosition(success, error, options);
	if (watch_id == 0) {
		watch_id = navigator.geolocation.watchPosition(success, error, options); // 現在地情報を定期的に
	}
}
function currentWatchReset() {
	if (watch_id > 0) {
		navigator.geolocation.clearWatch(watch_id);
		watch_id = 0;
	}
	if (curMarker) {
		map.removeLayer(curMarker);
		curMarker = null;
	}
}
</script>
</body>
</html>
