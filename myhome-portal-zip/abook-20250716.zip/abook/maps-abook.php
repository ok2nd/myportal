<?php
	require("__include-common.php");
	require("../account/__logincheck.php");
	if (!defined("GOOGLE_API_KEY")) {
		define("GOOGLE_API_KEY", "ABQIAAAA1XbMiDxx_BTCY2_FkPh06RRaGTYH6UMl8mADNa0YKuWNNa8VNxQEerTAUcfkyrr6OwBovxn7TDAH5Q");
	}
	if (!defined("MAPS_SIDE_BAR_WIDTH")) {
		define("MAPS_SIDE_BAR_WIDTH", "90px");
	}
	if (!defined("MAPS_SIDE_BAR_WIDTH_WORLD_HERITAGE")) {
		define("MAPS_SIDE_BAR_WIDTH_WORLD_HERITAGE", "160px");
	}
	if (!defined("MAPS_FIX_HEIGHT")) {
		define("MAPS_FIX_HEIGHT", 25);
	}
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta charset="utf-8">
<meta name="author" content="ok.2nd">
<meta name="description" content="abook">
<meta name="keywords" content="住所録, マップ">
<title>MyHome 住所録 マップ</title>
<style>
* { margin: 0px; padding: 0px; }
html {
	width: 100%;
	height: 100%;
	overflow: hidden;
}
form { margin: 0px; }
img { border: 0px; }
body {
	background-color: #ffffff;
	text-align: left;
	font-size: 84%;
	font-family: "ＭＳ Ｐゴシック",arial,helvetica,clean,sans-serif;
	margin: 0;
	width: 100%;
	height: 100%;
}
#page_body {
	width: 100%;
	height: 100%;
}
#page_contents {
	width: 100%;
	height: 100%;
}
#map3d {
	width: 100%;
	height: 100%;
}
#maps_filter {
	clear: both;
	margin: 0 0 0 10px;
	padding: 0;
}
.block {
	clear: both;
}
.block_left {
	float: left;
	text-align: left;
	padding: 0;
}
a:link { color: #2128e0; font-weight: normal; }
a:visited { color: #2128e0; font-weight: normal; }
a:hover { color: #f43316; font-weight: normal; background-color: #ffffc0; }
a:active { color: #f43316; font-weight: normal; background-color: #ffffc0; }
a.unesco_translate:link { color: #ff69b4; font-weight: normal; font-size: 72%; }
a.unesco_translate:visited { color: #ff69b4; font-weight: normal; font-size: 72%; }
a.unesco_translate:hover { color: #ff0000; font-weight: normal; font-size: 72%; }
a.unesco_translate:active { color: #ff0000; font-weight: normal; font-size: 72%; }
.error_msg { color: red; margin: 20px; padding: 0; }
.noramal_msg { color: #000000; margin: 20px; padding: 0; }
<?
	if ($_GET['opt'] == 'wh' || $_GET['opt'] == 'sk' || $_GET['opt'] == 'hs') {
		$side_bar_width = MAPS_SIDE_BAR_WIDTH_WORLD_HERITAGE;
	} else {
		$side_bar_width = MAPS_SIDE_BAR_WIDTH;
	}
?>
#side_bar {
	position: absolute; top: 40px; right: 6px; width: <?= $side_bar_width?>; height: 70%;
	border: 1px solid #666; padding: 6px; line-height: 1.4; overflow:scroll;
/*	background: #ffffff; filter: alpha(opacity=75); -moz-opacity:0.75; opacity:0.75; */
	background: url(../images/trans-white.png);
}
#side_bar li {
	white-space: nowrap;
}
</style>
</head>
<body onload="init()" onunload="GUnload()">
<?
	$con = my_mysqli_connect(_DB_SCHEMA);
	$sql = "select * from v_abook where id_abook in (".$_GET['id'].')';
	if ($_GET['so'] <> '') {
		$sql .= ' order by '.my_GET('so');
	}
	$rs = my_mysqli_query($sql);
	$row = mysqli_num_rows($rs);
	if ($row <> 0) {
		google_maps($rs, $row);
	} else {
		echo "<script type='text/javascript'>function init(){}</script>\n";
		error_msg('該当するデータがありません。');
	}
	mysqli_close($con);
?>
</body>
</html>
<?php
	exit();
?>
<?php
function google_maps($rs, $row) {
	if (!defined("GETLATLNG_SLEEP_TIME")) {
		define("GETLATLNG_SLEEP_TIME", 200000);	// 0.2秒
	}
?>
<script src="http://www.google.com/jsapi?key=<?= GOOGLE_API_KEY ?>"></script>
<script src="../scripts/jquery.js"></script>
<script src="../scripts/jquery.cookie.js"></script>
<script src="../scripts/ok2nd.js"></script>
<script>
var map;
var ge;
var geocoder = null;
var maxLat=-999, minLat=999, maxLng=-999, minLng=999;
var notFound = '';
google.load("maps", "2.x");
function setHeightPercent(elementID, fixHeight) {
	// マップの高さ設定
	//if (document.all) {	// IE
	//	fixHeight += 40;
	//}
	mapsWinHeight = 100 - Math.ceil( fixHeight * 100 / screen.availHeight );
	document.getElementById(elementID).style.height = mapsWinHeight + "%";
}
function init() {
	setHeightPercent('map3d', <?= MAPS_FIX_HEIGHT ?>);
	map = new GMap2(document.getElementById('map3d'));
	var mapui = map.getDefaultUI();
	mapui.maptypes.physical = true;
	map.setUI(mapui);
	map.addMapType(G_SATELLITE_3D_MAP);
	GEvent.addListener(map, 'maptypechanged', function() {
		if (ge) return;
		map.getEarthInstance(function(pluginInstance) {
			ge = pluginInstance;
			doStuffWithEarth();
		});
	});
	geocoder = new GClientGeocoder();
	maxLat = -999;
	minLat = 999;
	maxLng = -999;
	minLng = 999;
	var vpoint = Array();
<?php
	$popstr = '';
	$address = '';
	$point_tbl = array();
	while ($rec=mysqli_fetch_array($rs)) {
		if (($address <> '' and $address <> $rec['c_address1'])) {
			$point_tbl[] = array($address, $popstr, $name);
			$popstr = '';
		}
		if ($_GET['opt'] == 'wh') {	// 世界遺産
			$name = quote_chg($rec['c_name1']);
			$name_left = explode('(', $rec['c_name1']);
			$popstr .= '≪<a href="http://www.google.com/search?q='.urlencode($name_left[0]).'" target="_blank" style="color:#000080;font-weight:bold;">'.quote_chg($name).'</a>≫<br>';
			$popstr .= quote_chg($rec['c_name2']).'<br><br>';
			$popstr .= 'Ref.'.quote_chg($rec['c_phone1']).'&nbsp;&nbsp;';
			$popstr .= '<a href="http://maps.google.com/maps?q=' . urlencode($rec['c_address1']);
			$popstr .= '" target="_blank">' . quote_chg($rec['c_address1']) . '</a><br><br>';
			$popstr .= '<p><a href="http://whc.unesco.org/en/list/'. my_htmlspecialchars($rec['c_phone1']) . '" target="_blank">UNESCO</a>&nbsp;&nbsp;';
			$popstr .= '<a href="http://translate.google.com/translate?prev=hp&hl=ja&js=y&u=http://whc.unesco.org/en/list/' . my_htmlspecialchars($rec['c_phone1']) . '" class="unesco_translate" target="_blank">→日本語</a></p><br>';
			$popstr .= quote_chg($rec['c_memo']).'<br>';
			$popstr .= quote_chg($rec['c_address2']).'<br>';
		} elseif ($_GET['opt'] == 'hm') {	// 百名山
			$name = quote_chg($rec['c_name1']);
			$name_left = explode('(', $rec['c_name1']);
			$popstr .= '≪<a href="http://www.google.com/search?q='.urlencode($name_left[0]).'" target="_blank" style="color:#000080;font-weight:bold;">'.quote_chg($name).'</a>≫ <span style="color:#000080;">'.quote_chg($rec['c_name2']).'</span><br><br>';
			$popstr .= '<a href="http://maps.google.com/maps?q=' . urlencode($rec['c_address1']);
			$popstr .= '" target="_blank">' . quote_chg($rec['c_address1']) . '</a><br><br>';
			$popstr .= quote_chg($rec['c_address2']).'<br><br>';
			$popstr .= '標高：'.quote_chg($rec['c_memo']).'m<br>';
		} elseif ($_GET['opt'] == 'sk') {	// 桜名木
			$name = quote_chg($rec['c_name1']);
			$name_left = explode('(', $rec['c_name1']);
			$popstr .= '≪<a href="http://www.google.com/search?q='.urlencode($name_left[0]).'" target="_blank" style="color:#000080;font-weight:bold;">'.quote_chg($name).'</a>≫ <span style="color:#000080;">'.quote_chg($rec['c_name2']).'</span><br><br>';
			$popstr .= '<a href="http://maps.google.com/maps?q=' . urlencode($rec['c_address1']);
			$popstr .= '" target="_blank">' . quote_chg($rec['c_address1']) . '</a><br><br>';
			$popstr .= quote_chg($rec['c_kenmei']).'<br>';
			$popstr .= quote_chg($rec['c_address2']).'<br><br>';
			$popstr .= '樹齢：'.quote_chg($rec['c_phone1']).'<br>';
			$popstr .= '見頃：'.quote_chg($rec['c_memo']).'<br>';
		} elseif ($_GET['opt'] == 'hs') {	// 日本百選
			$name = quote_chg($rec['c_name1']);
			$popstr .= '<a href="http://www.google.com/search?q='.urlencode($rec['c_memo']).'" target="_blank" style="color:#0080E0;">'.quote_chg($rec['c_memo']).'</a><br><br>';
			$popstr .= '<a href="http://www.google.com/search?q='.urlencode($rec['c_name1']).'" target="_blank" style="color:#000080;text-decoration:none;">≪<b>'.$name.'</b>≫</a><br><br>';
			$popstr .= '<a href="http://maps.google.com/maps?q=' . urlencode($rec['c_address1']);
			$popstr .= '" target="_blank">' . quote_chg($rec['c_address1']) . '</a><br><br>';
			$popstr .= quote_chg($rec['c_address2']).'<br>';
		} elseif ($_GET['opt'] == 'ts') {	// 鉄道駅
			$rail = quote_chg($rec['c_memo']);
			$rail_left = explode('(', $rec['c_memo']);
			$popstr .= '<a href="http://www.google.com/search?q='.urlencode($rail_left[0]).'" target="_blank" style="color:#000080;">'.$rail.'</a><br><br>';
			$name = quote_chg($rec['c_name1']);
			$name_left = explode('(', $rec['c_name1']);
			$popstr .= '≪<a href="http://www.google.com/search?q='.urlencode($name_left[0]).'" target="_blank" style="color:#000080;font-weight:bold;">'.quote_chg($name).'</a>≫<br><br>';
			$popstr .= quote_chg($rec['c_kenmei']).'<br>';
			$popstr .= '<a href="http://maps.google.com/maps?q=' . urlencode($rec['c_address1']);
			$popstr .= '" target="_blank">' . quote_chg($rec['c_address1']) . '</a><br><br>';
			$popstr .= quote_chg($rec['c_address2']).'<br>';
		} else {
			$name = quote_chg($rec['c_name1']).' '.quote_chg($rec['c_name2']);
			$popstr .= '<font color=#000080>≪<b>'.$name.'</b>≫</font><br><br>';
			$popstr .= quote_chg($rec['c_kenmei']).'<br>';
			$popstr .= '<a href="http://maps.google.com/maps?q=' . urlencode($rec['c_address1']);
			$popstr .= '" target="_blank">' . quote_chg($rec['c_address1']) . '</a><br><br>';
			$popstr .= quote_chg($rec['c_memo']).'<br>';
			$popstr .= quote_chg($rec['c_address2']).'<br>';
		}
		$address = $rec['c_address1'];
	}
	$point_tbl[] = array($address, $popstr, $name);
	$adr_cnt = 0;
	foreach ($point_tbl as $point) {
		$p_ary = explode(',', $point[0]);
		if (count($p_ary) == 2 && is_numeric($p_ary[0]) && is_numeric($p_ary[1])) {
?>
	vpoint[<?= $adr_cnt ?>] = Array();
	vpoint[<?= $adr_cnt ?>]["address"] = '<?= $point[0] ?>';
	vpoint[<?= $adr_cnt ?>]["popstr"] = '<?= $point[1] ?>';
	vpoint[<?= $adr_cnt ?>]["name"] = '<?= $point[2] ?>';
	vpoint[<?= $adr_cnt ?>]["lat"] = <?= $p_ary[0] ?>;
	vpoint[<?= $adr_cnt ?>]["lng"] = <?= $p_ary[1] ?>;
	vpoint[<?= $adr_cnt ?>]["status"] = 200;
<?php
		} else {
			$status = getLatLng($point[0], $lat, $lng);
?>
	vpoint[<?= $adr_cnt ?>] = Array();
	vpoint[<?= $adr_cnt ?>]["address"] = '<?= $point[0] ?>';
	vpoint[<?= $adr_cnt ?>]["popstr"] = '<?= $point[1] ?>';
	vpoint[<?= $adr_cnt ?>]["name"] = '<?= $point[2] ?>';
	vpoint[<?= $adr_cnt ?>]["lat"] = <?= $lat ?>;
	vpoint[<?= $adr_cnt ?>]["lng"] = <?= $lng ?>;
	vpoint[<?= $adr_cnt ?>]["status"] = <?= $status ?>;
<?php
		//	usleep(GETLATLNG_SLEEP_TIME);
		}
		++$adr_cnt;
	}
?>
	showMarker(vpoint, <?= $adr_cnt ?>);
}
var side_bar_html = "";
var gmarkers = [];
var i = 0;
function createMarker(point, addr, popstr, name, lat, lng) {
	var marker = new GMarker(point);
	GEvent.addListener(marker, "click", function() {
		html = popstr;
		map.openInfoWindowHtml(point, html);
	});
	gmarkers[i] = marker;
	side_bar_html += '<li><a href="javascript:myClick(' + i + ')">' + name + '</a></li>';
	i++;
	return marker;
}
function myClick(i) {
	GEvent.trigger(gmarkers[i], "click");
}
function showMarker(vpoint, cnt) {
	if (geocoder) {
		for (var ix=0; ix<cnt; ix++) {
			if (vpoint[ix]["status"] == 200) {
				var lat = vpoint[ix]["lat"];
				var lng = vpoint[ix]["lng"];
				var point = new GLatLng(lat, lng);
				if (maxLat < lat) maxLat = lat;
				if (minLat > lat) minLat = lat;
				if (maxLng < lng) maxLng = lng;
				if (minLng > lng) minLng = lng;
				map.addOverlay(createMarker(point, vpoint[ix]["address"], vpoint[ix]["popstr"], vpoint[ix]["name"], lat, lng));
			} else {
				notFound += vpoint[ix]["address"] + '&nbsp;';
			}
		}
		bounds = new GLatLngBounds(new GLatLng(minLat,minLng), new GLatLng(maxLat,maxLng));
		zoomlevel = map.getBoundsZoomLevel(bounds);
		if (zoomlevel > 15) zoomlevel = 15;
		map.setCenter(bounds.getCenter(), zoomlevel);
		document.getElementById('side_bar').innerHTML = "<ul>"+side_bar_html+"</ul>";
		document.getElementById('not_found').innerHTML = notFound;
	}
}
function doStuffWithEarth() {
	document.getElementById('installed-plugin-version').innerHTML = ge.getPluginVersion().toString();
}
function markerClear() {
	map.clearOverlays();
}
function addressClear() {
	document.getElementById("address").value = '';
}
</script>
<div id="map3d"></div>
<div id="side_bar">Loading...</div>
<div>Not found: <span id="not_found" style="color: red;"></span></div>
<div>Installed Plugin Version: <span id="installed-plugin-version" style="font-weight: bold;">Loading...</span></div>
<?php
}
function getLatLngV2($address, &$lat, &$lng) {		// Geocoding API V2
	$latLng = my_file_get_contents('http://maps.google.com/maps/geo?q='.urlencode($address).'&output=csv&sensor=false&key='.GOOGLE_API_KEY);
	$ary = explode(',', $latLng);
	$lat = $ary[2];
	$lng = $ary[3];
	return $ary[0];
}
function getLatLng($address, &$lat, &$lng) {		// Geocoding API V3
	$json = my_file_get_contents('http://maps.google.com/maps/api/geocode/json?address='.urlencode($address).'&sensor=false');
	$latLng = json_decode($json, true);
	if ($latLng['status'] <> 'OK') return 0;
	$lat = $latLng['results'][0]['geometry']['location']['lat'];
	$lng = $latLng['results'][0]['geometry']['location']['lng'];
	return 200;	// getLatLngV2() との互換性のため
}
?>
