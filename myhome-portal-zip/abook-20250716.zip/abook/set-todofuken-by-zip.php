<?php
	require("__include-common.php");
	require("../account/__logincheck.php");
	html_header(HTML_TITLE);
	page_header();
	contents_header();
	set_todofuken_by_zip();
	page_footer();
	html_footer();
?>
<?php
function set_todofuken_by_zip() {
?>
<div class="input_form">
<h3><font color=#000000>郵便番号による都道府県名セット</font></h3>
<br>
<?php
	if (is_write_permit() != True) {
		error_exit('書き込み権限がありません。');
	}
	$con = my_mysqli_connect(_DB_SCHEMA);
	$sql = "select * from v_abook_chk_ken where id_account = '" . $_SESSION['current_id'] . "'";
	$rs = my_mysqli_query($sql);
	if ($rs) {
		$row = mysqli_num_rows($rs);
	} else {
		$row = 0;
	}
	mysqli_close($con);
?>
<p>
郵便番号から判断して都道府県名をセットします。<br>
郵便番号が入力されていないデータは処理されません。<br>
都道府県名が既に登録済みのデータは処理されません。<br>
99%以上は正しくセットされますが、一部、隣の都道府県名がセットされる可能性があります。<br><br>
<?php
	if ($row == 0) {
		error_msg('対象データがありません。');
		return;
	}
?>
対象データ（郵便番号が入力されていて、都道府県名が空白のデータ）が、<span style="color:red; font-weight:bold; font-size:140%;"><?= $row ?></span> 件あります。
</p>
<br>
<form name="form0" method="POST" action="<?= $_SERVER['SCRIPT_NAME'] ?>">
	<input type="submit" name="実行" value="都道府県名をセットする">
</form>
<?php
	if ($_POST) {
		$con = my_mysqli_connect(_DB_SCHEMA);
		$sql = "update v_abook_chk_ken set c_kenid = c_zip_kenid";
		$sql .= " where id_account = '" . $_SESSION['current_id'] . "'";
		$rs = my_mysqli_query($sql);

		$sql = "select * from v_abook_chk_ken where id_account = '" . $_SESSION['current_id'] . "'";
		$rs = my_mysqli_query($sql);
		if ($rs) {
			$row = mysqli_num_rows($rs);
		} else {
			$row = 0;
		}
?>
<p>
<br><br>都道府県名をセットしました。<br><br>
郵便番号が入力されていて、都道府県名が空白のデータは、<span style="color:red; font-weight:bold; font-size:140%;"><?= $row ?></span> 件です。
</p>
<?php
	}
}
?>
