<?php
	require("__include-common.php");
	require("../account/__logincheck.php");
//	require("../account/__logincheck_write_permit.php");
	require("../calendar/_my_calendar.php");
	ini_set("memory_limit", FILE_UPLOAD_MEMORY_LIMIT);		//メモリサイズ
	ini_set("max_execution_time", FILE_UPLOAD_MAX_EXECUTION_TIME);	//最大実行時間
	if ($_POST) {
// *********************************************************************************
// * max_execution_time
// * post_max_size
// * upload_max_filesizeを越えるとisset($_POST['登録'])がTrueにならない。
// *********************************************************************************
		check_post_account($_POST['login_id'], $_POST['current_id']);
		post_done_proc();
	} else {
		if (INPUT_POPUP_CALENDAR == 'YUI') {
			$add_input_header = '_add_input_header_YUI.php';
		} else if (INPUT_POPUP_CALENDAR == 'kanaya') {
			$add_input_header = '_add_input_header-kanaya.php';
		} else {
			$add_input_header = '_add_input_header.php';
		}
		html_header(HTML_TITLE, $add_input_header, '', ' onload="document.form0.c_name.focus()"');
		if (gpslog_PAGE_HEADER == 'YES') {
			page_header();
		} else {
			page_header_return_index();
		}
		input_form();
		page_footer();
		html_footer();
	}
	exit();
?>
<?php
function post_done_proc() {
	if ($_POST['user_id']."" <> "") {
		$user_id = $_POST['user_id'];
	} else {
		error_exit("不正アクセス：ユーザーIDなし", True);
	}
	if (check_permit_id($_SESSION['login_id'], $user_id) != "w") {
		error_exit("不正アクセス：書き込み権限がありません。", True);
	}
	if ($_POST['update_id']) {
		if (!is_numeric($_POST['update_id'])) {
			error_exit("不正アクセス", True);
		}
		$id = intval($_POST['update_id']);
	} else {
		error_exit("IDなし", True);
	}
	if ($_POST['inputY']) {
		$year = get_post_str("inputY");
	}
	if ($_POST['inputM']) {
		$month = get_post_str("inputM");
	}
	if ($_POST['inputD']) {
		$day = get_post_str("inputD");
	}
	if (!checkdate($month, $day, $year)) {
		error_exit("日付が不正", True);
	}
	$diary_date = date("Y-m-d", mktime(0, 0, 0, $month, $day, $year));
	$con = my_mysqli_connect(_DB_SCHEMA);
	if ($_POST['削除'] <> '') {
		$sql = "update m_gpslog set";
		$sql .= " c_delete = 999";
		$sql .= ", c_updatetime = '". date("Y/m/d H:i:s") . "'";
		$sql .= " where id_gpslog = ".$id;
		$sql .= " and id_account = ".$user_id;
		$ret = my_mysqli_query($sql, "削除できませんでした。");
	} else {
		$sql = "update m_gpslog set";
		$sql .= " id_category = '".$_POST['id_category']."'";
		$sql .= ", c_name = '".post_to_mysql("c_name")."'";
		$sql .= ", c_description = '".post_to_mysql("c_description")."'";
		$sql .= ", c_photo_folder = '".str_replace("\\\\",'/',post_to_mysql("c_photo_folder"))."'";
		$sql .= ", c_date = '".$diary_date."'";
		$sql .= ", c_updatetime = '". date("Y/m/d H:i:s") . "'";
		$sql .= " where id_gpslog = ".$id;
		$sql .= " and id_account = ".$user_id;
		$ret = my_mysqli_query($sql, "更新できませんでした。");
	}
	// ****** 添付ファイル ******
	if ($id == 0) {
		$id = my_mysqli_insert_id();	//直近のINSERTクエリによりAUTO_INCREMENTカラム用に生成されたIDを取得
	}
	$sw = False;
	$sqlupd = "";
	if ($_POST['削除'].'' == '') {
		for ($ix=1; $ix<=1; $ix++) {
			$attachFile = file_upload("filename".$ix, $id, ATTACH_FILE_FOLDER, $user_id);
			if ($attachFile <> "") {
				if ($sw) {
					$sqlupd .= ",";
				}
				$sqlupd .= " c_attachFile" . $ix . " = '" . $attachFile . "'";
				$sw = True;
			} else if ($_POST['fileDelete'.$ix] == "YES") {
				if ($sw) {
					$sqlupd .= ",";
				}
				$sqlupd .= " c_attachFile" . $ix . " = ''";
				$sw = True;
			}
		}
	}
	if ($sw) {
		$sql = "update m_gpslog set";
		$sql .= $sqlupd;
		$sql .= " where id_gpslog = ".$id;
		$sql .= " and id_account = '".$user_id."'";
		$ret = my_mysqli_query($sql, "アップロードファイル名DB登録失敗。");
	}
	mysqli_close($con);
	if ($sw) {
		redirect("view-wadachi.php?".$_SERVER['QUERY_STRING']."&id=".$id."&mode=upd");
	} elseif ($_GET['ret'] == 'view') {
		redirect("view-wadachi.php?".$_SERVER['QUERY_STRING']."&id=".$id);
	} else {
		redirect("list.php?".$_SERVER['QUERY_STRING']."#id_".$id);
	}
}
function input_form() {
	if ($_GET['id'] <> "") {
		$id = $_GET['id'];
		if ($_GET['page'] <> "") {
			$page = $_GET['page'];
		}
	} else {
		$id = 0;
	}
	$con = my_mysqli_connect(_DB_SCHEMA);
	$sql = "select * from v_gpslog where id_gpslog = ".$id." and c_delete = 0";
	$sql .= " and id_account = ".$_SESSION['current_id'];
	$rs = my_mysqli_query($sql);
	$rec = mysqli_fetch_array($rs);
?>
<div class="input_form">
<h3><?= $_SESSION['current_handle'] ?><a class="a_cancel_back" href="javascript:history.back();">戻る</a></h3>
<script>
function formCheck(form) {
	if (form0.c_name.value == '') {
		window.alert('名前を入れてください。');
		return false;		// 送信を中止
	}
	return true;	// 送信を実行
}
</script>
<form name="form0" method="POST" action="<?= $_SERVER['SCRIPT_NAME'] ?>?<?= $_SERVER['QUERY_STRING'] ?>" enctype="multipart/form-data" onSubmit="return formCheck(this)">
	<input type="hidden" name="user_id" value="<?= $_SESSION['current_id'] ?>">
	<input type="hidden" name="update_id" value="<?= $id ?>">
	<input type="hidden" name="login_id" value="<?= $_SESSION['login_id'] ?>">
	<input type="hidden" name="current_id" value="<?= $_SESSION['current_id'] ?>">
<table>
<tr>
	<td nowrap>カテゴリ</td>
	<td nowrap>
<?php
	$sqlsel = "select * from m_category where id_account = '".$_SESSION['current_id']."'";
	$sqlsel = $sqlsel . " and c_delete = 0";
	$sqlsel = $sqlsel . " order by c_categoryDisplayOrder";
	$rs_sel = my_mysqli_query($sqlsel);
?>
	<select name="id_category">
<?php
		if ($id == 0) {
			$category = (int)$_GET['cat'];
		} else {
			$category = $rec['id_category'];
		}
		while ($rec_sel=mysqli_fetch_array($rs_sel)) {
?>
		<option value="<?= $rec_sel['id_category'] ?>"<?= $rec_sel['id_category'] == $category ? " selected" : "" ?>><?= my_htmlspecialchars($rec_sel['c_categoryName']) ?>
<?php
		}
?>
	</select>
	</td>
</tr>
<tr>
	<td>日付</td>
	<td nowrap>
		<p>
			<input type="hidden" name="c_date_current" value="<?= $rec['c_date'] ?>">
		<?php
			$endYY = date("Y") + 1;
			$year = date_from_mysql("Y", $rec['c_date']);
			$month = date_from_mysql("n", $rec['c_date']);
			$day = date_from_mysql("d", $rec['c_date']);
			select_view_with_id("inputY", "年", gpslog_CALENDAR_SELECT_FIRST_YEAR, $endYY, $year);
			select_view_with_id("inputM", "月", 1, 12, $month);
			select_view_with_id("inputD", "日", 1, 31, $day);
		?>
		<?php	if (INPUT_POPUP_CALENDAR == 'YUI') { ?>
			<img src="../images/calendar.png" onclick="YahhoCal.render('inputY', 'inputM', 'inputD');">
		<?php	} else if (INPUT_POPUP_CALENDAR == 'kanaya') { ?>
			<img src="../images/calendar.png" onClick="wrtCalendar(event,document.form0.ymd1,'inputY','inputM','inputD');">
			<input type="hidden" name="ymd1" id="ymd1" value="">
		<?php	} else { ?>
			<a href="javascript:viewCalen(theMonth,'calenArea1','inputY','inputM','inputD'); void(0);"><img src="../images/calendar.png"></a>
			<span id="calenArea1" class="calenBox"></span>
		<?php	} ?>
		</div>
	</td>
</tr>
<tr>
	<td>名前</td>
	<td>
		<input class="text" type="text" name="c_name" value="<?= my_htmlspecialchars($rec['c_name']) ?>" style="width:300px;">
	</td>
</tr>
<tr>
	<td>補足説明</td>
	<td>
		<div class="block_left">
		<textarea id="c_description" name="c_description" style="width:500px;" rows="5" wrap="soft"><?= my_htmlspecialchars($rec['c_description']) ?></textarea>
		</div>
	</td>
</tr>
<tr>
	<td>GPXファイル</td>
	<td>
<?php if ($rec['c_attachFile1'] <> "") { ?>
	<p><span class="alarm_text">GPXファイルを差し替える場合のみ選択してください。</span></p>
<?php } ?>
<?php
	for ($ix=1; $ix<=1; $ix++) {
?>
		<div class="block">
		<div class="block_left">(<?= $ix ?>)</div>
		<div class="block_left">
<?php
		if ($rec['c_attachFile'.$ix] <> "") {
			attach_file_view($rec['id_account'], $rec['c_attachFile'.$ix]);
?>
		<label>
		<input type="hidden" name="filenameCurrent<?= $ix ?>" value="<?= $rec['c_attachFile'.$ix] ?>">
<?php
		}
?>
		<input type="file" size=40 name="filename<?= $ix ?>" style="button-font-size:small">
		</div>
		</div>
<?php
	}
?>
	</td>
</tr>
<tr>
	<td>写真フォルダ</td>
	<td>写真をGPSログ・マップに表示する場合、写真のフォルダを指定してください。<br>
	JPEGに書き込まれているGPS情報を使う方法と、写真の撮影時間から撮影場所を特定する方法を選択できます。<br>
	写真が多いとGPSログ・マップの表示に時間がかかります。<br>
	<?php	$calendar_folder = $_SESSION['login_friends_album_calendar_folder_'.$_SESSION['current_id']]; ?>
	<?php	if ($_SESSION['システム管理者'] == "YES") { ?>
	<a href="../tools/file-manager.php?path=<?= urlencode($calendar_folder) ?>" target="_blank" style="margin: 0 2px;"><?= $calendar_folder ?></a>
	<?php	} else { ?>
	<?= $calendar_folder ?>
	<?php	} ?>
	からの相対フォルダで指定してください。<br>
	<input class="text" type="text" name="c_photo_folder" value="<?= my_htmlspecialchars($rec['c_photo_folder']) ?>" style="width:400px;">
	<?php	if ($_SESSION['システム管理者'] == "YES" and $rec['c_photo_folder'].'' <> '') {
		$photo_folder = str_replace('//','/',$calendar_folder.'/'.$rec['c_photo_folder']);
	?>
	<br><a href="../tools/file-manager.php?path=<?= urlencode($photo_folder) ?>" target="_blank" style="margin-left: 2px;"><?= $photo_folder ?></a>
	<a href="../photo/?path=<?= urlencode($photo_folder) ?>" target="_blank" style="margin-left: 10px;">→アルバム</a>
	<?php	} ?>
	</td>
</tr>
</table>
	<input class="input_form_button" type="submit" name="登録" value="修正">
	<input class="input_form_button" type="submit" name="削除" value="削除" onClick="return delete_check();" style="margin-left:20px;">
</form>
<script>
function delete_check() {
	if (window.confirm('このデータを削除しますか？')) {
		return true;
	} else {
		return false;
	}
}
</script>
<?php
}
function select_view_with_id($name, $suffix, $first, $end, $now) {
	if ($suffix == '年') {
		if (strstr($_SERVER['HTTP_USER_AGENT'], "Chrome")) {
?>
<input type="number" id="<?= $name ?>" name="<?= $name ?>" value="<?= $now ?>" style="width:4em;"><?= $suffix ?>
<?php		} else { ?>
<script>
function YearUpDown(id, updown) {
	$("#"+id).val(Number($("#"+id).val()) + Number(updown));
}
</script>
<input type="text" class="text" id="<?= $name ?>" name="<?= $name ?>" value="<?= $now ?>" style="width:3em;"><input type="button" value="▲" style="font-size:10px;margin:0;padding:0;" OnClick="YearUpDown('<?= $name ?>',1)"><input type="button" value="▼" style="font-size:10px;margin:0;padding:0;" OnClick="YearUpDown('<?= $name ?>',-1)"><?= $suffix ?>
<?php		} ?>
<?php	} else {
		echo "<select id='".$name."' name='".$name."'>";
		for ($i=$first; $i<=$end; $i++) {
			echo "<option value='".$i."'";
			if ($i == $now) {
				echo " selected";
			}
			echo ">".$i."</option>";
		}
		echo "</select>".$suffix;
	}
}
function select_view_with_id_with_blank($name, $suffix, $first, $end, $now) {
	echo "<select id='".$name."' name='".$name."'>";
	echo "<option value=''>";
	for ($i=$first; $i<=$end; $i++) {
		echo "<option value='".$i."'";
		if ($i == $now) {
			echo " selected";
		}
		echo ">".$i."</option>";
	}
	echo "</select>".$suffix;
}
function diary_get($user_id, $id, $new_id) {
	$sql = "select * from m_schedule where id_schedule = ".$id;
	if ($new_id <> 0) {
		$sql .= " and c_delete = 111";	//仮登録
	} else {
		$sql .= " and c_delete = 0";
	}
	$sql .= " and id_account = ".$user_id;
	$rs = my_mysqli_query($sql);
	return mysqli_fetch_array($rs);
}
function select_view_options($prefix, $name, $suffix, $options, $now) {
	$option_ary = explode(",", $options);
	echo $prefix;
	echo "<select id='".$name."' name='".$name."'>";
	foreach ($option_ary as $opt) {
		echo "<option value='".$opt."'";
		if ($opt == $now) {
			echo " selected";
		}
		echo ">".$opt."</option>";
	}
	echo "</select>".$suffix;
}
?>
