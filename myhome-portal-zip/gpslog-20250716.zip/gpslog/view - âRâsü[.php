<?php
	require("__include-common.php");
	require("../account/__logincheck.php");
	if (!defined("gpslog_MARKERPOINT_SELECT")) {
		define("gpslog_MARKERPOINT_SELECT", "1,2,5,10,15,20,30,60,120");
		define("gpslog_MARKERPOINT_SELECT_DEFAULT", "10");
	}
	if ($_COOKIE['gpslog_markerPoint'].'' == '') {
		$_COOKIE['gpslog_markerPoint'] = gpslog_MARKERPOINT_SELECT_DEFAULT;
	}
	if (!defined("gpslog_PLAYSPEED_SELECT")) {
		define("gpslog_PLAYSPEED_SELECT", "1,2,5,10,20,50,100");
		define("gpslog_PLAYSPEED_SELECT_DEFAULT", "5");
	}
	if (!defined("gpslog_CHART_WIDTH")) {
		define("gpslog_CHART_WIDTH", '95%');
	}
	if (!defined("gpslog_CHART_HEIGHT")) {
		define("gpslog_CHART_HEIGHT", '400');
	}
	if (!defined("gpslog_CHART_COLOR_SPEED")) {
		define("gpslog_CHART_COLOR_SPEED", '#CD853F');
	}
	if (!defined("gpslog_CHART_COLOR_HEIGHT")) {
		define("gpslog_CHART_COLOR_HEIGHT", '#89A54E');
	}
	if (!defined("ALBUM_MAPS_PHOTO_ICON_MARKER_SIZE")) {
		define("ALBUM_MAPS_PHOTO_ICON_MARKER_SIZE", "40,40");
	}
	if (!defined("MAPS_PHOTO_MARKER_DRAGGABLE")) {
		define("MAPS_PHOTO_MARKER_DRAGGABLE", "YES");
	}
	if ($_COOKIE['gpslog_playSpeed'].'' == '') {
		$_COOKIE['gpslog_playSpeed'] = gpslog_PLAYSPEED_SELECT_DEFAULT;
	}
	if ($_GET['id'].'' <> '') {
		$id = intval($_GET['id']);
	} else {
		$id = 0;
	}
	if ($_GET['move'].'' <> '') {
		$move = intval($_GET['move']);
	} else {
		$move = -1;
	}
	if ($id == 0 and $move < 0) {
		error_exit("不正アクセス。(1)<br>", False);
	}
	if ($_GET['page'].'' <> '') {
		$page = intval($_GET['page']);
	}
	if ($_GET['row'].'' <> '') {
		$row = intval($_GET['row']);
	}
	if ($_GET['pl'].'' <> '') {
		$pageline = intval($_GET['pl']);
	}
	if ($_GET['ac'].'' <> '') {
		$ac = intval($_GET['ac']);
	}
	$con = my_mysqli_connect(_DB_SCHEMA);
	if ($id == 0) {
		if ($_SESSION['gpslog_list_sql'].'' == '') {
			error_exit("不正アクセス。(2)<br>", False);
		}
		$rs = my_mysqli_query($_SESSION['gpslog_list_sql']);
		if ($rs) {
			if (($row = mysqli_num_rows($rs)) == 0) {
				rec_not_found('データがありません。');
				return;
			}
			if ($row < $move+1) {
				rec_not_found('データがありません。');
				return;
			}
			if (!mysqli_data_seek($rs, $move)) {
				rec_not_found('データがありません。');
				return;
			}
			$rec = mysqli_fetch_array($rs);
			$id = $rec['id_gpslog'];
		}
	} else {
		$sql = "select * from m_gpslog where id_gpslog = ".$id;
		$rs = my_mysqli_query($sql);
		if (mysqli_num_rows($rs) == 0) {
			rec_not_found('データがありません。');
			return;
		}
		$rec = mysqli_fetch_array($rs);
	}
	if ($_GET['mp'].'' <> '') {
		$sql = "update m_gpslog set";
		$sql .= " c_markerpoint = '".$_GET['mp']."'";
		$sql .= " where id_gpslog = ".$id;
		$sql .= " and id_account = ".$_SESSION['current_id'];
		$ret = my_mysqli_query($sql, "更新できませんでした。");
		$rec['c_markerpoint'] = intval($_GET['mp']);
	}
	mysqli_close($con);
	$filename = $rec['c_attachFile1'];
	$filepath = ATTACH_FILE_FOLDER.$_SESSION['current_id'].'/'.$filename;
?>
<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="utf-8">
<meta name="author" content="ok.2nd">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>GPSログ View</title>
<link rel="stylesheet" href="../style/original/common.css?20131130">
<link rel="stylesheet" type="text/css" href="css/style.css">
<style>
#header {
	width: 100%;
	height: 20px;
}
#map {
	width: 100%;
	height: 500px;
}
#chart {
	width: 100%;
	margin: 5px 0 0 0;
	height: 230px;
	display: none;
}
.panel {
	font-family: Consolas, Monaco, 'Andale Mono', 'Ubuntu Mono', monospace;
	font-size: 12px;
	margin : 2px 6px;
	padding: 0;
	background: #fff;
}
.panelDate {
	font-size: 14px;
	font-weight: bold;
}
.panelPlace {
	font-size: 16px;
	font-weight: bold;
}
.timeLavel {
	display: table-cell;
	color: #f00;
	background-color: #ff8;
	opacity: 0.8;
	white-space: nowrap;
	font-size: 12px;
}
</style>
<link rel="stylesheet" href="//unpkg.com/leaflet@1.7.1/dist/leaflet.css" integrity="sha512-xodZBNTC5n17Xt2atTPuE1HxjVMSvLVW9ocqUKLsCC5CXdbqCmblAshOMAS6/keqq/sMZMZ19scR4PsZChSR7A==" crossorigin=""/>
<script src="//unpkg.com/leaflet@1.7.1/dist/leaflet.js" integrity="sha512-XQoYMqMTK8LvdxXYG3nZ448hOEQiglfqkJs1NOQV44cWnUrBc8PkAOcXy20w0vlaXaVUearIOBhiXZ5V3ynxwA==" crossorigin=""></script>
<link rel="stylesheet" href="//use.fontawesome.com/releases/v5.6.3/css/all.css"/>
<link rel="stylesheet" href="css/easy-button.css"/>
<script src="js/easy-button.js"></script>
<script src="//code.highcharts.com/highcharts.js"></script>
<script src="js/my-gpx-2.2.js"></script>
</head>
<body>
<div id="container">
	<div id="header">
	<p>
		<a class="a_view_cancel_back" href='list.php?page=<?= $page ?>&arg=session'>一覧に戻る</a>
	<?php if ($move <> -1) { ?>
		<span class="view_page"><span class="view_page_num"><?= $move+1 ?></span> / <span class="view_page_num"><?= $row ?></span></span>
		<?php if ($move <> 0) { ?>
		<a class="a_view_move" href="<?= $_SERVER['SCRIPT_NAME'] ?>?move=0&row=<?= $row ?>&page=<?= $page ?>">[←先頭]</a>
		<a class="a_view_move" href="<?= $_SERVER['SCRIPT_NAME'] ?>?move=<?= $move-1 ?>&row=<?= $row ?>&page=<?= $page ?>">[←前]</a>
		<?php } else { ?>
		<span class="view_link_off">[←先頭]</span>
		<span class="view_link_off">[←前]</span>
		<?php } ?>
		<?php if ($move < $row-1) { ?>
		<a class="a_view_move" href="<?= $_SERVER['SCRIPT_NAME'] ?>?move=<?= $move+1 ?>&row=<?= $row ?>&page=<?= $page ?>">[→次]</a>
		<a class="a_view_move" href="<?= $_SERVER['SCRIPT_NAME'] ?>?move=<?= $row-1 ?>&row=<?= $row ?>&page=<?= $page ?>">[→最後]</a>
		<?php } else { ?>
		<span class="view_link_off">[→次]</span>
		<span class="view_link_off">[→最後]</span>
		<?php } ?>
	<?php } else { ?>
		<a class="a_view_cancel_back" href='input.php' style="margin-left:10px;">新規登録</a>
	<?php } ?>
		<a class="a_update_form" href="edit.php?id=<?= $id ?>&move=<?= $move ?>&row=<?= $row ?>&cat=<?= $_GET['cat'] ?>&key=<?= urlencode($_GET['key']) ?>&sort=<?= $_GET['sort'] ?>&page=<?= $page ?>&pl=<?= $pageline ?>&ret=view&#input">[修正]</a>
		&nbsp;&nbsp;&nbsp;&nbsp;<a class="a_view_move" href="view-wadachi.php?id=<?= $id ?>&move=<?= $move ?>&row=<?= $row ?>&page=<?= $page ?>&pl=<?= $pageline ?>&cat=<?= $_GET['cat'] ?>&key=<?= urlencode($_GET['key']) ?>&sort=<?= $_GET['sort'] ?>">[轍版]</a>
	</p>
	</div>
	<div id="map"></div>
	<div id="chart"></div>
</div>
<script>
	var request = new XMLHttpRequest();
	request.open('get', '<?= $filepath ?>', false);
	request.send(null);
	gpx2map(request.responseText, false, '<?= $rec['c_name'] ?>', 230, 32);
</script>
</body>
</html>
