<?php
	require("__include-common.php");
	require("../account/__logincheck.php");
//	require("../account/__logincheck_write_permit.php");
	ini_set("memory_limit", FILE_UPLOAD_MEMORY_LIMIT);		//メモリサイズ
	ini_set("max_execution_time", FILE_UPLOAD_MAX_EXECUTION_TIME);	//最大実行時間
	if ($_POST) {
// *********************************************************************************
// * max_execution_time
// * post_max_size
// * upload_max_filesizeを越えるとisset($_POST['登録'])がTrueにならない。
// *********************************************************************************
		check_post_account($_POST['login_id'], $_POST['current_id']);
		post_done_proc();
	} else {
		html_header(HTML_TITLE, '', '', '');
		if (gpslog_PAGE_HEADER == 'YES') {
			page_header();
		} else {
			page_header_return_index();
		}
		input_form();
		page_footer();
		html_footer();
	}
	exit();
?>
<?php
function post_done_proc() {
	if ($_POST['user_id']."" <> "") {
		$user_id = $_POST['user_id'];
	} else {
		error_exit("不正アクセス：ユーザーIDなし", True);
	}
	if (check_permit_id($_SESSION['login_id'], $user_id) != "w") {
		error_exit("不正アクセス：書き込み権限がありません。", True);
	}
	$con = my_mysqli_connect(_DB_SCHEMA);
	if ($id == 0) {
		$sql = "insert into m_gpslog ";
		$sql .= "(id_account";
		$sql .= ", id_category";
		$sql .= ", c_photo_folder";
		$sql .= ", c_registtime";
		$sql .= ", c_updatetime";
		$sql .= ") values ";
		$sql .= "( '".$user_id."'";
		$sql .= ", '".$_POST['id_category']."'";
		$sql .= ", '".str_replace("\\\\",'/',post_to_mysql("c_photo_folder"))."'";
		$sql .= ", '".date("Y/m/d H:i:s")."'";
		$sql .= ", '".date("Y/m/d H:i:s")."'";
		$sql .= ")";
		$ret = my_mysqli_query($sql, "登録できませんでした。");
	}
	// ****** 添付ファイル ******
	if ($id == 0) {
		$id = my_mysqli_insert_id();	//直近のINSERTクエリによりAUTO_INCREMENTカラム用に生成されたIDを取得
	}
	$sw = False;
	$sqlupd = "";
	// ***** ファイルのアップロード *****
	$attachFile = file_upload("filename1", $id, ATTACH_FILE_FOLDER, $user_id);
	if ($attachFile <> "") {
		if ($sw) {
			$sqlupd .= ",";
		}
		$sqlupd .= " c_attachFile1 = '".$attachFile."'";
		$sw = True;
	}
	if ($sw) {
		$sql = "update m_gpslog set";
		$sql .= $sqlupd;
		$sql .= " where id_gpslog = ".$id;
		$sql .= " and id_account = '".$user_id."'";
			//echo $sql;
			//exit;
		$ret = my_mysqli_query($sql, "アップロードファイル名DB登録失敗。");
	}
	mysqli_close($con);
	redirect("view-wadachi.php?".$_SERVER['QUERY_STRING']."&mode=new&id=".$id);
//	redirect("view.php?".$_SERVER['QUERY_STRING']."&mode=new&id=".$id);
}
function input_form() {
	$id = 0;
	$con = my_mysqli_connect(_DB_SCHEMA);
?>
<div class="input_form">
<h3><?= $_SESSION['current_handle'] ?> 新規登録<a class="a_cancel_back" href='list.php?arg=session'>戻る</a></h3>
<script>
function formCheck(form) {
	if (form0.filename1.value == '') {
		window.alert('アップロードするファイルを指定してください。');
		return false;		// 送信を中止
	}
	return true;	// 送信を実行
}
</script>
<form name="form0" method="POST" action="<?= $_SERVER['SCRIPT_NAME'] ?>?<?= $_SERVER['QUERY_STRING'] ?>" enctype="multipart/form-data" onSubmit="return formCheck(this)">
	<input type="hidden" name="user_id" value="<?= $_SESSION['current_id'] ?>">
	<input type="hidden" name="update_id" value="<?= $id ?>">
	<input type="hidden" name="login_id" value="<?= $_SESSION['login_id'] ?>">
	<input type="hidden" name="current_id" value="<?= $_SESSION['current_id'] ?>">
<table>
<tr>
	<td nowrap>カテゴリ</td>
	<td nowrap>
<?php
	$sqlsel = "select * from m_category where id_account = '".$_SESSION['current_id']."'";
	$sqlsel = $sqlsel." and c_delete = 0";
	$sqlsel = $sqlsel." order by c_categoryDisplayOrder";
	$rs_sel = my_mysqli_query($sqlsel);
?>
	<select name="id_category">
<?php
		if ($id == 0) {
			$category = (int)$_GET['cat'];
		} else {
			$category = $rec['id_category'];
		}
		while ($rec_sel=mysqli_fetch_array($rs_sel)) {
?>
		<option value="<?= $rec_sel['id_category'] ?>"<?= $rec_sel['id_category'] == $category ? " selected" : "" ?>><?= my_htmlspecialchars($rec_sel['c_categoryName']) ?>
<?php
		}
?>
	</select>
	</td>
</tr>
<tr>
	<td>GPXファイル</td>
	<td><p><span class="alarm_text">GPX形式のファイルをアップロードしてください。</span></p>
		<div class="block">
		<div class="block_left">
		<input type="file" size=40 name="filename1" style="button-font-size:small">
		</div>
		</div>
	</td>
</tr>
<tr>
	<td>写真フォルダ</td>
	<td>写真をGPSログ・マップに表示する場合、写真のフォルダを指定してください。<br>
	JPEGに書き込まれているGPS情報を使う方法と、写真の撮影時間から撮影場所を特定する方法を選択できます。<br>
	写真が多いとGPSログ・マップの表示に時間がかかります。<br>
	<?php	$calendar_folder = $_SESSION['login_friends_album_calendar_folder_'.$_SESSION['current_id']]; ?>
	<?php	if ($_SESSION['システム管理者'] == "YES") { ?>
	<a href="../tools/file-manager.php?path=<?= urlencode($calendar_folder) ?>" target="_blank" style="margin: 0 2px;"><?= $calendar_folder ?></a>
	<?php	} else { ?>
	<?= $calendar_folder ?>
	<?php	} ?>
	からの相対フォルダで指定してください。<br>
	<input class="text" type="text" name="c_photo_folder" value="" style="width:400px;">
	</td>
</tr>
</table>
	<input class="input_form_button" type="submit" name="登録" value="登録">
</form>
<?
}
?>
