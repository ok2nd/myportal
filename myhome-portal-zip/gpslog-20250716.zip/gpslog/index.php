<?php
	header("Location: list.php?".$_SERVER['QUERY_STRING']);
?>
