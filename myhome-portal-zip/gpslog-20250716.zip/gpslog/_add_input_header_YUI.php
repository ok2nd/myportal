<link rel="stylesheet" href="../style/YahhoCal.css" />
<script src="../scripts/YahhoCal.js"></script>
<script>
	//YahhoCal.loadYUI();				// ネットアクセスできないとWAIT状態になる
	YahhoCal.loadYUI("/_myhome/scripts/yui");	// Yahoo! UI Library(YUI)をローカルサーバから読み込む
</script>
<style>
#map3d img { cursor: crosshair; }
</style>
