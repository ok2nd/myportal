
<!--
	**********  ここからコピー  *********************************
	＝＞	github/leaflet/-open-list.html
-->

<table id="gpslog_list_table">
<thead>
<tr>
	<th>日付</th>
	<th>△</th>
	<th>行先</th>
	<th class="list-data">距離<br>(km)</th>
	<th class="list-data">所要<br>時間</th>
	<th class="list-data">出発<br>時間</th>
	<th class="list-data">最高<br>地点</th>
	<th class="list-data">標高<br>差</th>
</tr>
</thead>
<tbody>
<?php
	mysqli_data_seek($rs, $startline);			//テーブル内の指定行に移動
	$line = $startline;					//$lineに$startlineを代入
	$old_date = "";
	while ($rec=mysqli_fetch_array($rs) and $line<=$endline) {
?>
<?php
		if ($line <> $startline) {
?>
	<a name="id_<?= $rec['id_gpslog'] ?>"></a>
	</td>
</tr>
<?php
		}
?>
<tr>
	<?php if (1 == 1) { // *** 全て日付を表示 *** ?>
	<?php // if ($old_date <> $rec['c_date']) { ?>
	<td class="gpslog_list_table_day" class="list-ymd">
<?php
		$date = $rec['c_date'];
		$year = date_from_mysql("Y", $date);
		$month = date_from_mysql("n", $date);
		$day = date_from_mysql("d", $date);
		$day_week = mb_substr("日月火水木金土", date_from_mysql("w", $date), 1);
		$holiday = holiday_check($year, $month, $day);
		if ($holiday) {
			$day_class = 'holiday';
			$day_week_view = "<a title='".$holiday."' class='dayweek_".$day_class."'>".$day_week."</a>";
		} else {
			if ($day_week == '日') {
				$day_class = "sunday";
			} elseif ($day_week == '土') {
				$day_class = "saturday";
			} else {
				$day_class = "weekday";
			}
			$day_week_view = "<span class='dayweek_".$day_class."'>".$day_week."</span>";
		}
?>
		<p><?= date_from_mysql("Y-m-d", $date) ?><?= $day_week_view ?></p>
	</td>
	<?php } else { ?>
	<td class="gpslog_list_table_day_cont">
		<br>
	</td>
	<?php } ?>
	<?php $old_date = $rec['c_date'] ?>
	<td class="list-category">
	<span class="category" style="background-color:<?= $rec['c_categoryDisplayColor'].'' <> '' ? $rec['c_categoryDisplayColor'] : '#b0b0b0' ?>"><?= $rec['c_categoryName'] ?></span>
	</td>
	<td class="list-name">
	<p>
<?php
	if ($rec['c_time1']."" <> "" || $rec['c_time2']."" <> "") {
		echo '<span class="calendar_time">';
		echo sch_time_format($rec['c_time1'], $rec['c_time2'])."&nbsp;";
		echo '</span>';
	}
	if ($rec['c_iconImage'] <> "") {
		echo "<img src='".IMAGES_FOLDER."/".$rec['c_iconImage']."'/>";
	}
// ***************************************
//				↓↓↓↓　　　& query_from_http_arg_pool($http_arg)
// ***************************************
?>
	<a name="id_<?= $rec['id_gpslog'] ?>" target="_blank" class="title" href='view-open-route.html?gpx=<?= $rec['c_attachFile1'] ?>&name=<?= $rec['c_name'] ?>'><?php
		if ($rec['c_name'] == '') {
			echo NO_SUBJECT_INPUT_MARK;
		} else {
			echo my_htmlspecialchars($rec['c_name']);
		}
	?></a>
	<?php
		if ($rec['c_name'] <> '') {
			?></p><p><?php
		}
	?>
	</td>
	<td class="list-data"><?= number_format($rec['c_distance'],1) ?></td>
	<td class="list-data"><?= Left(date_from_mysql('H:i:s', $rec['c_taketime']),5) ?></td>
	<td class="list-data"><?= Left(date_from_mysql('H:i:s', $rec['c_starttime']),5) ?></td>
	<td class="list-data"><?= $rec['c_height_max'] ?><br></td>
<!--
	<td class="list-data"><?= $rec['c_height_min'] ?><br></td>
-->
	<td class="list-data"><?= $rec['c_height_max'] - $rec['c_height_min'] ?><br></td>

<?php
		$line++;
	}
?>
	</td>
</tr>
<tbody>
	</table>

<!--
	**********  ここまで  *********************************
-->

<?php
	jquery_highlight('.memo_body', keystr_and_or($keystring));
?>
