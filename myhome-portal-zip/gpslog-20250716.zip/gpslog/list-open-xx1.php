<?php
	require("__include-common.php");
	require("../account/__logincheck.php");
	require("../__common__/include-common-mp-list-open.php");
	require("../calendar/_my_calendar.php");

	$table_name_view = "v_gpslog";
	$table_name = "m_gpslog";
	$id_item = "id_gpslog";
	$must_item = "c_name";
	$arg_pool_prefix = "calendar_schedule";
	$mp_list_arg = array();
	$mp_list_arg['account_id']		= $_SESSION['current_id'];
	$mp_list_arg['table_name_view']		= "v_gpslog";
	$mp_list_arg['table_name_edit']		= "v_gpslog";
	$mp_list_arg['table_name_update']	= "m_gpslog";
	$mp_list_arg['id_item']			= "id_gpslog";
	$mp_list_arg['must_item']		= "c_name";
	$mp_list_arg['add_list']		= "no";
	$mp_list_arg['add_row_use']		= "no";


	$mp_list_arg['input_new']		= "no";
	$mp_list_arg['edit_list_all']		= "no";


//	$mp_list_arg['add_filter']		= "../calendar/list-my-add-filter.php";
	$mp_list_arg['template_view']		= "list-open-my-template-hyokosa.php";

	$item_tbl = array();
	$item_tbl[] = array(	"表示名"=>"日付",	"列名"=>"c_date",
				"type"=>"date", "firstYear"=>_CALENDAR_SELECT_FIRST_YEAR, "toYear"=>10, "ime-mode"=>"disabled",
				"date_http_arg_y"=>"selY", "date_http_arg_m"=>"selM", "date_http_arg_d"=>"selD");
//	$item_tbl[] = array(	"表示名"=>"カテゴリ",	"列名"=>"id_category", "http_arg_GET名"=>"cat",
//				"type"=>"select", "参照テーブル"=>"m_category", "参照テーブル表示列"=>"c_categoryName",
//				"参照テーブル表示順"=>"c_categoryDisplayOrder");
	$item_tbl[] = array(	"表示名"=>"名前",	"列名"=>"c_name",
				"type"=>"text", "size"=>20, "ime-mode"=>"active", "文字検索"=>"Y");
//	$item_tbl[] = array(	"表示名"=>"補足説明",	"列名"=>"c_description",
//				"type"=>"textarea", "cols"=>30, "rows"=>3, "文字検索"=>"Y");
//	$item_tbl[] = array(	"表示名"=>"写真フォルダ",	"列名"=>"c_photo_folder",
//				"type"=>"text", "size"=>50, "ime-mode"=>"active", "filePath"=>"Y");
	$order_tbl = array();
	$order_tbl[] = array(   "表示名"=>"登録最新順", "get_order_name"=>"new",
				"order_by"=>"id_gpslog desc");
//	$order_tbl[] = array(   "表示名"=>"日付順(昇順)", "get_order_name"=>"date_a",
//				"order_by"=>"c_date asc, c_starttime asc");
//	$order_tbl[] = array(   "表示名"=>"日付順(降順)", "get_order_name"=>"date_d",
//				"order_by"=>"c_date desc, c_starttime asc");

	$http_arg = array();
	$http_arg['pl'] = PAGE_LINE_DEFAULT;		// mp_list 必須
	$http_arg['sort'] = '';				// mp_list 必須
	$http_arg['cat'] = '';				// mp_list 必須
	$http_arg['key'] = '';				// mp_list 必須
	$http_arg['selY'] = '';
	$http_arg['selM'] = '';
	$http_arg['selD'] = '';
	$http_arg['toY'] = '';
	$http_arg['toM'] = '';
	$http_arg['toD'] = '';
	$http_arg['y'] = '';
	$http_arg['m'] = '';
/*
	if (isset($_POST['登録'])) {
		check_post_account($_POST['login_id'], $_POST['current_id']);
		mp_list_update($mp_list_arg, $item_tbl, $order_tbl, $http_arg);
	} else {
		_GET_to_http_arg_pool($http_arg, $arg_pool_prefix, 'selY,selM,selD,toY,toM,toD,sort,key,pl,y,m');
		html_header(HTML_TITLE);
*/
?>
<!DOCTYPE html>
<!--

	コピー ＝＞	github/leaflet/-open-list.html

-->
<html lang="ja">
<head>
<meta charset="utf-8">
<meta name="author" content="ok.2nd">
<meta name="description" content="GPSログ">
<link rel="stylesheet" href="../style/original/common.css?20131130">
<!--
<link rel="stylesheet" type="text/css" href="//cdn.datatables.net/v/dt/dt-1.10.24/datatables.min.css"/>
-->
<style>
body {
	padding: 8px 1px;
}
.list-ymd {
	white-space: nowrap;
}
.list-category {
	white-space: nowrap;
}
.gpslog_list_table_day {
	white-space: nowrap;
}
.category {
	font-size: 10px;
	color: #fff;
	padding: 2px;
}
.list-name {
	width: 240px;;
}
.list-data {
	text-align: right;
	padding:0 4px;
	white-space: nowrap;"
}
</style>
<script type="text/javascript" src="//code.jquery.com/jquery-3.5.1.js"></script>
<!-- <script src="../scripts/ok2nd.js"></script> -->
<link rel="shortcut icon" href="../images/favicon/house_red.ico" type="image/ico">
<link rel="icon" href="../images/favicon/house_red.ico" type="image/ico">
<title>MyHome GPSログ</title>
</head>
<body>
<div id="page_body">
<?php
		if (gpslog_PAGE_HEADER == 'YES') {
	//		page_header();
		} else {
	//		page_header_return_index();
		}
	//	contents_header();
	//	if ($_GET['edit'] == "y") {
	//		mp_list_edit($mp_list_arg, $item_tbl, $order_tbl, $http_arg);
	//	} else {
			$_SESSION['gpslog_list_sql'] = mp_list_view($mp_list_arg, $item_tbl, $order_tbl, $http_arg);
	//	}
	//	page_footer();

?>
<script type="text/javascript" src="//cdn.datatables.net/v/dt/dt-1.10.24/datatables.min.js"></script>
<script type="text/javascript" src="//cdn.jsdelivr.net/g/mark.js(jquery.mark.min.js),datatables.mark.js"></script>
<script type="text/javascript">
$(function() {
	var table = $('#gpslog_list_table').DataTable({
		language: {	// 日本語化
			url: "//cdn.datatables.net/plug-ins/9dcbecd42ad/i18n/Japanese.json"
		},
		paging: false,		// ページングしない。
		ordering: true,
		"aaSorting": [[ 0, "desc" ]],	// 1列目で降順に並び替え
		mark: true		// 検索文字列ハイライト (by mark.js)
	});
});
</script>
<div style="clear:left;height:100px;"></div>
<?php
	//	html_footer();
//	}
//	exit();
?>
</body>
</html>
