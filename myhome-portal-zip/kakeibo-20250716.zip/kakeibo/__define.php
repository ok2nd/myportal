<?php
	if (defined("HTML_TITLE_kakeibo")) {
		define("HTML_TITLE", HTML_TITLE_kakeibo);
	} else {
		define("HTML_TITLE", "MyHome 預貯金管理");
	}
	define("SESSION_PREFIX", "kakeibo");

	if (defined("_DB_SCHEMA_kakeibo")) {
		define("_DB_SCHEMA", _DB_SCHEMA_kakeibo);
	} else {
		define("_DB_SCHEMA", "_db_kakeibo");
	}

	define("PAGE_LINE_SELECT", "5,10,20,50,100,1000");	//頁内に表示する行数
	define("PAGE_LINE_DEFAULT", "100");			//頁内に表示する行数（デフォルト）
?>
