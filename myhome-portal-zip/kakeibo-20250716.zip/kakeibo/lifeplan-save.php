<?php
	require("__include-common.php");
	require("../account/__logincheck.php");
	if (check_permit_id($_SESSION['login_id'], $_SESSION['current_id']) != "w") {
		echo '書き込み権限なし';
		exit;
	}
	if ($_POST['name'].'' == '') {
		echo 'タイトルなし';
		exit;
	}
	$updateD = date("Y/m/d H:i:s");
	$con = my_mysqli_connect(_DB_SCHEMA);
	$sql = "select id_num from m_lifeplan";
	$sql .= " where id_account = " . $_SESSION['current_id'] . " and id_num = " . post_to_mysql('id');
	$rs = my_mysqli_query($sql);
	if ($rs) {
		$row = mysqli_num_rows($rs);
		if ($row <> 0) {
			$sql = "update m_lifeplan";
			$sql .= " set c_name = '" . post_to_mysql('name') . "'";
			$sql .= ", c_json = '" . post_to_mysql('json') . "'";
			$sql .= ", c_updatetime = '" . $updateD . "'";
			$sql .= " where id_account = " . $_SESSION['current_id'] . " and id_num = " . post_to_mysql('id');
		} else {
			$sql = "insert into m_lifeplan (";
			$sql .= "id_account, id_num, c_name, c_json";
			$sql .= ", c_updatetime, c_registtime)";
			$sql .= " values (";
			$sql .= "'" . $_SESSION['current_id'] . "'";
			$sql .= ", '" . post_to_mysql('id') . "'";
			$sql .= ", '" . post_to_mysql('name') . "'";
			$sql .= ", '" . post_to_mysql('json') . "'";
			$sql .= ", '" . $updateD . "'";
			$sql .= ", '" . $updateD . "'";
			$sql .= ")";
		}
		echo 'OK';
	}
	mysqli_query($con, $sql);
	mysqli_close($con);
?>
