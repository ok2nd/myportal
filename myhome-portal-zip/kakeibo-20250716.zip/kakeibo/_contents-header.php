<?php
function contents_header() {
	$menu_item = array();
	$menu_item[] = array("href"=>"list.php", "query"=>"arg=session", "name"=>"預貯金一覧");
	$menu_item[] = array("href"=>"cross.php", "name"=>"クロス集計");
	$menu_item[] = array("href"=>"ginkou.php", "name"=>"金融機関一覧");
	$menu_item[] = array("href"=>"lifeplan.php", "name"=>"ライフプラン");
?>
<div id="contents_header">
<?php
	contents_menu($menu_item);
//	if (basename($_SERVER['SCRIPT_FILENAME']) != 'lifeplan.php') {
		change_account_menu();
//	}
?>
</div><!-- id="contents_header" -->
<?php
}
?>
