<?php
function add_where_create($http_arg) {
	if ($_SESSION['chokin_kaiyakuJotai'] <> 'on') return '';
	$add_where = "id_mankitype = '40'";
	$add_where .= " and current_date > c_mankiYMD";
	return ($add_where);
}
function add_my_filter($http_arg) {
}
?>
