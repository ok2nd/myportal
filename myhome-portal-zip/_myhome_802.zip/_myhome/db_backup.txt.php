<?
/*

:■■■■■ アクセスログデータ一括削除 ( _db_ )
mysql -u root -pパスワード
use _db_account;
truncate table z_loginlog;
exit

:■■■■■ バックアップ ( _db_ )
mysqldump -u root -pパスワード _db_account > "D:\xampp\htdocs\_myhome\z_db_backup\_db_account.bk.txt"
mysqldump -u root -pパスワード _db_index > "D:\xampp\htdocs\_myhome\z_db_backup\_db_index.bk.txt"
mysqldump -u root -pパスワード _db_calendar > "D:\xampp\htdocs\_myhome\z_db_backup\_db_calendar.bk.txt"
mysqldump -u root -pパスワード _db_memo > "D:\xampp\htdocs\_myhome\z_db_backup\_db_memo.bk.txt"
mysqldump -u root -pパスワード _db_zid_mgr_b > "D:\xampp\htdocs\_myhome\z_db_backup\_db_zid_mgr_b.bk.txt"
mysqldump -u root -pパスワード _db_zid_mgr_a > "D:\xampp\htdocs\_myhome\z_db_backup\_db_zid_mgr_a.bk.txt"
mysqldump -u root -pパスワード _db_bbs > "D:\xampp\htdocs\_myhome\z_db_backup\_db_bbs.bk.txt"
mysqldump -u root -pパスワード _db_rss > "D:\xampp\htdocs\_myhome\z_db_backup\_db_rss.bk.txt"
mysqldump -u root -pパスワード _db_chat > "D:\xampp\htdocs\_myhome\z_db_backup\_db_chat.bk.txt"
mysqldump -u root -pパスワード _db_kakeibo > "D:\xampp\htdocs\_myhome\z_db_backup\_db_kakeibo.bk.txt"
mysqldump -u root -pパスワード _db_study > "D:\xampp\htdocs\_myhome\z_db_backup\_db_study.bk.txt"
mysqldump -u root -pパスワード _db_abook > "D:\xampp\htdocs\_myhome\z_db_backup\_db_abook.bk.txt"
mysqldump -u root -pパスワード _db_diary > "D:\xampp\htdocs\_myhome\z_db_backup\_db_diary.bk.txt"
mysqldump -u root -pパスワード _db_guide > "D:\xampp\htdocs\_myhome\z_db_backup\_db_guide.bk.txt"
mysqldump -u root -pパスワード _db_sticky > "D:\xampp\htdocs\_myhome\z_db_backup\_db_sticky.bk.txt"
mysqldump -u root -pパスワード _db_photo > "D:\xampp\htdocs\_myhome\z_db_backup\_db_photo.bk.txt"
mysqldump -u root -pパスワード _db_svg > "D:\xampp\htdocs\_myhome\z_db_backup\_db_svg.bk.txt"
mysqldump -u root -pパスワード _db_draw > "D:\xampp\htdocs\_myhome\z_db_backup\_db_draw.bk.txt"
mysqldump -u root -pパスワード _db_psketch > "D:\xampp\htdocs\_myhome\z_db_backup\_db_psketch.bk.txt"
mysqldump -u root -pパスワード _db_email > "D:\xampp\htdocs\_myhome\z_db_backup\_db_email.bk.txt"
mysqldump -u root -pパスワード _db_gpslog > "D:\xampp\htdocs\_myhome\z_db_backup\_db_gpslog.bk.txt"

*/
?>
