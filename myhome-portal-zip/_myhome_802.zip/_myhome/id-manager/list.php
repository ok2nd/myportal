<?php
	require("__include-common.php");
	require("../account/__logincheck.php");
	require("__include-im-login.php");
	require("im-logincheck.php");
	require("../__common__/include-common-mp-list.php");
	require("_include_idpass.php");

	$table_name = "m_pass";

	$mp_list_arg = array();
	$mp_list_arg['account_id']	= $_SESSION['current_id'];
	$mp_list_arg['table_name_view']		= "v_pass";
	$mp_list_arg['table_name_edit']		= "v_pass";
	$mp_list_arg['table_name_update']	= "m_pass";
	$mp_list_arg['id_item']		= "id_pass";
	$mp_list_arg['must_item']	= "c_subject";
	$mp_list_arg['add_filter']	= "";
	$mp_list_arg['template_view']	= "list-my-template.php";
	$mp_list_arg['edit_list_all']	= "no";		// default "yes"
	$mp_list_arg['edit_button_item'] = "c_subject";	//修正ボタン表示項目
	$mp_list_arg['use_privacy']	= "yes";

	$item_tbl = array();
	$item_tbl[] = array(	"表示名"=>"カテゴリ",	"列名"=>"id_category", "http_arg_GET名"=>"cat",
				"type"=>"select", "参照テーブル"=>"m_category", "参照テーブル表示列"=>"c_categoryName",
				"filter_type"=>"radio",
				"参照テーブル表示順"=>"c_categoryDisplayOrder", "参照テーブル表示色"=>"c_categoryDisplayColor");
	$item_tbl[] = array(	"表示名"=>"表題",	"列名"=>"c_subject",
				"type"=>"text", "size"=>20, "ime-mode"=>"active", "文字検索"=>"Y");
	$item_tbl[] = array(	"表示名"=>"メモ",	"列名"=>"c_body",
				"type"=>"textarea", "cols"=>20, "rows"=>2, "文字検索"=>"Y");
	$item_tbl[] = array(	"表示名"=>"URL",	"列名"=>"c_homepageUrl",
				"type"=>"text", "size"=>20, "ime-mode"=>"inactive");
	for ($ix=1; $ix<=ID_MANAGER_ITEM_NUMBER; $ix++) {
		$item_tbl[] = array(	"表示名"=>"項目1",	"列名"=>"c_item".$ix,
					"type"=>"text", "size"=>20, "ime-mode"=>"active");
	}
	$order_tbl = array();
	$order_tbl[] = array(   "表示名"=>"カテゴリ順", "get_order_name"=>"cat",
				"order_by"=>"c_categoryDisplayOrder, id_category, c_subject");	/* default */
	$order_tbl[] = array(   "表示名"=>"タイトル順", "get_order_name"=>"subject",
				"order_by"=>"c_subject");
	$order_tbl[] = array(   "表示名"=>"登録最新順", "get_order_name"=>"new",
				"order_by"=>"id_pass desc");

	$http_arg = array();

	$http_arg['pl'] = PAGE_LINE_DEFAULT;		// mp_list 必須
	$http_arg['sort'] = '';				// mp_list 必須
	$http_arg['cat'] = '';				// mp_list 必須
	$http_arg['key'] = '';				// mp_list 必須

	if (isset($_POST['登録'])) {
		check_post_account($_POST['login_id'], $_POST['current_id']);
		mp_list_update($mp_list_arg, $item_tbl, $order_tbl, $http_arg);
	} else {
		_GET_to_http_arg_pool($http_arg, $table_name, 'sort,key,pl');
		if ($_GET['scroll'] <> '') {
			html_header(HTML_TITLE, '', '', ' onLoad="window_scroll('.$_GET['scroll'].')"');
		} else {
			html_header(HTML_TITLE);
		}
		page_header();
		contents_header();
		if ($_GET['edit'] == "y") {
			mp_list_edit($mp_list_arg, $item_tbl, $order_tbl, $http_arg);
		} else {
			mp_list_view($mp_list_arg, $item_tbl, $order_tbl, $http_arg);
		}
		page_footer();
		html_footer();
	}
	exit();
