<?php
	require("__include-common.php");
	require("../account/__logincheck.php");
	require("__include-im-login.php");
	require("im-logincheck.php");
	require("_include_idpass.php");
	html_header(HTML_TITLE);
?>
<script src="../scripts/zeroclipboard/ZeroClipboard-ok2nd.js"></script>
<script>
function clipSetBtn(id, text) {
	var clip = new ZeroClipboard.Client();
	clip.setText(text);
	clip.glue('button'+id);
}
</script>
<?php
	$con = my_mysqli_connect(_DB_SCHEMA);
	$sql = "select * from v_pass where id_pass = '" . $_GET['id'] . "'";
	$sql .= " and id_account = '" . $_SESSION['current_id'] . "'";
	$sql .= " and c_delete = 0 ";
	if ($_SESSION['current_id'] != $_SESSION['login_id']) {
		$sql .= " and c_privacy = 0";
	}
	$rs = my_mysqli_query($sql);
	$row = mysqli_num_rows($rs);
	if ($row == 0) {
		echo "レコードがみつかりません。";
		exit;
	}
	if ($rec = mysqli_fetch_array($rs)) {
?>
		<div id="view_idpass_body">
		<p id="view_idpass_subject"><?= my_htmlspecialchars($rec['c_subject']) ?></p>
<?php
		id_pass_view($rec, $ix);
?>
		<p class="id_manager_body"><?= ins_atag_br($rec['c_body']) ?></p>
		</div>
<?php
	}
	mysqli_close($con);
	html_footer();
?>
