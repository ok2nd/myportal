<?php
	require("__include-common.php");
	require("../account/__logincheck.php");
	require("__include-im-login.php");

	if (isset($_POST['ログイン'])) {
		post_done_proc();
	} else {
		html_header(HTML_TITLE, '', '', ' onload="document.form0.password.focus()"');
		page_header(False);
		input_form();
		page_footer();
		html_footer();
	}
	exit();
?>
<?php
function input_form() {
?>
<div id="im_login_body">
	<form name="form0" method="POST" action="<?= $_SERVER['SCRIPT_NAME'] ?>">
	<table>
	<tr>
		<td>ID管理パスワード：</td>
		<td><input class="password" type="password" name="password" style="width:100px;"></td>
	</tr>
	<tr>
		<td><br></td>
		<td><input type="submit" name="ログイン" value="ログイン"></td>
	</tr>
	</table>
	</form>
<?php if ($_SESSION['_id_mgr_logincheck'] <> "OK") { ?>
	<p class="err_msg"><?= $_SESSION['_id_mgr_logincheck'] ?></p>
</div>
<?php } ?>
<?php
	return;
}
function post_done_proc() {
	setcookie("login_account_id_mgr_pass", "", time() + IDMGR_COOKIE_EXPIRE, MY_SESSION_PATH);			// クリア
	$password = my_hash(Trim($_POST['password']));
	$_SESSION['_id_mgr_logincheck'] = id_mgr_account_login($_SESSION['login_id'], $password, $_SESSION['current_id']);
	if ($_SESSION['_id_mgr_logincheck'] <> "OK") {
		redirect ($_SERVER['SCRIPT_NAME']);
	}
	setcookie("login_account_id_mgr_pass", $password, time() + IDMGR_COOKIE_EXPIRE, MY_SESSION_PATH);
	if ($_SESSION['url_id_manager'] == "" or $_SESSION['url_id_manager'] == "login.php") {
		redirect("../id-manager/list.php");
	} else {
		redirect($_SESSION['url_id_manager']);
	}
	return;
}
?>
