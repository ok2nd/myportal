<?php
if ($_SERVER['QUERY_STRING'] <> "") {
	$_SESSION['url_id_manager'] = $_SERVER['SCRIPT_NAME'] . "?" . $_SERVER['QUERY_STRING'];
} else {
	$_SESSION['url_id_manager'] = $_SERVER['SCRIPT_NAME'];
}

if ($_SESSION['_id_mgr_logincheck'] <> "OK") {
	if ($_COOKIE['login_account_id_mgr_pass'] <> "") {
		$password = $_COOKIE['login_account_id_mgr_pass'];
		$_SESSION['_id_mgr_logincheck'] = id_mgr_account_login($_SESSION['login_id'], $password, $_SESSION['current_id']);
		if ($_SESSION['_id_mgr_logincheck'] <> "OK") {
			redirect("../id-manager/im-login.php");
		}
	} else {
		redirect("../id-manager/im-login.php");
	}
}
?>
