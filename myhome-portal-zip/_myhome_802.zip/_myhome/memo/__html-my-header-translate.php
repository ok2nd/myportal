<meta charset="utf-8">
<meta name="author" content="ok.2nd">
<meta name="description" content="Memo">
<meta name="keywords" content="memo">
<script src="../scripts/jquery.js"></script>
<link rel="stylesheet" href="<?= _STYLE_SHEET_FOLDER_COMMON ?>/common.css?20131130">
<link rel="stylesheet" href="<?= _STYLE_SHEET_BUTTON ?>">
<link rel="stylesheet" href="<?= _STYLE_SHEET_FOLDER ?>/mp-list.css?20130525">
<link rel="stylesheet" href="<?= _STYLE_SHEET_FOLDER ?>/memo.css?20131020">
<script src="http://www.google.com/jsapi"></script>
<script>
google.load("language", "1");
</script>