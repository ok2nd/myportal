<?php
	require("__include-common.php");
	require("../account/__logincheck.php");
//	require("../account/__logincheck_write_permit.php");
	ini_set("memory_limit", FILE_UPLOAD_MEMORY_LIMIT);		//メモリサイズ
	ini_set("max_execution_time", FILE_UPLOAD_MAX_EXECUTION_TIME);	//最大実行時間
	if ($_POST) {
// *********************************************************************************
// * max_execution_time
// * post_max_size
// * upload_max_filesizeを越えるとisset($_POST['登録'])がTrueにならない。
// *********************************************************************************
		check_post_account($_POST['login_id'], $_POST['current_id']);
		post_done_proc();
	} else {
		if (MEMO_SUBJECT_USE <> 'YES') {
			html_header(HTML_TITLE, '', '', ' onload="document.form0.c_memo.focus()"');
		} else {
			html_header(HTML_TITLE, '', '', ' onload="document.form0.c_subject.focus()"');
		}
		page_header();
		input_form();
		page_footer();
		html_footer();
	}
	exit();
?>
<?php
function post_done_proc() {
	if ($_POST['user_id']."" <> "") {
		$user_id = $_POST['user_id'];
	} else {
		error_exit("不正アクセス：ユーザーIDなし", True);
	}
	if (check_permit_id($_SESSION['login_id'], $user_id) != "w") {
		error_exit("不正アクセス：書き込み権限がありません。", True);
	}
	if ($_POST['update_id']) {
		if (!is_numeric($_POST['update_id'])) {
			error_exit("不正アクセス", True);
		}
		$id = intval($_POST['update_id']);
	} else {
		$id = 0;
	}
	if (isset($_POST['削除'])) {
		//	if ($_POST['削除する'] <> "YES") {
		//		error_exit("削除するにチェックしてください。", True);
		//	}
	}
		/*	// 件名なし許可 
		elseif ($_POST['c_subject'] == "") {
			error_exit("件名なし", True);
		}
		*/
	$con = my_mysqli_connect(_DB_SCHEMA);
	if ($id == 0) {
		$sql = "insert into m_memo ";
		$sql .= "(id_account";
		$sql .= ", id_category";
		if (MEMO_SUBJECT_USE == 'YES') {
			$sql .= ", c_subject";
		}
		$sql .= ", c_memo";
		if ($_SESSION['current_id'] == $_SESSION['login_id']) {
			$sql .= ", c_privacy";
		}
		$sql .= ", c_registtime";
		$sql .= ", c_updatetime";
		$sql .= ") values ";
		$sql .= "( '".$user_id."'";
		$sql .= ", '" . $_POST['id_category'] . "'";
		if (MEMO_SUBJECT_USE == 'YES') {
			$sql .= ", '".post_to_mysql("c_subject")."'";
		}
		$sql .= ", '".post_to_mysql("c_memo")."'";
		if ($_SESSION['current_id'] == $_SESSION['login_id']) {
			if ($_POST['c_privacy'] == '444') {
				$sql .= ", 444";
			} else {
				$sql .= ", 0";
			}
		}
		$sql .= ", '". date("Y/m/d H:i:s") . "'";
		$sql .= ", '". date("Y/m/d H:i:s") . "'";
		$sql .= ")";
		$ret = my_mysqli_query($sql, "登録できませんでした。");
	} elseif ($_POST['削除'] <> "") {
		$sql = "update m_memo set";
		$sql .= " c_delete = 999";
		$sql .= ", c_updatetime = '". date("Y/m/d H:i:s") . "'";
		$sql .= " where id_memo = ".$id;
		$sql .= " and id_account = ".$user_id;
		$ret = my_mysqli_query($sql, "削除できませんでした。");
	} else {
		$sql = "update m_memo set";
		$sql .= " id_category = '".$_POST['id_category']."'";
		if (MEMO_SUBJECT_USE == 'YES') {
			$sql .= ", c_subject = '".post_to_mysql("c_subject")."'";
		}
		$sql .= ", c_memo = '".post_to_mysql("c_memo")."'";
		if ($_SESSION['current_id'] == $_SESSION['login_id']) {
			if ($_POST['c_privacy'] == '444') {
				$sql .= ", c_privacy = 444";
			} else {
				$sql .= ", c_privacy = 0";
			}
		}
		$sql .= ", c_updatetime = '". date("Y/m/d H:i:s") . "'";
		$sql .= " where id_memo = ".$id;
		$sql .= " and id_account = ".$user_id;
		$ret = my_mysqli_query($sql, "更新できませんでした。");
	}
	// ****** 添付ファイル ******
	if ($id == 0) {
		$id = my_mysqli_insert_id();	//直近のINSERTクエリによりAUTO_INCREMENTカラム用に生成されたIDを取得
	}
	$sw = False;
	$sqlupd = "";
	for ($ix=1; $ix<=3; $ix++) {
		// ***** ファイルのアップロード *****
		$attachFile = file_upload("filename".$ix, $id, ATTACH_FILE_FOLDER, $user_id);
		if ($attachFile <> "") {
			if ($sw) {
				$sqlupd .= ",";
			}
			$sqlupd .= " c_attachFile" . $ix . " = '" . $attachFile . "'";
			$sw = True;
		} else if ($_POST['fileDelete'.$ix] == "YES") {
			if ($sw) {
				$sqlupd .= ",";
			}
			$sqlupd .= " c_attachFile" . $ix . " = ''";
			$sw = True;
		}
	}
	if ($sw) {
		$sql = "update m_memo set";
		$sql .= $sqlupd;
		$sql .= " where id_memo = ".$id;
		$sql .= " and id_account = '".$user_id."'";
			//echo $sql;
			//exit;
		$ret = my_mysqli_query($sql, "アップロードファイル名DB登録失敗。");
	}
	mysqli_close($con);
	redirect("list.php?".$_SERVER['QUERY_STRING']);
	//redirect("list.php?".$_SERVER['QUERY_STRING']."#id_".$id);	// javascript:window.scroll(0, y)に変更
}
function input_form() {
	if ($_GET['id'] <> "") {
		$id = $_GET['id'];
		if ($_GET['page'] <> "") {
			$page = $_GET['page'];
		}
	} else {
		$id = 0;
	}
	$con = my_mysqli_connect(_DB_SCHEMA);
	$sql = "select * from v_memo where id_memo = ".$id." and c_delete = 0";
	$sql .= " and id_account = ".$_SESSION['current_id'];
	$rs = my_mysqli_query($sql);
	$rec = mysqli_fetch_array($rs);

	if ($rec['c_subject'] <> '') {
		$subject = $rec['c_subject'];
	} elseif ($_GET['title'] <> '') {
		$subject = $_GET['title'];
	} else {
		$subject = '';
	}
	if ($rec['c_memo'] <> '') {
		$memo = $rec['c_memo'];
	} elseif ($_GET['memo'] <> '') {
		$memo = $_GET['memo'];
	} else {
		$memo = '';
	}
	$updatetime = $rec['c_updatetime'];
?>
<div class="input_form">
<?php	if ($_GET['title'] <> '') { ?>
<h3><?= $_SESSION['current_handle'] ?><a class="a_cancel_back" href='list.php?arg=session'>戻る</a></h3>
<?php	} else { ?>
<h3><?= $_SESSION['current_handle'] ?><a class="a_cancel_back" href='javascript:history.back();'>戻る</a></h3>
<?php	} ?>
<script>
function formCheck(form) {
	if (form.c_subject.value == '') {
		window.alert('件名を入れてください。');
		return false;		// 送信を中止
	}
	return true;	// 送信を実行
}
</script>
<form name="form0" method="POST" action="<?= $_SERVER['SCRIPT_NAME'] ?>?<?= $_SERVER['QUERY_STRING'] ?>" enctype="multipart/form-data"><!-- 件名なし許可 -->
	<input type="hidden" name="user_id" value="<?= $_SESSION['current_id'] ?>">
	<input type="hidden" name="update_id" value="<?= $id ?>">
	<input type="hidden" name="login_id" value="<?= $_SESSION['login_id'] ?>">
	<input type="hidden" name="current_id" value="<?= $_SESSION['current_id'] ?>">
<script src="../scripts/jquery.textarea.js"></script>
<script>
// http://teddevito.com/demos/textarea.html
$(function() {
	$('textarea#c_memo').tabby();
});
</script>
<table>
<tr>
	<td nowrap>カテゴリ</td>
	<td nowrap>
<?php
	$sqlsel = "select * from m_category where id_account = '".$_SESSION['current_id']."'";
	$sqlsel = $sqlsel . " and c_delete = 0";
	$sqlsel = $sqlsel . " order by c_categoryDisplayOrder";
	$rs_sel = my_mysqli_query($sqlsel);
?>
	<select name="id_category">
<?php
		if ($id == 0) {
			$category = (int)$_GET['cat'];
		} else {
			$category = $rec['id_category'];
		}
		while ($rec_sel=mysqli_fetch_array($rs_sel)) {
?>
		<option value="<?= $rec_sel['id_category'] ?>"<?= $rec_sel['id_category'] == $category ? " selected" : "" ?>><?= my_htmlspecialchars($rec_sel['c_categoryName']) ?>
<?php
		}
?>
	</select>
	<?php if ($_SESSION['current_id'] == $_SESSION['login_id']) { ?>
		&nbsp;&nbsp;<label><input type="checkbox" name="c_privacy" value="444" <?= $rec['c_privacy'] == 444 ? ' checked' : '' ?>>非公開</label>
	<?php } ?>
	</td>
</tr>
<?php	if (MEMO_SUBJECT_USE == 'YES') { ?>
<tr>
	<td>件名</td>
	<td>
		<input class="text" type="text" name="c_subject" value="<?= my_htmlspecialchars($subject) ?>" style="width:500px;">
	</td>
</tr>
<?php	} ?>
<tr>
	<td>メモ</td>
	<td>
		<div class="block_left">
		<?php
			$str = my_htmlspecialchars($memo);
			$rows = textarea_rows($str, 500) + 1;
			if ($rows < 10) {
				$rows = 10;
			} elseif (strstr($_SERVER['HTTP_USER_AGENT'], "MSIE") and $rows > 30) {
				$rows = 30;
			}
		?>
		<textarea id="c_memo" name="c_memo" style="width:500px;" rows="<?= $rows ?>" wrap="soft"><?= $str ?></textarea>
		</div>
		<?php	if (strstr($_SERVER['HTTP_USER_AGENT'], "MSIE")) { ?>
			<div class="block_left">
			<input type="button" value="小" OnClick="textareaBigSmall('c_memo','小')"><br>
			<input type="button" value="大" OnClick="textareaBigSmall('c_memo','大')"><br>
			</div>
		<?php	} ?>
	</td>
</tr>
<tr>
	<td>添付文書</td>
	<td>
<?php	if (VIDEO_PREVIEW == 'YES') { ?>
	<!--<p><span class="alarm_text">ファイル名が英数字以外のFLV,MP4ファイルは動画再生できません。</span></p>-->
<?php	} ?>
<?php if ($rec['c_attachFile1'] <> "" || $rec['c_attachFile2'] <> "" || $rec['c_attachFile3'] <> "") { ?>
	<p><span class="alarm_text">再度添付ファイル名を指定すると登録済ファイルに上書きされます。</span></p>
<?php } ?>
<?php
	for ($ix=1; $ix<=3; $ix++) {
?>
		<div class="block">
		<div class="block_left">(<?= $ix ?>)</div>
		<div class="block_left">
<?php
		if ($rec['c_attachFile'.$ix] <> "") {
			attach_file_view($rec['id_account'], $rec['c_attachFile'.$ix]);
?>
		<label><input type="checkbox" name="fileDelete<?= $ix ?>" value="YES">削除</label>
		<input type="hidden" name="filenameCurrent<?= $ix ?>" value="<?= $rec['c_attachFile'.$ix] ?>">
<?php
		}
?>
		<input type="file" size=40 name="filename<?= $ix ?>" style="button-font-size:small">
		</div>
		</div>
<?php
	}
?>
	</td>
</tr>
</table>
<?php
	if ($id == 0) {
?>
	<input class="input_form_button" type="submit" name="登録" value="登録">
<?php
	} else {
?>
	<input class="input_form_button" type="submit" name="登録" value="修正">
	<input class="input_form_button" type="submit" name="削除" value="削除" onClick="return delete_check();" style="margin-left:20px;">
<?php
	}
?>
</form>
<p style="margin-top:10px; width:550px; text-indent: -1.3em; margin-left: 1.4em;">
※ 以下のようなブックマークレットをブラウザに登録しておくことで、表示しているホームページのタイトルとURLを自動入力した登録画面を開くことができます。
</p>
<?php	if (MEMO_SUBJECT_USE == 'YES') { ?>
<p style="margin-top:10px; width:550px; margin-left: 1.4em;">
≪タイトル→件名、URL→メモ≫
</p>
<div style="border:solid 1px #808080; width:500px; margin-left:1.4em;">
javascript:(function(){window.open('http://<?= $_SERVER['HTTP_HOST'] ?>/<?= MY_SESSION_NAME ?>/memo/input.php?title='+encodeURIComponent(document.title)+'&memo='+encodeURIComponent(document.URL))})();
</div>
<p style="margin:5px 0 0 1.4em;">
<a href="javascript:(function(){window.open('http://<?= $_SERVER['HTTP_HOST'] ?>/<?= MY_SESSION_NAME ?>/memo/input.php?title='+encodeURIComponent(document.title)+'&memo='+encodeURIComponent(document.URL))})();">▲メモ</a> ←このリンクをブックマークバーにドラッグすると登録できます。
一覧ページ用→
<a href="javascript:(function(){window.open('http://<?= $_SERVER['HTTP_HOST'] ?>/<?= MY_SESSION_NAME ?>/memo/list.php?title='+encodeURIComponent(document.title)+'&memo='+encodeURIComponent(document.URL))})();">▲メモ</a>
</p>
<?php	} ?>
<p style="margin-top:10px; width:550px; margin-left: 1.4em;">
≪タイトル＋URL→メモ≫
</p>
<div style="border:solid 1px #808080; width:500px; margin-left:1.4em;">
javascript:(function(){window.open('http://<?= $_SERVER['HTTP_HOST'] ?>/<?= MY_SESSION_NAME ?>/memo/input.php?memo='+encodeURIComponent(document.title+'\n'+document.URL))})();
</div>
<p style="margin:5px 0 0 1.4em;">
<a href="javascript:(function(){window.open('http://<?= $_SERVER['HTTP_HOST'] ?>/<?= MY_SESSION_NAME ?>/memo/input.php?memo='+encodeURIComponent(document.title+'\n'+document.URL))})();">▲メモ</a> ←このリンクをブックマークバーにドラッグすると登録できます。
一覧ページ用→
<a href="javascript:(function(){window.open('http://<?= $_SERVER['HTTP_HOST'] ?>/<?= MY_SESSION_NAME ?>/memo/list.php?memo='+encodeURIComponent(document.title+'\n'+document.URL))})();">▲メモ</a>
</p>
<script>
function delete_check() {
	if (window.confirm('このデータを削除しますか？')) {
		return true;
	} else {
		return false;
	}
}
</script>
<?php	if (!strstr($_SERVER['HTTP_USER_AGENT'], "MSIE")) { ?>
<script src="../scripts/autoresize.jquery.min.js"></script>
<script>
$('textarea#c_memo').autoResize({
	onResize : function() {
		$(this).css({opacity:0.8});
	},
	animateCallback : function() {
		$(this).css({opacity:1});
	},
	animateDuration : 300,
	extraSpace : 20
});
$('textarea#c_memo').trigger('change'); // 初期表示時に自動リサイズさせるためchangeイベント実行
</script>
<?php	} ?>
<?
}
?>
