<?php
	require("__include-common.php");
	require("../account/__logincheck.php");
?>
<!DOCTYPE html>
<html lang="ja">
<head>
<?php
	require("__html-my-header-translate.php");
?>
</head>
<body>
<div id="translate_body">
<?php
	$con = my_mysqli_connect(_DB_SCHEMA);
	$sql = "select * from v_memo where c_delete = 0 and id_account = '" . $_SESSION['current_id'] . "'";
	$sql .= " and id_memo = " . $_GET['id'];
	if ($_SESSION['current_id'] != $_SESSION['login_id']) {
		$sql .= " and c_privacy = 0";
	}
	$rs = my_mysqli_query($sql);
	$row = mysqli_num_rows($rs);
	if ($row == 0) {
		exit;
	}
	if (!($rec = mysqli_fetch_array($rs))) {
		exit;
	}
?>
	<table id="memo_list_table">
	<tr class="memo_list_table_data">
	<td class="memo_list_subject">
		<p id="source0"><?= ins_atag_br($rec['c_subject']) ?></p>
		<p id="translation0" class="translation"></p>
	</td>
	</tr>
	<tr>
	<td class="<?= $view_memo_class ?>">
<?php
	$memo = str_replace('\n\n','\n',str_replace('。',"。\n",str_replace('. ',".\n",$rec['c_memo'])));
	$memo_ary = explode("\n", $memo);
	foreach ($memo_ary as $source) {
		if (left($source,7) == 'http://' or left($source,8) == 'https://') {
?>
	<p><?= ins_atag_br($source) ?></p>
<?php
		} else {
			++$trans;
?>
	<p id="source<?= $trans ?>"><?= ins_atag_br($source) ?></p>
	<p id="translation<?= $trans ?>" class="translation"></p>
<?php
		}
	}
?>
	</td>
	</tr>
	</table>
</div>
<script>
function translate_all() {
	for (ix=0; ix<=<?= $trans ?>; ix++) {
		translate(ix);
	}
}
function translate(num) {
	var source = document.getElementById("source"+num).innerHTML;
	google.language.translate(source, '', '<?= $_SESSION['memo_trans_lang'] ?>', function(result) {
		var translated = document.getElementById("translation"+num);
		if (result.translation) {
			translated.innerHTML = result.translation;
		}
	});
}
translate_all();
</script>
</body>
</html>