<?php
	if (VIDEO_PREVIEW == 'YES') {
?>
	<script src="../scripts/JWPlayer/swfobject.js"></script>
	<script src="../scripts/JWPlayer/movie_preview.js"></script>
	<script src="../scripts/JWPlayer/silverlight.js"></script>
	<script src="../scripts/JWPlayer/wmvplayer.js"></script>
<?php
	}
	jquery_highlight('.memo_list_subject', keystr_and_or($keystring));
	jquery_highlight('.memo_list_memo', keystr_and_or($keystring));
?>
	<table id="memo_list_table">
<?php
	mysqli_data_seek($rs, $startline);			//テーブル内の指定行に移動
	$line = $startline;					//$lineに$startlineを代入
	while ($rec=mysqli_fetch_array($rs) and $line<=$endline) {
		if ($rec['c_privacy'] == 444) {
			$privacy = 'privacy';
		} else {
			$privacy = '';
		}
		if ($line <> $startline) {
?>
	<a name="id_<?= $rec['id_memo'] ?>"></a>
	</td>
	</tr>
	</tbody>
<?php
		}
?>
	<tbody id="tb_<?= $rec['id_memo'] ?>">
	<tr class="memo_list_table_data">
	<td class="memo_list_category <?= $privacy ?>" style="text-align:right;padding-right:6px;">
	<span class="category" style="background-color:<?= $rec['c_categoryDisplayColor'].'' <> '' ? $rec['c_categoryDisplayColor'] : '#b0b0b0' ?>;"><?= $rec['c_categoryName'] ?></span><br>
	<span class="registtime"><?= $rec['c_registtime'] ?></span>
	</td>
<?	if (check_permit_id($_SESSION['login_id'], $_SESSION['current_id']) == "w") { ?>
	<td class="<?= $privacy ?>" style="width:34px;white-space:nowrap;">
		<button style="font-size:10px;" onClick="input_memo('<?= $rec['id_memo'] ?>','<?= $page ?>','<?= query_from_http_arg_pool($http_arg) ?>')">修正</button><br>
		<button style="font-size:10px;" onClick="popup_delete('<?= $rec['id_memo'] ?>')">削除</button>
	</td>
<?	} ?>
	<td class="<?= $privacy ?>">
<?php
	if (MEMO_SUBJECT_USE == 'YES' and $rec['c_subject'] <> '') {
?>
	<p class="memo_list_subject"><?= ins_atag_br($rec['c_subject']) ?></p>
<?php	} ?>
	<p class="memo_list_memo"><?= ins_atag($rec['c_memo']) ?></p>
	<?php
		$filename1 = $rec['c_attachFile1'];
		$filename2 = $rec['c_attachFile2'];
		$filename3 = $rec['c_attachFile3'];
		if ($filename1 <> "" || $filename2 <> "" || $filename3 <> "") {
	?>
			<p>
	<?php
			attach_file_view($rec['id_account'], $filename1, '<br>', VIEW_PHOTO_WIDTH, True, True, True,
				VIDEO_PREVIEW_WIDTH, VIDEO_PREVIEW_HEIGHT);
			attach_file_view($rec['id_account'], $filename2, '<br>', VIEW_PHOTO_WIDTH, True, True, True,
				VIDEO_PREVIEW_WIDTH, VIDEO_PREVIEW_HEIGHT);
			attach_file_view($rec['id_account'], $filename3, '<br>', VIEW_PHOTO_WIDTH, True, True, True,
				VIDEO_PREVIEW_WIDTH, VIDEO_PREVIEW_HEIGHT);
	?>
			</p>
	<?php
		}
	?>
<?php
		$line++;
	}
?>
	</td>
	</tr>
	</tbody>
	</table>
