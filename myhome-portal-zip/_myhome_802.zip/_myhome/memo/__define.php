<?php
	if (defined("HTML_TITLE_memo")) {
		define("HTML_TITLE", HTML_TITLE_memo);
	} else {
		define("HTML_TITLE", "MyHome メモ");
	}
	define("SESSION_PREFIX", "memo");

	if (defined("_DB_SCHEMA_memo")) {
		define("_DB_SCHEMA", _DB_SCHEMA_memo);
	} else {
		define("_DB_SCHEMA", "_db_memo");
	}
	if (defined("ATTACH_FILE_FOLDER_memo")) {
		define("ATTACH_FILE_FOLDER", ATTACH_FILE_FOLDER_memo);
	} else {
		//↓絶対パスにできない？？？
		define("ATTACH_FILE_FOLDER", "../_attach/memo/");
	}

	if (defined("VIEW_PHOTO_WIDTH_memo")) {
		define("VIEW_PHOTO_WIDTH", VIEW_PHOTO_WIDTH_memo);
	} else {
		define("VIEW_PHOTO_WIDTH", 200);
	}
	if (defined("VIDEO_PREVIEW_memo")) {
		define("VIDEO_PREVIEW", VIDEO_PREVIEW_memo);
		define("VIDEO_PREVIEW_EXT", VIDEO_PREVIEW_EXT_memo);
		define("VIDEO_PREVIEW_WIDTH", VIDEO_PREVIEW_WIDTH_memo);
		define("VIDEO_PREVIEW_HEIGHT", VIDEO_PREVIEW_HEIGHT_memo);
	} else {
		define("VIDEO_PREVIEW", "YES");
		define("VIDEO_PREVIEW_EXT", "flv,mp4,mp3,wmv");
		define("VIDEO_PREVIEW_WIDTH", "240");
		define("VIDEO_PREVIEW_HEIGHT", "180");
	}
	if (!defined("MEMO_SUBJECT_USE")) {
		define("MEMO_SUBJECT_USE", "YES");		// NO:メモの件名を使わない
	}
	define("PAGE_LINE_SELECT", "5,10,20,50,100,1000");	// 頁内に表示する行数
	define("PAGE_LINE_DEFAULT", "10");			// 頁内に表示する行数（デフォルト）
	if (!defined("FILE_UPLOAD_MEMORY_LIMIT")) {
		define("FILE_UPLOAD_MEMORY_LIMIT", "32M");	// ファイルアップロード メモリサイズ
	}
	if (!defined("FILE_UPLOAD_MAX_EXECUTION_TIME")) {
		define("FILE_UPLOAD_MAX_EXECUTION_TIME", "60");	// ファイルアップロード 最大実行時間
	}
?>
