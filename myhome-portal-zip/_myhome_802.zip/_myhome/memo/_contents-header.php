<?php
function contents_header() {
	$menu_item = array();
	$menu_item[] = array("href"=>"list.php", "query"=>"arg=session", "name"=>"メモ");
	$menu_item[] = array("href"=>"category.php", "name"=>"カテゴリ一覧");
?>
<div id="contents_header">
<?php
	contents_menu($menu_item);
	memo_input_form_onoff();
	change_account_menu();
?>
</div><!-- id="contents_header" -->
<?php
}
function memo_input_form_onoff() {
	if (!strstr($_SERVER['HTTP_USER_AGENT'], "MSIE")) {
		$checkbox_margin = 'margin-top:3px;';
	}
?>
<script>
function MemoInputFormOnOff(sel) {
	if ($(sel).attr('checked')) {
		$.cookie("memo_input_form_on","off",{ path:'<?= MY_SESSION_PATH ?>', expires:365 });
		$('#input_form').css('display','none');
		$('.a_renmei').css('width','40px');
	} else {
		$.cookie("memo_input_form_on","",{ path:'<?= MY_SESSION_PATH ?>', expires:365 });
		$('#input_form').css('display','');
	}
}
</script>
<span style="block:left;padding-left:15px;line-height:20px;">
<label><input type="checkbox" style="vertical-align:top;<?= $checkbox_margin ?>" onClick="MemoInputFormOnOff(this)"<?= $_COOKIE['memo_input_form_on'] == 'off' ? ' checked' : '' ?>>入力欄非表示</label>
</span>
<?php
}
?>
