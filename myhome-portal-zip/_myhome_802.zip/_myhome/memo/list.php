<?php
	require("__include-common.php");
	require("../account/__logincheck.php");
	require("../__common__/include-common-mp-list.php");

	$table_name_view = "v_memo";
	$table_name = "m_memo";
	$id_item = "id_memo";
	$must_item = "c_memo";

	$mp_list_arg = array();
	$mp_list_arg['account_id']	= $_SESSION['current_id'];
	$mp_list_arg['table_name_view']		= "v_memo";
	$mp_list_arg['table_name_edit']		= "v_memo";
	$mp_list_arg['table_name_update']	= "m_memo";
	$mp_list_arg['id_item']		= "id_memo";
	$mp_list_arg['must_item']	= "c_memo";
	$mp_list_arg['template_view']	= "list-my-template.php";
//	$mp_list_arg['input_new']	= "no";
	$mp_list_arg['use_privacy']	= "yes";
	$mp_list_arg['add_list']	= "yes";
//	$mp_list_arg['list_option_callback']	= "my_option_filter";	// Google Translate API v1が廃止のため削除。
//	if ($_GET['trans'].'' <> '') {
//		$_SESSION['memo_translate'] = $_GET['trans'];
//	}
	if ($_GET['lang'].'' <> '') {
		$_SESSION['memo_trans_lang'] = $_GET['lang'];
		setcookie("memo_trans_lang", $_GET['lang'], time() + LOGIN_COOKIE_EXPIRE, MY_SESSION_PATH);
	}
	if ($_SESSION['memo_trans_lang'] == '') {
		if ($_COOKIE['memo_trans_lang'] <> '') {
			$_SESSION['memo_trans_lang'] = $_COOKIE['memo_trans_lang'];
		} else {
			$_SESSION['memo_trans_lang'] = TRANSLATE_LANG_DEFAULT_memo;
		}
	}

	$item_tbl = array();
	$item_tbl[] = array(	"表示名"=>"カテゴリ",	"列名"=>"id_category", "http_arg_GET名"=>"cat",
				"filter_type"=>"radio",
				"type"=>"select", "参照テーブル"=>"m_category", "参照テーブル表示列"=>"c_categoryName",
				"参照テーブル表示順"=>"c_categoryDisplayOrder", "参照テーブル表示色"=>"c_categoryDisplayColor");
	if (MEMO_SUBJECT_USE == 'YES') {
		$item_tbl[] = array(	"表示名"=>"タイトル",	"列名"=>"c_subject",
				"type"=>"text", "size"=>40, "ime-mode"=>"active", "文字検索"=>"Y");
		$item_tbl[] = array(	"表示名"=>"メモ",	"列名"=>"c_memo",
				"type"=>"textarea", "cols"=>70, "rows"=>3, "文字検索"=>"Y");
	} else {
		$item_tbl[] = array(	"表示名"=>"メモ",	"列名"=>"c_memo",
				"type"=>"textarea", "cols"=>90, "rows"=>3, "文字検索"=>"Y");
	}
	$order_tbl = array();
	$order_tbl[] = array(   "表示名"=>"最新順", "get_order_name"=>"new",
				"order_by"=>"id_memo desc");		/* default */
	$order_tbl[] = array(   "表示名"=>"カテゴリ順", "get_order_name"=>"cat",
				"order_by"=>"c_categoryDisplayOrder, id_category, c_subject");
	if (MEMO_SUBJECT_USE == 'YES') {
		$order_tbl[] = array(   "表示名"=>"タイトル順", "get_order_name"=>"subject",
				"order_by"=>"c_subject");
	} else {
		$order_tbl[] = array(   "表示名"=>"メモ順", "get_order_name"=>"memo",
				"order_by"=>"c_memo");
	}
	$http_arg = array();
	$http_arg['pl'] = PAGE_LINE_DEFAULT;		// mp_list 必須
	$http_arg['sort'] = '';				// mp_list 必須
	$http_arg['cat'] = '';				// mp_list 必須
	$http_arg['key'] = '';				// mp_list 必須
	$http_arg['cid'] = '';

	if (isset($_POST['登録'])) {
		check_post_account($_POST['login_id'], $_POST['current_id']);
		mp_list_update($mp_list_arg, $item_tbl, $order_tbl, $http_arg);
	} else {
		_GET_to_http_arg_pool($http_arg, $table_name, 'sort,key,pl');
		if ($_GET['scroll'] <> '') {
			html_header(HTML_TITLE, '', '', ' onLoad="window_scroll('.$_GET['scroll'].')"');
		} else {
			html_header(HTML_TITLE);
		}
		page_header();
		contents_header();
		input_form();
		if ($_GET['edit'] == "a") {
			$mp_list_arg['sql_for_edit'] = "select * from v_memo where id_memo = 0";
			mp_list_edit($mp_list_arg, $item_tbl, $order_tbl, $http_arg);
		} elseif ($_GET['edit'] == "y") {
			mp_list_edit($mp_list_arg, $item_tbl, $order_tbl, $http_arg);
		} else {
			mp_list_view($mp_list_arg, $item_tbl, $order_tbl, $http_arg);
?>
<script>
function popup_edit(id) {
	w01 = window.open("edit.php?id="+id,"","toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes,width=630,height=300");
}
function popup_delete(id) {
	if (window.confirm('メモを削除しますか？')) {
		$.ajax({
			type: "GET",
			url: "delete.php?id="+id,
			async: false,
			success: function(res){
				$('#tb_'+id).html(res);
			}
		});
	}
}
function input_memo(id, page, opt) {
	var sclTop = document.body.scrollTop || document.documentElement.scrollTop;
	location.href='input.php?id='+id+'&page='+page+'&'+opt+'&scroll='+sclTop;
}
function window_scroll(y) {
	window.scroll(0, y);
}
</script>
<?php
		}
		page_footer();
		html_footer();
	}
	exit();
// ****************************************************************
function my_option_filter($http_arg) {
// ****************************************************************
?>
<script>
function CheckboxTranslate(onOff) {
	if (onOff == 'on') {
		window.location.href = "?trans=off&page=<?= $_GET['page'] ?>&<?= query_from_http_arg_pool($http_arg) ?>";
	} else {
		window.location.href = "?trans=on&page=<?= $_GET['page'] ?>&<?= query_from_http_arg_pool($http_arg) ?>";
	}
}
function SelectionLang(form, sel){
	for (i = 0; i < sel.options.length; i++) {
		if (sel.options[i].selected == true) {
			window.location.href = "?lang=" + escape(sel.options[i].value)+ "&page=<?= $_GET['page'] ?>&<?= query_from_http_arg_pool($http_arg) ?>";
		}
	}
}
</script>
<?php
?>
	<label><input type="checkbox" name="" value="on" onClick="CheckboxTranslate('<?= $_SESSION['memo_translate'] ?>')"<?= $_SESSION['memo_translate'] == 'on' ? ' checked' : '' ?> style="margin-left:3px;">翻訳</label>
<?php
	$lang_tbl = array();
	$lang_tbl[] = array('en', '英語');
	$lang_tbl[] = array('ja', '日本語');
	$lang_tbl[] = array('fr', 'フランス語');
	$lang_tbl[] = array('de', 'ドイツ語');
	$lang_tbl[] = array('it', 'イタリア語');
	$lang_tbl[] = array('es', 'スペイン語');
	$lang_tbl[] = array('ko', '韓国語');
	$lang_tbl[] = array('zh-CN', '中国語(簡体)');
	$lang_tbl[] = array('zh-TW', '中国語(繁体)');
	$lang_tbl[] = array('ar', 'アラビア語');
	$lang_tbl[] = array('id', 'インドネシア語');
	$lang_tbl[] = array('uk', 'ウクライナ語');
	$lang_tbl[] = array('nl', 'オランダ語');
	$lang_tbl[] = array('ca', 'カタロニア語');
	$lang_tbl[] = array('el', 'ギリシャ語');
	$lang_tbl[] = array('hr', 'クロアチア語');
	$lang_tbl[] = array('sv', 'スウェーデン語');
	$lang_tbl[] = array('sk', 'スロバキア語');
	$lang_tbl[] = array('sl', 'スロベニア語');
	$lang_tbl[] = array('sr', 'セルビア語');
	$lang_tbl[] = array('tl', 'タガログ語');
	$lang_tbl[] = array('cs', 'チェコ語');
	$lang_tbl[] = array('da', 'デンマーク語');
	$lang_tbl[] = array('no', 'ノルウェー語');
	$lang_tbl[] = array('hi', 'ヒンディー語');
	$lang_tbl[] = array('fi', 'フィンランド語');
	$lang_tbl[] = array('bg', 'ブルガリア語');
	$lang_tbl[] = array('vi', 'ベトナム語');
	$lang_tbl[] = array('iw', 'ヘブライ語');
	$lang_tbl[] = array('pl', 'ポーランド語');
	$lang_tbl[] = array('pt', 'ポルトガル語');
	$lang_tbl[] = array('lv', 'ラトビア語');
	$lang_tbl[] = array('lt', 'リトアニア語');
	$lang_tbl[] = array('ro', 'ルーマニア語');
	$lang_tbl[] = array('ru', 'ロシア語');
?>
	→<select id="target-language"  onChange="SelectionLang(this.form, this)">
<?php
		foreach ($lang_tbl as $lang) {
?>
		<option value="<?= $lang[0] ?>"<?= $lang[0] == $_SESSION['memo_trans_lang'] ? ' selected' : '' ?>><?= $lang[1] ?></option>
<?php
		}
?>
	</select>
<?php
}
?>
<?php
function input_form() {
	$con = my_mysqli_connect(_DB_SCHEMA);
?>
<form id="input_form" name="form0" method="POST" action="input.php?sort=new&cat=<?= $_GET['cat'] ?>"<?= $_COOKIE['memo_input_form_on'] == 'off' ? ' style="display:none;"' : '' ?>>
	<input type="hidden" name="user_id" value="<?= $_SESSION['current_id'] ?>">
	<input type="hidden" name="update_id" value="<?= $id ?>">
	<input type="hidden" name="login_id" value="<?= $_SESSION['login_id'] ?>">
	<input type="hidden" name="current_id" value="<?= $_SESSION['current_id'] ?>">
<script src="../scripts/jquery.textarea.js"></script>
<script>
// http://teddevito.com/demos/textarea.html
$(function() {
	$('textarea#c_memo').tabby();
});
</script>
<table style="margin-left:10px;">
<tr>
	<td nowrap style="text-align:right;vertical-align:middle;">カテゴリ</td>
	<td nowrap>
<?php
	$sqlsel = "select * from m_category where id_account = '".$_SESSION['current_id']."'";
	$sqlsel = $sqlsel . " and c_delete = 0";
	$sqlsel = $sqlsel . " order by c_categoryDisplayOrder";
	$rs_sel = my_mysqli_query($sqlsel);
?>
	<select name="id_category" onChange="chgCookieSelect(this, 'memo_input_form_category')">
<?php
		if ($id == 0) {
			$category = (int)$_GET['cat'];
		} else {
			$category = $rec['id_category'];
		}
		while ($rec_sel=mysqli_fetch_array($rs_sel)) {
?>
		<option value="<?= $rec_sel['id_category'] ?>"<?= $rec_sel['id_category'] == $_COOKIE['memo_input_form_category'] ? " selected" : "" ?>><?= my_htmlspecialchars($rec_sel['c_categoryName']) ?>
<?php
		}
?>
	</select>
	<?php if ($_SESSION['current_id'] == $_SESSION['login_id']) { ?>
		&nbsp;&nbsp;<label><input type="checkbox" name="c_privacy" value="444" <?= $rec['c_privacy'] == 444 ? ' checked' : '' ?>>非公開</label>
	<?php } ?>
	</td>
</tr>
<?php	if (MEMO_SUBJECT_USE == 'YES') { ?>
<tr>
	<td style="text-align:right;vertical-align:middle;">件名</td>
	<td>
		<input class="text" type="text" name="c_subject" value="<?= my_htmlspecialchars($_GET['title']) ?>" style="width:500px;">
	</td>
</tr>
<?php	} ?>
<tr>
	<td style="text-align:right;padding-top:2px;">メモ</td>
	<td>
		<div class="block_left">
		<textarea id="c_memo" name="c_memo" style="width:550px;" rows="5" wrap="soft"><?= my_htmlspecialchars($_GET['memo']) ?></textarea>
		</div>
		<?php	if (strstr($_SERVER['HTTP_USER_AGENT'], "MSIE")) { ?>
			<div class="block_left">
			<input type="button" value="小" OnClick="textareaBigSmall('c_memo','小')"><br>
			<input type="button" value="大" OnClick="textareaBigSmall('c_memo','大')"><br>
			</div>
		<?php	} ?>
		<input class="input_form_button" type="submit" name="登録" value="登録">
	</td>
</tr>
</table>
</form>
<?php
}
?>
