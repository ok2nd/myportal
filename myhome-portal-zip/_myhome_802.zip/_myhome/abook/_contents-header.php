<?php
function contents_header($account_menu='on') {
	$menu_item = array();
	$menu_item[] = array("href"=>"list.php", "query"=>"arg=session", "name"=>"住所録");
	$menu_item[] = array("href"=>"map-japan.php", "query"=>"arg=session", "name"=>"日本地図");
	if (check_permit_id($_SESSION['login_id'], $_SESSION['current_id']) == "w") {
		$menu_item[] = array("href"=>"edit-caption.php", "query"=>"arg=session", "name"=>"チェック項目見出し編集");
		$menu_item[] = array("href"=>"check_item_moveup.php", "query"=>"arg=session", "name"=>"チェック項目繰上");
		$menu_item[] = array("href"=>"set-todofuken-by-zip.php", "name"=>"都道府県名セット");
		$menu_item[] = array("href"=>"category.php", "name"=>"分類一覧");
		$menu_item[] = array("href"=>"mailfrom.php", "name"=>"OneToOneメール送信者");
	}
?>
<div id="contents_header">
<?php
	contents_menu($menu_item);
	if ($account_menu == 'on') {
		change_account_menu();
	}
?>
</div><!-- id="contents_header" -->
<?php
}
?>
