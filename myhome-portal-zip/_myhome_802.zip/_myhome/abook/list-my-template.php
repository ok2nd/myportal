<script>
function updateCheck(id, no, chkd) {
	var d = new Date();	// キャッシュを利用されないため
	if (chkd) {
		chk = 1;
	} else {
		chk = 0;
	}
	$.get("check-update.php?time="+d.getTime().toString(), {id:id,no:no,chk:chk});
	if (chkd) {
		color = "<?= CHECKED_BGCOLOR ?>";
	} else {
		color = "<?= UNCHECK_BGCOLOR ?>";
	}
	$("#ck"+id+"_"+no).css("background-color",color);
}
function checkOnAll() {
	$("input:checkbox[name^='check']").attr('checked', true);
	return false;
}
function checkOffAll() {
	$("input:checkbox[name^='check']").attr('checked', false);
	return false;
}
function winOpen(){
//	Chrome,Safariでも別ウンドウで何回でも開くため
	target = 't'+(new Date()).getTime();
	w = window.open("do-proc.php?<?= $_SERVER['QUERY_STRING'] ?>", target);
	document.frm0.target = target;
}
</script>
	<form id="abook_form" name="frm0" method="POST" action="do-proc.php?<?= $_SERVER['QUERY_STRING'] ?>" onSubmit="winOpen()">
	<input type="button" onClick="return checkOnAll()" value="全てチェック">
	<input type="button" onClick="return checkOffAll()" value="チェッククリア">
	<input type="submit" name="Email" value="OneToOneメール"><!-- 電子メール宛名 -->
	<input type="submit" name="Maps" value="マップ">
	<input type="submit" name="MapsV3" value="マップ(V3)">
	<input type="submit" name="PDF" value="葉書宛名書き">
	<label><input type="checkbox" name="差出人" value="印刷"<?php if ($_COOKIE['abook_print_sender'] == '印刷' ) echo ' checked';  ?>>差出人印刷</label>&nbsp;
	差出人名：<input class="text" type="text" name="差出人名" value="<?= $_COOKIE['abook_print_sender_name'] ?>" size=12>
	連名：<input class="text" type="text" name="連名" value="<?= $_COOKIE['abook_print_sender_renmei'] ?>" size=12>
<?php
	foreach ($order_tbl as $id=>$item) {
		if ($item['get_order_name'] == $_GET['sort']) {
			$sortorder = $item['order_by'];
			break;
		}
	}
	if ($sortorder == '') {
		$sortorder  = 'id_abook desc';
	}
?>
	<input type="hidden" name="sortOrder" value="<?= $sortorder ?>">
<?php
	global $chk_use;	// list-my-add-filter.phpでセット
?>
	<table id="abook_list_table">
	<tr>
		<th></th>
		<?php
			for ($ix=1; $ix<=CHECK_ITEM_NUMBER; $ix++) {
				if ($chk_use[$ix]) {
		?>
			<th><?= roman_number($ix) ?></th>
		<?php
				}
			}
		?>
		<th colspan=3>名前</th>
		<th colspan=2>分類</th>
		<th class="email_on_off" style="display:<?= $_COOKIE['abook_email_on_off'] == 'off' ? 'none;' : '' ?>">電話</th>
		<th class="email_on_off" style="display:<?= $_COOKIE['abook_email_on_off'] == 'off' ? 'none;' : '' ?>">EMailアドレス・メモ</th>
		<th>〒</th>
		<th>住所</th>
	</tr>
	<tbody id="abook_list_tbody">
<?php
	mysqli_data_seek($rs, $startline);
	$line = $startline;
	while ($rec=mysqli_fetch_array($rs) and $line<=$endline) {
		if ($rec['c_privacy'] == 444) {
			$list_tr = 'abook_list_privacy';
		} else {
			$list_tr = '';
		}
?>
	<tr class="<?= $list_tr ?>">
	<td class="abook_list_td a_check">
		<input class="abook_list_td_chk" type="checkbox" name="check[]" value="<?= $rec['id_abook'] ?>">
	</td>
	<?php
		for ($ix=1; $ix<=CHECK_ITEM_NUMBER; $ix++) {
			if ($chk_use[$ix]) {
	?>
		<td class="abook_list_mycheck" nowrap>
		<?php if (strstr($_SERVER['HTTP_USER_AGENT'], "MSIE")) { //IE ?>
		<input id="ck<?= $rec['id_abook'] ?>_<?= $ix ?>" class="abook_list_mycheck_chk_ie" style="background-color:<?= $rec['c_check'.$ix] == 1 ? CHECKED_BGCOLOR : UNCHECK_BGCOLOR ?>" type="checkbox" value="1"<?= $rec['c_check'.$ix] == 1 ? ' checked' : '' ?> OnClick="updateCheck(<?= $rec['id_abook'] ?>,<?= $ix ?>,this.checked)">
		<?php } else { ?>
		<span id="ck<?= $rec['id_abook'] ?>_<?= $ix ?>" class="abook_list_mycheck_span" style="background-color:<?= $rec['c_check'.$ix] == 1 ? CHECKED_BGCOLOR : UNCHECK_BGCOLOR ?>">
		<input class="abook_list_mycheck_chk" type="checkbox" value="1"<?= $rec['c_check'.$ix] == 1 ? ' checked' : '' ?> OnClick="updateCheck(<?= $rec['id_abook'] ?>,<?= $ix ?>,this.checked)"></span>
		<?php }  ?>
		</td>
	<?php
			}
		}
	?>
	<td class="abook_list_td a_name" style="padding-left:5px;">
		<p><a href="input.php?id=<?= $rec[$id_item] ?>&page=<?= $page ?>&pl=<?= $pageline ?>&cat=<?= $http_arg['cat'] ?>&ken=<?= $http_arg['ken'] ?>" class="tooltip"><?= my_htmlspecialchars($rec['c_name1']) ?><span><?= my_htmlspecialchars($rec['c_yomi1']) ?> <?= my_htmlspecialchars($rec['c_yomi2']) ?></span></a></p>
	</td>
	<td class="abook_list_td a_name">
		<p><a href="input.php?id=<?= $rec[$id_item] ?>&page=<?= $page ?>&pl=<?= $pageline ?>&cat=<?= $http_arg['cat'] ?>&ken=<?= $http_arg['ken'] ?>" class="tooltip"><?= my_htmlspecialchars($rec['c_name2']) ?><span><?= my_htmlspecialchars($rec['c_yomi1']) ?> <?= my_htmlspecialchars($rec['c_yomi2']) ?></span></a></p>
	</td>
	<td class="abook_list_td a_renmei" style="width:<?= $_COOKIE['abook_email_on_off'] == 'off' ? '40px;' : '26px;' ?>">
		<p><?= my_htmlspecialchars($rec['c_renmei']) ?></p>
	</td>
	<td class="abook_list_td a_category">
		<p><?= my_htmlspecialchars($rec['c_categoryName']) ?></p>
	</td>
	<td class="abook_list_td marker_icon">
		<?php
			if ($rec['c_markericon'] <> '') {
				$icon = $rec['c_markericon'];
			} else {
				$icon = $rec['c_categoryIcon'];
			}
		?>
		<?php	if ($icon <> '') { ?>
			<img src="<?= DIARY_MAPS_ICON_FOLDER ?><?= $icon ?>">
		<?php	} ?>
	</td>
	<td class="abook_list_td a_phone email_on_off" nowrap style="display:<?= $_COOKIE['abook_email_on_off'] == 'off' ? 'none;' : '' ?>">
		<p><?= my_htmlspecialchars($rec['c_phone1']) ?></p>
		<p><?= my_htmlspecialchars($rec['c_phone2']) ?></p>
	</td>
	<td class="abook_list_td a_email email_on_off" style="display:<?= $_COOKIE['abook_email_on_off'] == 'off' ? 'none;' : '' ?>">
		<p><a href="mailto:<?= urlencode(my_htmlspecialchars($rec['c_name1']).my_htmlspecialchars($rec['c_name2']).'様') ?>&lt;<?= my_htmlspecialchars($rec['c_email']) ?>&gt;"><?= my_htmlspecialchars($rec['c_email']) ?></a></p>
		<p><?= my_htmlspecialchars($rec['c_memo']) ?></p>
	</td>
	<td class="abook_list_td a_zip">
		<p><?= my_htmlspecialchars($rec['c_zip1']) ?>-<?= my_htmlspecialchars($rec['c_zip2']) ?></p>
		<p><a class="kenmei" href="?cat=<?= $_GET['cat'] ?>&ken=<?= $rec['c_kenid'] ?>"><?= my_htmlspecialchars($rec['c_kenmei']) ?></a></p>
	</td>
	<td class="abook_list_td a_address">
	<?php
		$address = my_htmlspecialchars($rec['c_address1']);
		$addr_enc = urlencode($address);
	?>
		<p><?= my_htmlspecialchars($rec['c_address1']) ?><br><?= my_htmlspecialchars($rec['c_address2']) ?>
	<?php
		if ($address <> '') {
			$link = '&nbsp;<a href="http://maps.google.co.jp/maps?q='.$addr_enc.'" target="_blank" class="map_href">→地図</a>';
			$link .= '&nbsp;<a href="../tools/google-maps-earth-v3.php?addr='.$addr_enc.'" target="_blank" class="map_href">→●</a>';
			$link .= '&nbsp;<a href="http://maps.google.co.jp/maps?ie=UTF8&f=d&ttype=dep&dirflg=r&saddr='.urlencode($_SESSION['login_friends_home_address_'.$_SESSION['current_id']]).'&daddr='.$addr_enc.'" target="_blank" class="route_href">→経路</a>';
			echo $link;
		}
	?>
		</p>
	</td>
	</tr>
<?php
		$line++;
	}
?>
	</tbody>
	</table>
	</form>
