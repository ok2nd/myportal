<?php
	require("__include-common.php");
	require("../account/__logincheck.php");
//	require("../account/__logincheck_write_permit.php");

	if ($_POST) {
		check_post_account($_POST['login_id'], $_POST['current_id']);
		post_done_proc();
	} else {
		html_header(HTML_TITLE);
		page_header();
		contents_header();
		input_form();
		page_footer();
		html_footer();
	}
	exit();
?>
<?php
function post_done_proc() {
	if ($_POST['user_id']."" <> "") {
		$user_id = $_POST['user_id'];
	} else {
		error_exit("不正アクセス：ユーザーIDなし", True);
	}
	if (check_permit_id($_SESSION['login_id'], $user_id) != "w") {
		error_exit("不正アクセス：書き込み権限がありません。", True);
	}
	$con = my_mysqli_connect(_DB_SCHEMA);
	$sql = "select * from m_check_caption where id_account = " . $user_id;
	$rs = my_mysqli_query($sql);
	if (mysqli_num_rows($rs) == 0) {
		$sql = "insert into m_check_caption ";
		$sql .= "(id_account";
		for ($ix=1; $ix<=CHECK_ITEM_NUMBER; $ix++) {
			$sql .= ", c_caption".$ix;
		}
		$sql .= ") values ";
		$sql .= "( '".$user_id."'";
		for ($ix=1; $ix<=CHECK_ITEM_NUMBER; $ix++) {
			$sql .= ", '".post_to_mysql("c_caption".$ix)."'";
		}
		$sql .= ")";
		$ret = my_mysqli_query($sql, "登録できませんでした。");
	} else {
		$sql = "update m_check_caption set";
		$sql .= " c_caption1 = '".$_POST['c_caption1']."'";
		for ($ix=2; $ix<=CHECK_ITEM_NUMBER; $ix++) {
			$sql .= ", c_caption".$ix." = '".post_to_mysql("c_caption".$ix)."'";
		}
		$sql .= " where id_account = ".$user_id;
		$ret = my_mysqli_query($sql, "更新できませんでした。");
	}
	mysqli_close($con);
	redirect("list.php?" . $_SERVER['QUERY_STRING']);
}
function input_form() {
	$con = my_mysqli_connect(_DB_SCHEMA);
	$sql = "select * from m_check_caption where id_account = " . $_SESSION['current_id'];
	$rs = my_mysqli_query($sql);
	$rec = mysqli_fetch_array($rs);
?>
<div class="input_form">
<h3><?= $_SESSION['current_handle'] ?><a class="a_cancel_back" href='javascript:history.back();'>戻る</a></h3>
<form name="form0" method="POST" action="<?= $_SERVER['SCRIPT_NAME'] ?>?<?= $_SERVER['QUERY_STRING'] ?>">
	<input type="hidden" name="login_id" value="<?= $_SESSION['login_id'] ?>">
	<input type="hidden" name="user_id" value="<?= $_SESSION['current_id'] ?>">
<table>
<?php
	for ($ix=1; $ix<=CHECK_ITEM_NUMBER; $ix++) {
?>
<tr>
	<td style="text-align:center;"><?= roman_number($ix) ?></td>
	<td>
	<input class="text" type="text" name="c_caption<?=$ix?>" size=20 value="<?= my_htmlspecialchars($rec['c_caption'.$ix]) ?>">
	</td>
</tr>
<?
	}
?>
</table>
<input class="input_form_button" type="submit" name="登録" value="登録">
</form>
<?
}
?>
