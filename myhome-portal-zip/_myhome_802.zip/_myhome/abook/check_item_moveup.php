<?php
	require("__include-common.php");
	require("../account/__logincheck.php");
	if ($_POST) {
		done_proc();
	} else {
		html_header(HTML_TITLE);
		page_header();
		contents_header();
		post_form();
		page_footer();
		html_footer();
		exit();
	}
?>
<?php
function post_form() {
?>
	<div style="margin: 20px;">
	<h3 style="color:#000000;">チェック項目繰上<a class="a_cancel_back" href='javascript:history.back();'>戻る</a></h3>
	<br>ユーザー「<span style="color:#ff0000; font-weight:bold;"><?= $_SESSION['login_friends_handle_'.$_SESSION['current_id']] ?></span>」の住所録<b>チェック項目</b>を、<b>見出し</b>と<b>チェックデータ</b>を、1つずらします。<br><br>処理実行後、元に戻すことは出来ませんので、注意してください。<br><br><br>
<?php
	if (check_permit_id($_SESSION['login_id'], $_SESSION['current_id']) != 'w') {
		error_exit("書き込み権限がありません。", True);
	}
	$caption = array();
	$sql = "select * from m_check_caption where id_account = " . $_SESSION['current_id'];
	$con = my_mysqli_connect(_DB_SCHEMA);
	$rs = my_mysqli_query($sql);
	if (mysqli_num_rows($rs) <> 0) {
		$rec = mysqli_fetch_array($rs);
		if ($rec) {
			for ($ix=1; $ix<=CHECK_ITEM_NUMBER; $ix++) {
				if ($rec['c_caption'.$ix] <> '') {
					$caption[$ix] = $rec['c_caption'.$ix];
				} else {
					$caption[$ix] = '(ブランク)';
				}
			}
		}
	}
	mysqli_close($con);
?>
	<table><tr>
<?php
	for ($ix=1; $ix<=CHECK_ITEM_NUMBER; $ix++) {
?>
		<td style="padding-right:10px;"><b><?= roman_number($ix) ?></b>:&nbsp;<span style="color:#ff0000"><?= $caption[$ix] ?></span></td>
<?php
	}
?>
	</tr>
	<tr><td colspan=6 style="text-align: center;padding: 10px 0;"><b>↓↓↓↓↓</b></td></tr>
	<tr>
	<td></td>
<?php
	for ($ix=1; $ix<=(CHECK_ITEM_NUMBER-1); $ix++) {
?>
		<td style="padding-right:10px;"><b><?= roman_number($ix) ?></b>:&nbsp;<span style="color:#ff0000"><?= $caption[$ix+1] ?></span></td>
<?php
	}
?>
	<td style="padding-right:10px;"><b><?= roman_number(CHECK_ITEM_NUMBER) ?></b>:&nbsp;<span style="color:#ff0000">(ブランク)</span></td>
	</tr></table>
	<br><br>
	<form name="form0" method="POST" action="<?= $_SERVER['SCRIPT_NAME'] ?>" style="margin-left:10px;">
		<label><input type="checkbox" name="実行確認" value="YES">実行確認</label>
		<input type="submit" name="実行" value="処理実行" style="margin-left:10px;">
		<input type="hidden" name="user_id" value="<?= $_SESSION['current_id'] ?>">
	</form>
	</div>
<?php
}
function done_proc() {
	if ($_POST['実行確認'] <> "YES") {
		error_exit("「実行確認」にチェックしてください。", True);
	}
	if ($_POST['user_id'].'' <> '') {
		$user_id = $_POST['user_id'];
	} else {
		error_exit("不正アクセス：ユーザーIDなし", True);
	}
	if ($user_id <> $_SESSION['current_id']) {
		error_exit("不正アクセス：ユーザーID不正", True);
	}
	if (check_permit_id($_SESSION['login_id'], $user_id) != 'w') {
		error_exit("不正アクセス：書き込み権限がありません。", True);
	}
	$con = my_mysqli_connect(_DB_SCHEMA);
	$sql = "update m_check_caption set";
	for ($ix=1; $ix<CHECK_ITEM_NUMBER; $ix++) {
		$sql .= " c_caption".$ix." = c_caption".($ix+1).",";
	}
	$sql .= " c_caption".CHECK_ITEM_NUMBER." = ''";
	$sql .= " where id_account = ".$user_id;
	my_mysqli_query($sql);
	mysqli_close($con);

	$con = my_mysqli_connect(_DB_SCHEMA);
	$sql = "update m_abook set";
	for ($ix=1; $ix<CHECK_ITEM_NUMBER; $ix++) {
		$sql .= " c_check".$ix." = c_check".($ix+1).",";
	}
	$sql .= " c_check".CHECK_ITEM_NUMBER." = 0";
	$sql .= " where id_account = ".$user_id;
	my_mysqli_query($sql);
	mysqli_close($con);
	redirect('list.php'.$_SERVER['QUERY_STRING']);
}
?>
