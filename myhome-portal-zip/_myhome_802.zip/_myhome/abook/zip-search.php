<?php
	require("__include-common.php");
?>
<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="utf-8">
<link rel="stylesheet" href="<?= _STYLE_SHEET_FOLDER_COMMON ?>/common.css?20131130">
<link rel="stylesheet" href="<?= _STYLE_SHEET_BUTTON ?>">
<style>
.outer {
	border-right: silver 1px solid; border-top: silver 1px solid;
	border-left: silver 1px solid; border-bottom: silver 1px solid;
	background-color: #808080;
}
tr.head td {
	padding-right: 1px; padding-left: 1px; padding-bottom: 1px; padding-top: 1px; background-color: #e0e0ff;
}
</style>
<script>
function addr_set(zip1,zip2,ken,addr) {
	window.opener.set_zip_addr(zip1,zip2,ken,addr);
	window.close();
}
</script>
<title>住所検索</title>
</head>
<body>
<center>
<center><br>
<h3>住所検索</h3>
<?php
	if ($_POST['clear']) {
		$addr = '';
	} else {
		$addr = $_POST['addr'];
	}
?>
<form method="post" action="">
	<font size=-1>住所の一部(カナ可)：</font><input type="text" name="addr" value="<?= $addr ?>">
	<input type="submit" name="search" value="検索">
	<input type="submit" name="clear" value="クリア">
</form>
<?php
	if ($addr <> '') {
		addr_list($addr);
	}
?>
<div style="margin-top:16px;">
<a href="http://groovetechnology.co.jp/webservice/" target="_blank"><img src="http://groovetechnology.co.jp/images/gt_websrv_w.gif" alt="グルーブテクノロジー Web サービス" width="125" height="17" /></a>
</div>
</body>
</html>
<?php
function addr_list($addr) {
	$url = 'http://api.postalcode.jp/v1/zipsearch?format=json&ie=UTF-8&oe=UTF-8&word='.urlencode($addr);
	$json = my_file_get_contents($url);
	$json_array = json_decode($json, true);
?>
	<p style="margin:4px 0;"><span style="color:red;">※ 住所をクリックしてください。</span>大口事業所は除いています。</p>
	<table border=0 cellpadding=1 cellspacing=1 class="outer">
	<tr class=head>
	<td align=left bgcolor=#ffffff nowrap><font size=-1>郵便番号</td>
	<td align=left bgcolor=#ffffff nowrap><font size=-1>都道府県</td>
	<td align=left bgcolor=#ffffff><font size=-1>住所</td>
	</tr>
<?php
	foreach ($json_array as $words) {
		foreach ($words as $word) {
			$zip1 = left($word['zipcode'],3);
			$zip2 = right($word['zipcode'],4);
			if (!$word['office_name']) {		//	['street']['office_name'] なし:大口事業所個別以外
?>
	<tr>
	<td align=left bgcolor=#ffffff nowrap><font size=-1><?= $zip1 ?>-<?= $zip2 ?></td>
	<td align=left bgcolor=#ffffff nowrap><font size=-1><?= $word['prefecture'] ?></td>
	<td align=left bgcolor=#ffffff><font size=-1><a href="javascript:addr_set('<?= $zip1 ?>','<?= $zip2 ?>','<?= $word['prefecture'] ?>','<?= $word['city'] ?><?= $word['town'] ?>')"><?= $word['city'] ?><?= $word['town'] ?></a></td>
	</tr>
<?php
			}
		}
	}
?>
	</table>
<?php
}
?>
