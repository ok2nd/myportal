<?php
	require("__include-common.php");
	require("../account/__logincheck.php");
	$table_name = "m_abook";
	$http_arg = http_arg_from_session_pool($table_name);
	$cat = $http_arg['cat'];
	html_header(HTML_TITLE, '', '#ffffff', '', '', '__html-my-header-map-japan.php');
	page_header();
	contents_header();
	map_japan('list.php', 'cat=' . $cat . '&ken');
	page_footer();
	html_footer();
?>
<?php
function map_japan($php, $arg) {
?>
<table id="clickable_map" cellspacing="1">
<tr>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td colspan=2 id="hokkaido"><a href="<?= $php ?>?<?= $arg ?>=01" class="hokkaido">北海道</a></td>
</tr>
<tr>
	<td colspan=13 style="height: 10px; line-height: 10px;"></td>
</tr>
<tr>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td colspan=2 class="colspan_2"><a href="<?= $php ?>?<?= $arg ?>=02" class="touhoku">青森</a></td>
</tr>
<tr>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td><a href="<?= $php ?>?<?= $arg ?>=04" class="touhoku">秋田</a></td>
	<td><a href="<?= $php ?>?<?= $arg ?>=03" class="touhoku">岩手</a></td>
</tr>
<tr>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td><a href="<?= $php ?>?<?= $arg ?>=05" class="touhoku">山形</a></td>
	<td><a href="<?= $php ?>?<?= $arg ?>=06" class="touhoku">宮城</a></td>
</tr>
<tr>
	<td><a href="<?= $php ?>?<?= $arg ?>=47" class="kyushu">沖縄</a></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td><a href="<?= $php ?>?<?= $arg ?>=23" class="chubu">石川</a></td>
	<td></td>
	<td colspan=2 class="colspan_2"><a href="<?= $php ?>?<?= $arg ?>=21" class="chubu">新潟</a></td>
	<td colspan=2 class="colspan_2"><a href="<?= $php ?>?<?= $arg ?>=07" class="touhoku">福島</a></td>
</tr>
<tr>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td><a href="<?= $php ?>?<?= $arg ?>=22" class="chubu">福井</a></td>
	<td><a href="<?= $php ?>?<?= $arg ?>=24" class="chubu">富山</a></td>
	<td rowspan=2 class="rowspan_2"><a href="<?= $php ?>?<?= $arg ?>=19" class="chubu">長野</a></td>
	<td><a href="<?= $php ?>?<?= $arg ?>=14" class="kantou">群馬</a></td>
	<td><a href="<?= $php ?>?<?= $arg ?>=13" class="kantou">栃木</a></td>
	<td><a href="<?= $php ?>?<?= $arg ?>=12" class="kantou">茨城</a></td>
</tr>
<tr>
	<td></td>
	<td></td>
	<td></td>
	<td><a href="<?= $php ?>?<?= $arg ?>=35" class="chugoku">島根</a></td>
	<td><a href="<?= $php ?>?<?= $arg ?>=34" class="chugoku">鳥取</a></td>
	<td rowspan=2 class="rowspan_2"><a href="<?= $php ?>?<?= $arg ?>=27" class="kinki">兵庫</a></td>
	<td><a href="<?= $php ?>?<?= $arg ?>=26" class="kinki">京都</a></td>
	<td><a href="<?= $php ?>?<?= $arg ?>=28" class="kinki">滋賀</a></td>
	<td><a href="<?= $php ?>?<?= $arg ?>=17" class="chubu">岐阜</a></td>
	<td><a href="<?= $php ?>?<?= $arg ?>=15" class="chubu">山梨</a></td>
	<td><a href="<?= $php ?>?<?= $arg ?>=10" class="kantou">埼玉</a></td>
	<td rowspan=2 class="rowspan_2"><a href="<?= $php ?>?<?= $arg ?>=11" class="kantou">千葉</a></td>
</tr>
<tr>
	<td></td>
	<td></td>
	<td><a href="<?= $php ?>?<?= $arg ?>=33" class="chugoku">山口</a></td>
	<td><a href="<?= $php ?>?<?= $arg ?>=31" class="chugoku">広島</a></td>
	<td><a href="<?= $php ?>?<?= $arg ?>=32" class="chugoku">岡山</a></td>
	<td><a href="<?= $php ?>?<?= $arg ?>=25" class="kinki">大阪</a></td>
	<td><a href="<?= $php ?>?<?= $arg ?>=29" class="kinki">奈良</a></td>
	<td><a href="<?= $php ?>?<?= $arg ?>=16" class="chubu">愛知</a></td>
	<td><a href="<?= $php ?>?<?= $arg ?>=18" class="chubu">静岡</a></td>
	<td><a href="<?= $php ?>?<?= $arg ?>=09" class="kantou">神奈川</a></td>
	<td><a href="<?= $php ?>?<?= $arg ?>=08" class="kantou">東京</a></td>
</tr>
<tr>
	<td><a href="<?= $php ?>?<?= $arg ?>=41" class="kyushu">佐賀</a></td>
	<td><a href="<?= $php ?>?<?= $arg ?>=40" class="kyushu">福岡</a></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td><a href="<?= $php ?>?<?= $arg ?>=30" class="kinki">和歌山</a></td>
	<td><a href="<?= $php ?>?<?= $arg ?>=20" class="chubu">三重</a></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
</tr>
<tr>
	<td><a href="<?= $php ?>?<?= $arg ?>=42" class="kyushu">長崎</a></td>
	<td><a href="<?= $php ?>?<?= $arg ?>=44" class="kyushu">大分</a></td>
	<td></td>
	<td><a href="<?= $php ?>?<?= $arg ?>=38" class="shikoku">愛媛</a></td>
	<td><a href="<?= $php ?>?<?= $arg ?>=37" class="shikoku">香川</a></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
</tr>
<tr>
	<td><a href="<?= $php ?>?<?= $arg ?>=43" class="kyushu">熊本</a></td>
	<td><a href="<?= $php ?>?<?= $arg ?>=45" class="kyushu">宮崎</a></td>
	<td></td>
	<td><a href="<?= $php ?>?<?= $arg ?>=39" class="shikoku">高知</a></td>
	<td><a href="<?= $php ?>?<?= $arg ?>=36" class="shikoku">徳島</a></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
</tr>
<tr>
	<td colspan=2 class="colspan_2"><a href="<?= $php ?>?<?= $arg ?>=46" class="kyushu">鹿児島</a></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
</tr>
</table>
<?php
}
?>
