<?php
function add_where_create($http_arg) {
	$add_where = "";
	for ($ix=1; $ix<=CHECK_ITEM_NUMBER; $ix++) {
		if ($_GET['chk'.$ix] <> '') {
			if ($_GET['chk'.$ix] == 'all') {
				 $_SESSION[$_SESSION['current_id'].'abook_chk_sel'.$ix] = '';
			} else {
				 $_SESSION[$_SESSION['current_id'].'abook_chk_sel'.$ix] = $_GET['chk'.$ix];
			}
		}
		if ($_SESSION[$_SESSION['current_id'].'abook_chk_sel'.$ix] <> '') {
			if ($add_where <> "") $add_where .= " and";
			$add_where .= " c_check".$ix." = '".$_SESSION[$_SESSION['current_id'].'abook_chk_sel'.$ix]."'";
		}
	}
	if ($_GET['yomi'].'' == '__reset__') {
		$_SESSION['abook_yomi'] = '';
	} elseif ($_GET['yomi'].'' <> '') {
		$_SESSION['abook_yomi'] = $_GET['yomi'];
	}
	if ($_SESSION['abook_yomi'] <> '') {
		if ($add_where <> "") $add_where .= " and";
			if ($_SESSION['abook_yomi'] >= 'A' and $_SESSION['abook_yomi'] <= 'Z') {
				$add_where .= " (c_name1 like '".$_SESSION['abook_yomi']."%'";
				$add_where .= " or c_name2 like '".$_SESSION['abook_yomi']."%'";
				$add_where .= " or c_yomi1 like '".$_SESSION['abook_yomi']."%'";
				$add_where .= " or c_yomi2 like '".$_SESSION['abook_yomi']."%' )";
			} else {
				$add_where .= " (";
				$kana_ary = kana_array();
				foreach ($kana_ary as $kana) {
					if ($kana[0] == $_SESSION['abook_yomi']) {
						$len = mb_strlen($kana[1]);
						for ($ix=0; $ix<$len; $ix++) {
							if ($ix<>0) {
								$add_where .= " or";
							}
							$add_where .= " c_name1 like '".mb_substr($kana[1],$ix,1)."%'";
							$add_where .= " or c_name2 like '".mb_substr($kana[1],$ix,1)."%'";
							$add_where .= " or c_yomi1 like '".mb_substr($kana[1],$ix,1)."%'";
							$add_where .= " or c_yomi2 like '".mb_substr($kana[1],$ix,1)."%'";
						}
					}
				}
				$add_where .= " )";
			}
	}
	if ($_GET['cat'] == HYAKUMEIZAN_CATEGORY_ID) {
		if ($_GET['hm_kubun'].'' == '__reset__') {
			$_SESSION['abook_hyakumeizan_kubun'] = '';
		} elseif ($_GET['hm_kubun'].'' <> '') {
			$_SESSION['abook_hyakumeizan_kubun'] = $_GET['hm_kubun'];
		}
		if ($_SESSION['abook_hyakumeizan_kubun'] <> '') {
			if ($add_where <> "") $add_where .= " and";
			$add_where .= " (c_name2 = '".$_SESSION['abook_hyakumeizan_kubun']."')";
		}
	}
	if ($_GET['cat'] == SEKAI_ISAN_CATEGORY_ID) {
		if ($_GET['wh_kubun'].'' == '__reset__') {
			$_SESSION['abook_sekaiisan_kubun'] = '';
		} elseif ($_GET['wh_kubun'].'' <> '') {
			$_SESSION['abook_sekaiisan_kubun'] = $_GET['wh_kubun'];
		}
		if ($_SESSION['abook_sekaiisan_kubun'] <> '') {
			if ($add_where <> "") $add_where .= " and";
			$add_where .= " (c_memo like '%".$_SESSION['abook_sekaiisan_kubun']."%')";
		//	$add_where .= " (c_memo = '".$_SESSION['abook_sekaiisan_kubun']."' or";
		//	$add_where .= " c_memo like '".$_SESSION['abook_sekaiisan_kubun']."/%')";
		}
	}
	if ($_GET['cat'] == HYAKUSEN_CATEGORY_ID) {
		if ($_GET['hs_kubun'].'' == '__reset__') {
			$_SESSION['abook_hyakusen_kubun'] = '';
		} elseif ($_GET['hs_kubun'].'' <> '') {
			$_SESSION['abook_hyakusen_kubun'] = $_GET['hs_kubun'];
		}
		if ($_SESSION['abook_hyakusen_kubun'] <> '') {
			if ($add_where <> "") $add_where .= " and";
			$add_where .= " (c_memo = '".$_SESSION['abook_hyakusen_kubun']."')";
		}
	}
	return ($add_where);
}
?>
<?php
function add_my_filter($http_arg) {
?>
	<div id="check_select">
<script>
jQuery(function(){
	jquery_cs_function = 'SelectionYomi';
	jquery_cs_arg = 'yomi';
	jquery_cs_style = '';
	$('#jquery_cs_yomi select').cs();
});
function SelectionYomi(key, data) {
	window.location.href = "?"+key+"="+data+"&<?= query_from_http_arg_pool($http_arg, 'yomi') ?>";
}
function SelectionYomiReset() {
	window.location.href = "?yomi=__reset__&<?= query_from_http_arg_pool($http_arg, 'yomi') ?>";
}
</script>
<span id="jquery_cs_yomi">
	読み：<select class="<? if ($_SESSION['abook_yomi'] <> '') echo 'mp_list_filter_true'; ?>">：
	<option value="__reset__" class="mp_list_filter_false">すべて</option>
<?php
	$kana_ary = kana_array();
	$ix = 0;
	foreach ($kana_ary as $kana) {
		if ((floor($ix/5)*5 == $ix and $ix <= 35) or $ix == 38 or $ix == 43) {
			if ($ix <> 0) {
				if (!strstr($_SERVER['HTTP_USER_AGENT'], "MSIE")) {
				// IE以外 (なぜか一番下の選択肢がリセットのボックスにはみ出してしまうため)
?>
			<option value=""></option>
<?php
				}
?>
		</optgroup>
<?php
			}
?>
		<optgroup label="<?= $kana[0] ?>">
<?php
		}
?>
		<option value="<?= urlencode($kana[0]) ?>"<?= $kana[0] == $_SESSION['abook_yomi'] ? ' selected class="mp_list_filter_true"' : ' class="mp_list_filter_false"' ?>><?= $kana[0] ?></option>
<?php
		$ix++;
	}
	for ($ix=65; $ix<91; $ix++) {
		if (floor($ix/5)*5 == $ix and $ix <> 90) {
				if (!strstr($_SERVER['HTTP_USER_AGENT'], "MSIE")) {
				// IE以外 (なぜか一番下の選択肢がリセットのボックスにはみ出してしまうため)
?>
			<option value=""></option>
		</optgroup>
<?php
			}
?>
		<optgroup label="<?= chr($ix) ?>">
<?php
		}
?>
		<option value="<?= chr($ix) ?>"<?= chr($ix) == $_SESSION['abook_yomi'] ? ' selected class="mp_list_filter_true"' : ' class="mp_list_filter_false"' ?>><?= chr($ix) ?></option>
<?php
	}
		if (!strstr($_SERVER['HTTP_USER_AGENT'], "MSIE")) {
		// IE以外 (なぜか一番下の選択肢がリセットのボックスにはみ出してしまうため)
?>
		<option value=""></option>
<?php
		}
?>
		</optgroup>
	</select>
	<input type="button" value="リセット" onClick="SelectionYomiReset()">
</span>
<script>
function SelectionCheck(form, sel, no) {
	for (i = 0; i < sel.options.length; i++) {
		if (sel.options[i].selected == true) {
			window.location.href = '<?= $_SERVER['SCRIPT_NAME'] ?>?<?= query_from_http_arg_pool($http_arg) ?>&chk' + no + '=' + sel.options[i].value;
		}
	}
}
<?php
	$chkclr = '';
	for ($ix=1; $ix<=CHECK_ITEM_NUMBER; $ix++) {
		$chkclr .= '&chk'.$ix.'=all';
	}
?>
function SelectionCheckClear() {
	window.location.href = '<?= $_SERVER['SCRIPT_NAME'] ?>?<?= query_from_http_arg_pool($http_arg) ?><?= $chkclr ?>';
}
function EmailOnOff(sel) {
	if ($(sel).attr('checked')) {
		$.cookie("abook_email_on_off","off",{ path:'<?= MY_SESSION_PATH ?>', expires:365 });
		$('#email_on_off_chk').css('background-color','#ffe0c0');
		$('.email_on_off').css('display','none');
		$('.a_renmei').css('width','40px');
	} else {
		$.cookie("abook_email_on_off","",{ path:'<?= MY_SESSION_PATH ?>', expires:365 });
		$('#email_on_off_chk').css('background-color','');
		$('.email_on_off').css('display','');
		$('.a_renmei').css('width','26px');
	}
}
</script>
<script>
function SelectionKubun(sel, selname) {
	for (i = 0; i < sel.options.length; i++) {
		if (sel.options[i].selected == true) {
			window.location.href = "<?= $_SERVER['SCRIPT_NAME'] ?>?<?= query_from_http_arg_pool($http_arg) ?>" + "&" + selname + "=" + encodeURL(sel.options[i].value);
		}
	}
}
function SelectionKubunReset(selname) {
	window.location.href = "<?= $_SERVER['SCRIPT_NAME'] ?>?<?= query_from_http_arg_pool($http_arg) ?>" + "&" + selname + "=__reset__";
}
</script>
<?php
	if ($_GET['cat'] <> HYAKUMEIZAN_CATEGORY_ID and $_GET['cat'] <> SEKAI_ISAN_CATEGORY_ID and $_GET['cat'] <> TETSUDO_EKI_CATEGORY_ID and $_GET['cat'] <> SAKURA_MEISHO_CATEGORY_ID and $_GET['cat'] <> HYAKUSEN_CATEGORY_ID) {
?>
	<label><input type="checkbox" name="" value="on" onClick="EmailOnOff(this)" <?= $_COOKIE['abook_email_on_off'] == 'off' ? ' checked' : '' ?> style="margin-left:5px;"><span id="email_on_off_chk" style="<?= $_COOKIE['abook_email_on_off'] == 'off' ? 'background-color: #ffe0c0;' : '' ?>">電話・EMail表示なし</span></label>
<?php
	}
?>
<?php
	if ($_GET['cat'] == HYAKUMEIZAN_CATEGORY_ID) {
		$kubun_tbl = array("百名山", "二百名山", "三百名山")
?>
	<span style="margin-left:5px;">百名山区分：<select name="" onchange="SelectionKubun(this, 'hm_kubun')"<? if ($_SESSION['abook_hyakumeizan_kubun'] <> '') echo ' class="mp_list_filter_true"'; ?>>
	<option value="__reset__" class="mp_list_filter_false">すべて</option>
<?php
		foreach ($kubun_tbl as $kubun) {
?>
		<option value="<?= $kubun ?>"<?= $_SESSION['abook_hyakumeizan_kubun'] == $kubun ? ' selected class="mp_list_filter_true"' : ' class="mp_list_filter_false"' ?>><?= $kubun ?></option>
<?php
		}
?>
	</select></span>
	<input type="button" value="リセット" onClick="SelectionKubunReset('hm_kubun')">
<?php
	}
?>
<?php
	if ($_GET['cat'] == SEKAI_ISAN_CATEGORY_ID) {
?>
	<span style="margin-left:5px;">国：<select name="" onchange="SelectionKubun(this, 'wh_kubun')"<? if ($_SESSION['abook_sekaiisan_kubun'] <> '') echo ' class="mp_list_filter_true"'; ?>>
	<option value="__reset__" class="mp_list_filter_false">すべて</option>
<?php
		$kubun_tbl = explode(",", SEKAI_ISAN_COUNTRY);
		$kubun_check = False;
		foreach ($kubun_tbl as $kubun) {
?>
		<option value="<?= $kubun ?>"<?= $_SESSION['abook_sekaiisan_kubun'] == $kubun ? ' selected class="mp_list_filter_true"' : ' class="mp_list_filter_false"' ?>><?= $kubun ?></option>
<?php
			if ($_SESSION['abook_sekaiisan_kubun'] == $kubun) {
				$kubun_check = True;
			}
		}
		if ($_SESSION['abook_sekaiisan_kubun'] <> '' and $kubun_check == False) {
?>
		<option value="<?= $_SESSION['abook_sekaiisan_kubun'] ?>" selected class="mp_list_filter_true"><?= $_SESSION['abook_sekaiisan_kubun'] ?></option>
<?php
		}
?>
	</select></span>
	<input type="button" value="リセット" onClick="SelectionKubunReset('wh_kubun')">
	<a href="world-map.php" style="margin-left:20px;color:#ff8000;" target="_blank">世界地図</a>
<?php
	}
?>
<?php
	if ($_GET['cat'] == HYAKUSEN_CATEGORY_ID) {
?>
	<span style="margin-left:5px;">百選種類：<select name="" onchange="SelectionKubun(this, 'hs_kubun')"<? if ($_SESSION['abook_hyakusen_kubun'] <> '') echo ' class="mp_list_filter_true"'; ?>>
	<option value="__reset__" class="mp_list_filter_false">すべて</option>
<?php
		$sql_kbn = "select distinct c_memo from m_abook where id_category = ".HYAKUSEN_CATEGORY_ID." order by c_memo";
		$rs_kbn = my_mysqli_query($sql_kbn);
		while ($rec_kbn = mysqli_fetch_array($rs_kbn)) {
?>
		<option value="<?= $rec_kbn['c_memo'] ?>"<?= $_SESSION['abook_hyakusen_kubun'] == $rec_kbn['c_memo'] ? ' selected class="mp_list_filter_true"' : ' class="mp_list_filter_false"' ?>><?= $rec_kbn['c_memo'] ?></option>
<?php
		}
?>
	</select></span>
	<input type="button" value="リセット" onClick="SelectionKubunReset('hs_kubun')">
	<a href="list-hyakusen-shurui.php" style="margin-left:20px;color:#0060c0;">百選種類一覧</a>
<?php
	}
?>
	</div>
<?php
	global $chk_use;	// list-my-template.phpで使用
	$chk_use = array();
	$sqlchk = "select * from m_check_caption where id_account = " . $_SESSION['current_id'];
	$sqlchk .= " and ( c_caption1 <> '' or c_caption2 <> '' or c_caption3 <> '' or c_caption4 <> '' or c_caption5 <> '' )";
	$rs_chk = my_mysqli_query($sqlchk);
	if (mysqli_num_rows($rs_chk) <> 0) {
		$rec = mysqli_fetch_array($rs_chk);
		if ($rec) {
?>
		<p id="check_caption_box">チェック有無：<?php
			for ($ix=1; $ix<=CHECK_ITEM_NUMBER; $ix++) {
				if ($rec['c_caption'.$ix] <> '') {
					$chk_use[$ix] = True;
?><select name="" onchange="SelectionCheck(this.form, this, <?= $ix ?>)"<? if ($_SESSION[$_SESSION['current_id'].'abook_chk_sel'.$ix] <> '') echo ' class="mp_list_filter_true"'; ?>>
		<option value="all" class="mp_list_filter_false">
		<option value="1"<?= $_SESSION[$_SESSION['current_id'].'abook_chk_sel'.$ix] == '1' ? ' selected class="mp_list_filter_true"' : ' class="mp_list_filter_false"' ?>>有
		<option value="0"<?= $_SESSION[$_SESSION['current_id'].'abook_chk_sel'.$ix] == '0' ? ' selected class="mp_list_filter_true"' : ' class="mp_list_filter_false"' ?>>無
		</select><span class="check_caption" style="margin-right:2px;"><b><?= roman_number($ix) ?></b>：<?= $rec['c_caption'.$ix] ?></span>
<?php
				} else{
					$chk_use[$ix] = False;
				}
			}
?>
		<input type="button" value="←リセット" onClick="SelectionCheckClear()">
		<!--<a href="check_item_moveup.php" style="margin-left:5px;">チェック項目繰上</a>-->
		</p>
<?php
		}
	}
}
?>
<?php
function kana_array() {
	$kana = array(
			array('あ','あア'),
			array('い','いイ'),
			array('う','うウヴ'),
			array('え','えエ'),
			array('お','おオ'),
			array('か','かカがガ'),
			array('き','きキぎギ'),
			array('く','くクぐグ'),
			array('け','けケげゲ'),
			array('こ','こコごゴ'),
			array('さ','さサざザ'),
			array('し','しシじジ'),
			array('す','すスずズ'),
			array('せ','せセぜゼ'),
			array('そ','そソぞゾ'),
			array('た','たタだダ'),
			array('ち','ちチぢヂ'),
			array('つ','つツづヅ'),
			array('て','てテでデ'),
			array('と','とトどド'),
			array('な','なナ'),
			array('に','にニ'),
			array('ぬ','ぬヌ'),
			array('ね','ねネ'),
			array('の','のノ'),
			array('は','はハばバぱパ'),
			array('ひ','ひヒびビぴピ'),
			array('ふ','ふフぶブぷプ'),
			array('へ','へヘべベぺペ'),
			array('ほ','ほホぼボぽポ'),
			array('ま','まマ'),
			array('み','みミ'),
			array('む','むム'),
			array('め','めメ'),
			array('も','もモ'),
			array('や','やヤ'),
			array('ゆ','ゆユ'),
			array('よ','よヨ'),
			array('ら','らラ'),
			array('り','りリ'),
			array('る','るル'),
			array('れ','れレ'),
			array('ろ','ろロ'),
			array('わ','わワ'),
			array('を','をヲ'),
			array('ん','んン'),
		);
	return $kana;
}
?>
