<?php
	if (defined("HTML_TITLE_abook")) {
		define("HTML_TITLE", HTML_TITLE_abook);
	} else {
		define("HTML_TITLE", "MyHome 住所録");
	}
	define("SESSION_PREFIX", "abook");

	if (defined("_DB_SCHEMA_abook")) {
		define("_DB_SCHEMA", _DB_SCHEMA_abook);
	} else {
		define("_DB_SCHEMA", "_db_abook");
	}
	if (!defined("CHECKED_BGCOLOR")) {
		define("CHECKED_BGCOLOR", "#ffd000");
		define("UNCHECK_BGCOLOR", "#e0e0e0");
	}
	if (!defined("HYAKUMEIZAN_CATEGORY_ID")) {
		define("HYAKUMEIZAN_CATEGORY_ID", 3);		//百名山のid_category(in m_category)
	}
	if (!defined("SEKAI_ISAN_CATEGORY_ID")) {
		define("SEKAI_ISAN_CATEGORY_ID", 4);		//世界遺産のid_category(in m_category)
	}
	if (!defined("TETSUDO_EKI_CATEGORY_ID")) {
		define("TETSUDO_EKI_CATEGORY_ID", 5);		//鉄道駅のid_category(in m_category)
	}
	if (!defined("SAKURA_MEISHO_CATEGORY_ID")) {
		define("SAKURA_MEISHO_CATEGORY_ID", 6);		//桜名所のid_category(in m_category)
	}
	if (!defined("HYAKUSEN_CATEGORY_ID")) {
		define("HYAKUSEN_CATEGORY_ID", 7);		//日本百選のid_category(in m_category)
	}
	if (!defined("CHECK_ITEM_NUMBER")) {
		define("CHECK_ITEM_NUMBER", 6);			//チェック項目の数
	}
	if (!defined("SEKAI_ISAN_COUNTRY")) {
		define("SEKAI_ISAN_COUNTRY", "日本,中華人民共和国,大韓民国,イタリア,スペイン,フランス,ドイツ,英国,スイス,ベルギー,ギリシャ,ポルトガル,スウェーデン,ポーランド,チェコ,ロシア,カナダ,アメリカ合衆国,メキシコ,ブラジル,ペルー,インド,イラン,オーストラリア");
	}
	if (!defined("DIARY_MAPS_ICON_FOLDER")) {
		define("DIARY_MAPS_ICON_FOLDER", "../icon/maps/");
	}
	define("IMAGES_FOLDER", DIARY_MAPS_ICON_FOLDER);
	define("PAGE_LINE_SELECT", "5,10,20,50,100,200,1000");	//頁内に表示する行数
	define("PAGE_LINE_DEFAULT", "10");			//頁内に表示する行数（デフォルト）
?>
