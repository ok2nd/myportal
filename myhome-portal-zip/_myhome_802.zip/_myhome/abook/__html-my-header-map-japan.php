<meta charset="utf-8">
<meta name="author" content="ok.2nd">
<meta name="description" content="abook">
<meta name="keywords" content="abook">
<link rel="stylesheet" href="<?= _STYLE_SHEET_FOLDER_COMMON ?>/common.css?20131130">
<link rel="stylesheet" href="<?= _STYLE_SHEET_BUTTON ?>">
<link rel="stylesheet" href="<?= _STYLE_SHEET_FOLDER ?>/map-japan.css?20091114">
