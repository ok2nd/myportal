<meta charset="utf-8">
<meta name="author" content="ok.2nd">
<meta name="description" content="abook">
<meta name="keywords" content="abook">
<link rel="stylesheet" href="<?= _STYLE_SHEET_FOLDER_COMMON ?>/common.css?20131130">
<link rel="stylesheet" href="<?= _STYLE_SHEET_BUTTON ?>">
<link rel="stylesheet" href="<?= _STYLE_SHEET_FOLDER ?>/mp-list.css?20130525">
<link rel="stylesheet" href="<?= _STYLE_SHEET_FOLDER ?>/abook.css?20140208">
<script src="../scripts/jquery.js"></script>
<script src="../scripts/jquery.cookie.js"></script>
<script src="../scripts/ok2nd.js"></script>
<script src="../scripts/jquery.cs.ok2nd.js"></script>
