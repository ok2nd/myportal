<?php
	require("__include-common.php");
	require("../account/__logincheck.php");
	require("../__common__/include-common-mp-list.php");

	if (isset($_GET['em'])) {
		$_SESSION['abook_email_off'] = $_GET['em'];
		setcookie('abook_email_off', $_SESSION['abook_email_off'], time() + LOGIN_COOKIE_EXPIRE, MY_SESSION_PATH);
	} else {
		if (isset($_COOKIE['abook_email_off'])) {
			$_SESSION['abook_email_off'] = $_COOKIE['abook_email_off'];
		}
	}

	$table_name_view = "v_abook";
	$table_name = "m_abook";
	$id_item = "id_abook";
	$must_item = "c_title";

	$mp_list_arg = array();
	$mp_list_arg['account_id']	= $_SESSION['current_id'];
	$mp_list_arg['table_name_view']		= "v_abook";
	$mp_list_arg['table_name_edit']		= "v_abook";
	$mp_list_arg['table_name_update']	= "m_abook";
	$mp_list_arg['id_item']		= "id_abook";
	$mp_list_arg['must_item']	= "c_name1";
	$mp_list_arg['add_filter']	= "list-my-add-filter.php";
	$mp_list_arg['input_new']	= "yes";
	$mp_list_arg['use_privacy']	= "yes";
	$mp_list_arg['add_list']	= "yes";

	if ($_GET['cat'] == HYAKUMEIZAN_CATEGORY_ID) {		//百名山のid_categor
		$mp_list_arg['template_view']	= "list-my-template-hyakumeizan.php";
	} elseif ($_GET['cat'] == SEKAI_ISAN_CATEGORY_ID) {	//世界遺産のid_categor
		$mp_list_arg['template_view']	= "list-my-template-sekaiisan.php";
	} elseif ($_GET['cat'] == TETSUDO_EKI_CATEGORY_ID) {	//鉄道駅のid_categor
		$mp_list_arg['template_view']	= "list-my-template-tetsudo-eki.php";
	} elseif ($_GET['cat'] == SAKURA_MEISHO_CATEGORY_ID) {	//桜名所のid_categor
		$mp_list_arg['template_view']	= "list-my-template-sakura-meisho.php";
	} elseif ($_GET['cat'] == HYAKUSEN_CATEGORY_ID) {	//日本百選のid_categor
		$mp_list_arg['template_view']	= "list-my-template-hyakusen.php";
	} else {
		$mp_list_arg['template_view']	= "list-my-template.php";
	}
	$item_tbl = array();
	$item_tbl[] = array(	"表示名"=>"分類",	"列名"=>"id_category", "http_arg_GET名"=>"cat",
				"type"=>"select", "参照テーブル"=>"m_category", "参照テーブル表示列"=>"c_categoryName",
				"参照テーブル表示順"=>"c_categoryDisplayOrder", "参照テーブル表示色"=>"c_categoryDisplayColor");
	$item_tbl[] = array(	"表示名"=>"姓<br>(よみ)",	"列名"=>"c_name1", "align"=>"right",
				"type"=>"text", "size"=>20, "ime-mode"=>"active", "文字検索"=>"Y", "break"=>"後");
	$item_tbl[] = array(	"表示名"=>"",	"列名"=>"c_yomi1", "文字変換"=>"ひらがな",
				"type"=>"text", "size"=>20, "ime-mode"=>"active", "文字検索"=>"Y", "break"=>"前後");
	$item_tbl[] = array(	"ラベル"=>"連名&nbsp;",
				"type"=>"no_edit", "break"=>"前");
	$item_tbl[] = array(	"表示名"=>"名<br>(よみ)",	"列名"=>"c_name2",
				"type"=>"text", "size"=>20, "ime-mode"=>"active", "文字検索"=>"Y", "break"=>"後");
	$item_tbl[] = array(	"表示名"=>"",	"列名"=>"c_yomi2", "文字変換"=>"ひらがな",
				"type"=>"text", "size"=>20, "ime-mode"=>"active", "文字検索"=>"Y", "break"=>"前後");
	$item_tbl[] = array(	"表示名"=>"",	"列名"=>"c_renmei",
				"type"=>"text", "size"=>20, "ime-mode"=>"active", "文字検索"=>"Y", "break"=>"前");
	$item_tbl[] = array(	"表示名"=>"電話", "ラベル"=>"固",	"列名"=>"c_phone1", "align"=>"right",
				"type"=>"text", "size"=>18, "ime-mode"=>"inactive", "break"=>"後");
	$item_tbl[] = array(	"表示名"=>"",	"ラベル"=>"携",	"列名"=>"c_phone2",
				"type"=>"text", "size"=>18, "ime-mode"=>"inactive", "break"=>"前");
	$item_tbl[] = array(	"表示名"=>"EMail・メモ",	"列名"=>"c_email", "align"=>"right",
				"type"=>"text", "size"=>46, "ime-mode"=>"inactive", "文字検索"=>"Y", "break"=>"後");
	$item_tbl[] = array(	"表示名"=>"",	"ラベル"=>"メモ", "列名"=>"c_memo",
				"type"=>"text", "size"=>40, "ime-mode"=>"active", "文字検索"=>"Y", "break"=>"前後");
	$item_tbl[] = array(	"表示名"=>"",	"ラベル"=>"アイコン", "列名"=>"c_markericon",
				"type"=>"text", "size"=>30, "ime-mode"=>"inactive", "break"=>"前");
	$item_tbl[] = array(	"表示名"=>"住所", "ラベル"=>"〒",	"列名"=>"c_zip1", "align"=>"left",
				"type"=>"text", "size"=>5, "ime-mode"=>"inactive", "break"=>"後連");
	$item_tbl[] = array(	"表示名"=>"", "ラベル"=>"-",	"列名"=>"c_zip2", "align"=>"left",
				"type"=>"text", "size"=>8, "ime-mode"=>"inactive", "break"=>"連");
	if ($_GET['cat'] <> SEKAI_ISAN_CATEGORY_ID) {		//世界遺産のid_categor
	$item_tbl[] = array(	"表示名"=>"都道府県", "ラベル"=>"都道府県", "列名"=>"c_kenid", "align"=>"left", "break"=>"連後",
				"type"=>"select", "http_arg_GET名"=>"ken",
				"参照テーブル"=>"r_kenmei", "参照テーブル表示列"=>"c_kenmei", "参照テーブル表示順"=>"c_kenid",
				"参照テーブルoptgroup"=>"c_area",
				"optgroup_jquery_cs"=>"yes",		// 都道府県選択のプルダウンで「jquery.cs.js」を使用
				"参照テーブルユーザー"=>"共有", "filter_c_delete"=>"no", "select_space"=>"Y");
	}
	$item_tbl[] = array(	"表示名"=>"",	"列名"=>"c_address1",
				"type"=>"text", "size"=>50, "ime-mode"=>"active", "文字検索"=>"Y", "break"=>"前後");
	$item_tbl[] = array(	"表示名"=>"",	"ラベル"=>"ビル名", "列名"=>"c_address2",
				"type"=>"text", "size"=>50, "ime-mode"=>"active", "文字検索"=>"Y", "break"=>"前");
	$order_tbl = array();
	$order_tbl[] = array(   "表示名"=>"最新順", "get_order_name"=>"new",
				"order_by"=>"id_abook desc");		/* default */

	if ($_GET['cat'] == HYAKUMEIZAN_CATEGORY_ID) {			//百名山のid_categor
		$order_tbl[] = array(   "表示名"=>"名前よみ順", "get_order_name"=>"name",
					"order_by"=>"c_yomi1");
		$order_tbl[] = array(   "表示名"=>"区分(+名前よみ)順", "get_order_name"=>"kbn",
					"order_by"=>"c_name2 desc, c_yomi1");
		$order_tbl[] = array(   "表示名"=>"都道府県(+名前よみ)順", "get_order_name"=>"ken",
					"order_by"=>"c_kenid, c_yomi1");
		$order_tbl[] = array(   "表示名"=>"標高順", "get_order_name"=>"memo",
					"order_by"=>"(c_memo + 0) desc");	// 文字列を数値としてソート
	} elseif ($_GET['cat'] == SEKAI_ISAN_CATEGORY_ID) {		//世界遺産のid_categor
		$order_tbl[] = array(   "表示名"=>"遺産名順", "get_order_name"=>"name",
					"order_by"=>"c_name1, c_name1");
		$order_tbl[] = array(   "表示名"=>"遺産名順(Eng.)", "get_order_name"=>"name_e",
					"order_by"=>"c_yomi1, c_name2");
		$order_tbl[] = array(   "表示名"=>"国順", "get_order_name"=>"country",
					"order_by"=>"c_memo");
		$order_tbl[] = array(   "表示名"=>"国順(Eng.)", "get_order_name"=>"country_e",
					"order_by"=>"c_address2");
		$order_tbl[] = array(   "表示名"=>"Ref.順", "get_order_name"=>"ref",
					"order_by"=>"cast(c_phone1 as unsigned) asc");
		$order_tbl[] = array(   "表示名"=>"Ref.降順", "get_order_name"=>"refd",
					"order_by"=>"cast(c_phone1 as unsigned) desc");
	} elseif ($_GET['cat'] == TETSUDO_EKI_CATEGORY_ID) {		//鉄道駅のid_categor
		$order_tbl[] = array(   "表示名"=>"路線・駅順", "get_order_name"=>"rosen",
					"order_by"=>"c_phone1");
		$order_tbl[] = array(   "表示名"=>"駅名順", "get_order_name"=>"name",
					"order_by"=>"c_name1");
		$order_tbl[] = array(   "表示名"=>"駅名よみ順", "get_order_name"=>"yomi",
					"order_by"=>"case when c_yomi1 = '' then '1' else concat('0',c_yomi1) end");
		$order_tbl[] = array(   "表示名"=>"都道府県順", "get_order_name"=>"ken",
					"order_by"=>"c_kenid, c_address1");
	} elseif ($_GET['cat'] == SAKURA_MEISHO_CATEGORY_ID) {		//桜名所のid_categor
		$order_tbl[] = array(   "表示名"=>"名称よみ順", "get_order_name"=>"name",
					"order_by"=>"c_yomi1");
		$order_tbl[] = array(   "表示名"=>"品種よみ順", "get_order_name"=>"hinshu",
					"order_by"=>"case when c_yomi2 = '' then '1' else concat('0',c_yomi2) end");
		$order_tbl[] = array(   "表示名"=>"樹齢順", "get_order_name"=>"jurei",
					"order_by"=>"(c_phone1 + 0) desc");	// 文字列を数値としてソート
		$order_tbl[] = array(   "表示名"=>"見頃順", "get_order_name"=>"migoro",
					"order_by"=>"case when c_memo = '' then 99999 else (c_memo + 0) end, c_memo");
		$order_tbl[] = array(   "表示名"=>"都道府県順", "get_order_name"=>"ken",
					"order_by"=>"c_kenid, c_address1");
	} elseif ($_GET['cat'] == HYAKUSEN_CATEGORY_ID) {			//日本百選のid_categor
		$order_tbl[] = array(   "表示名"=>"名前よみ順", "get_order_name"=>"name",
					"order_by"=>"c_yomi1");
		$order_tbl[] = array(   "表示名"=>"都道府県(+名前よみ)順", "get_order_name"=>"ken",
					"order_by"=>"c_kenid, c_yomi1");
		$order_tbl[] = array(   "表示名"=>"種類(+名前よみ)順", "get_order_name"=>"shurui",
					"order_by"=>"c_memo, c_yomi1");
	} else {
		$order_tbl[] = array(   "表示名"=>"分類＋よみ順", "get_order_name"=>"cat",
					"order_by"=>"c_categoryDisplayOrder, id_category, c_yomi1, c_yomi2");
		$order_tbl[] = array(   "表示名"=>"分類＋メモ順", "get_order_name"=>"catm",
					"order_by"=>"c_categoryDisplayOrder, id_category, c_memo, c_yomi1, c_yomi2");
		$order_tbl[] = array(   "表示名"=>"名前順", "get_order_name"=>"name",
					"order_by"=>"c_name1, c_name2");
		$order_tbl[] = array(   "表示名"=>"よみ順", "get_order_name"=>"yomi",
					"order_by"=>"c_yomi1, c_yomi2");
		$order_tbl[] = array(   "表示名"=>"都道府県順", "get_order_name"=>"ken",
					"order_by"=>"c_kenid, c_address1");
		$order_tbl[] = array(   "表示名"=>"〒番号順", "get_order_name"=>"zip",
					"order_by"=>"c_zip1, c_zip2, c_yomi1, c_yomi2");
		$order_tbl[] = array(   "表示名"=>"メモ順", "get_order_name"=>"memo",
					"order_by"=>"c_memo, c_yomi1, c_yomi2");
		$order_tbl[] = array(   "表示名"=>"登録順", "get_order_name"=>"old",
					"order_by"=>"id_abook asc");
	}
	$http_arg = array();
	$http_arg['pl'] = PAGE_LINE_DEFAULT;		// mp_list 必須
	$http_arg['sort'] = '';				// mp_list 必須
	$http_arg['cat'] = '';				// mp_list 必須
	$http_arg['key'] = '';				// mp_list 必須
	$http_arg['ken'] = '';
	$http_arg['cid'] = '';

	if (isset($_POST['登録'])) {
		check_post_account($_POST['login_id'], $_POST['current_id']);
		mp_list_update($mp_list_arg, $item_tbl, $order_tbl, $http_arg);
	} else {
		_GET_to_http_arg_pool($http_arg, $table_name, 'sort,key,pl');
		html_header(HTML_TITLE);
		page_header();
		contents_header();
		if ($_GET['edit'] == "a") {
			$mp_list_arg['sql_for_edit'] = "select * from v_abook where id_abook = 0";
			mp_list_edit($mp_list_arg, $item_tbl, $order_tbl, $http_arg);
		} elseif ($_GET['edit'] == "y") {
			mp_list_edit($mp_list_arg, $item_tbl, $order_tbl, $http_arg);
		} else {
			mp_list_view($mp_list_arg, $item_tbl, $order_tbl, $http_arg);
		}
		page_footer();
		html_footer();
	}
	exit();
