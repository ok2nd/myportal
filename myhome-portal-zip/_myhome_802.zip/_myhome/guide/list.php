<?php
	require("__include-common.php");
//	require("../account/__logincheck.php");
	require("../__common__/include-common-mp-list.php");

	$table_name_view = "v_guide";
	$table_name = "m_guide";
	$id_item = "id_guide";
	$must_item = "c_title";

	$mp_list_arg = array();
	$mp_list_arg['account_id']	= "ALL";		// 共通
	$mp_list_arg['table_name_view']		= "v_guide";
	$mp_list_arg['table_name_edit']		= "v_guide";
	$mp_list_arg['table_name_update']	= "m_guide";
	$mp_list_arg['id_item']		= "id_guide";
	$mp_list_arg['must_item']	= "c_subject";
	$mp_list_arg['template_view']	= "list-my-template.php";
	$mp_list_arg['use_privacy']	= "yes";
	$mp_list_arg['category_title']	= "章";
	if ($_SESSION['システム管理者'] <> "YES") {
		$mp_list_arg['input_new']	= "no";
	}

	$item_tbl = array();
	$item_tbl[] = array(	"表示名"=>"章",	"列名"=>"id_category", "http_arg_GET名"=>"cat",
				"type"=>"select", "参照テーブル"=>"m_category", "参照テーブル表示列"=>"c_categoryName",
				"参照テーブル表示順"=>"c_categoryDisplayOrder", "参照テーブル表示色"=>"c_categoryDisplayColor");
	$item_tbl[] = array(	"表示名"=>"タイトル",	"列名"=>"c_subject",
				"type"=>"text", "size"=>40, "ime-mode"=>"active", "文字検索"=>"Y");
	$item_tbl[] = array(	"表示名"=>"メモ",	"列名"=>"c_body",
				"type"=>"textarea", "cols"=>60, "rows"=>5, "文字検索"=>"Y");

	$order_tbl = array();
	if ($_SESSION['システム管理者'] == "YES") {
		$order_tbl[] = array(   "表示名"=>"章節順", "get_order_name"=>"cat",
				"order_by"=>"c_categoryDisplayOrder, id_category, c_subject");	/* default */
		$order_tbl[] = array(   "表示名"=>"最新順", "get_order_name"=>"new",
				"order_by"=>"id_guide desc");
	} else {
		$order_tbl[] = array(   "表示名"=>"", "get_order_name"=>"cat",			// メニューを隠す
				"order_by"=>"c_categoryDisplayOrder asc, c_subject asc");	/* default */
	}

	if ($_SESSION['システム管理者'] <> "YES") {
		$mp_list_arg['edit_list_all']	= "no";
	}

	$http_arg = array();

	$http_arg['pl'] = PAGE_LINE_DEFAULT;		// mp_list 必須
	$http_arg['sort'] = '';				// mp_list 必須
	$http_arg['cat'] = '';				// mp_list 必須
	$http_arg['key'] = '';				// mp_list 必須

	$http_arg['cid'] = '';

	if (isset($_POST['登録'])) {
		if ($_SESSION['システム管理者'] == "YES") {
			check_post_account($_POST['login_id']);
			mp_list_update($mp_list_arg, $item_tbl, $order_tbl, $http_arg);
		}
	} else {
		_GET_to_http_arg_pool($http_arg, $table_name, 'sort,key,pl');
		html_header(HTML_TITLE, '', '#ffffff');
		page_header(False);			// ログイン不要
		contents_header();
		if ($_GET['edit'] == "y") {
			if ($_SESSION['システム管理者'] == "YES") {
				mp_list_edit($mp_list_arg, $item_tbl, $order_tbl, $http_arg);
			}
		} else {
			mp_list_view($mp_list_arg, $item_tbl, $order_tbl, $http_arg);
		}
		page_footer();
		html_footer();
	}
	exit();
