<?php
	if (defined("HTML_TITLE_guide")) {
		define("HTML_TITLE", HTML_TITLE_guide);
	} else {
		define("HTML_TITLE", "MyHome 利用ガイド");
	}
	define("SESSION_PREFIX", "guide");

	if (defined("_DB_SCHEMA_guide")) {
		define("_DB_SCHEMA", _DB_SCHEMA_guide);
	} else {
		define("_DB_SCHEMA", "_db_guide");
	}

	if (defined("ATTACH_FILE_FOLDER_guide")) {
		define("ATTACH_FILE_FOLDER", ATTACH_FILE_FOLDER_guide);
	} else {
		//↓絶対パスにできない？？？
		define("ATTACH_FILE_FOLDER", "../_attach/guide/");
	}

	define("PAGE_LINE_SELECT", "");		//ページングしない
	define("PAGE_LINE_DEFAULT", "");
?>
