	<table id="guide_list_table">
<?php
	mysqli_data_seek($rs, 0);				//テーブル内の先頭に移動
	$categoryName = '';
	while ($rec=mysqli_fetch_array($rs)) {
		if ($categoryName <> '') {
?>
	<a name="id_<?= $rec['id_guide'] ?>"></a>
	</td>
	</tr>
<?php
		}
		if ($categoryName <> $rec['c_categoryName']) {
?>
	<tr class="guide_list_table_data">
	<td colspan=2 class="guide_list_category">
		<h3><?= $rec['c_categoryName'] ?></h3>
	</td>
	</tr>
<?
			$categoryName = $rec['c_categoryName'];
		}
?>
	<tr class="guide_list_table_data">
	<td colspan=2 class="guide_list_subject">
		<span class="guide_list_subject_h"><?= my_htmlspecialchars($rec['c_subject']) ?></span>
		<? if ($_SESSION['システム管理者'] == "YES") { ?>
		<a class="a_update_form" href='input.php?id=<?= $rec['id_guide'] ?>&page=<?= $page ?>&<?= query_from_http_arg_pool($http_arg) ?>'>[修正]</a>
		<? } ?>
	</td>
	</tr>
	<tr>
<?php		if ($rec['c_attachFile1'] == '' && $rec['c_attachFile2'] == '' && $rec['c_attachFile3'] == '') { ?>
	<td class="guide_list_body" colspan=2>
		<ol>
		<?= str_replace('{{','<span style="color:red;">',str_replace('}}','</span>',ins_atag_br_li($rec['c_body']))) ?>
		</ol>
<?php		} else { ?>
	<td class="guide_list_pict">
	<?php
		my_attach_file_view($rec['c_attachFile1']);
		my_attach_file_view($rec['c_attachFile2']);
		my_attach_file_view($rec['c_attachFile3']);
	?>
	</td>
	<td class="guide_list_body">
		<ol>
		<?= str_replace('{{','<span style="color:red;">',str_replace('}}','</span>',ins_atag_br_li($rec['c_body']))) ?>
		</ol>
<?php
		}
	}
?>
	</td>
	</tr>
	</table>
<?php
	jquery_highlight('.guide_list_subject_h', keystr_and_or($keystring));
	jquery_highlight('.guide_list_body', keystr_and_or($keystring));
?>
<?php
function my_attach_file_view($filename) {
	if ($filename <> "") {
		$folder = ATTACH_FILE_FOLDER;
		$filepath = $folder.$filename;
?>
		<img src="<?= $filepath ?>" class="bicubic" border=0 style="max-width:400px;"><br>
<?php
	}
}
?>
