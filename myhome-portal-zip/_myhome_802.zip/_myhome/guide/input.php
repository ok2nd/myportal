<?php
	require("__include-common.php");
	require("../account/__logincheck.php");
	if ($_SESSION['システム管理者'] <> "YES") {
		error_exit("不正アクセス：編集権限がありません。", True);
	}
	if ($_POST) {
// *********************************************************************************
// * max_execution_time
// * post_max_size
// * upload_max_filesizeを越えるとisset($_POST['登録'])がTrueにならない。
// *********************************************************************************
		check_post_account($_POST['login_id']);
		post_done_proc();
	} else {
		html_header(HTML_TITLE, '', '#ffffff', ' onload="document.form0.c_subject.focus()"');
		page_header();
		input_form();
		page_footer();
		html_footer();
	}
	exit();
?>
<?php
function post_done_proc() {
	if ($_POST['update_id']) {
		if (!is_numeric($_POST['update_id'])) {
			error_exit("不正アクセス", True);
		}
		$id = intval($_POST['update_id']);
	} else {
		$id = 0;
	}
	if (isset($_POST['削除'])) {
		//	if ($_POST['削除する'] <> "YES") {
		//		error_exit("削除するにチェックしてください。", True);
		//	}
	}
	if ($_POST['c_subject'] == "") {
		error_exit("件名なし", True);
	}
	$con = my_mysqli_connect(_DB_SCHEMA);
	if ($id == 0) {
		$sql = "insert into m_guide ";
		$sql .= "( id_category";
		$sql .= ", c_subject";
		$sql .= ", c_body";
		$sql .= ", c_registtime";
		$sql .= ", c_updatetime";
		$sql .= ") values ";
		$sql .= "( '" . $_POST['id_category'] . "'";
		$sql .= ", '".post_to_mysql("c_subject")."'";
		$sql .= ", '".post_to_mysql("c_body")."'";
		$sql .= ", '". date("Y/m/d H:i:s") . "'";
		$sql .= ", '". date("Y/m/d H:i:s") . "'";
		$sql .= ")";
		$ret = my_mysqli_query($sql, "登録できませんでした。");
	} elseif ($_POST['削除'] <> "") {
		$sql = "update m_guide set";
		$sql .= " c_delete = 999";
		$sql .= ", c_updatetime = '". date("Y/m/d H:i:s") . "'";
		$sql .= " where id_guide = ".$id;
		$ret = my_mysqli_query($sql, "削除できませんでした。");
	} else {
		$sql = "update m_guide set";
		$sql .= " id_category = '".$_POST['id_category']."'";
		$sql .= ", c_subject = '".post_to_mysql("c_subject")."'";
		$sql .= ", c_body = '".post_to_mysql("c_body")."'";
		$sql .= ", c_updatetime = '". date("Y/m/d H:i:s") . "'";
		$sql .= " where id_guide = ".$id;
		$ret = my_mysqli_query($sql, "更新できませんでした。");
	}
	// ****** 添付ファイル ******
	if ($id == 0) {
		$id = my_mysqli_insert_id();	//直近のINSERTクエリによりAUTO_INCREMENTカラム用に生成されたIDを取得
	}
	$sw = False;
	$sqlupd = "";
	for ($ix=1; $ix<=3; $ix++) {
		// ***** ファイルのアップロード *****
		$attachFile = file_upload("filename".$ix, $id, ATTACH_FILE_FOLDER);
		if ($attachFile <> "") {
			if ($sw) {
				$sqlupd .= ",";
			}
			$sqlupd .= " c_attachFile" . $ix . " = '" . $attachFile . "'";
			$sw = True;
		} else if ($_POST['fileDelete'.$ix] == "YES") {
			if ($sw) {
				$sqlupd .= ",";
			}
			$sqlupd .= " c_attachFile" . $ix . " = ''";
			$sw = True;
		}
	}
	if ($sw) {
		$sql = "update m_guide set";
		$sql .= $sqlupd;
		$sql .= " where id_guide = ".$id;
			//echo $sql;
			//exit;
		$ret = my_mysqli_query($sql, "アップロードファイル名DB登録失敗。");
	}
	mysqli_close($con);
	redirect("list.php?".$_SERVER['QUERY_STRING']."#id_".$id);
}
function input_form() {
	if ($_GET['id'] <> "") {
		$id = $_GET['id'];
		if ($_GET['page'] <> "") {
			$page = $_GET['page'];
		}
	} else {
		$id = 0;
	}
	$con = my_mysqli_connect(_DB_SCHEMA);
	$sql = "select * from v_guide where id_guide = ".$id." and c_delete = 0";
	$rs = my_mysqli_query($sql);
	$rec = mysqli_fetch_array($rs);

	$subject = $rec['c_subject'];
	$body = $rec['c_body'];
	$updatetime = $rec['c_updatetime'];
?>
<div class="input_form">
<h3><?= $_SESSION['current_handle'] ?><a class="a_cancel_back" href='javascript:history.back();'>戻る</a></h3>
<script>
function formCheck(form) {
	if (form.c_subject.value == '') {
		window.alert('件名を入れてください。');
		return false;		// 送信を中止
	}
	return true;	// 送信を実行
}
</script>
<form name="form0" method="POST" action="<?= $_SERVER['SCRIPT_NAME'] ?>?<?= $_SERVER['QUERY_STRING'] ?>" enctype="multipart/form-data" onSubmit="return formCheck(this)">
	<input type="hidden" name="user_id" value="<?= $_SESSION['current_id'] ?>">
	<input type="hidden" name="update_id" value="<?= $id ?>">
	<input type="hidden" name="login_id" value="<?= $_SESSION['login_id'] ?>">
	<input type="hidden" name="current_id" value="<?= $_SESSION['current_id'] ?>">
<table>
<tr>
	<td nowrap>章</td>
	<td nowrap>
<?php
	$sqlsel = "select * from m_category where c_delete = 0";
	$sqlsel = $sqlsel . " order by c_categoryDisplayOrder";
	$rs_sel = my_mysqli_query($sqlsel);
?>
	<select name="id_category">
<?php
		if ($id == 0) {
			$category = (int)$_GET['cat'];
		} else {
			$category = $rec['id_category'];
		}
		while ($rec_sel=mysqli_fetch_array($rs_sel)) {
?>
		<option value="<?= $rec_sel['id_category'] ?>"<?= $rec_sel['id_category'] == $category ? " selected" : "" ?>><?= my_htmlspecialchars($rec_sel['c_categoryName']) ?>
<?php
		}
?>
	</select>
	</td>
</tr>
<tr>
	<td>件名</td>
	<td>
		<input class="text" type="text" name="c_subject" size=50 value="<?= $subject ?>">
	</td>
	</tr>
	<tr>
	<td>本文</td>
	<td>
		<div class="block">
		<div class="block_left">
		<?php
			$str = my_htmlspecialchars($body);
			$rows = textarea_rows($str, 400) + 1;
			if ($rows < 10) {
				$rows = 10;
			} elseif (strstr($_SERVER['HTTP_USER_AGENT'], "MSIE") and $rows > 30) {
				$rows = 30;
			}
		?>
		<textarea id="c_body" name="c_body" style="width:400px;" rows="<?= $rows ?>" wrap="soft"><?= $str ?></textarea>
		</div>
		<?php	if (strstr($_SERVER['HTTP_USER_AGENT'], "MSIE")) { ?>
			<div class="block_left">
			<input type="button" value="小" OnClick="textareaBigSmall('c_body','小')"><br>
			<input type="button" value="大" OnClick="textareaBigSmall('c_body','大')">
			</div>
		<?php	} ?>
		<div class="block_left">
		<p style="margin:4px 0 0 8px;width:160px;">改行を２つ連続で入れると、&lt;li&gtタグが挿入されます。<br>文字列を{{と}}で囲むと、赤色表示します。</p>
		</div>
		</div>
	</td>
</tr>
<tr>
	<td>添付文書</td>
	<td>
<?php if ($rec['c_attachFile1'] <> "" || $rec['c_attachFile2'] <> "" || $rec['c_attachFile3'] <> "") { ?>
	<p><span class="alarm_text">再度添付ファイル名を指定すると登録済ファイルに上書きされます。</span></p>
<?php } ?>
<?php
	for ($ix=1; $ix<=3; $ix++) {
?>
		<div class="block">
		<div class="block_left">(<?= $ix ?>)</div>
		<div class="block_left">
<?php
		if ($rec['c_attachFile'.$ix] <> "") {
			attach_file_view('', $rec['c_attachFile'.$ix], '', 100);
?>
		<label><input type="checkbox" name="fileDelete<?= $ix ?>" value="YES">削除</label>
		<input type="hidden" name="filenameCurrent<?= $ix ?>" value="<?= $rec['c_attachFile'.$ix] ?>">
<?php
		}
?>
		<input type="file" size=40 name="filename<?= $ix ?>" style="button-font-size:small">
		</div>
		</div>
<?php
	}
?>
	</td>
</tr>
</table>
<?php
	if ($id == 0) {
?>
	<input class="input_form_button" type="submit" name="登録" value="登録">
<?php
	} else {
?>
	<input class="input_form_button" type="submit" name="登録" value="修正">
	<input class="input_form_button" type="submit" name="削除" value="削除" onClick="return delete_check();" style="margin-left:20px;">
<?php
	}
?>
</form>
<script>
function delete_check() {
	if (window.confirm('このデータを削除しますか？')) {
		return true;
	} else {
		return false;
	}
}
</script>
<?php	if (!strstr($_SERVER['HTTP_USER_AGENT'], "MSIE")) { ?>
<script src="../scripts/autoresize.jquery.min.js"></script>
<script>
$('textarea#c_body').autoResize({
	onResize : function() {
		$(this).css({opacity:0.8});
	},
	animateCallback : function() {
		$(this).css({opacity:1});
	},
	animateDuration : 300,
	extraSpace : 20
});
$('textarea#c_body').trigger('change'); // 初期表示時に自動リサイズさせるためchangeイベント実行
</script>
<?php	} ?>
<?
}
?>
