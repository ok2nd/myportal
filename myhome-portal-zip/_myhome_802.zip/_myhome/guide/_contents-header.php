<?php
function contents_header() {
	$menu_item = array();
	$menu_item[] = array("href"=>"list.php", "query"=>"arg=session", "name"=>"利用ガイド");
	$menu_item[] = array("href"=>"category.php", "name"=>"章タイトル一覧");
?>
<div id="contents_header">
<?php
	if ($_SESSION['システム管理者'] == "YES") {
		contents_menu($menu_item);
	} else {
		echo "<p><br></p>";
	}
?>
</div><!-- id="contents_header" -->
<?php
}
?>
