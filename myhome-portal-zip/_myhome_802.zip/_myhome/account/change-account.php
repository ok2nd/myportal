<?php
	require("__include-common.php");
	require("__include-login.php");

	$login_id = $_SESSION['login_id'];
	$change_id = $_GET['uid'];
	$return_page = $_GET['ret'];
	if ($_SESSION['logincheck'] == "OK") {
		if ($_COOKIE['login_account_okuser_id'] <> "" and $_COOKIE['login_account_okuser_pass'] <> "") {

			$account_id = $_COOKIE['login_account_okuser_id'];
			$password = $_COOKIE['login_account_okuser_pass'];

			$_SESSION['logincheck'] = _account_login($account_id, "", $password, $change_id);
			if ($_SESSION['logincheck'] <> "OK") {
				redirect("../account/login.php");
			}
			if ($_COOKIE['account_chg_all'] == 'all') {
				// ----- 全コンテンツ：ユーザ切り替え -----
				$contents_path = get_contents_path();
				foreach ($contents_path as $contents) {
					$_SESSION['current_id'.$contents] = $_SESSION['current_id'];
					$_SESSION['current_handle'.$contents] = $_SESSION['current_handle'];
				}
				// ----- 全コンテンツ：ユーザ切り替え -----
			} else {
				// ----- コンテンツ毎にユーザ切り替え -----
				$contents = current_contents_name($return_page);
				$_SESSION['current_id'.$contents] = $_SESSION['current_id'];
				$_SESSION['current_handle'.$contents] = $_SESSION['current_handle'];
				// ----- コンテンツ毎にユーザ切り替え -----
			}
			redirect($return_page);
		}
	}
?>
