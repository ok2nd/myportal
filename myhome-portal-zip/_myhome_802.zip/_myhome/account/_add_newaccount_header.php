<script>
function accountCheck() {
	httpObj = createXMLHttpRequest(accountCheckComplete);
	if (httpObj) {
		httpObj.open("GET","account-chk.php?account="+document.form0.account.value,true);
		httpObj.send(null);
	}
}
function accountCheckComplete() {
	if ((httpObj.readyState == 4) && (httpObj.status == 200)) {
		var res = httpObj.responseText;
		if (res == 'OK') {
			document.getElementById('accountErrMsg').innerHTML = "使用可能です。";
		} else if (res == 'USED') {
			document.getElementById('accountErrMsg').innerHTML = "登録済みです。";
		} else if (res == 'NULL') {
			document.getElementById('accountErrMsg').innerHTML = "アカウントを入れてください。";
		} else if (res == 'CANNOTCONNECT') {
			document.getElementById('accountErrMsg').innerHTML = "データベース接続エラー。";
		} else if (res == 'SELECTERROR') {
			document.getElementById('accountErrMsg').innerHTML = "データベース検索エラー。";
		} else if (res == 'SHORT') {
			document.getElementById('accountErrMsg').innerHTML = "アカウントは、<?= ACCOUNT_ID_NAME_MIN_LENGTH ?>文字以上にしてください。";
		} else if (res == 'LONG') {
			document.getElementById('accountErrMsg').innerHTML = "アカウントは、20文字以下にしてください。";
		} else if (res == 'NOPERMIT') {
			document.getElementById('accountErrMsg').innerHTML = "使用できません。";
		} else if (res == 'NOTANC') {
			document.getElementById('accountErrMsg').innerHTML = "アカウントには、英数字以外は使えません。";
		} else {
			document.getElementById('accountErrMsg').innerHTML = res;
		}
	}
}
function handleCheck() {
	httpObj = createXMLHttpRequest(handleCheckComplete);
	if (httpObj) {
		httpObj.open("GET","account-chk.php?handle="+encodeURL(document.form0.handle.value),true);
		httpObj.send(null);
	}
}
function handleCheckComplete() {
	if ((httpObj.readyState == 4) && (httpObj.status == 200)) {
		var res = httpObj.responseText;
		if (res == 'OK') {
			document.getElementById('handleErrMsg').innerHTML = "使用可能です。";
		} else if (res == 'USED') {
			document.getElementById('handleErrMsg').innerHTML = "登録済みです。";
		} else if (res == 'NULL') {
			document.getElementById('handleErrMsg').innerHTML = "ハンドル名を入れてください。";
		} else if (res == 'CANNOTCONNECT') {
			document.getElementById('handleErrMsg').innerHTML = "データベース接続エラー。";
		} else if (res == 'SELECTERROR') {
			document.getElementById('handleErrMsg').innerHTML = "データベース検索エラー。";
		} else if (res == 'SHORT') {
			document.getElementById('handleErrMsg').innerHTML = "ハンドル名を入れてください。";
		} else if (res == 'LONG') {
			document.getElementById('handleErrMsg').innerHTML = "ハンドル名は、10文字以下にしてください。";
		} else if (res == 'NOPERMIT') {
			document.getElementById('handleErrMsg').innerHTML = "使用できません。";
		//} else if (res == 'NOTZENKAKU') {
		//	document.getElementById('handleErrMsg').innerHTML = "ハンドル名は、全角文字で入れてください。";
		} else {
			document.getElementById('handleErrMsg').innerHTML = res;
		}
	}
}
</script>
<script>
function popup(id) {
	w01 = window.open("popup.php?id="+id,"","toolbar=yes,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes,width=600,height=600");
}
function inputVerifyAll() {
	if (document.form0.account.value == "") {
		window.alert('アカウントを入れてください。');
		return false;
	} else if (document.form0.handle.value == "") {
		window.alert('ハンドル名を入れてください。');
		return false;
	} else if (document.form0.password.value == "") {
		window.alert('パスワードを入れてください。');
		return false;
	} else if (document.form0.password2.value == "") {
		window.alert('確認用のパスワードを入れてください。');
		return false;
	} else if (!document.form0.kiyaku_confirm.checked) {
		window.alert('規約に同意にチェックしてください。');
		return false;
	}
	if ((errmsg = AccountVerify(document.form0.account.value)) != '') {
		window.alert(errmsg);
		return false;
	} else if ((errmsg = HandleVerify(document.form0.handle.value)) != '') {
		window.alert(errmsg);
		return false;
	} else if ((errmsg = PasswordVerifyConfirm(document.form0.password.value)) != '') {
		window.alert(errmsg);
		return false;
	} else if ((errmsg = Password2Verify(document.form0.password.value, document.form0.password2.value)) != '') {
		window.alert(errmsg);
		return false;
	} else {
		document.form0.submit();
		return true;
	}
}
function AccountCheckOnChange() {
	//var errMsg = getElement('accountErrMsg');
	//errMsg.innerHTML = AccountCheck(document.form0.account.value);
	//document.getElementById('accountErrMsg').innerText = AccountCheck(document.form0.account.value);
	document.getElementById('accountErrMsg').innerHTML = AccountVerify(document.form0.account.value);
}
function AccountVerify(str) {
	if (str.length < <?= ACCOUNT_ID_NAME_MIN_LENGTH ?>) {
		return "アカウントは、<?= ACCOUNT_ID_NAME_MIN_LENGTH ?>文字以上にしてください。";
	} else if (str.length > 20) {
		return "アカウントは、20文字以下にしてください。";
	} else if (!checkIsAlphaNum(str)) {
		return "アカウントには、英数字以外は使えません。";
	} else {
		return "";
	}
}
function HandleCheckOnChange() {
	var errMsg = getElement('handleErrMsg');
	errMsg.innerHTML = HandleVerify(document.form0.handle.value);
}
function HandleVerify(str) {
	if (str.length < 1) {
		return "ハンドル名を入れてください。";
	} else if (str.length > 10) {
		return "ハンドル名は、10文字以下にしてください。";
				//} else if (checkIsZenkaku(str)) {	// SJIS
				//	return "";
//	} else if (checkFullStringOnly(str,"") == "") {
//		return "";
//	} else {
//		return "ハンドル名は、全角文字で入れてください。";
	}
	return "";
}
function EmailCheckOnChange() {
	var errMsg = getElement('emailErrMsg');
	errMsg.innerHTML = EmailVerify(document.form0.email.value);
}
function EmailVerify(str) {
	return "";
	if (!checkIsEmail(str)) {
		return "電子メールアドレスとして正しくありません。";
	} else {
		return "";
	}
}
function PasswordCheckOnChange() {
	var errMsg = getElement('passwordErrMsg');
	errMsg.innerHTML = PasswordVerify(document.form0.password.value);
}
function PasswordVerify(str) {
	if (str.length < <?= ACCOUNT_PASSWORD_MIN_LENGTH ?>) {
		return "パスワードは、<?= ACCOUNT_PASSWORD_MIN_LENGTH ?>文字以上にしてください。";
	} else if (str.length > 30) {
		return "パスワードは、30文字以下にしてください。";
	} else if (checkIsNumber(str)) {
		return "パスワードには、数字以外の文字も含めることをお勧めします。";
	} else if (checkIsAlpha(str)) {
		return "パスワードには、英字以外の文字も含めることをお勧めします。";
	} else {
		return "";
	}
}
function PasswordVerifyConfirm(str) {
	if (str.length < <?= ACCOUNT_PASSWORD_MIN_LENGTH ?>) {
		return "パスワードは、<?= ACCOUNT_PASSWORD_MIN_LENGTH ?>文字以上にしてください。";
	} else if (str.length > 30) {
		return "パスワードは、30文字以下にしてください。";
	} else {
		return "";
	}
}
function Password2CheckOnChange() {
	var errMsg = getElement('password2ErrMsg');
	errMsg.innerHTML = Password2Verify(document.form0.password.value, document.form0.password2.value);
}
function Password2Verify(str, str2) {
	if (str != str2) {
		return "確認用のパスワードが違っています。";
	} else {
		return "";
	}
}
function checkIsAlphaNum(str) { 
	var result = str.match(/[0-9a-zA-Z]*/);
	if (str == result) {
		return true;
	} else {
		return false;
	}
}
function checkIsEmail(str) { 
	var result = str.match(/[0-9a-zA-Z@]*/);
	if (str == result) {
		return true;
	} else {
		return false;
	}
}
function checkIsNumber(str) {
	return (str.match(/[0-9]+/g) == str);
}
function checkIsAlpha(str) {
	return (str.match(/[a-zA-Z]+/g) == str);
}
function checkIsZenkaku(str) {
	for (var i = 0; i < str.length; ++i) {
	var c = str.charCodeAt(i);
		//  半角カタカナは不許可
	if (c < 256 || (c >= 0xff61 && c <= 0xff9f)) {
		return false;
		}
	}
	return true;
}
/*
	by stroll::blog 全角文字チェック
	http://melrose.jugem.cc/?eid=187
*/
function checkFullStringOnly(str, option){
	//var str = formElement.value;
	var bace_len = "ア".length;
	var str_length = str.length;
	if (bace_len == 1) { str_length = str_length * 2; }
	var code, count;
	for (var i = 0; i < str_length; i++) {
		count = 0;
		code = str.charCodeAt(i);
		if ((0 <= code && code <= 255) || (65382 <= code && code <= 65439)) { count++; }
		/* オプション文字 */
		if (!option == "" && option.indexOf(String.fromCharCode(code)) < 0) { count++; }
		if (option == "" && count == 1) { return str.substring(i, i+1); }
		if (!option == "" && count == 2) { return str.substring(i, i+1); }
	}
	return "";
}
function getElement(name) {
	if (document.all) {
		return document.all(name);
	}
	return document.getElementById(name);
}
</script>
<script src="../scripts/xmlhttp.js"></script>
