	<table id="mp_list_table_nowidth">
	<tr class="mp_list_table_head">
		<th>ID</th>
		<th>ハンドル</th>
		<th>公開先<br>(自分の公開先)</th>
		<th>公開元<br>(自分への公開状況)</th>
		<th>My参照<br>(自分のメンバ設定)</th>
		<th>表示順</th>
	</tr>
<?php
	mysqli_data_seek($rs, $startline);
	$line = $startline;
	while ($rec=mysqli_fetch_array($rs) and $line<=$endline) {
?>
	<tr class="mp_list_table_data">
		<td><?= my_htmlspecialchars($rec['id_account']) ?></td>
		<td><?= my_htmlspecialchars($rec['c_handle']) ?></td>
		<td><?= my_htmlspecialchars($rec['public_permit_to']) ?></td>
		<td><?= my_htmlspecialchars($rec['public_permit_from']) ?></td>
		<td>
		<label><input type="checkbox" name="FRIENDS_NEW<?= $rec['id_account'] ?>" value="<?= $rec['id_account'] ?>"<?= $rec['id_member_id'].'' <> '' ? ' checked' : '' ?>>参照メンバ</label>
		<input type="hidden" name="FRIENDS_OLD<?= $rec['id_account'] ?>" value="<?= $rec['id_member_id'] ?>">
		</td>
		<td>
		<input class="text ascii" type="text" name="D_ORDER_NEW<?= $rec['id_account'] ?>" style="width: 30px;" value="<?= $rec['c_displayOrder'] ?>">
		<input type="hidden" name="D_ORDER_OLD<?= $rec['id_account'] ?>" value="<?= $rec['c_displayOrder'] ?>">
		</td>
	</tr>
<?php
		$line++;
	}
?>
	</table>
<script src="../scripts/valueconvertor.js"></script>
