<?php
	require("__include-common.php");

	$_SESSION = array();
	if (isset($_COOKIE[session_name()])) {
		setcookie(session_name(), '', time() - 42000, MY_SESSION_PATH);
	}
	session_destroy();

	setcookie("login_account_okuser_id", "", time() + LOGIN_COOKIE_EXPIRE, MY_SESSION_PATH);		// クリア
	setcookie("login_account_okuser_pass", "", time() + LOGIN_COOKIE_EXPIRE, MY_SESSION_PATH);		// クリア
	// ************* id_manager用 *************
	setcookie("login_account_id_mgr_pass", "", time() + IDMGR_COOKIE_EXPIRE, MY_SESSION_PATH);		// クリア

	redirect("login.php");
?>
