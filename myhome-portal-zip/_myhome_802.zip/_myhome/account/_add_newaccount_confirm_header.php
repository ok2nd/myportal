<script>
<!--
function inputCheckAll() {
	if (document.form0.captchastr.value == "") {
		window.alert('認証用絵文字コードを入れてください。');
		return false;
	} else {
		document.form0.submit();
		return true;
	}
}
//-->
</script>
<!--
<//script src="../scripts/prototype.js"></script>
-->
