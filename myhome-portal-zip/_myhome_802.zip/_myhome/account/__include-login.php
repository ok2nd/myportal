<?php
function _account_login($account_id="0", $account="", $password, $change_current_id="") {
	// $password: 暗号化済
	$_SESSION['logincheck'] = "";
	$_SESSION['login_id'] = "";
	$_SESSION['login_account'] = "";
	$_SESSION['login_handle'] = "";
	$_SESSION['システム管理者'] = "";
	$_SESSION['current_id'] = "";
	$_SESSION['current_handle'] = "";

	if ($account_id == "0" && $account == "") {
		return("アカウントを入れてください。");
	}
	if ($password == "") {
		return("パスワードを入力してください。");
	}
	$con_account = my_mysqli_connect(_DB_ACCOUNT_SCHEMA, False);

	if ($account_id == "0") {
		$sql = "select * from m_account where c_account = '" . $account . "' and c_delete = 0";
		$errmsg = "アカウントまたはパスワードが間違っています。";
		$log_status = "ERROR LOGIN ";
	} else {
		$sql = "select * from m_account where id_account = '" . $account_id . "' and c_delete = 0";
		$errmsg = "前回のログイン情報が無効です。";
		$log_status = "ERROR COOKIE ";
	}
	$rs_account = my_mysqli_query($sql, '', $con_account);
	$row = mysqli_num_rows($rs_account);
	if ($row == 0) {
		$sql = "insert into z_loginlog (id_account,c_account,c_password,c_status)";
		$sql .= " VALUES ('" . $account_id . "','" . $account . "','" . $password . "','" . $log_status ."ACCOUNT')";
		$ret = my_mysqli_query($sql, '', $con_account);
		mysqli_close($con_account);
		return($errmsg);
	}
	$rec_account = mysqli_fetch_array($rs_account);
	if (my_hash($rec_account['c_password']) <> $password) {
		$sql = "insert into z_loginlog (id_account,c_account,c_password,c_status)";
		$sql .= " VALUES ('" . $rec_account['id_account'] . "','" . $rec_account['c_account'] . "','" . $password . "','" . $log_status ."PASSWORD')";
		$ret = my_mysqli_query($sql, '', $con_account);
		mysqli_close($con_account);
		return($errmsg);
	}

	$_SESSION['login_id'] = $rec_account['id_account'];
	$_SESSION['login_account'] = $rec_account['c_account'];
	$_SESSION['login_handle'] = $rec_account['c_handle'];

	if ($rec_account['c_page_navi_link_color'].'' <> '') {
		$_SESSION['page_navi_link_color'] = $rec_account['c_page_navi_link_color'];
	} else {
		$_SESSION['page_navi_link_color'] = PAGE_NAVI_LINK_COLOR;
	}
	if ($rec_account['c_page_navi_link_bg'].'' <> '') {
		$_SESSION['page_navi_link_bg'] = $rec_account['c_page_navi_link_bg'];
	} else {
		$_SESSION['page_navi_link_bg'] = PAGE_NAVI_LINK_BG;
	}
	if ($rec_account['c_page_navi_current_color'].'' <> '') {
		$_SESSION['page_navi_current_color'] = $rec_account['c_page_navi_current_color'];
	} else {
		$_SESSION['page_navi_current_color'] = PAGE_NAVI_CURRENT_COLOR;
	}
	if ($rec_account['c_page_navi_current_bg'].'' <> '') {
		$_SESSION['page_navi_current_bg'] = $rec_account['c_page_navi_current_bg'];
	} else {
		$_SESSION['page_navi_current_bg'] = PAGE_NAVI_CURRENT_BG;
	}
	if ($rec_account['c_page_navi_hover_color'].'' <> '') {
		$_SESSION['page_navi_hover_color'] = $rec_account['c_page_navi_hover_color'];
	} else {
		$_SESSION['page_navi_hover_color'] = PAGE_NAVI_HOVER_COLOR;
	}
	if ($rec_account['c_page_navi_hover_bg'].'' <> '') {
		$_SESSION['page_navi_hover_bg'] = $rec_account['c_page_navi_hover_bg'];
	} else {
		$_SESSION['page_navi_hover_bg'] = PAGE_NAVI_HOVER_BG;
	}
	if ($rec_account['c_page_navi_active_color'].'' <> '') {
		$_SESSION['page_navi_active_color'] = $rec_account['c_page_navi_active_color'];
	} else {
		$_SESSION['page_navi_active_color'] = PAGE_NAVI_ACTIVE_COLOR;
	}
	if ($rec_account['c_page_navi_active_bg'].'' <> '') {
		$_SESSION['page_navi_active_bg'] = $rec_account['c_page_navi_active_bg'];
	} else {
		$_SESSION['page_navi_active_bg'] = PAGE_NAVI_ACTIVE_BG;
	}

	if ($rec_account['c_admin'] == "admin") {
		$_SESSION['システム管理者'] = "YES";
	}
	$_SESSION['current_id'] = $_SESSION['login_id'];
	$_SESSION['current_handle'] = $_SESSION['login_handle'];

	// ***** 共有 *****
	$login_friends_number = 0;
	$_SESSION['login_friends_id_0'] = $_SESSION['login_id'];
	$_SESSION['login_friends_handle_'.$_SESSION['login_id']] = $_SESSION['login_handle'];
	$_SESSION['login_friends_album_folder_'.$_SESSION['login_id']] = get_album_folder($rec_account['c_album_folder']);
	$_SESSION['login_friends_album_calendar_folder_'.$_SESSION['login_id']] = get_album_folder($rec_account['c_album_calendar_folder']);
	$_SESSION['login_friends_body_background_color_'.$_SESSION['login_id']] = $rec_account['c_body_background_color'];
	$_SESSION['login_friends_body_background_img_'.$_SESSION['login_id']] = $rec_account['c_index_bg_image'];
	$_SESSION['login_friends_home_address_'.$_SESSION['login_id']] = $rec_account['c_home_address'];
	$_SESSION['login_friends_home_station_'.$_SESSION['login_id']] = $rec_account['c_home_station'];
	$_SESSION['login_friends_cal_sbj_use_'.$_SESSION['login_id']] = $rec_account['c_cal_sbj_use'];

	$sql = "select v_friends.id_member_id, m_account.c_handle, m_account.c_album_folder, m_account.c_album_calendar_folder, m_account.c_body_background_color, m_account.c_index_bg_image, m_account.c_home_address, m_account.c_home_station, m_account.c_cal_sbj_use, v_friends.c_displayOrder";
	$sql .= " from v_friends";
	$sql .= " LEFT OUTER JOIN m_account ON v_friends.id_member_id = m_account.id_account";
	$sql .= " where v_friends.id_account = '" . $_SESSION['login_id'] . "'";
	$sql .= " and v_friends.c_delete = 0";
	$sql .= " order by v_friends.c_displayOrder";

//echo $sql."<br>";
	$rs_friends = my_mysqli_query($sql, '', $con_account);
	$row = mysqli_num_rows($rs_friends);
	if ($row > 0) {
		while ($rec_friends = mysqli_fetch_array($rs_friends)) {
			$sql = "select * from m_public where id_account = '" . $rec_friends['id_member_id'] . "'";
			$sql .= " and id_permit_id = '" . $_SESSION['login_id'] . "' and c_delete = 0";
			$rs_public = my_mysqli_query($sql, '', $con_account);
			$row_public = mysqli_num_rows($rs_public);
			if ($row_public > 0) {
				++$login_friends_number;
				$id_member_id = $rec_friends['id_member_id'];
				$_SESSION['login_friends_id_'.$login_friends_number] = $id_member_id;
				$_SESSION['login_friends_handle_'.$id_member_id] = $rec_friends['c_handle'];
				$_SESSION['login_friends_album_folder_'.$id_member_id] = get_album_folder($rec_friends['c_album_folder']).'';
				$_SESSION['login_friends_album_calendar_folder_'.$id_member_id] = get_album_folder($rec_friends['c_album_calendar_folder']).'';
				$_SESSION['login_friends_body_background_color_'.$id_member_id] = $rec_friends['c_body_background_color'].'';
				$_SESSION['login_friends_body_background_img_'.$id_member_id] = $rec_friends['c_index_bg_image'].'';
				$_SESSION['login_friends_home_address_'.$id_member_id] = $rec_friends['c_home_address'].'';
				$_SESSION['login_friends_home_station_'.$id_member_id] = $rec_friends['c_home_station'].'';
				$_SESSION['login_friends_cal_sbj_use_'.$id_member_id] = $rec_friends['c_cal_sbj_use'].'';
				// *** c_displayOrderが0のユーザーを、デフォルトユーザーに設定
				if ($change_current_id == "" && $rec_friends['c_displayOrder'] == 0) {
					$_SESSION['current_id'] = $rec_friends['id_member_id'];
					$_SESSION['current_handle'] = $rec_friends['c_handle'];
				}
				// *** c_displayOrderが0のユーザーを、一番左に表示
				if ($rec_friends['c_displayOrder'] == 0) {
					$_SESSION['login_friends_id_'.$login_friends_number] = $_SESSION['login_friends_id_0'];
					$_SESSION['login_friends_id_0'] = $rec_friends['id_member_id'];
				}
				if ($change_current_id <> "" && $change_current_id == $rec_friends['id_member_id']) {
					$_SESSION['current_id'] = $rec_friends['id_member_id'];
					$_SESSION['current_handle'] = $rec_friends['c_handle'];
					$rec_public = mysqli_fetch_array($rs_public);
					//$_SESSION['current_permit_type'] = $rec_public['id_permit_type'];
				}
//echo $_SESSION['login_friends_handle_'.$login_friends_number]."<br>";
			}
		}
	}

	// ----- コンテンツ毎にユーザ切り替え (初期設定) -----
	// ********************************************************************** コンテンツ定義の場所変更
	$contents_path = get_contents_path();
	foreach ($contents_path as $contents) {
		if ($_SESSION['current_id'.$contents]."" == "") {
			$_SESSION['current_id'.$contents] = $_SESSION['current_id'];
			$_SESSION['current_handle'.$contents] = $_SESSION['current_handle'];
		}
	}
	$_SESSION['current_id'.'account'] = $_SESSION['login_id'];		// accountは常に自分自身(login_id)
	$_SESSION['current_handle'.'account'] = $_SESSION['login_handle'];
	// ----- コンテンツ毎にユーザ切り替え (初期設定) -----

	$_SESSION['login_friends_number'] = $login_friends_number;
	// ***** ログイン記録 *****
	if ($change_current_id == "") {
		$log_status = "LOGIN";
		$change_current_id = 0;
	} else {
		$log_status = "CHANGE ACCOUNT";
	}
	$sql = "insert into z_loginlog (id_account,c_account,c_password,c_status,c_change_id) VALUES ('" . $_SESSION['login_id'] . "','" . $_SESSION['login_account'] . "','" . $password . "','" . $log_status . "','" . $change_current_id . "')";
	$ret = my_mysqli_query($sql, '', $con_account);
	mysqli_close($con_account);
	//$_SESSION['logincheck'] = "OK";
	return("OK");	// 正常
}
function _account_change($get_id) {
	if ($get_id.'' <> '' && $get_id.'' <> $_SESSION['current_id'].'') {
		$login_id = $_SESSION['login_id'];
		$change_uid = $get_id;
		if ($_SESSION['logincheck'] == "OK") {
			if ($_COOKIE['login_account_okuser_id'] <> "" and $_COOKIE['login_account_okuser_pass'] <> "") {
				$account_id = $_COOKIE['login_account_okuser_id'];
				$password = $_COOKIE['login_account_okuser_pass'];

				$_SESSION['logincheck'] = _account_login($account_id, "", $password, $change_uid);
				if ($_SESSION['logincheck'] <> "OK") {
					redirect("../account/login.php");
				}
				// ----- コンテンツ毎にユーザ切り替え -----
				$contents = current_contents_name($_SERVER['SCRIPT_NAME']);
				$_SESSION['current_id'.$contents] = $_SESSION['current_id'];
				$_SESSION['current_handle'.$contents] = $_SESSION['current_handle'];
				// ----- コンテンツ毎にユーザ切り替え -----
			}
		}
	}
}
?>
<?php
function get_album_folder($folder) {
	$album_folder = (str_replace(DIRECTORY_SEPARATOR, "/", str_replace('DOCUMENT_ROOT', $_SERVER['DOCUMENT_ROOT'], $folder)));
	if (defined("photo_LIMITED_IMAGES_FOLDER") and photo_LIMITED_IMAGES_FOLDER <> '') {
		return photo_LIMITED_IMAGES_FOLDER.'/'.$album_folder;
	}
	return $album_folder;
}
?>
