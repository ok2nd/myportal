<?php
	header("Location: list-user.php?".$_SERVER['QUERY_STRING']);
?>
