<?php
	require("__include-common.php");
	require("../account/__logincheck.php");
	require("../__common__/include-common-mp-list.php");

	$mp_list_arg = array();
	$mp_list_arg['sql_for_edit'] = "SELECT m_account.*,";
	$mp_list_arg['sql_for_edit'] .= " r_permit_type_2.id_permit_type AS public_permit_to_id,";
	$mp_list_arg['sql_for_edit'] .= " LEFT(r_permit_type_1.c_permit_type,2) AS public_permit_from,";
	$mp_list_arg['sql_for_edit'] .= " LEFT(r_permit_type_2.c_permit_type,2) AS public_permit_to,";
	$mp_list_arg['sql_for_edit'] .= " LEFT(r_permit_type_3.c_permit_type,2) AS friends_permit";
	$mp_list_arg['sql_for_edit'] .= " FROM (SELECT * FROM m_public WHERE";
	$mp_list_arg['sql_for_edit'] .= " (m_public.id_account = '".$_SESSION['login_id']."') AND m_public.c_delete = 0) T2";
	$mp_list_arg['sql_for_edit'] .= " LEFT OUTER JOIN";
	$mp_list_arg['sql_for_edit'] .= " r_permit_type r_permit_type_2";
	$mp_list_arg['sql_for_edit'] .= " ON T2.id_permit_type = r_permit_type_2.id_permit_type";
	$mp_list_arg['sql_for_edit'] .= " RIGHT OUTER JOIN m_account";
	$mp_list_arg['sql_for_edit'] .= " LEFT OUTER JOIN";
	$mp_list_arg['sql_for_edit'] .= " (SELECT * FROM m_public WHERE";
	$mp_list_arg['sql_for_edit'] .= " (m_public.id_permit_id = '".$_SESSION['login_id']."') AND m_public.c_delete = 0) T1";
	$mp_list_arg['sql_for_edit'] .= " LEFT OUTER JOIN";
	$mp_list_arg['sql_for_edit'] .= " r_permit_type r_permit_type_1";
	$mp_list_arg['sql_for_edit'] .= " ON T1.id_permit_type = r_permit_type_1.id_permit_type";
	$mp_list_arg['sql_for_edit'] .= " ON m_account.id_account = T1.id_account";
	$mp_list_arg['sql_for_edit'] .= " ON T2.id_permit_id = m_account.id_account";
	$mp_list_arg['sql_for_edit'] .= " LEFT OUTER JOIN";
	$mp_list_arg['sql_for_edit'] .= " (SELECT * FROM v_friends WHERE";
	$mp_list_arg['sql_for_edit'] .= " (v_friends.id_account = '".$_SESSION['login_id']."') AND v_friends.c_delete = 0) T3";
	$mp_list_arg['sql_for_edit'] .= " LEFT OUTER JOIN";
	$mp_list_arg['sql_for_edit'] .= " r_permit_type r_permit_type_3";
	$mp_list_arg['sql_for_edit'] .= " ON T3.id_permit_type = r_permit_type_3.id_permit_type";
	$mp_list_arg['sql_for_edit'] .= " ON m_account.id_account = T3.id_member_id";
	$mp_list_arg['sql_for_edit'] .= " WHERE (m_account.c_delete = 0)";
	$mp_list_arg['sql_for_edit'] .= " AND (m_account.id_account <> ".$_SESSION['login_id'].")";

	$mp_list_arg['template_edit']	= "list-my-template-edit-public.php";

	$order_tbl = array();
	$order_tbl[] = array(   "表示名"=>"ID順", "get_order_name"=>"id",
				"order_by"=>"id_account asc");		/* default */
	$http_arg = array();
	$http_arg['pl'] = 1000000;		// mp_list 必須

	if (isset($_POST['登録'])) {
		check_post_account($_POST['login_id']);
		update_public();
		redirect("myprofile.php");
	} else {
		_GET_to_http_arg_pool($http_arg, $table_name);
		html_header(HTML_TITLE);
		page_header();
		contents_header();
?>
<div class="input_form">
<h3>公開先メンバ修正<a class="a_cancel_back" href="myprofile.php">[キャンセル]</a></h3>
<?php
		$item_tbl = array();
		mp_list_edit($mp_list_arg, $item_tbl, $order_tbl, $http_arg);
?>
</div>
<div style="float:left;padding-left:23px;width:200px;"><p style="text-indent:-1.3em;">※ 書込許可していなくても、カレンダーの伝言機能による新規スケジュールの書き込みは可能です。</p></div></div>
<?php
		page_footer();
		html_footer();
	}
	exit();
function update_public() {
	$con = my_mysqli_connect(_DB_ACCOUNT_SCHEMA);
	foreach ($_POST as $name => $value) {
		if (mb_substr($name,0,10) == "PERMIT_NEW") {
			$up_id_account = mb_substr($name, 10);
			$permit_new = $_POST['PERMIT_NEW'.$up_id_account];
			$permit_old = $_POST['PERMIT_OLD'.$up_id_account];
			if ($permit_new <> $permit_old) {
				$updateD = date("Y/m/d H:i:s");
				if ($permit_old == '') {
					$sql = "insert into m_public (";
					$sql .= "id_account, id_permit_id, id_permit_type";
					$sql .= ", c_updatetime, c_registtime)";
					$sql .= " values (";
					$sql .= "'" . $_SESSION['login_id'] . "'";
					$sql .= ", '" . intval($up_id_account) . "'";
					$sql .= ", '" . intval($permit_new) . "'";
					$sql .= ", '" . $updateD . "'";
					$sql .= ", '" . $updateD . "'";
					$sql .= ")";
				} elseif ($permit_new == '') {
					$sql = "delete from m_public where id_account = " . $_SESSION['login_id'];
					$sql .= " and id_permit_id = " . intval($up_id_account);
				} else {
					$sql = "update m_public";
					$sql .= " set id_permit_type = " . intval($permit_new);
					$sql .= ", c_updatetime = '" . $updateD . "'";
					$sql .= " where id_account = " . $_SESSION['login_id'];
					$sql .= " and id_permit_id = " . intval($up_id_account);
				}
				$ret = mysqli_query($con, $sql);
				if (!$ret) {
					if (_DEBUG_ERROR_MSG == "YES") {
						error_exit("更新 失敗。<br><br>".$sql, True);
					} else {
						error_exit("更新 失敗。", True);
					}
				}
			}
		}
	}
	mysqli_close($con);
}
