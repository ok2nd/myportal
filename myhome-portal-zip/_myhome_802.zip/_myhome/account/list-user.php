<?php
	require("__include-common.php");
	require("../account/__logincheck.php");
	require("../__common__/include-common-mp-list.php");

	if ($_GET['edit'] == "a" or $_GET['edit'] == "y" and $_SESSION['システム管理者'] == "YES") {
		if (DB_TOOL_ID_PASSWORD_USE == 'YES') {
			require("../id-manager/__include-im-login.php");
			require("../id-manager/im-logincheck.php");
		}
	}

	$table_name_view = "v_account";
	$table_name = "m_account";
	$id_item = "id_account";
	$must_item = "c_title";

	$mp_list_arg = array();
	$mp_list_arg['account_id']	= "ALL";			//　全アカウント
	$mp_list_arg['table_name_view']	= "m_account";
	$mp_list_arg['table_name_edit']	= "m_account";


	$mp_list_arg['sql_for_view'] = "SELECT m_account.*,";
	$mp_list_arg['sql_for_view'] .= " LEFT(r_permit_type_1.c_permit_type,2) AS public_permit_from,";
	$mp_list_arg['sql_for_view'] .= " LEFT(r_permit_type_2.c_permit_type,2) AS public_permit_to,";
	$mp_list_arg['sql_for_view'] .= " LEFT(r_permit_type_3.c_permit_type,2) AS friends_permit";
	$mp_list_arg['sql_for_view'] .= " FROM (SELECT * FROM m_public WHERE";
	$mp_list_arg['sql_for_view'] .= " (m_public.id_account = '".$_SESSION['login_id']."') AND m_public.c_delete = 0) T2";
	$mp_list_arg['sql_for_view'] .= " LEFT OUTER JOIN";
	$mp_list_arg['sql_for_view'] .= " r_permit_type r_permit_type_2";
	$mp_list_arg['sql_for_view'] .= " ON T2.id_permit_type = r_permit_type_2.id_permit_type";
	$mp_list_arg['sql_for_view'] .= " RIGHT OUTER JOIN m_account";
	$mp_list_arg['sql_for_view'] .= " LEFT OUTER JOIN";
	$mp_list_arg['sql_for_view'] .= " (SELECT * FROM m_public WHERE";
	$mp_list_arg['sql_for_view'] .= " (m_public.id_permit_id = '".$_SESSION['login_id']."') AND m_public.c_delete = 0) T1";
	$mp_list_arg['sql_for_view'] .= " LEFT OUTER JOIN";
	$mp_list_arg['sql_for_view'] .= " r_permit_type r_permit_type_1";
	$mp_list_arg['sql_for_view'] .= " ON T1.id_permit_type = r_permit_type_1.id_permit_type";
	$mp_list_arg['sql_for_view'] .= " ON m_account.id_account = T1.id_account";
	$mp_list_arg['sql_for_view'] .= " ON T2.id_permit_id = m_account.id_account";
	$mp_list_arg['sql_for_view'] .= " LEFT OUTER JOIN";
	$mp_list_arg['sql_for_view'] .= " (SELECT * FROM v_friends WHERE";
	$mp_list_arg['sql_for_view'] .= " (v_friends.id_account = '".$_SESSION['login_id']."') AND v_friends.c_delete = 0) T3";
	$mp_list_arg['sql_for_view'] .= " LEFT OUTER JOIN";
	$mp_list_arg['sql_for_view'] .= " r_permit_type r_permit_type_3";
	$mp_list_arg['sql_for_view'] .= " ON T3.id_permit_type = r_permit_type_3.id_permit_type";
	$mp_list_arg['sql_for_view'] .= " ON m_account.id_account = T3.id_member_id";
	$mp_list_arg['sql_for_view'] .= " WHERE (m_account.c_delete = 0)";

	$mp_list_arg['sql_for_edit'] = $mp_list_arg['sql_for_view'];	// sort order で 公開元順などに対応するため

	$mp_list_arg['id_item']		= "id_account";
	$mp_list_arg['must_item']	= "c_account";
	$mp_list_arg['input_new']	= "no";
	if ($_SESSION['システム管理者'] == "YES") {
		$mp_list_arg['add_list'] = "yes";
	} else {
		$mp_list_arg['edit_list_all']	= "no";
	}
	$item_tbl = array();
	$item_tbl[] = array(	"表示名"=>"ID",	"列名"=>"id_account",				"width"=>"14",
				"type"=>"no_edit");
	if ($_SESSION['システム管理者'] == "YES") {
		$item_tbl[] = array(	"表示名"=>"アカウント",	"列名"=>"c_account", "文字検索"=>"Y",	"width"=>"60",
					"type"=>"text", "size"=>10, "ime-mode"=>"inactive");
	}

	if (empty($_POST['登録']) and $_GET['edit'].'' == '') {
		define("IMAGES_FOLDER", ATTACH_FILE_FOLDER);
		$item_tbl[] = array(	"表示名"=>"画像",	"列名"=>"x", "brOff"=>'Y',
					"イメージ表示列名"=>"c_profile_image",
					"i_width"=>PROFILE_ICON_IMAGE_SIZE, "i_height"=>PROFILE_ICON_IMAGE_SIZE);
		$item_tbl[] = array(	"表示名"=>"背景",	"列名"=>"x", "brOff"=>'Y',
					"イメージ表示列名"=>"c_index_bg_image",
					"i_height"=>PROFILE_ICON_IMAGE_SIZE);
	}

	$item_tbl[] = array(	"表示名"=>"ハンドル",	"列名"=>"c_handle",	"文字検索"=>"Y",	"width"=>"60",
				"type"=>"text", "size"=>10, "ime-mode"=>"active");
	$item_tbl[] = array(	"表示名"=>"氏名",	"列名"=>"c_fullname",	"文字検索"=>"Y",	"width"=>"60",
				"type"=>"text", "size"=>14, "ime-mode"=>"active");
	$item_tbl[] = array(	"表示名"=>"公開<br>先", "列名"=>"public_permit_to", "type"=>"no_edit_no_col");
	$item_tbl[] = array(	"表示名"=>"公開<br>元", "列名"=>"public_permit_from", "type"=>"no_edit_no_col");
	$item_tbl[] = array(	"表示名"=>"My<br>参照", "列名"=>"friends_permit", "type"=>"no_edit_no_col");

	if ($_SESSION['システム管理者'] == "YES") {
		$item_tbl[] = array(	"表示名"=>"パスワード",	"列名"=>"c_password",
					"type"=>"password", "size"=>10, "ime-mode"=>"inactive");
		$item_tbl[] = array(	"表示名"=>"権限",	"列名"=>"c_admin",
					"type"=>"text", "size"=>6, "ime-mode"=>"inactive");
		$item_tbl[] = array(	"表示名"=>"電子メール(パス忘れ用)/<br>スケジュール送信先",	"列名"=>"c_email", "文字検索"=>"Y",
					"type"=>"text", "size"=>28, "ime-mode"=>"inactive", "break"=>"後");
		$item_tbl[] = array(	"表示名"=>"",	"列名"=>"c_email_calendar", "文字検索"=>"Y",	"width"=>"160",
					"type"=>"text", "size"=>28, "ime-mode"=>"inactive", "break"=>"前");
	}

	$item_tbl[] = array(	"表示名"=>"住所", "ラベル"=>"〒",	"列名"=>"c_zip1", "align"=>"left",
				"type"=>"text", "size"=>5, "ime-mode"=>"inactive", "break"=>"後連");
	$item_tbl[] = array(	"表示名"=>"", "ラベル"=>"-","ラベルLIST"=>"-","列名"=>"c_zip2", "align"=>"left",
				"type"=>"text", "size"=>8, "ime-mode"=>"inactive", "break"=>"連後");
	$item_tbl[] = array(	"表示名"=>"",	"列名"=>"c_home_address",
				"type"=>"text", "size"=>50, "ime-mode"=>"active", "文字検索"=>"Y", "break"=>"前後");
	$item_tbl[] = array(	"表示名"=>"",	"ラベル"=>"ビル名", "列名"=>"c_home_address2",
				"type"=>"text", "size"=>41, "ime-mode"=>"active", "文字検索"=>"Y", "break"=>"前");
	$item_tbl[] = array(	"表示名"=>"コメント",	"列名"=>"c_msg",
				"type"=>"textarea", "cols"=>50, "rows"=>4,	"文字検索"=>"Y");
	$order_tbl = array();
	$order_tbl[] = array(   "表示名"=>"ID順", "get_order_name"=>"id",
				"order_by"=>"id_account asc");		/* default */
	if ($_SESSION['システム管理者'] == "YES") {
		$order_tbl[] = array(   "表示名"=>"アカウント順", "get_order_name"=>"account",
					"order_by"=>"c_account asc");
	}
	$order_tbl[] = array(   "表示名"=>"ハンドル名順", "get_order_name"=>"handle",
				"order_by"=>"c_handle asc");
	$order_tbl[] = array(   "表示名"=>"公開元順", "get_order_name"=>"permit",
				"order_by"=>"public_permit_from desc, friends_permit desc");
	$order_tbl[] = array(   "表示名"=>"最新順", "get_order_name"=>"new",
				"order_by"=>"id_account desc");

	$http_arg = array();
	$http_arg['pl'] = PAGE_LINE_DEFAULT;		// mp_list 必須
	$http_arg['sort'] = '';				// mp_list 必須
	$http_arg['cat'] = '';				// mp_list 必須
	$http_arg['key'] = '';				// mp_list 必須

	$http_arg['cid'] = '';

	if (isset($_POST['登録'])) {
		if ($_SESSION['システム管理者'] == "YES") {
			check_post_account($_POST['login_id']);
			mp_list_update($mp_list_arg, $item_tbl, $order_tbl, $http_arg);
		}
	} else {
		_GET_to_http_arg_pool($http_arg, $table_name);
		html_header(HTML_TITLE);
		page_header();
		contents_header();
		if ($_GET['edit'] == "a") {
			if ($_SESSION['システム管理者'] == "YES") {
				$mp_list_arg['sql_for_edit'] = "select * from m_account where id_account = 0";
				mp_list_edit($mp_list_arg, $item_tbl, $order_tbl, $http_arg);
			}
		} else if ($_GET['edit'] == "y") {
			if ($_SESSION['システム管理者'] == "YES") {
				mp_list_edit($mp_list_arg, $item_tbl, $order_tbl, $http_arg);
			}
		} else {
			mp_list_view($mp_list_arg, $item_tbl, $order_tbl, $http_arg);
		}
		page_footer();
		html_footer();
	}
	exit();
