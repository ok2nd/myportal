<?php
	require("__include-common.php");
	require("../account/__logincheck.php");
	if ($_SESSION['システム管理者'] <> "YES") {
		exit;
	}
	if ($_GET['seek'].'' <> '') {
		$seek = $_GET['seek'];
	} else {
		$seek = 0;
	}
	if (is_numeric($_POST['save_count'])) {
		$save_count = $_POST['save_count'];
		setcookie("list_loginlog_save_count", $save_count, time() + LOGIN_COOKIE_EXPIRE, MY_SESSION_PATH);
	} else if ($_COOKIE['list_loginlog_save_count'].'' <> '') {
		$save_count = $_COOKIE['list_loginlog_save_count'];
	} else {
		$save_count = '10000';
	}
	html_header(HTML_TITLE);
	page_header();
	contents_header();
	if (isset($_POST['logClear'])) {
		log_clear($save_count);
	}
	print_loginlog($seek, $save_count);
	page_footer();
	html_footer();
	exit();
function log_clear($save_count) {
	$con = my_mysqli_connect(_DB_SCHEMA);
	$sql = 'select id from z_loginlog order by id desc limit 1;';
	$rs = my_mysqli_query($sql);
	$rec = mysqli_fetch_array($rs);
	$sql = 'delete from z_loginlog where id < '.($rec['id']-intval($save_count)+1).';';
	my_mysqli_query($sql);
	mysqli_close($con);
}
function print_loginlog($seek, $save_count) {
?>
	<div id="log_list_body">
	<h2>MyHome Portal ログイン履歴表示</h2><br>
	<form method="POST" action="<?= $_SERVER['SCRIPT_NAME'] ?>" style="margin: 0 0 5px 0; ">
	最新の<input class="text" type="text" name="save_count" size="10" value="<?= $save_count ?>">件を残して、<input type="submit" name="logClear" value="古いログを削除する">
	</form>
	DB：<span class="db_table_name"><?= _DB_SCHEMA ?></span> TABLE：<span class="db_table_name">z_loginlog</span>
<?php
	$seek_max = $seek + LOGINLOG_MAXREC;
	$con = my_mysqli_connect(_DB_SCHEMA);
	$sql = "select * from z_loginlog order by id desc";
	$rs = my_mysqli_query($sql);
	$rowcnt = mysqli_num_rows($rs);
?>
	&nbsp;ログ件数：<span class="db_table_name"><?= $rowcnt ?></span>件
	&nbsp;最新：<span class="db_table_name"><?= $seek+1 ?></span>～<span class="db_table_name"><?= $seek_max ?></span>
	&nbsp;<a href="?seek=0">[先頭]</a>
	&nbsp;<a href="?seek=<?= $seek_max ?>">[→次]</a><br><br>
<?php
	if ($rowcnt <= $seek) {
		error_msg("ログがありません。");
		return;
	}
	mysqli_data_seek($rs, $seek);
?>
	<table id="log_table" cellspacing=1>
	<tr><th><br></th><th>id_account</th><th>c_account</th><th>c_logintime</th><th>c_status</th><th>c_change_id</th><th>id</th></tr>
<?php
	$cnt = $seek;
	while ($rec=mysqli_fetch_array($rs) and ++$cnt <= $seek_max) {
?>
		<tr>
		<td style="text-align: right;"><?= $cnt ?></td>
		<td><?= $rec['id_account'] ?></td>
		<td><?= $rec['c_account'] ?></td>
		<td><?= $rec['c_logintime'] ?></td>
		<td><?= $rec['c_status'] ?></td>
		<td><?= $rec['c_change_id'] ?></td>
		<td><?= $rec['id'] ?></td>
		</tr>
<?php
	}
	mysqli_close($con);
?>
	</table>
	</div>
<?php
}
?>
