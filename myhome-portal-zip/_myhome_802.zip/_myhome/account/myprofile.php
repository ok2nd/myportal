<?php
	require("__include-common.php");
	require("../account/__logincheck.php");

	html_header(HTML_TITLE);
	page_header();

	$_SESSION['edit_myprofile_error'] = "";
	$_SESSION['edit_myprofile_handle'] = "";
	$_SESSION['edit_myprofile_email'] = "";
	$_SESSION['edit_mypass_error'] = "";

	main_proc();

	page_footer();
	html_footer();
	exit();

function main_proc() {
	$con = my_mysqli_connect(_DB_ACCOUNT_SCHEMA);
	$sql = "SELECT * FROM m_account WHERE id_account = '" . $_SESSION['login_id'] . "'";
	$selectdb = mysqli_select_db($con, $db);
	$rs_account = my_mysqli_query($sql);
	$row = mysqli_num_rows($rs_account);
	if ($row == 0) {
		echo "アカウント情報がみつかりません。";
		exit;
	}
	$rec_account = mysqli_fetch_array($rs_account);
?>
<div class="input_form">
<h3>My設定</h3>
	<div class="menu_standard">
	<ul>
		<li><a href="edit-myprofile.php">[アカウント情報修正]</a></li>
		<li><a href="edit-mypass.php">[パスワード修正]</a></li>
		<li><a href="edit-id-mgr-pass.php">[ID管理パスワード修正]</a></li>
	</ul>
	</div>
<div id="myprofile_account">
	<h4>アカウント情報</h4>
<table class="myprofile_info_table">
<tr>
	<th nowrap>アカウント名</th>
	<td nowrap><?= my_htmlspecialchars($rec_account['c_account']) ?></td>
</tr>
<tr>
	<th nowrap>ハンドル名</th>
	<td nowrap><?= my_htmlspecialchars($rec_account['c_handle']) ?></td>
</tr>
<tr>
	<th nowrap>アイコン画像</th>
	<td nowrap>
		<?php if ($rec_account['c_profile_image'] <> '') { ?>
			<img src="<?= ATTACH_FILE_FOLDER.'/'.($rec_account['c_profile_image']) ?>" style="width:<?= PROFILE_ICON_IMAGE_SIZE ?>px; height:<?= PROFILE_ICON_IMAGE_SIZE ?>px;">
		<?php } ?>
	</td>
</tr>
<tr>
	<th nowrap>INDEX 背景画像</th>
	<td nowrap>
		<?php if ($rec_account['c_index_bg_image'] <> '') { ?>
			<img src="<?= ATTACH_FILE_FOLDER.'/'.($rec_account['c_index_bg_image']) ?>" style="height:<?= PROFILE_ICON_IMAGE_SIZE ?>px;">
		<?php } ?>
	</td>
</tr>
<tr>
	<th nowrap>電子メールアドレス<br>(パスワード忘れ用)</th>
	<td nowrap><?= my_htmlspecialchars($rec_account['c_email']) ?></td>
</tr>
<tr>
	<th nowrap>電子メールアドレス<br>(スケジュール送信先)</th>
	<td nowrap><?= my_htmlspecialchars($rec_account['c_email_calendar']) ?></td>
</tr>
<tr>
	<th nowrap>コメント</th>
	<td nowrap><?= ins_br(my_htmlspecialchars($rec_account['c_msg'])) ?></td>
</tr>
<tr>
	<th nowrap>アルバムフォルダ</th>
<?php
	if (defined("photo_LIMITED_IMAGES_FOLDER") and photo_LIMITED_IMAGES_FOLDER <> '') {
		$photo_folder = photo_LIMITED_IMAGES_FOLDER.'/';
	}
?>
	<td nowrap><?= $photo_folder ?><?= my_htmlspecialchars($rec_account['c_album_folder']) ?></td>
</tr>
<tr>
	<th nowrap>カレンダーアルバムフォルダ</th>
<?php
	if (defined("photo_LIMITED_IMAGES_FOLDER") and photo_LIMITED_IMAGES_FOLDER <> '') {
		$photo_folder = photo_LIMITED_IMAGES_FOLDER.'/';
	}
?>
	<td nowrap><?= $photo_folder ?><?= my_htmlspecialchars($rec_account['c_album_calendar_folder']) ?></td>
</tr>
<tr>
	<th nowrap>ページ背景色</th>
	<td nowrap><?= my_htmlspecialchars($rec_account['c_body_background_color']) ?></td>
</tr>
<tr>
	<th nowrap>氏名</th>
	<td nowrap><?= my_htmlspecialchars($rec_account['c_fullname']) ?></td>
</tr>
<tr>
	<th nowrap>〒番号</th>
	<td nowrap><?= my_htmlspecialchars($rec_account['c_zip1']) ?>-<?= my_htmlspecialchars($rec_account['c_zip2']) ?></td>
</tr>
<tr>
	<th nowrap>住所(経路起点)</th>
	<td nowrap><?= my_htmlspecialchars($rec_account['c_home_address']) ?></td>
</tr>
<tr>
	<th nowrap>住所2</th>
	<td nowrap><?= my_htmlspecialchars($rec_account['c_home_address2']) ?></td>
</tr>
<tr>
	<th nowrap>最寄駅(乗換乗車駅)</th>
	<td nowrap><?= my_htmlspecialchars($rec_account['c_home_station']) ?></td>
</tr>
<tr>
	<th nowrap>カレンダー</th>
	<td nowrap><? if ($rec_account['c_cal_sbj_use']=='NO') echo '件名を使わない（スケジュール本文のみを使う）'; ?></td>
</tr>
<tr>
	<th nowrap>トップメニュー色</th>
	<td nowrap>
		<table cellspacing=0 class="inner_table">
		<tr>
		<td style="vertical-align:middle">標準：<br></td>
		<td>文字色＝<?= $_SESSION['page_navi_link_color'] ?></td>
		<td>背景色＝<?= $_SESSION['page_navi_link_bg'] ?></td>
		<td><span style="color:<?= $_SESSION['page_navi_link_color'] ?>;background-color:<?= $_SESSION['page_navi_link_bg'] ?>">サンプル</span></td>
		</tr>
		<tr>
		<td style="vertical-align:middle">カレント：<br></td>
		<td>文字色＝<?= $_SESSION['page_navi_current_color'] ?></td>
		<td>背景色＝<?= $_SESSION['page_navi_current_bg'] ?></td>
		<td><span style="color:<?= $_SESSION['page_navi_current_color'] ?>;background-color:<?= $_SESSION['page_navi_current_bg'] ?>">サンプル</span></td>
		</tr>
		<tr>
		<td style="vertical-align:middle">hover：<br></td>
		<td>文字色＝<?= $_SESSION['page_navi_hover_color'] ?></td>
		<td>背景色＝<?= $_SESSION['page_navi_hover_bg'] ?></td>
		<td><span style="color:<?= $_SESSION['page_navi_hover_color'] ?>;background-color:<?= $_SESSION['page_navi_hover_bg'] ?>">サンプル</span></td>
		</tr>
		<tr>
		<td style="vertical-align:middle">active：<br></td>
		<td>文字色＝<?= $_SESSION['page_navi_active_color'] ?></td>
		<td>背景色＝<?= $_SESSION['page_navi_active_bg'] ?></td>
		<td><span style="color:<?= $_SESSION['page_navi_active_color'] ?>;background-color:<?= $_SESSION['page_navi_active_bg'] ?>">サンプル</span></td>
		</tr>
		</table>
	</td>
</tr>
</table>
</div>
<div id="myprofile_friends">
<?php
	if (EDIT_FRIENDS_PAGE == "IDINP") {
		$edit_php = "edit-friends-inp.php";
	} else {
		$edit_php = "edit-friends.php";
	}
?>
	<h4>My参照メンバ<a class="a_update_form" href="<?= $edit_php ?>">追加/削除</a></h4>
<?php
	//$sql = "SELECT m_friends.*, m_account.c_handle FROM m_friends";
	//$sql .= " LEFT OUTER JOIN m_account ON m_friends.id_member_id = m_account.id_account";
	//$sql .= " WHERE m_friends.c_delete = 0 and m_friends.id_account = '" . $_SESSION['login_id'] . "'";
	//$sql .= " order by id_member_id";

	$sql = "SELECT * FROM v_friends";
	$sql .= " WHERE c_delete = 0 and id_account = '" . $_SESSION['login_id'] . "'";
	$sql .= " order by c_displayOrder";

	$selectdb = mysqli_select_db($con, $db);
	$rs_friends = my_mysqli_query($sql);
	$row = mysqli_num_rows($rs_friends);
	if ($row > 0) {
?>
	<table class="myprofile_info_table">
		<tr>
		<th>ID</th>
		<th>ハンドル名</th>
		<th colspan=2></th>
		</tr>
<?php
		while ($rec_friends=mysqli_fetch_array($rs_friends)) {
?>
		<tr>
		<td><?= my_htmlspecialchars($rec_friends['id_member_id']) ?></td>
		<td><?= my_htmlspecialchars($rec_friends['c_handle']) ?></td>
		<td><?= my_htmlspecialchars($rec_friends['c_permit_type']) ?></td>
		<td style="text-align: right;"><?= my_htmlspecialchars($rec_friends['c_displayOrder']) ?></td>
		</tr>
<?php
		}
?>
	</table>
<?php
	}
?>
</div>
<div id="myprofile_public">
<?php
	if (EDIT_PUBLIC_PAGE == "IDINP") {
		$edit_php = "edit-public-inp.php";
	} else {
		$edit_php = "edit-public.php";
	}
?>
	<h4>公開先メンバ<a class="a_update_form" href="<?= $edit_php ?>">追加/削除</a></h4>
<?php
	$sql = "SELECT * FROM m_public WHERE id_account = '" . $_SESSION['login_id'] . "'";

	$sql = "SELECT m_public.*, m_account.c_handle, r_permit_type.c_permit_type FROM m_public";
	$sql .= " LEFT OUTER JOIN m_account ON m_public.id_permit_id = m_account.id_account";
	$sql .= " LEFT OUTER JOIN r_permit_type ON m_public.id_permit_type = r_permit_type.id_permit_type";
	$sql .= " WHERE m_public.c_delete = 0 and m_public.id_account = '" . $_SESSION['login_id'] . "'";
	$sql .= " order by id_permit_id";

	$selectdb = mysqli_select_db($con, $db);
	$rs_public = my_mysqli_query($sql);
	$row = mysqli_num_rows($rs_public);
	if ($row > 0) {
?>
	<table class="myprofile_info_table">
		<tr>
		<th>ID</th>
		<th>ハンドル名</th>
		<th></th>
		</tr>
<?php
		while ($rec_public=mysqli_fetch_array($rs_public)) {
?>
		<tr>
		<td><?= my_htmlspecialchars($rec_public['id_permit_id']) ?></td>
		<td><?= my_htmlspecialchars($rec_public['c_handle']) ?></td>
		<td><?= my_htmlspecialchars($rec_public['c_permit_type']) ?></td>

		</tr>
<?php
		}
?>
	</table>
<?php
	}
?>
</div>
</div>
<?php
	mysqli_close($con);
}
?>
