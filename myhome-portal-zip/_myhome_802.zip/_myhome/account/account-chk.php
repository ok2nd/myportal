<?php
	//header("Content-type: text/html");
	//header("Cache-Control: no-cache");

	require("__include-common.php");
	require("__include-account-check.php");

//***** データベース接続 **************************************************
	if (isset($_POST['account']) || isset($_GET['account'])) {
		if (isset($_POST['account'])) {
			$account = trim($_POST['account']);
		} else {
			$account = trim($_GET['account']);
		}
		if ($account <> "") {
			if (strlen($account) < ACCOUNT_ID_NAME_MIN_LENGTH) {
				echo "SHORT";
				exit;
			}
			if (strlen($account) > 20) {
				echo "LONG";
				exit;
			}
			if (strpos($account,"admin") !== False or mb_substr($account,0,4) == "root") {
				echo "NOPERMIT";
				exit;
			}
			if (!checkIsAlphaNum($account)) {
				echo "NOTANC";
				exit;
			}
			$con_account = my_mysqli_connect(_DB_ACCOUNT_SCHEMA, False);
			$sql = "SELECT * FROM m_account WHERE c_account = '" . str_for_mysql($account) . "'";
			$rs = my_mysqli_query($sql, '', $con_account);
			if ($rs) {
				$row = mysqli_num_rows($rs);
				if ($row == 0) {
					echo "OK";
					exit;
				} else {
					echo "USED";
					exit;
				}
			} else {
				echo "SELECTERROR";
				exit;
			}
		} else {
			echo "NULL";
			exit;
		}
	} else if (isset($_POST['handle']) || isset($_GET['handle'])) {
		if (isset($_POST['handle'])) {
			$handle = trim($_POST['handle']);
		} else {
			$handle = trim($_GET['handle']);
		}
		if ($handle <> "") {
			$interenc = mb_internal_encoding();
			mb_language('Japanese');
			mb_internal_encoding('UTF-8');		//"Shift-JIS" 'UTF-8' "iso-8859-1"
		//	if (!checkIsZenkaku($handle)) {
		//		echo "NOTZENKAKU";
		//		exit;
		//	}
			if (mb_strlen($handle) < 1) {
				echo "SHORT";
				exit;
			}
			if (mb_strlen($handle) > 10) {
				echo "LONG";
				exit;
			}
			if (strpos($handle,"管理") !== False or strpos($handle,"システム") !== False or strpos($handle,"特権" or strpos($handle,"admin") !== False or mb_substr($handle,0,4) == "root") !== False) {
				echo "NOPERMIT";
				exit;
			}
			$con_account = my_mysqli_connect(_DB_ACCOUNT_SCHEMA, False);
			$sql = "SELECT * FROM m_account WHERE c_handle = '" . str_for_mysql($handle) . "'";
			$rs = my_mysqli_query($sql, '', $con_account);
			if ($rs) {
				$row = mysqli_num_rows($rs);
				if ($row == 0) {
					echo "OK";
					exit;
				} else {
					if (isset($_POST['ac'])) {
						$rec = mysqli_fetch_array($rs);
						if (trim($rec[c_account]) == trim($_POST['ac'])) {
							echo "YOUR";
							exit;
						} else {
							echo "USED";
							exit;
						}
					}
					echo "USED";
					exit;
				}
			} else {
				echo $sql;
				exit;
			}
		} else {
			echo "NULL";
			exit;
		}
	} else {
		echo "NULLALL";
		exit;
	}
?>
