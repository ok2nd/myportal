<?php
	require("__include-common.php");
	require("../account/__logincheck.php");
	require("../__common__/include-common-mp-list.php");

	$table_name_view = "v_public";
	$table_name = "v_public";
	$id_item = "id_public";
	$must_item = "id_permit_id";

	$mp_list_arg = array();
	$mp_list_arg['account_id']		= $_SESSION['login_id'];
	$mp_list_arg['table_name_view']		= "v_public";
	$mp_list_arg['table_name_edit']		= "v_public";
	$mp_list_arg['table_name_update']	= "m_public";
	$mp_list_arg['id_item']		= "id_public";
	$mp_list_arg['must_item']	= "id_permit_id";
	$mp_list_arg['input_new']	= "no";
	$mp_list_arg['update_redirect'] = "myprofile.php";

	$item_tbl = array();
	$item_tbl[] = array(	"表示名"=>"アカウントID",	"列名"=>"id_permit_id",
				"type"=>"text", "size"=>8, "ime-mode"=>"inactive");
	$item_tbl[] = array(	"表示名"=>"ハンドル名",	"列名"=>"c_handle",
				"type"=>"no_edit");
	$item_tbl[] = array(	"表示名"=>"権限",	"列名"=>"id_permit_type", "http_arg_GET名"=>"cat",
				"type"=>"select", "参照テーブル"=>"r_permit_type",
				"参照テーブル表示列"=>"c_permit_type",
				"参照テーブル表示順"=>"id_permit_type");

	$order_tbl = array();
	$order_tbl[] = array(   "表示名"=>"ID順", "get_order_name"=>"new",
				"order_by"=>"id_permit_id asc");		/* default */

	$http_arg = array();
	$http_arg['pl'] = PAGE_LINE_DEFAULT;		// mp_list 必須
	$http_arg['sort'] = '';				// mp_list 必須
	$http_arg['cat'] = '';				// mp_list 必須
	$http_arg['key'] = '';				// mp_list 必須

	$http_arg['cid'] = '';

	if (isset($_POST['登録'])) {
		check_post_account($_POST['login_id']);
		mp_list_update($mp_list_arg, $item_tbl, $order_tbl, $http_arg);
	} else {
		_GET_to_http_arg_pool($http_arg, $table_name);
		html_header(HTML_TITLE);
		page_header();
		contents_header();
?>
<div class="input_form">
<h3>公開先メンバ修正<a class="a_cancel_back" href="myprofile.php">[キャンセル]</a></h3>
<?php
		mp_list_edit($mp_list_arg, $item_tbl, $order_tbl, $http_arg);
?>
</div>
<?php
		page_footer();
		html_footer();
	}
	exit();
?>
