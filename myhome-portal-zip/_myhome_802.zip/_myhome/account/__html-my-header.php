<meta charset="utf-8">
<meta name="author" content="ok.2nd">
<meta name="description" content="Account">
<meta name="keywords" content="account">
<link rel="stylesheet" href="<?= _STYLE_SHEET_FOLDER_COMMON ?>/common.css?20131130">
<link rel="stylesheet" href="<?= _STYLE_SHEET_BUTTON ?>">
<link rel="stylesheet" href="<?= _STYLE_SHEET_FOLDER ?>/mp-list.css?20130525">
<link rel="stylesheet" href="<?= _STYLE_SHEET_FOLDER ?>/account.css?20120323">
<script src="../scripts/jquery.js"></script>
<script src="../scripts/jquery.cookie.js"></script>
<script src="../scripts/ok2nd.js"></script>
