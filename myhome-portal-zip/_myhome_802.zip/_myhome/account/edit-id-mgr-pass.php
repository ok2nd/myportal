<?php
	require("__include-common.php");
	require("__include-login.php");
	require("__include-account-check.php");
	$error_msg = "";
	if ($_POST) {
		check_post_account($_POST['login_id']);
		$error_msg = post_done_proc();
	}
	html_header(HTML_TITLE, "_add_newaccount_header.php");
	page_header(False);
	input_form($error_msg);
	page_footer();
	html_footer();
	exit();
?>
<?php
function input_form($error_msg) {
	$con = my_mysqli_connect(_DB_ACCOUNT_SCHEMA);
	$sql = "SELECT * FROM m_account WHERE id_account = '" . $_SESSION['login_id'] . "'";
	$rs_account = my_mysqli_query($sql);
	$row = mysqli_num_rows($rs_account);
	if ($row == 0) {
		error_exit("アカウントがみつかりません", True);
	}
	$rec_account = mysqli_fetch_array($rs_account);
	if (!$_POST) {
		$_SESSION['edit_myprofile_handle'] = my_htmlspecialchars($rec_account['c_handle']);
		$_SESSION['edit_myprofile_email'] = my_htmlspecialchars($rec_account['c_email']);
		$_SESSION['edit_myprofile_msg'] = my_htmlspecialchars($rec_account['c_msg']);
	}
?>
<div class="input_form">
<h3>ID管理パスワード修正<a class="a_cancel_back" href="myprofile.php">[キャンセル]</a></h3>
<form name="form0" method="POST" action="<?= $_SERVER['SCRIPT_NAME'] ?>">
	<input type="hidden" name="login_id" value="<?= $_SESSION['login_id'] ?>">
	<input type="hidden" name="current_id" value="<?= $_SESSION['current_id'] ?>">
<table class="myprofile_info_table">
<tr>
	<th nowrap>アカウント名</th>
	<td nowrap><?= my_htmlspecialchars($rec_account['c_account']) ?></td>
</tr>
<tr valign="top">
	<th nowrap>現在の<b>ログイン</b>パスワード<br><span style="color:red;">(ID管理パスワードではありません。)</span></th>
	<td nowrap>
	<input class="password" type="password" name="password_now" style="width: 160px;">
	</td>
</tr>
<tr valign="top">
	<th nowrap>新ID管理パスワード(英数記号/<?= ACCOUNT_PASSWORD_MIN_LENGTH ?>～30文字)</th>
	<td nowrap>
	<input class="password" type="password" name="password" style="width: 160px;" onChange="PasswordCheckOnChange()">
	<span id="passwordErrMsg" class="alarm_text"></span>
	</td>
</tr>
<tr valign="top">
	<th nowrap>新ID管理パスワード(再入力)</th>
	<td nowrap>
	<input class="password" type="password" name="password2" style="width: 160px;" onChange="Password2CheckOnChange()">
	<span id="password2ErrMsg" class="alarm_text"></span>
	</td>
</tr>
</table>
	<input class="input_form_button" type="submit" name="修正" value="修正">
	<input class="input_form_button" type="reset" name="リセット" value="リセット">
</form>
	<p class="error_msg"><?= $error_msg ?><p>
</div>
<?php
	return(0);
}
?>
<?php
function post_done_proc() {
	$con = my_mysqli_connect(_DB_ACCOUNT_SCHEMA);
	$sql = "select * from m_account where id_account = '" . $_SESSION['login_id'] . "'";
	$rs_account = my_mysqli_query($sql);
	$rec_account = mysqli_fetch_array($rs_account);
	if ($rec_account['c_password'] <> $_POST['password_now']) {
		return "現在のログインパスワードが間違っています。";
	}
	$password = $_POST['password'];
	if (($ret = ac_chk_password($password, $_POST['password2'])) <> "") return ($ret);
	$sql = "update m_account";
	$sql .= " set c_id_mgr_pass = '". str_for_mysql($password) . "'";
	$sql .= ", c_updatetime = '". date("Y/m/d H:i:s") . "'";
	$sql .= " where id_account = '" . $_SESSION['login_id'] . "'";
	$ret = my_mysqli_query($sql);
	if (!$ret) {
		mysqli_close($con);
		return "パスワード修正に失敗しました。";
	}
	mysqli_close($con);
	setcookie("login_account_id_mgr_pass", '', time() + LOGIN_COOKIE_EXPIRE, MY_SESSION_PATH);
	$_SESSION['_id_mgr_logincheck'] = '';
	redirect("myprofile.php");
}
?>
