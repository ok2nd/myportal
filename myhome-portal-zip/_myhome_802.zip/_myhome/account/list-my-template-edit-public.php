	<table id="mp_list_table_nowidth">
	<tr class="mp_list_table_head">
		<th>ID</th>
		<th>ハンドル</th>
		<th>公開先</th>
		<th>公開元<br>(自分への公開状況)</th>
		<th>My参照<br>(自分の参照メンバ)</th>
	</tr>
<?php
	mysqli_data_seek($rs, $startline);
	$line = $startline;
	while ($rec=mysqli_fetch_array($rs) and $line<=$endline) {
?>
	<tr class="mp_list_table_data">
		<td><?= my_htmlspecialchars($rec['id_account']) ?></td>
		<td><?= my_htmlspecialchars($rec['c_handle']) ?></td>
		<td>
		<select name="PERMIT_NEW<?= $rec['id_account'] ?>">
			<option value="">
<?php
		$sqlsel = "select * from r_permit_type";
		$rs_sel = my_mysqli_query($sqlsel);
		while ($rec_sel=mysqli_fetch_array($rs_sel)) {
?>
			<option value="<?= $rec_sel['id_permit_type'] ?>"<?= $rec_sel['id_permit_type'] == $rec['public_permit_to_id'] ? " selected" : "" ?>><?= $rec_sel['c_permit_type'] ?>
<?php
		}
?>
		</select>
		<input type="hidden" name="PERMIT_OLD<?= $rec['id_account'] ?>" value="<?= $rec['public_permit_to_id'] ?>">
		</td>
		<td><?= my_htmlspecialchars($rec['public_permit_from']) ?></td>
		<td><?= my_htmlspecialchars($rec['friends_permit']) ?></td>
	</tr>
<?php
		$line++;
	}
?>
	</table>
