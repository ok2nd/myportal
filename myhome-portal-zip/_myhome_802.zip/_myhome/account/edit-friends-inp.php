<?php
	require("__include-common.php");
	require("../account/__logincheck.php");
	require("../__common__/include-common-mp-list.php");

	$table_name_view = "v_friends";
	$table_name = "v_friends";
	$id_item = "id_friends";
	$must_item = "id_member_id";

	$mp_list_arg = array();
	$mp_list_arg['account_id']		= $_SESSION['login_id'];
	$mp_list_arg['table_name_view']		= "v_friends";
	$mp_list_arg['table_name_edit']		= "v_friends";
	$mp_list_arg['table_name_update']	= "m_friends";
	$mp_list_arg['id_item']		= "id_friends";
	$mp_list_arg['must_item']	= "id_member_id";
	$mp_list_arg['input_new']	= "no";
	$mp_list_arg['update_redirect'] = "myprofile.php";
	$mp_list_arg['update_after_callback'] = "update_after_callback";
	$mp_list_arg['list_edit_right_add_html']	= "in-block-friends-description.php";

	$item_tbl = array();
	$item_tbl[] = array(	"表示名"=>"アカウントID",	"列名"=>"id_member_id",
				"type"=>"text", "size"=>8, "ime-mode"=>"inactive");
	$item_tbl[] = array(	"表示名"=>"ハンドル名",	"列名"=>"c_handle",
				"type"=>"no_edit");
	$item_tbl[] = array(	"表示名"=>"表示順",	"列名"=>"c_displayOrder",
				"type"=>"text", "size"=>3, "ime-mode"=>"disabled", "toInt"=>"Y");

	$order_tbl = array();
	$order_tbl[] = array(   "表示名"=>"表示順", "get_order_name"=>"order",
				"order_by"=>"c_displayOrder asc");		/* default */

	$http_arg = array();
	$http_arg['pl'] = PAGE_LINE_DEFAULT;		// mp_list 必須
	$http_arg['sort'] = '';				// mp_list 必須
	$http_arg['cat'] = '';				// mp_list 必須
	$http_arg['key'] = '';				// mp_list 必須

	$http_arg['cid'] = '';

	if (isset($_POST['登録'])) {
		check_post_account($_POST['login_id']);
		mp_list_update($mp_list_arg, $item_tbl, $order_tbl, $http_arg);
	} else {
		_GET_to_http_arg_pool($http_arg, $table_name);
		html_header(HTML_TITLE);
		page_header();
		contents_header();
?>
<div class="input_form">
<h3>My参照メンバ修正<a class="a_cancel_back" href="myprofile.php">[キャンセル]</a></h3>
<?php
		mp_list_edit($mp_list_arg, $item_tbl, $order_tbl, $http_arg);
?>
</div>
<?php
		page_footer();
		html_footer();
	}
	exit();

function update_after_callback() {
	//My参照メンバ設定を反映させるため
	_account_login($_SESSION['login_id'], "", $_COOKIE['login_account_okuser_pass']);
}
?>
