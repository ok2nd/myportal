<?php
	require("__include-common.php");
	require("__include-login.php");
	require("__include-account-check.php");
	$error_msg = "";
	if ($_POST) {
		check_post_account($_POST['login_id']);
		$error_msg = post_done_proc();
	}
	html_header(HTML_TITLE, "_add_newaccount_header.php");
	page_header(False);
	input_form($error_msg);
	page_footer();
	html_footer();
	exit();
?>
<?php
function input_form($error_msg) {
	$con = my_mysqli_connect(_DB_ACCOUNT_SCHEMA);
	$sql = "SELECT * FROM m_account WHERE id_account = '" . $_SESSION['login_id'] . "'";
	$rs_account = my_mysqli_query($sql);
	$row = mysqli_num_rows($rs_account);
	if ($row == 0) {
		error_exit("アカウントがみつかりません", True);
	}
	$rec_account = mysqli_fetch_array($rs_account);
	if (!$_POST) {
		$_SESSION['edit_myprofile_handle'] = my_htmlspecialchars($rec_account['c_handle']);
		$_SESSION['edit_myprofile_email'] = my_htmlspecialchars($rec_account['c_email']);
		$_SESSION['edit_myprofile_email_calendar'] = my_htmlspecialchars($rec_account['c_email_calendar']);
		$_SESSION['edit_myprofile_album_folder'] = my_htmlspecialchars($rec_account['c_album_folder']);
		$_SESSION['edit_myprofile_album_calendar_folder'] = my_htmlspecialchars($rec_account['c_album_calendar_folder']);
		$_SESSION['edit_myprofile_body_background_color'] = my_htmlspecialchars($rec_account['c_body_background_color']);
		$_SESSION['edit_myprofile_msg'] = my_htmlspecialchars($rec_account['c_msg']);
		$_SESSION['edit_myprofile_fullname'] = my_htmlspecialchars($rec_account['c_fullname']);
		$_SESSION['edit_myprofile_zip1'] = my_htmlspecialchars($rec_account['c_zip1']);
		$_SESSION['edit_myprofile_zip2'] = my_htmlspecialchars($rec_account['c_zip2']);
		$_SESSION['edit_myprofile_home_address'] = my_htmlspecialchars($rec_account['c_home_address']);
		$_SESSION['edit_myprofile_home_address2'] = my_htmlspecialchars($rec_account['c_home_address2']);
		$_SESSION['edit_myprofile_home_station'] = my_htmlspecialchars($rec_account['c_home_station']);
		$_SESSION['edit_myprofile_cal_sbj_use'] = my_htmlspecialchars($rec_account['c_cal_sbj_use']);

		$_SESSION['edit_page_navi_link_color'] = $rec_account['c_page_navi_link_color'];
		$_SESSION['edit_page_navi_link_bg'] = $rec_account['c_page_navi_link_bg'];
		$_SESSION['edit_page_navi_current_color'] = $rec_account['c_page_navi_current_color'];
		$_SESSION['edit_page_navi_current_bg'] = $rec_account['c_page_navi_current_bg'];
		$_SESSION['edit_page_navi_hover_color'] = $rec_account['c_page_navi_hover_color'];
		$_SESSION['edit_page_navi_hover_bg'] = $rec_account['c_page_navi_hover_bg'];
		$_SESSION['edit_page_navi_active_color'] = $rec_account['c_page_navi_active_color'];
		$_SESSION['edit_page_navi_active_bg'] = $rec_account['c_page_navi_active_bg'];
	}
?>
<div class="input_form">
<script src="../scripts/valueconvertor.js"></script>
<script src="../scripts/jqKey.js"></script>
<script>
$(function() {
	$('table#form_table td').jqKey({
		Enter:true
	})
});
</script>
<h3>アカウント情報修正<a class="a_cancel_back" href="myprofile.php">[キャンセル]</a></h3>
<form name="form0" method="POST" action="<?= $_SERVER['SCRIPT_NAME'] ?>#submit" enctype="multipart/form-data">
	<input type="hidden" name="login_id" value="<?= $_SESSION['login_id'] ?>">
	<input type="hidden" name="current_id" value="<?= $_SESSION['current_id'] ?>">
<table id="form_table" class="myprofile_info_table">
<tr>
	<th nowrap>アカウント名</th>
	<td nowrap><?= my_htmlspecialchars($rec_account['c_account']) ?></td>
</tr>
<tr valign="top">
	<th nowrap>ハンドル名<br>（10文字以下）</th>
	<td nowrap>
	<p><span style='color: #8080ff;'><?= my_htmlspecialchars($rec_account['c_handle']) ?></span></p>
	<input class="text" type="text" name="handle" value="<?= my_htmlspecialchars($_SESSION['edit_myprofile_handle']) ?>" size=20 onChange="HandleCheckOnChange()" style="ime-mode: active;">
	<button onclick="handleCheck();return false;">チェック</button>
	<span id="handleErrMsg" class="alarm_text"></span>
	</td>
</tr>
<tr>
	<th>アイコン画像
	<?php if (photo_JPEG_RESIZE == 'YES') { ?>
		<br>（画像は<?= PROFILE_ICON_IMAGE_SIZE ?>px四方に<br>縮小されます。）
	<?php } ?>
	</th>
	<td nowrap>
<?php
		if ($rec_account['c_profile_image'] <> "") {
?>
		<img src="<?= ATTACH_FILE_FOLDER.'/'.($rec_account['c_profile_image']) ?>" style="width:<?= PROFILE_ICON_IMAGE_SIZE ?>px; height:<?= PROFILE_ICON_IMAGE_SIZE ?>px;" />
		<label><input type="checkbox" name="imageDelete" value="YES">削除</label>
<?php
		}
?>
		<input type="file" size=40 name="image" style="button-font-size:small">
	</td>
</tr>
<tr>
	<th>INDEX 背景画像
	</th>
	<td nowrap>
<?php
		if ($rec_account['c_index_bg_image'] <> "") {
?>
		<img src="<?= ATTACH_FILE_FOLDER.'/'.($rec_account['c_index_bg_image']) ?>" style="height:<?= PROFILE_ICON_IMAGE_SIZE ?>px;" />
		<label><input type="checkbox" name="bg_imageDelete" value="YES">削除</label>
<?php
		}
?>
		<input type="file" size=40 name="bg_image" style="button-font-size:small">
	</td>
</tr>
<tr>
	<th nowrap>電子メールアドレス<br>（パスワード忘れ用）</th>
	<td nowrap>
	<p><span style='color: #8080ff;'><?= my_htmlspecialchars($rec_account['c_email']) ?></span></p>
	<input class="text ascii" type="text" name="email" size=50 value="<?= my_htmlspecialchars($_SESSION['edit_myprofile_email']) ?>" style="ime-mode: disabled;">
	</td>
</tr>
<tr>
	<th nowrap>電子メールアドレス<br>（スケジュール送信先）</th>
	<td nowrap>
	<p><span style='color: #8080ff;'><?= my_htmlspecialchars($rec_account['c_email_calendar']) ?></span></p>
	<input class="text ascii" type="text" name="email_calendar" size=50 value="<?= my_htmlspecialchars($_SESSION['edit_myprofile_email_calendar']) ?>" style="ime-mode: disabled;">
	</td>
</tr>
<tr valign="top">
	<th nowrap>コメント<br>（100文字以下）</th>
	<td nowrap>
	<p><span style='color: #8080ff;'><?= ins_br(my_htmlspecialchars($rec_account['c_msg'])) ?></span></p>
	<div class="block_left">
	<textarea id="msg" name="msg" style="width:400px;" rows=5 wrap="soft"><?= my_htmlspecialchars($_SESSION['edit_myprofile_msg']) ?></textarea>
	<span id="msgErrMsg" class="alarm_text"></span>
	</div>
	<div class="block_left">
	<input type="button" value="小" OnClick="textareaBigSmall('msg','小')"><br>
	<input type="button" value="大" OnClick="textareaBigSmall('msg','大')">
	</div>
	</td>
</tr>
<tr>
	<th nowrap>アルバムフォルダ</th>
	<td nowrap>
<?php
	$photo_folder = '';
	if (defined("photo_LIMITED_IMAGES_FOLDER") and photo_LIMITED_IMAGES_FOLDER <> '') {
		$photo_folder = photo_LIMITED_IMAGES_FOLDER.'/';
	}
?>
	<p><span style='color: #8080ff;'><?= $photo_folder ?><?= my_htmlspecialchars($rec_account['c_album_folder']) ?></span></p>
	<?= $photo_folder ?><input class="text" type="text" name="album_folder" size=60 value="<?= my_htmlspecialchars($_SESSION['edit_myprofile_album_folder']) ?>" style="ime-mode: inactive;">
	<? if ($photo_folder = '') { ?>
	<p><span style='color: #00a000;'>ex: D:\xampp\htdocs\<?= MY_SESSION_NAME ?>\z_photo_sample</span></p>
	<p><span style='color: #00a000;'>ex: DOCUMENT_ROOT/<?= MY_SESSION_NAME ?>/z_photo_sample</span></p>
	<? } ?>
	</td>
</tr>
<tr>
	<th nowrap>カレンダーアルバム<br>フォルダ</th>
	<td nowrap>
<?php
	$photo_folder = '';
	if (defined("photo_LIMITED_IMAGES_FOLDER") and photo_LIMITED_IMAGES_FOLDER <> '') {
		$photo_folder = photo_LIMITED_IMAGES_FOLDER.'/';
	}
?>
	<p><span style='color: #8080ff;'><?= $photo_folder ?><?= my_htmlspecialchars($rec_account['c_album_calendar_folder']) ?></span></p>
	<?= $photo_folder ?><input class="text" type="text" name="album_calendar_folder" size=60 value="<?= my_htmlspecialchars($_SESSION['edit_myprofile_album_calendar_folder']) ?>" style="ime-mode: inactive;">
	<? if ($photo_folder = '') { ?>
	<p><span style='color: #00a000;'>ex: D:\xampp\htdocs\<?= MY_SESSION_NAME ?>\z_photo_sample</span></p>
	<p><span style='color: #00a000;'>ex: DOCUMENT_ROOT/<?= MY_SESSION_NAME ?>/z_photo_sample</span></p>
	<? } ?>
	</td>
</tr>
<tr>
	<th nowrap>ページ背景色</th>
	<td nowrap>
	<p><span style='color: #8080ff;'><?= my_htmlspecialchars($rec_account['c_body_background_color']) ?></span></p>
	<input class="text ascii" type="text" name="body_background_color" size=10 value="<?= my_htmlspecialchars($_SESSION['edit_myprofile_body_background_color']) ?>" style="ime-mode: inactive;">&nbsp;&nbsp;<span style='color: #00a000;'>(ex.#F0F0FF)</span>
	<a href="../__common__/color-chart.php" target="_blank" style="margin-left:14px;">カラーチャート</a>
	</td>
</tr>
<tr valign="top">
	<th nowrap>氏名（フルネーム）</th>
	<td nowrap>
	<p><span style='color: #8080ff;'><?= my_htmlspecialchars($rec_account['c_fullname']) ?></span></p>
	<input class="text fullwidth-kana" type="text" name="fullname" value="<?= my_htmlspecialchars($_SESSION['edit_myprofile_fullname']) ?>" size=60 style="ime-mode: active;">
	</td>
</tr>
<tr valign="top">
	<th nowrap>〒番号</th>
	<td nowrap>
	<p><span style='color: #8080ff;'><?= my_htmlspecialchars($rec_account['c_zip1']) ?>-<?= my_htmlspecialchars($rec_account['c_zip2']) ?></span></p>
	<input class="text ascii" type="text" name="zip1" value="<?= my_htmlspecialchars($_SESSION['edit_myprofile_zip1']) ?>" size=5 style="ime-mode: disabled;">-
	<input class="text ascii" type="text" name="zip2" value="<?= my_htmlspecialchars($_SESSION['edit_myprofile_zip2']) ?>" size=10 style="ime-mode: disabled;">
	</td>
</tr>
<tr valign="top">
	<th nowrap>住所（Google<br>経路検索起点）</th>
	<td nowrap>
	<p><span style='color: #8080ff;'><?= my_htmlspecialchars($rec_account['c_home_address']) ?></span></p>
	<input class="text fullwidth-kana" type="text" name="home_address" value="<?= my_htmlspecialchars($_SESSION['edit_myprofile_home_address']) ?>" size=60 style="ime-mode: active;">
	</td>
</tr>
<tr valign="top">
	<th nowrap>住所2（マンション名など）<br>（住所録葉書差出人用）</th>
	<td nowrap>
	<p><span style='color: #8080ff;'><?= my_htmlspecialchars($rec_account['c_home_address2']) ?></span></p>
	<input class="text fullwidth-kana" type="text" name="home_address2" value="<?= my_htmlspecialchars($_SESSION['edit_myprofile_home_address2']) ?>" size=60 style="ime-mode: active;">
	</td>
</tr>
<tr valign="top">
	<th nowrap>最寄駅（乗換検索乗車駅）</th>
	<td nowrap>
	<p><span style='color: #8080ff;'><?= my_htmlspecialchars($rec_account['c_home_station']) ?></span></p>
	<input class="text fullwidth-kana" type="text" name="home_station" value="<?= my_htmlspecialchars($_SESSION['edit_myprofile_home_station']) ?>" size=30 style="ime-mode: active;">
	</td>
</tr>
<tr valign="top">
	<th nowrap>カレンダー</th>
	<td nowrap>
	<label><input type="checkbox" name="cal_sbj_use" value="NO"<?php if ($_SESSION['edit_myprofile_cal_sbj_use'] == 'NO') echo ' checked' ?>>件名を使わない（スケジュール本文のみを使う）</label>
	</td>
</tr>
<tr>
	<th nowrap>トップメニュー色</th>
	<td nowrap>
		<table cellspacing=0 class="inner_table">
		<tr>
		<td style="vertical-align:middle">標準：<br></td>
		<td nowrap>
		文字色(規定値=<?= PAGE_NAVI_LINK_COLOR ?>)<input class="text ascii" type="text" name="page_navi_link_color" style="width: 60px;" value="<?= my_htmlspecialchars($_SESSION['edit_page_navi_link_color']) ?>" style="ime-mode: inactive;">
	</td><td nowrap>
		背景色(規定値=<?= PAGE_NAVI_LINK_BG ?>)<input class="text ascii" type="text" name="page_navi_link_bg" style="width: 60px;" value="<?= my_htmlspecialchars($_SESSION['edit_page_navi_link_bg']) ?>" style="ime-mode: inactive;">
		</td>
		</td><td style="vertical-align:middle" rowspan=4>
			<a href="../__common__/color-chart.php" target="_blank" style="margin-left:14px;">カラーチャート</a>
		</tr>
		<tr>
		<td style="vertical-align:middle">カレント：</td>
		<td nowrap>
		文字色(規定値=<?= PAGE_NAVI_CURRENT_COLOR ?>)<input class="text ascii" type="text" name="page_navi_current_color" style="width: 60px;" value="<?= my_htmlspecialchars($_SESSION['edit_page_navi_current_color']) ?>" style="ime-mode: inactive;">
	</td><td nowrap>
		背景色(規定値=<?= PAGE_NAVI_CURRENT_BG ?>)<input class="text ascii" type="text" name="page_navi_current_bg" style="width: 60px;" value="<?= my_htmlspecialchars($_SESSION['edit_page_navi_current_bg']) ?>" style="ime-mode: inactive;">
		</td>
		</tr>
		<tr>
		<td style="vertical-align:middle">hover：</td>
		<td nowrap>
		文字色(規定値=<?= PAGE_NAVI_HOVER_COLOR ?>)<input class="text ascii" type="text" name="page_navi_hover_color" style="width: 60px;" value="<?= my_htmlspecialchars($_SESSION['edit_page_navi_hover_color']) ?>" style="ime-mode: inactive;">
	</td><td nowrap>
		背景色(規定値=<?= PAGE_NAVI_HOVER_BG ?>)<input class="text ascii" type="text" name="page_navi_hover_bg" style="width: 60px;" value="<?= my_htmlspecialchars($_SESSION['edit_page_navi_hover_bg']) ?>" style="ime-mode: inactive;">
		</td>
		</tr>
		<tr>
		<td style="vertical-align:middle">active：</td>
		<td nowrap>
		文字色(規定値=<?= PAGE_NAVI_ACTIVE_COLOR ?>)<input class="text ascii" type="text" name="page_navi_active_color" style="width: 60px;" value="<?= my_htmlspecialchars($_SESSION['edit_page_navi_active_color']) ?>" style="ime-mode: inactive;">
	</td><td nowrap>
		背景色(規定値=<?= PAGE_NAVI_ACTIVE_BG ?>)<input class="text ascii" type="text" name="page_navi_active_bg" style="width: 60px;" value="<?= my_htmlspecialchars($_SESSION['edit_page_navi_active_bg']) ?>" style="ime-mode: inactive;">
		</td>
		</tr>
		</table>
	</td>
</tr>
<tr valign="top">
	<th nowrap style="background-color:#ffff80;">現在のログインパスワード</th>
	<td nowrap style="background-color:#ffff80;"><span style="color:red;">（必須）</span>
	<input type="text" name="dummy" value="" style="display:none;">
	<input class="password" type="password" name="password_now" value="<?= $_COOKIE['edit_myprofile_login_pass'] ?>" size=30>
	</td>
</tr>
</table>
	<span style="color:red;">修正のためには、ログインパスワードが必要です。</span><br>
	<input class="input_form_button" id="submit" type="submit" name="修正" value="修正">
	<input class="input_form_button" type="reset" name="リセット" value="リセット">
</form>
	<p class="error_msg"><?= $error_msg ?><p>
</div>
<?php
	return(0);
}
?>
<?php
function post_done_proc() {
	$handle = form_str_adjust_strip_tags($_POST['handle']);
	$email = form_str_adjust_strip_tags($_POST['email']);
	$email_calendar = form_str_adjust_strip_tags($_POST['email_calendar']);
	$album_folder = form_str_adjust_strip_tags($_POST['album_folder']);
	$album_calendar_folder = form_str_adjust_strip_tags($_POST['album_calendar_folder']);
	$body_background_color = form_str_adjust_strip_tags($_POST['body_background_color']);
	$msg = form_str_adjust_strip_tags($_POST['msg']);
	$fullname = form_str_adjust_strip_tags($_POST['fullname']);
	$zip1 = form_str_adjust_strip_tags($_POST['zip1']);
	$zip2 = form_str_adjust_strip_tags($_POST['zip2']);
	$home_address = form_str_adjust_strip_tags($_POST['home_address']);
	$home_address2 = form_str_adjust_strip_tags($_POST['home_address2']);
	$home_station = form_str_adjust_strip_tags($_POST['home_station']);
	$cal_sbj_use = $_POST['cal_sbj_use'];

	$_SESSION['edit_myprofile_handle'] = $handle;
	$_SESSION['edit_myprofile_email'] = $email;
	$_SESSION['edit_myprofile_email_calendar'] = $email_calendar;
	$_SESSION['edit_myprofile_album_folder'] = $album_folder;
	$_SESSION['edit_myprofile_album_calendar_folder'] = $album_calendar_folder;
	$_SESSION['edit_myprofile_body_background_color'] = $body_background_color;
	$_SESSION['edit_myprofile_msg'] = $msg;
	$_SESSION['edit_myprofile_fullname'] = $fullname;
	$_SESSION['edit_myprofile_zip1'] = $zip1;
	$_SESSION['edit_myprofile_zip2'] = $zip2;
	$_SESSION['edit_myprofile_home_address'] = $home_address;
	$_SESSION['edit_myprofile_home_address2'] = $home_address2;
	$_SESSION['edit_myprofile_home_station'] = $home_station;
	$_SESSION['edit_myprofile_cal_sbj_use'] = $cal_sbj_use;

	$_SESSION['edit_page_navi_link_color'] = $_POST['page_navi_link_color'];
	$_SESSION['edit_page_navi_link_bg'] = $_POST['page_navi_link_bg'];
	$_SESSION['edit_page_navi_current_color'] = $_POST['page_navi_current_color'];
	$_SESSION['edit_page_navi_current_bg'] = $_POST['page_navi_current_bg'];
	$_SESSION['edit_page_navi_hover_color'] = $_POST['page_navi_hover_color'];
	$_SESSION['edit_page_navi_hover_bg'] = $_POST['page_navi_hover_bg'];
	$_SESSION['edit_page_navi_active_color'] = $_POST['page_navi_active_color'];
	$_SESSION['edit_page_navi_active_bg'] = $_POST['page_navi_active_bg'];

	if ($_POST['password_now'] == '') {
		return "現在のログインパスワードを入れてください。";
	}
	$con = my_mysqli_connect(_DB_ACCOUNT_SCHEMA);
	$sql = "select * from m_account where id_account = '" . $_SESSION['login_id'] . "'";
	$rs_account = my_mysqli_query($sql);
	$rec_account = mysqli_fetch_array($rs_account);
	if ($rec_account['c_password'] <> $_POST['password_now']) {
		return "現在のログインパスワードが間違っているため、修正できません。";
	}
	setcookie("edit_myprofile_login_pass", $_POST['password_now'], time() + EDIT_MYPROFILE_LOGIN_PASS_EXPIRE, MY_SESSION_PATH);
	if (($ret = ac_chk_handle($handle, $_SESSION['login_id'])) <> "") return ($ret);
	if (($ret = ac_chk_email($email)) <> "") return ($ret);
	if (($ret = ac_chk_email($email_calendar)) <> "") return ($ret);
	if (($ret = ac_chk_msg($msg)) <> "") return ($ret);

	$con = my_mysqli_connect(_DB_ACCOUNT_SCHEMA);
	$sql = "update m_account";
	$sql .= " set c_handle = '". str_for_mysql($handle) . "'";
	$sql .= ", c_email = '". trim(str_for_mysql($email)) . "'";
	$sql .= ", c_email_calendar = '". trim(str_for_mysql($email_calendar)) . "'";
	$sql .= ", c_album_folder = '". trim(str_for_mysql($album_folder)) . "'";
	$sql .= ", c_album_calendar_folder = '". trim(str_for_mysql($album_calendar_folder)) . "'";
	$sql .= ", c_body_background_color = '". trim(str_for_mysql($body_background_color)) . "'";
	$sql .= ", c_msg = '". str_for_mysql($msg) . "'";
	$sql .= ", c_fullname = '". trim(str_for_mysql($fullname)) . "'";
	$sql .= ", c_zip1 = '". trim(str_for_mysql($zip1)) . "'";
	$sql .= ", c_zip2 = '". trim(str_for_mysql($zip2)) . "'";
	$sql .= ", c_home_address = '". trim(str_for_mysql($home_address)) . "'";
	$sql .= ", c_home_address2 = '". trim(str_for_mysql($home_address2)) . "'";
	$sql .= ", c_home_station = '". trim(str_for_mysql($home_station)) . "'";
	$sql .= ", c_cal_sbj_use = '". trim(str_for_mysql($cal_sbj_use)) . "'";
	$sql .= ", c_page_navi_link_color = '". post_to_mysql('page_navi_link_color') . "'";
	$sql .= ", c_page_navi_link_bg = '". post_to_mysql('page_navi_link_bg') . "'";
	$sql .= ", c_page_navi_current_color = '". post_to_mysql('page_navi_current_color') . "'";
	$sql .= ", c_page_navi_current_bg = '". post_to_mysql('page_navi_current_bg') . "'";
	$sql .= ", c_page_navi_hover_color = '". post_to_mysql('page_navi_hover_color') . "'";
	$sql .= ", c_page_navi_hover_bg = '". post_to_mysql('page_navi_hover_bg') . "'";
	$sql .= ", c_page_navi_active_color = '". post_to_mysql('page_navi_active_color') . "'";
	$sql .= ", c_page_navi_active_bg = '". post_to_mysql('page_navi_active_bg') . "'";
	$sql .= ", c_updatetime = '". date("Y/m/d H:i:s") . "'";

	$attachFile = image_file_upload("image", ATTACH_FILE_FOLDER, $_SESSION['login_id']);
	if ($attachFile <> '') {
		$sql .= ", c_profile_image = '" . $attachFile . "'";
	} else if ($_POST['imageDelete'] == 'YES') {
		$sql .= ", c_profile_image = ''";
	}
	$attachFile = bg_image_file_upload("bg_image", ATTACH_FILE_FOLDER, $_SESSION['login_id']);
	if ($attachFile <> '') {
		$sql .= ", c_index_bg_image = '" . $attachFile . "'";
		$_SESSION['login_friends_body_background_img_'.$_SESSION['login_id']] = $attachFile;
	} else if ($_POST['bg_imageDelete'] == 'YES') {;
		$sql .= ", c_index_bg_image = ''";
		$_SESSION['login_friends_body_background_img_'.$_SESSION['login_id']] = '';
	}
	$sql .= " where id_account = '" . $_SESSION['login_id'] . "'";
	$ret = my_mysqli_query($sql);
	if (!$ret) {
		mysqli_close($con);
		return "アカウント情報修正に失敗しました。";
	}
	mysqli_close($con);

	$_SESSION['login_handle'] = $handle;
	$_SESSION['login_friends_handle_'.$_SESSION['login_id']] = $handle;
	$_SESSION['login_friends_album_folder_'.$_SESSION['login_id']] = get_album_folder($album_folder);
	$_SESSION['login_friends_album_calendar_folder_'.$_SESSION['login_id']] = get_album_folder($album_calendar_folder);
	$_SESSION['login_friends_body_background_color_'.$_SESSION['login_id']] = $body_background_color;
	$_SESSION['login_friends_home_address_'.$_SESSION['login_id']] = $home_address;
	$_SESSION['login_friends_home_station_'.$_SESSION['login_id']] = $home_station;
	$_SESSION['login_friends_cal_sbj_use_'.$_SESSION['login_id']] = $cal_sbj_use;

	if ($_POST['page_navi_link_color'].'' <> '') {
		$_SESSION['page_navi_link_color'] = $_POST['page_navi_link_color'];
	} else {
		$_SESSION['page_navi_link_color'] = PAGE_NAVI_LINK_COLOR;
	}
	if ($_POST['page_navi_link_bg'].'' <> '') {
		$_SESSION['page_navi_link_bg'] = $_POST['page_navi_link_bg'];
	} else {
		$_SESSION['page_navi_link_bg'] = PAGE_NAVI_LINK_BG;
	}
	if ($_POST['page_navi_current_color'].'' <> '') {
		$_SESSION['page_navi_current_color'] = $_POST['page_navi_current_color'];
	} else {
		$_SESSION['page_navi_current_color'] = PAGE_NAVI_CURRENT_COLOR;
	}
	if ($_POST['page_navi_current_bg'].'' <> '') {
		$_SESSION['page_navi_current_bg'] = $_POST['page_navi_current_bg'];
	} else {
		$_SESSION['page_navi_current_bg'] = PAGE_NAVI_CURRENT_BG;
	}
	if ($_POST['page_navi_hover_color'].'' <> '') {
		$_SESSION['page_navi_hover_color'] = $_POST['page_navi_hover_color'];
	} else {
		$_SESSION['page_navi_hover_color'] = PAGE_NAVI_HOVER_COLOR;
	}
	if ($_POST['page_navi_hover_bg'].'' <> '') {
		$_SESSION['page_navi_hover_bg'] = $_POST['page_navi_hover_bg'];
	} else {
		$_SESSION['page_navi_hover_bg'] = PAGE_NAVI_HOVER_BG;
	}
	if ($_POST['page_navi_active_color'].'' <> '') {
		$_SESSION['page_navi_active_color'] = $_POST['page_navi_active_color'];
	} else {
		$_SESSION['page_navi_active_color'] = PAGE_NAVI_ACTIVE_COLOR;
	}
	if ($_POST['page_navi_active_bg'].'' <> '') {
		$_SESSION['page_navi_active_bg'] = $_POST['page_navi_active_bg'];
	} else {
		$_SESSION['page_navi_active_bg'] = PAGE_NAVI_ACTIVE_BG;
	}
	redirect("myprofile.php");
}
function image_file_upload($varName, $storeFolder, $login_id) {
	$fileName = $_FILES[$varName]['name'];
	$fileSize = $_FILES[$varName]['size'];
	$fileType = $_FILES[$varName]['type'];		// MIME タイプ
	$fileError = $_FILES[$varName]['error'];
	if ($fileSize > 0 and is_img_filename($fileName)) {
		$tmpfilename = $_FILES[$varName]['tmp_name'];
		if (is_uploaded_file($tmpfilename)) {
			$uploadFile = 'p-'.$login_id.'-'.$fileName;
			$uploadPath = $storeFolder.$uploadFile;
			if (!move_uploaded_file($tmpfilename , myfile_ENCODE($uploadPath))) {
				error_exit("ファイルアップロード失敗：".$fileName);
			}
			if (photo_JPEG_RESIZE == 'YES') {
				$resizeFile = $login_id.'-'.$fileName;
				$storeFolder_REAL = realpath($storeFolder);
				resize_jpeg_utf8($storeFolder_REAL.DIRECTORY_SEPARATOR.$uploadFile, PROFILE_ICON_IMAGE_SIZE, $storeFolder_REAL.DIRECTORY_SEPARATOR.$resizeFile);
				return($resizeFile);
			} else {
				return($uploadFile);
			}
		}
		return('');
	} else {
		return('');
	}
}
function bg_image_file_upload($varName, $storeFolder, $login_id) {
	$fileName = $_FILES[$varName]['name'];
	$fileSize = $_FILES[$varName]['size'];
	$fileType = $_FILES[$varName]['type'];		// MIME タイプ
	$fileError = $_FILES[$varName]['error'];
	if ($fileSize > 0 and is_img_filename($fileName)) {
		$tmpfilename = $_FILES[$varName]['tmp_name'];
		if (is_uploaded_file($tmpfilename)) {
			$uploadFile = 'bg-'.$login_id.'-'.$fileName;
			$uploadPath = $storeFolder.$uploadFile;
			if (!move_uploaded_file($tmpfilename , myfile_ENCODE($uploadPath))) {
				error_exit("ファイルアップロード失敗：".$fileName);
			}
			return($uploadFile);
		}
		return('');
	} else {
		return('');
	}
}
function resize_jpeg_utf8($src, $size, $tgt) {		// UTF-8
	exec('i_view32 "'.myfile_ENCODE($src).'" /resize=('.$size.','.$size.') /silent /convert="'.myfile_ENCODE($tgt).'"', $o, $ret);
	return $ret;
}
?>
