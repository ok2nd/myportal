<?php
	require("__include-common.php");
	require("__include-login.php");

	if (isset($_POST['ログイン'])) {
		post_done_proc();
	} else {
		html_header(HTML_TITLE, '', '', ' onload="document.form0.account.focus()"');
		page_header(False);
		login_form();
		page_footer();
		html_footer();
	}
	exit();
?>
<?php
function login_form() {
?>
<div id="login_body">
<div id="login_main">
<div class="input_form">
<form name="form0" method="POST" action="<?= $_SERVER['SCRIPT_NAME'] ?>">
<table>
	<tr>
		<td>アカウント名：</td>
		<td><input class="text" type="text" name="account" value="<?= $_COOKIE['login_account'] ?>" style="width:100px;"></td>
	</tr>
	<tr>
		<td>パスワード：</td>
		<td><input class="password" type="password" name="password" style="width:100px;"></td>
	</tr>
</table>
	<input class="input_form_button" type="submit" name="ログイン" value="ログイン">
</form>
<?php if ($_SESSION['logincheck'] <> "OK") { ?>
	<p class="err_msg"><?= $_SESSION['logincheck'] ?></p>
<?php } ?>
</div>
</div>
<div id="login_side">
	<ul>
<?php	if (USER_SELF_NEW_ACCOUNT <> 'NO') { ?>
	<li><a href="newaccount.php">ユーザー登録</a></li>
<?php	} ?>
<?php	if (_FORGOT_PASS_USE) { ?>
	<li><a href="forgot-pass.php">パスワード忘れ</a></li>
<?php	} ?>
	</ul>
</div>
</div>
<?php
	return;
}
function post_done_proc() {

	$account = Trim($_POST['account']);
	$password = my_hash(Trim($_POST['password']));

	setcookie("login_account_okuser_id", "", time() + LOGIN_COOKIE_EXPIRE, MY_SESSION_PATH);		// クリア
	setcookie("login_account_okuser_pass", "", time() + LOGIN_COOKIE_EXPIRE, MY_SESSION_PATH);		// クリア
	setcookie("login_account", $account, time() + LOGIN_COOKIE_EXPIRE, MY_SESSION_PATH);

	$_SESSION['logincheck'] = _account_login("0", $account, $password);
	if ($_SESSION['logincheck'] <> "OK") {
		redirect ($_SERVER['SCRIPT_NAME']);
	}

	setcookie("login_account_okuser_id", $_SESSION['login_id'], time() + LOGIN_COOKIE_EXPIRE, MY_SESSION_PATH);
	setcookie("login_account_okuser_pass", $password, time() + LOGIN_COOKIE_EXPIRE, MY_SESSION_PATH);

	if ($_SESSION['url'] == "" or $_SESSION['url'] == "login.php") {
		redirect("../index");
	} else {
		redirect($_SESSION['url']);
	}
	return;
}
?>
