<?php
	require("__include-common.php");

	html_header('Fatal Error');
	page_header(False);
?>
	<br><br><br>
	<p><?= $_GET['msg']?></p>
	<br><br><br>
	<p><a href="../account/login.php">ログイン</a></p>
<?php
	page_footer();
	html_footer();
	exit();
?>
