<?php
	require("__include-common.php");

	if (isset($_POST['ログアウト'])) {
		logout_proc();
	} elseif (isset($_POST['ID管理ログアウト'])) {
		logout_im_proc();
	} else {
		html_header(HTML_TITLE);
		page_header(False);
		input_form();
		page_footer();
		html_footer();
	}
	exit();
?>
<?php
function input_form() {
?>
<div id="login_body">
<div id="logout_main">
<div id="login_form">
<form method="POST" action="<?= $_SERVER['SCRIPT_NAME'] ?>">
	<input class="input_form_button" type="submit" name="ログアウト" value="ログアウト">
<?php	if ($_SESSION['_id_mgr_logincheck'] == "OK") { ?>
	<br><br><input class="input_form_button" type="submit" name="ID管理ログアウト" value="ID管理のみログアウト">
<?php	} ?>
</form>
</div>
</div>
<div id="login_side">
	<ul>
<?php	if (USER_SELF_NEW_ACCOUNT <> 'NO') { ?>
	<li><a href="newaccount.php">ユーザー登録</a></li>
<?php	} ?>
<?php	if (_FORGOT_PASS_USE) { ?>
	<li><a href="forgot-pass.php">パスワード忘れ</a></li>
<?php	} ?>
	<li><a href="myprofile.php">My設定</a></li>
	</ul>
</div>
<?php if ($_SESSION['システム管理者'] == "YES") {	?>
<div id="login_side">
	<ul>
	<li><a href="/xampp/index.php" target="_blank">XAMPP for Windows</a></li>
	<li><a href="/xampp/phpinfo.php" target="_blank">phpinfo</a></li>
	<li><a href="/phpmyadmin/" target="_blank">phpMyAdmin</a></li>
	<li></li>
	<li><a href="list-loginlog.php">MyHome Portal ログイン履歴表示</a></li>
	<li></li>
	<li><a href="../setup-sample.php">サンプルDB（再）セットアップ</a></li>
	<li></li>
	<li><a href='../index/' target='_blank' onClick='window.open("../index/","","toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes,width=840,height=500");return(false)'>マニュアル用Windowオープン</a>
	</li>
	<li></li>
	<?php	if (file_exists(_MY_DEFINE_COMMON)) { ?>
		<li><a href="../__common__/sample_mode_chg.php">サンプルモードに切替</a></li>
	<?php	} elseif (file_exists(_MY_DEFINE_COMMON_SAVE)) { ?>
		<li><a href="../__common__/sample_mode_chg.php">実運用モードに切替</a></li>
	<?php	} ?>
	</ul>
</div>
<?php }							?>
</div>
<?php
	return;
}
?>
<?php
function logout_proc() {
	$_SESSION = array();
	if (isset($_COOKIE[session_name()])) {
		setcookie(session_name(), '', time() - 42000, MY_SESSION_PATH);
	}
	session_destroy();

	setcookie("login_account_okuser_id", "", time() + LOGIN_COOKIE_EXPIRE, MY_SESSION_PATH);		// クリア
	setcookie("login_account_okuser_pass", "", time() + LOGIN_COOKIE_EXPIRE, MY_SESSION_PATH);		// クリア
	// ************* id_manager用 *************
	setcookie("login_account_id_mgr_pass", "", time() + IDMGR_COOKIE_EXPIRE, MY_SESSION_PATH);		// クリア

	redirect("../");
	return;
}
function logout_im_proc() {
	$_SESSION['_id_mgr_logincheck'] = '';
	$_SESSION['url_id_manager'] = '';

	setcookie("login_account_id_mgr_pass", "", time() + IDMGR_COOKIE_EXPIRE, MY_SESSION_PATH);		// クリア

	redirect("../");
	return;
}
?>
