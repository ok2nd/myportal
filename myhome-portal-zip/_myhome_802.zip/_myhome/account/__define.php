<?php
	if (defined("HTML_TITLE_account")) {
		define("HTML_TITLE", HTML_TITLE_account);
	} else {
		define("HTML_TITLE", "MyHome 管理");
	}
	define("SESSION_PREFIX", "account");

	if (defined("_DB_SCHEMA_account")) {
		define("_DB_SCHEMA", _DB_SCHEMA_account);
	} else {
		define("_DB_SCHEMA", "_db_account");
	}
	if (defined("_NEWACOUNT_KIYAKU_account")) {
		define("_NEWACOUNT_KIYAKU", _NEWACOUNT_KIYAKU_account);
	} else {
		define("_NEWACOUNT_KIYAKU", "ハンドル名とコメントは公開されます。
本システム利用による何らかの不利益に一切の責任を負いません。");
	}
	define("PAGE_LINE_SELECT", "5,10,20,50,100,1000");	//頁内に表示する行数
	define("PAGE_LINE_DEFAULT", "10");			//頁内に表示する行数（デフォルト）

	if (defined("LOGINLOG_MAXREC_account")) {		//list-loginlog.phpレコード表示件数
		define("LOGINLOG_MAXREC", LOGINLOG_MAXREC_account);
	} else {
		define("LOGINLOG_MAXREC", 100);
	}
	if (defined("EDIT_PUBLIC_PAGE_account")) {		//公開先メンバ修正ページ
		define("EDIT_PUBLIC_PAGE", EDIT_PUBLIC_PAGE_account);
	} else {
		define("EDIT_PUBLIC_PAGE", "");			//"":全ユーザー一覧から選択式、"IDINP":ID入力方式
	}
	if (defined("EDIT_FRIENDS_PAGE_account")) {		//My参照メンバ修正ページ
		define("EDIT_FRIENDS_PAGE", EDIT_FRIENDS_PAGE_account);
	} else {
		define("EDIT_FRIENDS_PAGE", "");		//"":全ユーザー一覧から選択式、"IDINP":ID入力方式
	}
	if (defined("NEWACCOUNT_CAPTCHASTR_USE_account")) {
		define("NEWACCOUNT_CAPTCHASTR_USE", NEWACCOUNT_CAPTCHASTR_USE_account);
	} else {
		define("NEWACCOUNT_CAPTCHASTR_USE", "YES");	//"YES":アカウント登録で、CAPTCHA(認証用絵文字コード)使用
	}
	if (defined("ATTACH_FILE_FOLDER_account")) {
		define("ATTACH_FILE_FOLDER", ATTACH_FILE_FOLDER_account);
	} else {
		define("ATTACH_FILE_FOLDER", "../_attach/account/");
	}
	if (!defined("ACCOUNT_ID_NAME_MIN_LENGTH")) {
		define("ACCOUNT_ID_NAME_MIN_LENGTH", 3);
	}
	if (!defined("ACCOUNT_PASSWORD_MIN_LENGTH")) {
		define("ACCOUNT_PASSWORD_MIN_LENGTH", 3);
	}
?>
