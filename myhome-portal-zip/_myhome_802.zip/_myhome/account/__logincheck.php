<?php
require(_MYHOME_REF_PATH."/account/__include-login.php");

if (LOGINCHECK_SESSION_URL <> "NO") {		// "NO"の場合、URLをSESSION変数にセットしない。
	if ($_SERVER['QUERY_STRING'] <> "") {
		$_SESSION['url'] = $_SERVER['SCRIPT_NAME'] . "?" . $_SERVER['QUERY_STRING'];
	} else {
		$_SESSION['url'] = $_SERVER['SCRIPT_NAME'];
	}
}
if ($_SESSION['logincheck'].'' <> "OK") {
	if ($_COOKIE['login_account_okuser_id'] <> "" and $_COOKIE['login_account_okuser_pass'] <> "") {
		$account_id = $_COOKIE['login_account_okuser_id'];
		$password = $_COOKIE['login_account_okuser_pass'];
		$_SESSION['logincheck'] = _account_login($account_id, "", $password);
		if ($_SESSION['logincheck'] <> "OK") {
			redirect(_MYHOME_REF_PATH."/account/login.php");
		}
	} else {
		redirect(_MYHOME_REF_PATH."/account/login.php");
	}
}
if ($_SESSION['login_id'] == "" || $_SESSION['current_id'] == "") {
	redirect(_MYHOME_REF_PATH."/account/login.php");
}
// カレントユーザに対するログインユーザのアクセス権チェック
	$_SESSION['current_permit_type'] = check_permit_id($_SESSION['login_id'], $_SESSION['current_id']);
	if ($_SESSION['current_permit_type'] == "") {
		//error_exit("不正アクセス：読み取り権限がありません。", True);
		redirect(_MYHOME_REF_PATH."/account/fatal-error.php?msg=".urlencode("不正アクセス：読み取り権限がありません。"));
	}
?>
<?php
function check_permit_id($login_id, $target_id) {
	if ($login_id."" <> "" && $login_id == $target_id) {
		return "w";
	}
	$con_account = my_mysqli_connect(_DB_ACCOUNT_SCHEMA, False);
	$sql = "select * from m_public where id_account = '" . $target_id . "'";
	$sql .= " and id_permit_id = '" . $login_id . "' and c_delete = 0";
	$rs_public = my_mysqli_query($sql, '', $con_account);
	$row_public = mysqli_num_rows($rs_public);
	if ($row_public > 0) {
		$rec_public = mysqli_fetch_array($rs_public);
		$permit = $rec_public['id_permit_type'];
		// 30:参照許可
		// 60:書込許可
	} else {
		$permit = 0;
	}
	mysqli_close($con_account);
	if ($permit == 60) {
		return "w";
	} elseif ($permit == 30) {
		return "r";
	} else {
		return "";
	}
}
?>
