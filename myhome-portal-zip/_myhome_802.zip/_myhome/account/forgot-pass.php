<?php
	require("__include-common.php");
	require("__include-login.php");
	require("__include-account-check.php");
	if (!_FORGOT_PASS_USE) {
		exit();
	}
	html_header(HTML_TITLE, "_add_newaccount_header.php");
	page_header(False);
	input_form();
	if ($_POST) {
		check_post_account($_POST['login_id']);
		if (($error = post_done_proc()) == '') {
			echo '<p class="noramal_msg">パスワードを送信しました。</p>';
		} else {
			echo '<p class="error_msg">' . $error . '</p>';
		}
	}
	page_footer();
	html_footer();
	exit();
?>
<?php
function input_form() {
?>
<div class="input_form">
<h3>パスワード忘れ</h3>
<form name="form0" method="POST" action="<?= $_SERVER['SCRIPT_NAME'] ?>">
	<input type="hidden" name="login_id" value="<?= $_SESSION['login_id'] ?>">
	<input type="hidden" name="current_id" value="<?= $_SESSION['current_id'] ?>">
<table>
<tr>
	<td nowrap>アカウント名：</td>
	<td nowrap>
	<input class="text" type="text" name="account" size=20 value="<?= $_POST['account'] ?>" style="ime-mode: disabled;">
	</td>
</tr>
<tr>
	<td nowrap>電子メールアドレス：</td>
	<td nowrap>
	<input class="text" type="text" name="email" size=40 value="<?= $_POST['email'] ?>" style="ime-mode: disabled;"><br>
	事前に登録されている電子メールアドレスと一致した場合のみ、送信されます。
	</td>
</tr>
</table>
	<input class="input_form_button" type="submit" name="送信" value="送信">
	<input class="input_form_button" type="button" value="キャンセル" onClick="location.href='index.php'">
</form>
</div>
<?php
	return(0);
}
function post_done_proc() {
	$account = trim($_POST['account']);
	$send_email = trim($_POST['email']);
	if ($account == '') {
		return 'アカウントを入れてください。';
	}
	if ($send_email == '') {
		return '電子メールアドレスを入れてください。';
	}
	$con = my_mysqli_connect(_DB_ACCOUNT_SCHEMA);
	$sql = "SELECT * FROM m_account WHERE c_account = '" . $account . "'";
	$rs_account = my_mysqli_query($sql);
	$row = mysqli_num_rows($rs_account);
	if ($row == 0) {
		return 'アカウントがみつかりません。';
	}
	$rec_account = mysqli_fetch_array($rs_account);
	if ($rec_account['c_delete'] == 999) {
		return '削除済みのアカウントです。';
	}
	if ($rec_account['c_email'] == '') {
		return '電子メールアドレスが事前登録されていませんので、パスワードの送信ができません。';
	}
	if (trim($rec_account[c_email]) <> $send_email) {
		return '登録されている電子メールアドレスと違います。';
	}

	$subject = 'MyHome Portal: 管理者からのお知らせ';
	$header_from = _SENDMAIL_EMAIL_NAME . ' <'._SENDMAIL_EMAIL_ADDR.'>';
	$to = $rec_account['c_email'];
	$body = 'パスワード：';
	$body .= $rec_account['c_password'];
	mysqli_close($con);

	$ret = my_send_mail(_SENDMAIL_EMAIL_ADDR, $header_from, $to, $subject, $body, _SENDMAIL_HOST, _SENDMAIL_PORT, _SENDMAIL_AUTH_USE, _SENDMAIL_EMAIL_USER, _SENDMAIL_EMAIL_PASS);
	if ($ret) {
		return '';
	} else {
		return 'メール送信でエラーが発生しました。';
	}
}
?>
