<?php
	require("__include-common.php");
	require("../account/__logincheck.php");
	require("../__common__/include-common-mp-list.php");

	$mp_list_arg = array();
	$mp_list_arg['sql_for_edit'] = "SELECT m_account.id_account, m_account.c_handle,";
	$mp_list_arg['sql_for_edit'] .= " T3.id_member_id AS id_member_id,";
	$mp_list_arg['sql_for_edit'] .= " T3.c_displayOrder AS c_displayOrder,";
	$mp_list_arg['sql_for_edit'] .= " LEFT(r_permit_type_1.c_permit_type,2) AS public_permit_from,";
	$mp_list_arg['sql_for_edit'] .= " LEFT(r_permit_type_2.c_permit_type,2) AS public_permit_to";
	$mp_list_arg['sql_for_edit'] .= " FROM (SELECT * FROM m_public WHERE";
	$mp_list_arg['sql_for_edit'] .= " (m_public.id_account = '".$_SESSION['login_id']."') AND m_public.c_delete = 0) T2";
	$mp_list_arg['sql_for_edit'] .= " LEFT OUTER JOIN";
	$mp_list_arg['sql_for_edit'] .= " r_permit_type r_permit_type_2";
	$mp_list_arg['sql_for_edit'] .= " ON T2.id_permit_type = r_permit_type_2.id_permit_type";
	$mp_list_arg['sql_for_edit'] .= " RIGHT OUTER JOIN m_account";
	$mp_list_arg['sql_for_edit'] .= " LEFT OUTER JOIN";
	$mp_list_arg['sql_for_edit'] .= " (SELECT * FROM m_public WHERE";
	$mp_list_arg['sql_for_edit'] .= " (m_public.id_permit_id = '".$_SESSION['login_id']."') AND m_public.c_delete = 0) T1";
	$mp_list_arg['sql_for_edit'] .= " LEFT OUTER JOIN";
	$mp_list_arg['sql_for_edit'] .= " r_permit_type r_permit_type_1";
	$mp_list_arg['sql_for_edit'] .= " ON T1.id_permit_type = r_permit_type_1.id_permit_type";
	$mp_list_arg['sql_for_edit'] .= " ON m_account.id_account = T1.id_account";
	$mp_list_arg['sql_for_edit'] .= " ON T2.id_permit_id = m_account.id_account";
	$mp_list_arg['sql_for_edit'] .= " LEFT OUTER JOIN";
	$mp_list_arg['sql_for_edit'] .= " (SELECT * FROM v_friends WHERE";
	$mp_list_arg['sql_for_edit'] .= " (v_friends.id_account = '".$_SESSION['login_id']."') AND v_friends.c_delete = 0) T3";
	$mp_list_arg['sql_for_edit'] .= " LEFT OUTER JOIN";
	$mp_list_arg['sql_for_edit'] .= " r_permit_type r_permit_type_3";
	$mp_list_arg['sql_for_edit'] .= " ON T3.id_permit_type = r_permit_type_3.id_permit_type";
	$mp_list_arg['sql_for_edit'] .= " ON m_account.id_account = T3.id_member_id";
	$mp_list_arg['sql_for_edit'] .= " WHERE (m_account.c_delete = 0)";
	$mp_list_arg['sql_for_edit'] .= " AND (m_account.id_account <> ".$_SESSION['login_id'].")";
	$mp_list_arg['sql_for_edit'] .= " AND (r_permit_type_1.c_permit_type IS NOT NULL)";

	$mp_list_arg['template_edit']	= "list-my-template-edit-friends.php";
	$mp_list_arg['list_edit_right_add_html']	= "in-block-friends-description.php";

	$order_tbl = array();
	$order_tbl[] = array(   "表示名"=>"ID順", "get_order_name"=>"id",
		"order_by"=>"CASE WHEN T3.c_displayOrder IS NULL THEN 10000 ELSE T3.c_displayOrder END, id_account asc");
	$http_arg = array();
	$http_arg['pl'] = 1000000;		// mp_list 必須

	if (isset($_POST['登録'])) {
		check_post_account($_POST['login_id']);
		update_friends();
		//My参照メンバ設定を反映させるため
		_account_login($_SESSION['login_id'], "", $_COOKIE['login_account_okuser_pass']);
		redirect("myprofile.php");
	} else {
		_GET_to_http_arg_pool($http_arg, $table_name);
		html_header(HTML_TITLE);
		page_header();
		contents_header();
?>
<div class="input_form">
<h3>My参照メンバ修正<a class="a_cancel_back" href="myprofile.php">[キャンセル]</a></h3>
<?php
		$item_tbl = array();
		mp_list_edit($mp_list_arg, $item_tbl, $order_tbl, $http_arg);
?>
</div>
<?php
		page_footer();
		html_footer();
	}
	exit();
function update_friends() {
	$con = my_mysqli_connect(_DB_ACCOUNT_SCHEMA);
	foreach ($_POST as $name => $value) {
		if (mb_substr($name,0,11) == "FRIENDS_OLD") {
			$up_id_account = mb_substr($name, 11);
			$friends_new = $_POST['FRIENDS_NEW'.$up_id_account].'';
			$friends_old = $_POST['FRIENDS_OLD'.$up_id_account];
			$displayOrder_new = $_POST['D_ORDER_NEW'.$up_id_account];
			$displayOrder_old = $_POST['D_ORDER_OLD'.$up_id_account];
			if ($friends_new <> $friends_old or ($friends_new <> '' and $displayOrder_new <> $displayOrder_old)) {
				$updateD = date("Y/m/d H:i:s");
				if ($friends_old == '') {
					$sql = "insert into m_friends (";
					$sql .= "id_account, id_member_id, c_displayOrder";
					$sql .= ", c_updatetime, c_registtime)";
					$sql .= " values (";
					$sql .= "'" . $_SESSION['login_id'] . "'";
					$sql .= ", '" . intval($friends_new) . "'";
					$sql .= ", '" . intval($displayOrder_new) . "'";
					$sql .= ", '" . $updateD . "'";
					$sql .= ", '" . $updateD . "'";
					$sql .= ")";
				} elseif ($friends_new == '') {
					$sql = "delete from m_friends where id_account = " . $_SESSION['login_id'];
					$sql .= " and id_member_id = " . intval($up_id_account);
				} else {
					$sql = "update m_friends";
					$sql .= " set c_displayOrder = " . intval($displayOrder_new);
					$sql .= ", c_updatetime = '" . $updateD . "'";
					$sql .= " where id_account = " . $_SESSION['login_id'];
					$sql .= " and id_member_id = " . intval($up_id_account);
				}
				$ret = mysqli_query($con, $sql);
				if (!$ret) {
					if (_DEBUG_ERROR_MSG == "YES") {
						error_exit("更新 失敗。<br><br>".$sql, True);
					} else {
						error_exit("更新 失敗。", True);
					}
				}
			}
		}
	}
	mysqli_close($con);
}
