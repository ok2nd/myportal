<?php
	if (!defined("_DB_SERVER")) {
		define("_DB_SERVER", "localhost");
	}
	if (defined("_DEFINE_mysql_ADMIN_db_tool")) {
		define("_DEFINE_mysql_ADMIN", _DEFINE_mysql_ADMIN_db_tool);
	} else {
		define("_DEFINE_mysql_ADMIN", "../../_myhome_myset/__define_mysql_admin.php");
	}
	if (file_exists(_DEFINE_mysql_ADMIN)) {
		require(_DEFINE_mysql_ADMIN);
		if (defined("_DB_ADMIN_USERNAME") && defined("_DB_ADMIN_PASSWORD")) {
			define("_DB_SCHEMA_USERNAME", _DB_ADMIN_USERNAME);
			define("_DB_SCHEMA_PASSWORD", _DB_ADMIN_PASSWORD);
		}
	}
	if (!defined("_DB_SCHEMA_USERNAME") && !defined("_DB_SCHEMA_PASSWORD")) {
		if (defined("_DB_USERNAME") && defined("_DB_PASSWORD")) {
			define("_DB_SCHEMA_USERNAME", _DB_USERNAME);
			define("_DB_SCHEMA_PASSWORD", _DB_PASSWORD);
		} else {
			define("_DB_SCHEMA_USERNAME", "myhome");
			define("_DB_SCHEMA_PASSWORD", "pass123");
		}
	}
	if (!defined("MEMORY_LIMIT_INI_SET")) {
		define("MEMORY_LIMIT_INI_SET", "128M");			// Excel/CSV インポート メモリサイズ
	}
	if (!defined("MAX_EXECUTION_TIME_INI_SET")) {
		define("MAX_EXECUTION_TIME_INI_SET", "240");		// Excel/CSV インポート 最大実行時間
	}
?>
