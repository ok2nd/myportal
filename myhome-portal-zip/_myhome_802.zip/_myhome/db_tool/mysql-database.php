<?php
	$con = NULL;	// $con = mysqli_connect();
	require("__include-common.php");
	require("../account/__logincheck.php");
	if ($_SESSION['システム管理者'] <> "YES") {
		exit;
	}
	if (DB_TOOL_ID_PASSWORD_USE == 'YES') {
		require("../id-manager/__include-im-login.php");
		require("../id-manager/im-logincheck.php");
	}
	if ($_GET['db'].'' == '') {
		$title = 'データベース一覧';
	} else {
		$title = 'テーブル一覧';
	}
?>
<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="utf-8">
<meta name="author" content="ok.2nd">
<title>MySQL管理ツール：<?= $title ?></title>
<link rel="stylesheet" href="<?= _STYLE_SHEET_FOLDER ?>/tools_common.css?20120406">
<link rel="stylesheet" href="<?= _STYLE_SHEET_FOLDER ?>/db_tools.css?20131020">
<script src="../scripts/jquery.js"></script>
<script src="../scripts/jquery.cookie.js"></script>
<script src="../scripts/ok2nd.js"></script>
</head>
<body>
<p id="tool_title_area">
<a href="../tools/" class="return_index">■</a>
<span id="tool_title">MySQL管理ツール：<?= $title ?></span>
<?php if ($_GET['db'].'' <> '') { ?>
<a class="a_cancel_back navi_back" href='mysql-database.php'>データベース一覧に戻る</a>
<? } ?>
</p>
<?php
	$con = @mysqli_connect(_DB_SERVER, _DB_SCHEMA_USERNAME, _DB_SCHEMA_PASSWORD);
	if ($con == False) {
		error_exit('データベース接続エラー');
	}
	mysqli_set_charset($con, 'utf8');
	if ($_GET['db'].'' == '') {
		print_database();
	} else {
		$tbl_array = print_table($_GET['db']);
		foreach ($tbl_array as $tbl) {
			print_field($_GET['db'], $tbl[0], $tbl[1]);
		}
	}
	mysqli_close($con);
?>
<div id="footer">
<a href="http://ok2nd.web.fc2.com/" target="_blank" style="color:#8080ff;">Powered by ok.2nd</a>
</div>
</body>
</html>
<?php
function print_database() {
	global $con;
	$rs = mysqli_query($con, 'show databases');
	if (!$rs) {
		error_exit('データベースなし');
	}
?>
	<table class="db_table" cellspacing=1>
	<tr><th>データベース</th></tr>
<?php
	while ($rec = mysqli_fetch_array($rs)) {
		if ($rec['Database'] <> 'information_schema') {
?>
		<tr><td>
		<a href="<?= $_SERVER['SCRIPT_NAME'] ?>?db=<?= $rec['Database'] ?>"><?= $rec['Database'] ?></a>
		</td></tr>
<?php
		}
	}
?>
	</table>
<?php
}
function print_table($dbname) {
	global $con;
	$tbl_array = array();
?>
	<p class="subtitle">データベース：<span class="db_name"><?= $dbname ?></span>
	<select onChange="chgFilterSelect(this, 'db', '<?= query_string_strip('db') ?>')">
<?php
	$rs = mysqli_query($con, 'show databases');
	while ($rec = mysqli_fetch_array($rs)) {
		if ($rec['Database'] <> 'information_schema') {
?>
		<option value="<?= $rec['Database'] ?>"<?= $_GET['db']==$rec['Database'] ? ' selected' : '' ?>><?= $rec['Database'] ?>
<?php
		}
	}
?>
		</select>
	</p>
<?php
	if (!mysqli_select_db($con, $dbname)) {
		error_exit('データベース選択エラー');
	}
	$sql = 'select TABLE_NAME, TABLE_TYPE from INFORMATION_SCHEMA.TABLES';
	$sql .= ' where TABLE_SCHEMA="'.$dbname.'" order by table_type, table_name';
	$rs = mysqli_query($con, $sql);
	if (!$rs) {
		error_exit ($dbname.'：テーブルなし');
	}
?>
	<table class="db_table" cellspacing=1>
	<tr><th>TABLE_NAME</th><th>TABLE_TYPE</th><th><br></th><th><br></th></tr>
<?php
	while ($rec = mysqli_fetch_array($rs)) {
		$tbl_array[] = array($rec['TABLE_NAME'], $rec['TABLE_TYPE']);
?>
		<tr>
		<td><a href="#<?= $rec['TABLE_NAME'] ?>"><?= $rec['TABLE_NAME'] ?></a></td>
		<td><?= $rec['TABLE_TYPE'] ?></td>
		<td><a href="mysql-table-list.php?db=<?= $dbname ?>&tb=<?= $rec['TABLE_NAME'] ?>">テーブル データ表示</a></td>
		<td>
		<?php	if ($rec['TABLE_TYPE'] <> 'VIEW') { ?>
		<a href="excel-import.php?db=<?= $dbname ?>&tb=<?= $rec['TABLE_NAME'] ?>">Excelインポート</a>
		<a href="csv-import.php?db=<?= $dbname ?>&tb=<?= $rec['TABLE_NAME'] ?>">CSVインポート</a>
		<?php	} ?>
		</td>
		</tr>
<?php
	}
?>
	</table>
<?php
	return $tbl_array;
}
function print_field($dbname, $tblname, $tbltype) {
	global $con;
?>
	<p id="<?= $tblname ?>" name="<?= $tblname ?>" class="subtitle">データベース：<span class="db_name"><?= $dbname ?></span>&nbsp;&nbsp;
	<?= table_type($tbltype) ?>：<span class="tbl_name"><?= $tblname ?></span>
	<a class="a_table_list" href="mysql-table-list.php?db=<?= $dbname ?>&tb=<?= $tblname ?>">データ表示</a>
	<a class="a_cancel_back" href='#'>先頭に戻る</a>
	</p>
<?php
	if (!mysqli_select_db($con, $dbname)) return;
	$rs = mysqli_query($con, 'desc '.$tblname);
	if (!$rs) {
		error_exit ($tblname.'：フィールドなし');
	}
?>
	<table class="db_table <?= $tbltype ?>" cellspacing=1>
	<tr><th>Field</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th><th>Extra</th></tr>
<?php
	while ($rec = mysqli_fetch_array($rs)) {
?>
		<tr>
		<td><?= $rec['Field'] ?></td>
		<td><?= $rec['Type'] ?></td>
		<td><?= $rec['Null'] ?></td>
		<td><?= $rec['Key'] ?></td>
		<td><?= $rec['Default'] ?></td>
		<td><?= $rec['Extra'] ?></td>
		</tr>
<?php
	}
?>
	</table>
<?php
	if ($tbltype == 'VIEW') {
		$sql = 'select VIEW_DEFINITION from INFORMATION_SCHEMA.VIEWS';
		$sql .= ' where TABLE_SCHEMA="'.$dbname.'" and TABLE_NAME="'.$tblname.'"';
		$rs = mysqli_query($con, $sql);
		$rec = mysqli_fetch_array($rs);
		if ($rs) {
			print_schema($rec['VIEW_DEFINITION']);
		}
	}
}
function table_type($tbltype) {
	if ($tbltype == 'BASE TABLE') return 'テーブル';
	if ($tbltype == 'VIEW') return '<span style="color: red;">ビュー</span>';
	return '不明';
}
function print_schema($schema) {
	echo '<span class="schema">スキーマ：';
	$schema = str_replace('/* ALGORITHM=UNDEFINED */', '', $schema);
	$schema = preg_replace('/(select | from | where | join | left join | right join | on| and | or )/', ' <br><font color=red>$0</font>', $schema);
	$schema = str_replace(',', ',<br>', $schema);
	echo $schema;
	echo '</span>';
}
?>
