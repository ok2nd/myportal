<?php
	require("__include-common.php");
	require("../account/__logincheck.php");
	if ($_SESSION['システム管理者'] <> "YES") {
		exit;
	}
	if (DB_TOOL_ID_PASSWORD_USE == 'YES') {
		require("../id-manager/__include-im-login.php");
		require("../id-manager/im-logincheck.php");
	}
	if (($dbname = $_GET['db']) == '') {
		error_exit('データベース名なし');
	}
	if (($tblname = $_GET['tb']) == '') {
		error_exit('テーブル名なし');
	}
	$omit_col = $_GET['col'].'';
	$fields = get_table_field($dbname, $tblname);
	put_table_list($dbname, $tblname, $fields, $omit_col);
function get_table_field($dbname, $tblname) {
	$con = @mysqli_connect(_DB_SERVER, _DB_SCHEMA_USERNAME, _DB_SCHEMA_PASSWORD);
	if ($con == False) {
		error_exit('データベース接続エラー');
	}
	mysqli_set_charset($con, 'utf8');
	if (!mysqli_select_db($con, $dbname)) {
		error_exit('データベース選択エラー');
	}
	$rs = mysqli_query($con, 'desc '.$tblname);
	if (!$rs) {
		error_exit ($tblname.'：テーブル選択エラー');
	}
	$fields = array();
	while ($rec = mysqli_fetch_array($rs)) {
		$fields[] = array($rec['Field'], $rec['Type']);
	}
	mysqli_close($con);
	return $fields;
}
function put_table_list($dbname, $tblname, $fields, $omit_col) {
	$colname = '';
	foreach ($fields as $field) {
		if ($colname <> '') $colname .= ',';
		$colname .= $field[0];
	}
	$sql = 'select ' . $colname . ' from ' . $tblname;
	if ($_GET['acc'] <> '') {
		$sql .= " where id_account = '".$_GET['acc']."'";
	}
	if ($_GET['cate'] <> '') {
		if ($_GET['acc'] <> '') {
			$sql .= ' and';
		} else {
			$sql .= ' where';
		}
		$sql .= " id_category = '".$_GET['cate']."'";
	}
	if ($_GET['so'] <> '') {
		$sql .= ' order by '.$_GET['so'].' '.$_SESSION['dbtool_table_sort_order'];
	}
	$con = @mysqli_connect(_DB_SERVER, _DB_SCHEMA_USERNAME, _DB_SCHEMA_PASSWORD);
	if ($con == False) {
		error_exit('データベース接続エラー');
	}
	mysqli_set_charset($con, 'utf8');
	if (!mysqli_select_db($con, $dbname)) {
		error_exit('データベース選択エラー');
	}
	header("Content-type: text/csv\n");
	header("Content-disposition: filename=".$dbname.'-'.myfile_ENCODE($tblname).".csv\n");
	$sw = False;
	foreach ($fields as $field) {
		if ($field[0] <> $omit_col) {
			if ($sw) {
				echo ',';
			} else {
				$sw = True;
			}
			if ($_GET['conv'] == 'sjis') {
				echo '"'.myfile_ENCODE($field[0]).'"';
			} else {
				echo '"'.$field[0].'"';
			}
		}
	}
	echo "\n";
	$rs = mysqli_query($con, $sql);
	while ($rec=mysqli_fetch_array($rs)) {
		$sw = False;
		foreach ($fields as $field) {
			if ($field[0] <> $omit_col) {
				if ($sw) {
					echo ',';
				} else {
					$sw = True;
				}
				if (stripos($field[1],'int') !== False or stripos($field[1],'decimal') !== False or stripos($field[1],'float') !== False or stripos($field[1],'double') !== False) {
					echo $rec[$field[0]];
				} else {
					if ($_GET['conv'] == 'sjis') {
						echo '"'.myfile_ENCODE(str_replace("\\","\\\\",str_replace('"','""',$rec[$field[0]]))).'"';
					} else {
						echo '"'.str_replace("\\","\\\\",str_replace('"','""',$rec[$field[0]])).'"';
					}
				}
			}
		}
		echo "\n";
	}
	mysqli_close($con);
}
?>
