<?php
	require("__include-common.php");
	require("../account/__logincheck.php");
	if ($_SESSION['システム管理者'] <> "YES") {
		exit;
	}
	if (DB_TOOL_ID_PASSWORD_USE == 'YES') {
		require("../id-manager/__include-im-login.php");
		require("../id-manager/im-logincheck.php");
	}
	if (($dbname = $_GET['db']) == '') {
		error_exit('データベース名なし');
	}
	if (($tblname = $_GET['tb']) == '') {
		error_exit('テーブル名なし');
	}
	$con = @mysqli_connect(_DB_SERVER, _DB_SCHEMA_USERNAME, _DB_SCHEMA_PASSWORD);
	if ($con == False) {
		error_exit('データベース接続エラー');
	}
	mysqli_set_charset($con, 'utf8');
	if (!mysqli_select_db($con, $dbname)) {
		error_exit('データベース選択エラー');
	}
	$rs = mysqli_query($con, 'desc '.$tblname);
	if (!$rs) {
		error_exit ($tblname.'：テーブル選択エラー');
	}
	$sql = 'delete from '.$tblname.' where c_delete = 999';
	$ret = my_mysqli_query($sql, "削除できませんでした。");
	mysqli_close($con);
	redirect('mysql-table-list.php?db='.$_GET['db'].'&tb='.$_GET['tb'].'&so='.$_GET['so'].'&acc='.$_GET['acc'].'&cate='.$_GET['cate']);
?>
