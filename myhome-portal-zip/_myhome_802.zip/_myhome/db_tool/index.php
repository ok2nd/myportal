<?php
	header("Location: mysql-database.php?".$_SERVER['QUERY_STRING']);
?>
