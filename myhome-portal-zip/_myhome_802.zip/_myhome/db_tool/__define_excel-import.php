<?php
	if (defined("EXCEL_IMPORT_FOLDER_db_tool")) {
		define("EXCEL_IMPORT_FOLDER", EXCEL_IMPORT_FOLDER_db_tool);
	} else {
		define("EXCEL_IMPORT_FOLDER", "../_attach/excel-import/");
	}
	define("EXCEL_FILE_UPLOAD", 1);
	define("EXCEL_FILE_EXIST", 2);
	define("EXCEL_FILE_NAME", $_SESSION['login_id']."-excel.xls");
?>
