<?php
	require("__include-common.php");
	require("../account/__logincheck.php");
	require("../calendar/_my_calendar.php");
	if (GOOGLE_MAPS_API_VERSION == 'V3') {
		require("__include-maps-v3.php");
	} else {
		require("__include-maps.php");
	}
	ini_set("memory_limit", FILE_UPLOAD_MEMORY_LIMIT);		//メモリサイズ
	ini_set("max_execution_time", FILE_UPLOAD_MAX_EXECUTION_TIME);	//最大実行時間
	if ($_POST) {
// *********************************************************************************
// * max_execution_time
// * post_max_size
// * upload_max_filesizeを越えるとisset($_POST['登録'])がTrueにならない。
// *********************************************************************************
		check_post_account($_POST['login_id'], $_POST['current_id']);
		post_done_proc();
	} else {
		if (INPUT_POPUP_CALENDAR == 'YUI') {
			$add_input_header = '_add_input_header_YUI.php';
		} else if (INPUT_POPUP_CALENDAR == 'kanaya') {
			$add_input_header = '_add_input_header-kanaya.php';
		} else {
			$add_input_header = '_add_input_header.php';
		}
		html_header(HTML_TITLE, $add_input_header, '', ' onunload="GUnload()"', '', '__html-my-header-maps.php');
		page_header();
		input_form();
		page_footer();
		html_footer();
	}
	exit();
?>
<?php
function post_done_proc() {
	if ($_POST['user_id']."" <> "") {
		$user_id = $_POST['user_id'];
	} else {
		error_exit("不正アクセス：ユーザーIDなし。", True);
	}
	if (check_permit_id($_SESSION['login_id'], $user_id) != "w") {
		error_exit("書き込み権限がありません。", True);
	}
	if ($_POST['update_id']) {
		if (!is_numeric($_POST['update_id'])) {
			error_exit("不正アクセス：ID不正", True);
		}
		$id = intval($_POST['update_id']);
	} else {
		$id = 0;
	}
	if (isset($_POST['削除'])) {
		//	if ($_POST['削除する'] <> "YES") {
		//		error_exit("削除するにチェックしてください。", True);
		//	}
	} elseif ($_POST['c_subject'] == "") {
		error_exit("タイトルを入れてください。", True);
	}
	if ($_POST['inputY']) {
		$year = get_post_str("inputY");
	}
	if ($_POST['inputM']) {
		$month = get_post_str("inputM");
	}
	if ($_POST['inputD']) {
		$day = get_post_str("inputD");
	}
	if (!checkdate($month, $day, $year)) {
		error_exit("日付が不正", True);
	}
	$diary_date = date("Y-m-d", mktime(0, 0, 0, $month, $day, $year));
	$updateD = date("Y/m/d H:i:s");
	$con = my_mysqli_connect(_DB_SCHEMA);
	if ($id == 0) {
		$sql = "insert into m_schedule ";
		$sql .= "(id_account";
		$sql .= ", c_date";
		$sql .= ", id_category";
		$sql .= ", c_subject";
		$sql .= ", c_memo";
		$sql .= ", c_mapHeight";
		$sql .= ", c_mapCenterLat";
		$sql .= ", c_mapCenterLng";
		$sql .= ", c_mapZoomLevel";
		$sql .= ", c_country";
		$sql .= ", c_currencyUnit";
		$sql .= ", c_exchangeRate";
		$sql .= ", c_registtime";
		$sql .= ", c_updatetime";
		$sql .= ") values ";
		$sql .= "( '".$user_id."'";
		$sql .= ", '".$diary_date."'";
		$sql .= ", '" . $_POST['id_category'] . "'";
		$sql .= ", '".post_to_mysql('c_subject')."'";
		$sql .= ", '".post_to_mysql('c_memo')."'";
		$sql .= ", '".post_to_mysql('c_mapHeight')."'";
		$sql .= ", '".post_to_mysql('c_mapCenterLat')."'";
		$sql .= ", '".post_to_mysql('c_mapCenterLng')."'";
		$sql .= ", '".post_to_mysql('c_mapZoomLevel')."'";
		$sql .= ", '".post_to_mysql('c_country')."'";
		$sql .= ", '".post_to_mysql('c_currencyUnit')."'";
		$sql .= ", '".post_to_mysql('c_exchangeRate')."'";
		$sql .= ", '". $updateD . "'";
		$sql .= ", '". $updateD . "'";
		$sql .= ")";
		$ret = my_mysqli_query($sql, "登録できませんでした。");
	} elseif (isset($_POST['削除'])) {
		$sql = "update m_schedule set";
		$sql .= " c_delete = 999";
		$sql .= ", c_updatetime = '". $updateD . "'";
		$sql .= " where id_schedule = ".$id;
		$sql .= " and id_account = ".$user_id;
		$ret = my_mysqli_query($sql, "削除できませんでした。");
	} else {
		$sql = "update m_schedule set";
		$sql .= " id_category = '".$_POST['id_category']."'";
		$sql .= ", c_date = '".$diary_date."'";
		$sql .= ", c_subject = '".post_to_mysql("c_subject")."'";
		$sql .= ", c_memo = '".post_to_mysql('c_memo')."'";
		$sql .= ", c_mapHeight = '".post_to_mysql('c_mapHeight')."'";
		$sql .= ", c_mapCenterLat = '".post_to_mysql('c_mapCenterLat')."'";
		$sql .= ", c_mapCenterLng = '".post_to_mysql('c_mapCenterLng')."'";
		$sql .= ", c_mapZoomLevel = '".post_to_mysql('c_mapZoomLevel')."'";
		$sql .= ", c_country = '".post_to_mysql('c_country')."'";
		$sql .= ", c_currencyUnit = '".post_to_mysql('c_currencyUnit')."'";
		$sql .= ", c_exchangeRate = '".post_to_mysql('c_exchangeRate')."'";
		$sql .= ", c_updatetime = '". $updateD . "'";
		if ($_POST['new_id'] <> '') {	// 新規登録
			$sql .= ", c_registtime = '". $updateD . "'";
			$sql .= ", c_delete = 0";
		}
		$sql .= " where id_schedule = ".$id;
		$sql .= " and id_account = ".$user_id;
		$ret = my_mysqli_query($sql, "更新できませんでした。");
	}
	// ****** 添付ファイル ******
	if ($id == 0) {
		$id = my_mysqli_insert_id();	//直近のINSERTクエリによりAUTO_INCREMENTカラム用に生成されたIDを取得
	}
	$sw = False;
	$sqlupd = "";
	for ($ix=1; $ix<=3; $ix++) {
		// ***** ファイルのアップロード *****
		$attachFile = file_upload("filename".$ix, $id, ATTACH_FILE_FOLDER, $user_id);
		if ($attachFile <> "") {
			if ($sw) {
				$sqlupd .= ",";
			}
			$sqlupd .= " c_attachFile" . $ix . " = '" . $attachFile . "'";
			$sw = True;
		} else if ($_POST['fileDelete'.$ix] == "YES") {
			if ($sw) {
				$sqlupd .= ",";
			}
			$sqlupd .= " c_attachFile" . $ix . " = ''";
			$sw = True;
		}
	}
	if ($sw) {
		$sql = "update m_schedule set";
		$sql .= $sqlupd;
		$sql .= " where id_schedule = ".$id;
		$sql .= " and id_schedule = ".$id;
		$sql .= " and id_account = '".$user_id."'";
			//echo $sql;
			//exit;
		$ret = my_mysqli_query($sql, "アップロードファイル名DB登録失敗。", NULL, True);
	}
	mysqli_close($con);
	if (isset($_POST['削除'])) {
		redirect('list.php?arg=session');
	} else {
		redirect($_POST['return_http']);		// 元のページに戻る
	}
}
function input_form() {
	$user_id = $_SESSION['current_id'];
	if ($_GET['uid'] <> '') {
		$user_id = $_GET['uid'];
	} elseif ($_GET['id'] == '') {
		error_exit("不正アクセス：ユーザーIDなし。", True);
	}
	if (check_permit_id($_SESSION['login_id'], $_SESSION['current_id']) != "w") {
		error_exit("書き込み権限がありません。", True);
	}
	for ($ix=0; $ix<=$_SESSION['login_friends_number']; $ix++) {
		$current_handle = $_SESSION['login_friends_handle_'.$user_id];
	}
?>
<div class="input_form">
<h3><?= $current_handle ?><a class="a_cancel_back" href='javascript:history.back();'>戻る</a></h3>
<?php
	$con = my_mysqli_connect(_DB_SCHEMA);
	if ($_GET['id']) {
		$id = $_GET['id'];
		if ($_GET['page']) {
			$page = $_GET['page'];
		}
		$new_id = 0;
	} else {
		if ($_GET['y']) {
			$year = $_GET['y'];
		} elseif ($_GET['selY']) {
			$year = $_GET['selY'];
		} else {
			$year = date('Y');
		}
		if ($_GET['m']) {
			$month = $_GET['m'];
		} elseif ($_GET['selM']) {
			$month = $_GET['selM'];
		} else {
			$month = date('n');
		}
		if ($_GET['d']) {
			$day = $_GET['d'];
		} elseif ($_GET['selD']) {
			$day = $_GET['selD'];
		} else {
			$day = date('j');
		}
		if (!checkdate($month, $day, $year)) {
			error_exit("日付が不正", True);
		}
		// *** マップ情報登録のために親テーブルm_scheduleにレコードが必要
		$sql = "insert into m_schedule ";
		$sql .= "(id_account, c_delete) values ";
		$sql .= "( '".$user_id."',111)";
		$ret = my_mysqli_query($sql, "DB仮登録でエラー発生。");
		$id = my_mysqli_insert_id();	//直近のINSERTクエリによりAUTO_INCREMENTカラム用に生成されたIDを取得
		$new_id = $id;
	}
	$rec = diary_get($user_id, $id, $new_id);
	if (!$rec) {
		error_exit("該当レコードなし", True);
	}
	diary_input($user_id, $id, $year, $month, $day, $page, $new_id, $rec, $new_id);
?>
</div>
<div id="google_map_form">
<?php
	google_map_view($id, $rec['c_mapCenterLat'], $rec['c_mapCenterLng'], $rec['c_mapZoomLevel'], $rec['c_mapHeight'], 'edit');
	mysqli_close($con);
?>
</div>
<?php
}
function diary_input($user_id, $id, $year, $month, $day, $page, $new_id, $rec, $new_id) {
	if ($new_id <> 0) {
		if (empty($_GET['d'])) {
			$year = date('Y');
			$month = date('n');
			$day = date('j');
		}
		$subject = "";
		$memo = "";
	} else {
		$year = date_from_mysql("Y", $rec['c_date']);
		$month = date_from_mysql("n", $rec['c_date']);
		$day = date_from_mysql("d", $rec['c_date']);
		$subject = $rec['c_subject'];
		$memo = $rec['c_memo'];
	}
?>
<script>
function formCheck(form) {
	if (form.c_subject.value == '') {
		window.alert('タイトルを入れてください。');
		return false;		// 送信を中止
	}
	return true;	// 送信を実行
}
</script>
<script src="../scripts/valueconvertor.js"></script>
<script src="../scripts/jqKey.js"></script>
<script>
$(function() {
	$('table.input_form_table td').jqKey({
		Enter:true
	})
});
</script>
<?php	if (strstr($_SERVER['HTTP_USER_AGENT'], "MSIE 6")) { ?>
<style>
.calenPopup {		/* IE6では、z-indexがselectプルダウンには効かないバグ対策。*/
	left: 80px;
	top: -50px;
</style>
<?php	} ?>
<form name="form0" method="POST" action="<?= $_SERVER['SCRIPT_NAME'] ?>?<?= $_SERVER['QUERY_STRING'] ?>" enctype="multipart/form-data" onSubmit="return formCheck(this)">
	<input type="hidden" name="return_http" value="<?= $_SERVER['HTTP_REFERER']?>">
	<input type="hidden" name="user_id" value="<?= $user_id ?>">
	<input type="hidden" name="update_id" value="<?= $id ?>">
	<input type="hidden" name="new_id" value="<?= $new_id ?>">
	<input type="hidden" name="page" value="<?= $page ?>">
	<input type="hidden" name="updatetime" value="<?= $updatetime ?>">
	<input type="hidden" name="login_id" value="<?= $_SESSION['login_id'] ?>">
	<input type="hidden" name="current_id" value="<?= $_SESSION['current_id'] ?>">
<table class="input_form_table">
<tr>
	<td>日付</td>
	<td nowrap>
		<p>
			<input type="hidden" name="c_date_current" value="<?= $rec['c_date'] ?>">
		<?php
			$endYY = date("Y") + 1;
			select_view_with_id("inputY", "年", _CALENDAR_SELECT_FIRST_YEAR, $endYY, $year);
			select_view_with_id("inputM", "月", 1, 12, $month);
			select_view_with_id("inputD", "日", 1, 31, $day);
		?>
		<?php	if (INPUT_POPUP_CALENDAR == 'YUI') { ?>
			<img src="../images/calendar.png" onclick="YahhoCal.render('inputY', 'inputM', 'inputD');">
		<?php	} else if (INPUT_POPUP_CALENDAR == 'kanaya') { ?>
			<img src="../images/calendar.png" onClick="wrtCalendar(event,document.form0.ymd1,'inputY','inputM','inputD');">
			<input type="hidden" name="ymd1" id="ymd1" value="">
		<?php	} else { ?>
			<a href="javascript:viewCalen(theMonth,'calenArea1','inputY','inputM','inputD'); void(0);"><img src="../images/calendar.png"></a>
			<span id="calenArea1" class="calenBox"></span>
		<?php	} ?>
		</div>
	</td>
</tr>
<tr>
	<td nowrap>カテゴリ</td>
	<td class="input_form_td">
	<div id="input_category_radio" class="block_left">
	<?php
		$sqlsel = "select * from m_category where id_account = '".$user_id."'";
		$sqlsel = $sqlsel . " and c_delete = 0";
		$sqlsel = $sqlsel . " order by c_categoryDisplayOrder";
		$rs_sel = my_mysqli_query($sqlsel);
		if ($id == 0) {
			$category = (int)$_GET['cat'];
		} else {
			$category = $rec['id_category'];
		}
		$ix = 0;
		while ($rec_sel=mysqli_fetch_array($rs_sel)) {
	?>
	<span><label><input type="radio" name="id_category" value="<?= $rec_sel['id_category'] ?>"<?= ($rec_sel['id_category'] == $category or ($new_id <> 0 and $ix == 0)) ? ' checked' : 'xx' ?>>
		<?= my_htmlspecialchars($rec_sel['c_categoryName']) ?></label>
	</span>
	<?php
			$ix++;
		}
	?>
	</div>
	</td>
</tr>
<?php if ($_SESSION['login_friends_cal_sbj_use_'.$user_id] <> 'NO' || $subject <> '') { ?>
<tr>
	<td>タイトル</td>
	<td>
		<input class="text fullwidth-kana" type="text" name="c_subject" size=80 value="<?= my_htmlspecialchars($subject) ?>">
	</td>
</tr>
<tr>
	<td>国</td>
	<td>
		<input class="text" type="text" name="c_country" size=20 value="<?= my_htmlspecialchars($rec['c_country']) ?>">
		為替レート：<?php
			select_view_options('1', 'c_currencyUnit', '', PRICE_UNIT_SELECT, $rec['c_currencyUnit']);
		?> =
		<input class="text ascii" type="text" name="c_exchangeRate" size=10 value="<?= my_htmlspecialchars($rec['c_exchangeRate']) ?>" style="ime-mode:disabled;">円

	</td>
</tr>
<?php } ?>
<tr>
	<td nowrap>概要</td>
	<td>
		<div class="block_left">
		<?php
			$str = my_htmlspecialchars($memo);
			$rows = textarea_rows($str, 480) + 1;
			if ($rows < 5) {
				$rows = 5;
			} elseif (strstr($_SERVER['HTTP_USER_AGENT'], "MSIE") and $rows > 30) {
				$rows = 30;
			}
		?>
		<?php
			if (strstr($_SERVER['HTTP_USER_AGENT'], "MSIE")) {
				$textarea_width = 410;
			} else {
				$textarea_width = 430;
			}
		?>
		<textarea id="c_memo" name="c_memo" style="width:<?= $textarea_width ?>px;" rows="<?= $rows ?>" wrap="soft"><?= $str ?></textarea>
		</div>
		<?php	if (strstr($_SERVER['HTTP_USER_AGENT'], "MSIE")) { ?>
			<div class="block_left">
			<input type="button" value="小" OnClick="textareaBigSmall('c_memo','小')"><br>
			<input type="button" value="大" OnClick="textareaBigSmall('c_memo','大')"><br>
			</div>
		<?php	} ?>
	</td>
</tr>
<tr>
	<td nowrap>添付文書</td>
	<td>
<?php if ($rec['c_attachFile1'] <> "" || $rec['c_attachFile2'] <> "" || $rec['c_attachFile3'] <> "") { ?>
	<p><span class="alarm_text">再度添付ファイル名を指定すると登録済ファイルに上書きされます。</span></p>
<?php } ?>
<?php
	for ($ix=1; $ix<=3; $ix++) {
?>
		<div class="block">
		<div class="block_left">(<?= $ix ?>)</div>
		<div class="block_left">
<?php
		if ($rec['c_attachFile'.$ix] <> "") {
			attach_file_view($rec['id_account'], $rec['c_attachFile'.$ix], '', 50, True);
?>
		<label><input type="checkbox" name="fileDelete<?= $ix ?>" value="YES">削除</label>
		<input type="hidden" name="filenameCurrent<?= $ix ?>" value="<?= $rec['c_attachFile'.$ix] ?>">
<?php
		}
?>
		<input type="file" size=40 name="filename<?= $ix ?>" style="button-font-size:small">
		</div>
		</div>
<?php
	}
?>
	</td>
</tr>
</table>
<?php
	if ($new_id <> 0) {
?>
	<input class="input_form_button" type="submit" name="登録" value="登録">
<?php
	} else {
?>
	<input class="input_form_button" type="submit" name="登録" value="修正">
	<input class="input_form_button" type="submit" name="削除" value="削除" onClick="return delete_check();" style="margin-left:20px;">
<?php
	}
?>
	<input type="hidden" id="c_mapHeight" name="c_mapHeight" value="<?= $rec['c_mapHeight'] ?>">
	<input type="hidden" id="c_mapCenterLat" name="c_mapCenterLat" value="<?= $rec['c_mapCenterLat'] ?>">
	<input type="hidden" id="c_mapCenterLng" name="c_mapCenterLng" value="<?= $rec['c_mapCenterLng'] ?>">
	<input type="hidden" id="c_mapZoomLevel" name="c_mapZoomLevel" value="<?= $rec['c_mapZoomLevel'] ?>">
</form>
<script>
function delete_check() {
	if (window.confirm('このデータを削除しますか？')) {
		return true;
	} else {
		return false;
	}
}
</script>
<?php	if (!strstr($_SERVER['HTTP_USER_AGENT'], "MSIE")) { ?>
<script src="../scripts/autoresize.jquery.min.js"></script>
<script>
$('textarea#c_memo').autoResize({
	onResize : function() {
		$(this).css({opacity:0.8});
	},
	animateCallback : function() {
		$(this).css({opacity:1});
	},
	animateDuration : 300,
	extraSpace : 20
});
$('textarea#c_memo').trigger('change'); // 初期表示時に自動リサイズさせるためchangeイベント実行
</script>
<?php	} ?>
<?
}
function select_view_with_id($name, $suffix, $first, $end, $now) {
	if ($suffix == '年') {
		if (strstr($_SERVER['HTTP_USER_AGENT'], "Chrome")) {
?>
<input type="number" id="<?= $name ?>" name="<?= $name ?>" value="<?= $now ?>" style="width:4em;"><?= $suffix ?>
<?php		} else { ?>
<script>
function YearUpDown(id, updown) {
	$("#"+id).val(Number($("#"+id).val()) + Number(updown));
}
</script>
<input type="text" class="text" id="<?= $name ?>" name="<?= $name ?>" value="<?= $now ?>" style="width:3em;"><input type="button" value="▲" style="font-size:10px;margin:0;padding:0;" OnClick="YearUpDown('<?= $name ?>',1)"><input type="button" value="▼" style="font-size:10px;margin:0;padding:0;" OnClick="YearUpDown('<?= $name ?>',-1)"><?= $suffix ?>
<?php		} ?>
<?php	} else {
		echo "<select id='".$name."' name='".$name."'>";
		for ($i=$first; $i<=$end; $i++) {
			echo "<option value='".$i."'";
			if ($i == $now) {
				echo " selected";
			}
			echo ">".$i."</option>";
		}
		echo "</select>".$suffix;
	}
}
function select_view_with_id_with_blank($name, $suffix, $first, $end, $now) {
	echo "<select id='".$name."' name='".$name."'>";
	echo "<option value=''>";
	for ($i=$first; $i<=$end; $i++) {
		echo "<option value='".$i."'";
		if ($i == $now) {
			echo " selected";
		}
		echo ">".$i."</option>";
	}
	echo "</select>".$suffix;
}
function diary_get($user_id, $id, $new_id) {
	$sql = "select * from m_schedule where id_schedule = ".$id;
	if ($new_id <> 0) {
		$sql .= " and c_delete = 111";	//仮登録
	} else {
		$sql .= " and c_delete = 0";
	}
	$sql .= " and id_account = ".$user_id;
	$rs = my_mysqli_query($sql);
	return mysqli_fetch_array($rs);
}
function select_view_options($prefix, $name, $suffix, $options, $now) {
	$option_ary = explode(",", $options);
	echo $prefix;
	echo "<select id='".$name."' name='".$name."'>";
	foreach ($option_ary as $opt) {
		echo "<option value='".$opt."'";
		if ($opt == $now) {
			echo " selected";
		}
		echo ">".$opt."</option>";
	}
	echo "</select>".$suffix;
}
?>
