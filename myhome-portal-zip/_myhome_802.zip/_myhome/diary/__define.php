<?php
	if (defined("HTML_TITLE_diary")) {
		define("HTML_TITLE", HTML_TITLE_diary);
	} else {
		define("HTML_TITLE", "MyHome 旅行記");
	}
	define("SESSION_PREFIX", "diary");

	if (defined("_DB_SCHEMA_diary")) {
		define("_DB_SCHEMA", _DB_SCHEMA_diary);
	} else {
		define("_DB_SCHEMA", "_db_diary");
	}
	if (defined("ATTACH_FILE_FOLDER_diary")) {
		define("ATTACH_FILE_FOLDER", ATTACH_FILE_FOLDER_diary);
	} else {
		//↓絶対パスにできない？？？
		define("ATTACH_FILE_FOLDER", "../_attach/diary/");
	}
	if (!defined("ATTACH_FILE_FOLDER_diary_marker")) {
		define("ATTACH_FILE_FOLDER_diary_marker", "../_attach/diary_marker/");
	}
	if (!defined("DIARY_MAPS_FRAME_WIDTH")) {
		define("DIARY_MAPS_FRAME_WIDTH", "700px");
	}
	if (!defined("DIARY_MAPS_FRAME_HEIGHT")) {
		define("DIARY_MAPS_FRAME_HEIGHT", "300px");
	}
	if (!defined("DIARY_MAPS_FRAME_HEIGHT_SELECT")) {
		define("DIARY_MAPS_FRAME_HEIGHT_SELECT", "300px,350px,400px,450px,500px,550px,600px,650px,700px,750px,800px");
	}
	if (defined("VIEW_PHOTO_WIDTH_diary")) {
		define("VIEW_PHOTO_WIDTH", VIEW_PHOTO_WIDTH_diary);
	} else {
		define("VIEW_PHOTO_WIDTH", 200);
	}
	if (defined("VIDEO_PREVIEW_diary")) {
		define("VIDEO_PREVIEW", VIDEO_PREVIEW_diary);
		define("VIDEO_PREVIEW_EXT", VIDEO_PREVIEW_EXT_diary);
		define("VIDEO_PREVIEW_WIDTH", VIDEO_PREVIEW_WIDTH_diary);
		define("VIDEO_PREVIEW_HEIGHT", VIDEO_PREVIEW_HEIGHT_diary);
	} else {
		define("VIDEO_PREVIEW", "YES");
		define("VIDEO_PREVIEW_EXT", "flv,mp4,mp3,wmv");
		define("VIDEO_PREVIEW_WIDTH", "200");
		define("VIDEO_PREVIEW_HEIGHT", "150");
	}
	if (!defined("DIARY_MAPS_ICON_FOLDER")) {
		define("DIARY_MAPS_ICON_FOLDER", "../icon/maps/");
	}
	define("IMAGES_FOLDER", DIARY_MAPS_ICON_FOLDER);
	if (!defined("PRICE_UNIT_SELECT")) {
		define("PRICE_UNIT_SELECT", "円,ドル,ユーロ");
	}
	if (defined("CALENDAR_FILTER_TITLE_diary")) {
		define("CALENDAR_FILTER_TITLE", CALENDAR_FILTER_TITLE_diary);
	} else {
		define("CALENDAR_FILTER_TITLE", "旅行記");
	}
	if (!defined("DIARY_RATING_CAPTION")) {
		define("DIARY_RATING_CAPTION", "総合評価,コスト,施設,雰囲気,料理,風呂");
	}
	define("PAGE_LINE_SELECT", "5,10,20,50,100,1000");	//頁内に表示する行数
	define("PAGE_LINE_DEFAULT", "10");			//頁内に表示する行数（デフォルト）
	if (defined("ALBUM_PHOTO_SIZE_calendar")) {
		define("ALBUM_PHOTO_SIZE", ALBUM_PHOTO_SIZE_calendar);
		define("ALBUM_PHOTO_SIZE_POP", ALBUM_PHOTO_SIZE_POP_calendar);
	} else {
		define("ALBUM_PHOTO_SIZE", 100);
		define("ALBUM_PHOTO_SIZE_POP", 300);
	}
	if (!defined("FILE_UPLOAD_MEMORY_LIMIT")) {
		define("FILE_UPLOAD_MEMORY_LIMIT", "32M");	// ファイルアップロード メモリサイズ
	}
	if (!defined("FILE_UPLOAD_MAX_EXECUTION_TIME")) {
		define("FILE_UPLOAD_MAX_EXECUTION_TIME", "60");	// ファイルアップロード 最大実行時間
	}

	// スケジュール入力画面の日付入力補助ポップアップカレンダーの種類
	// デフォルトは、ホームページの素(http://www.kanaya440.com/)の日付入力補助
	if (defined("INPUT_POPUP_CALENDAR_calendar")) {
		define("INPUT_POPUP_CALENDAR", INPUT_POPUP_CALENDAR_calendar);
	} else {
		define("INPUT_POPUP_CALENDAR", "");		// Yahoo! UI Library: Calendar を使う場合: "YUI"
	}
?>
