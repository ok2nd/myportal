<?php
	jquery_highlight('.diary_marker_td_subject', keystr_and_or(keystr_fix($http_arg['key'])));
	jquery_highlight('.diary_marker_td_comment', keystr_and_or(keystr_fix($http_arg['key'])));
?>
	<table id="diary_marker_table" cellspacing=0>
	<tr class="diary_marker_header">
	<th>日付</th>
	<th>タイトル</th>
	<th>場所</th>
	<th>種別</th>
	<th style="text-align:right;">費用</th>
	<th><br></th>
	<th>費用備考</th>
<?php
	$caption = explode(",", DIARY_RATING_CAPTION);
	$cap_num = count($caption);
	for ($ix=0; $ix<$cap_num; $ix++) {
		$d_name = $caption[$ix];
		if (strlen($d_name) > 2) {
			$d_name = left($d_name,2).'<br>'.mb_substr($d_name,2);
		}
?>
	<th><?= $d_name ?></th>
<?php
	}
?>
	<th>メモ</th>
	</tr>
<?php
	mysqli_data_seek($rs, $startline);			//テーブル内の指定行に移動
	$line = $startline;					//$lineに$startlineを代入
	$odd = False;
	$old_id_schedule = 0;
	while ($rec=mysqli_fetch_array($rs) and $line<=$endline) {
		if ($rec['id_schedule'] <> $old_id_schedule) {
			$odd =! $odd;
		}
		if ($odd) {
			$tr_class = 'diary_marker_table_data_odd';
		} else {
			$tr_class = 'diary_marker_table_data_even';
		}
		$old_id_schedule = $rec['id_schedule'];
		$view_category_class = 'diary_marker_category';
		$view_diary_class = 'diary_marker_diary';
?>
	<tr class="<?= $tr_class ?>">
	<td class="diary_marker_td_date">
		<p class="diary_marker_date"><?= date_from_mysql("Y-m-d", $rec['c_date']) ?></p>
		<?= day_week_view($rec['c_date']) ?>
	<td class="diary_marker_td_subject">
		<a class="a_list_subject" href='view.php?id=<?= $rec['id_schedule'] ?>'><?= ins_atag_br($rec['c_subject']) ?></a>
	</td>
	<td class="diary_marker_td_place">
		<?= my_htmlspecialchars($rec['c_place']) ?>
		<?php	if ($multi == '' and is_write_permit() == True) {	?>
		<a class="a_diary_update" href="item-input.php?mid=<?= $rec['id_marker'] ?>&page=<?= $_GET['page'] ?>&ret=list-marker.php">[修正]</a>
		<?php	} ?>
		<?php
			$filename1 = $rec['c_attachFile1'];
			$filename2 = $rec['c_attachFile2'];
			$filename3 = $rec['c_attachFile3'];
			if ($filename1 <> "" || $filename2 <> "" || $filename3 <> "") {
		?>
			<p>
		<?php
				view_attach_file($filename1);
				view_attach_file($filename2);
				view_attach_file($filename3);
		?>
			</p>
		<?php
			}
		?>
	</td>
	<td class="diary_marker_td_markertype">
		<?php	if ($rec['id_markertype'] <> 0) { ?>
		<img src="<?= DIARY_MAPS_ICON_FOLDER ?><?= my_htmlspecialchars($rec['c_markericon']) ?>"><br>
		<?php	} else { ?>
			<br>
		<?php 	} ?>
	</td>
	<td class="diary_marker_td_price">
		<?php	if ($rec['c_price'] <> 0) { ?>
			<?php	if (right($rec['c_price'].'',2) == '00') { ?>
				<?= number_format($rec['c_price']) ?><br>
			<?php	} else { ?>
				<?= $rec['c_price'] ?><br>
			<?php 	} ?>
		<?php	} else { ?>
			<br>
		<?php 	} ?>
	</td>
	<td class="diary_marker_td_priceUnit">
		<?php	if ($rec['c_price'] <> 0) { ?>
		<?= my_htmlspecialchars($rec['c_priceUnit']) ?>
		<?php	} else { ?>
			<br>
		<?php 	} ?>
	</td>
	<td class="diary_marker_td_priceMemo">
		<?= my_htmlspecialchars($rec['c_priceMemo']) ?><br>
	</td>
<?php
	$caption = explode(",", DIARY_RATING_CAPTION);
	$cap_num = count($caption);
	for ($ix=0; $ix<$cap_num; $ix++) {
?>
	<td class="diary_marker_td_rating">
		<?php	if ($rec['c_rating'.$ix] <> 0) { ?>
		<?= my_htmlspecialchars($rec['c_rating'.$ix]) ?>
		<?php	} else { ?>
		<br>
		<?php 	} ?>
	</td>
<?php
	}
?>
	<td class="diary_marker_td_comment">
		<?= ins_atag_br($rec['c_comment']) ?><br>
	</td>
	</tr>
<?php
		$line++;
	}
?>
	</table>
<?php
function view_attach_file($filename) {
	if ($filename == '') {
		return;
	} elseif (is_img_filename($filename)) {
		$img = '../images/img.png';
	} elseif (is_video_filename($filename)) {
		$img = '../images/video.png';
	} else {
		$img = '../images/paste.png';
	}
	echo '<a href="' . ATTACH_FILE_FOLDER_diary_marker.$_SESSION['current_id'].'/'.$filename . '" target="_blank"><img src="'.$img.'" border=0 /></a>';
}
?>
