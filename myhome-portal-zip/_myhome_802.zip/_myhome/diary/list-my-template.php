<script>
function checkOnAll() {
	$("input:checkbox[name^='check']").attr('checked', true);
	return false;
}
function checkOffAll() {
	$("input:checkbox[name^='check']").attr('checked', false);
	return false;
}
</script>
<?php
	jquery_highlight('.a_list_subject', keystr_and_or($keystring));
?>
	<form id="diary_form" name="frm0" method="POST" action="view.php?<?= $_SERVER['QUERY_STRING'] ?>">
	<input class="" type="button" onClick="return checkOnAll()" value="全てチェック">
	<input class="" type="button" onClick="return checkOffAll()" value="チェッククリア">
	<input class="" type="submit" name="multi" value="一括マップ">
	<table id="diary_list_table" cellspacing=0>
<?php
	mysqli_data_seek($rs, $startline);			//テーブル内の指定行に移動
	$line = $startline;					//$lineに$startlineを代入
	$trans = 0;
	while ($rec=mysqli_fetch_array($rs) and $line<=$endline) {
		$view_category_class = 'diary_list_category';
		$view_diary_class = 'diary_list_diary';
?>
	<tr class="diary_list_table_data">
	<td class="diary_list_td a_check">
		<input type="checkbox" name="check[]" value="<?= $rec['id_schedule'] ?>">
	</td>
	<td class="diary_list_subject diary_list_date_td">
		<p class="diary_list_date"><?= date_from_mysql("Y-m-d", $rec['c_date']) ?></p>
		<?= day_week_view($rec['c_date']) ?>
	<td class="diary_list_subject">
		<p>
		<a class="a_list_subject" href='view.php?id=<?= $rec['id_schedule'] ?>&move=<?= $line ?>&row=<?= $rowcnt ?>&page=<?= $page ?>&<?= query_from_http_arg_pool($http_arg) ?>'><?= ins_br($rec['c_subject']) ?></a>
		<?php if (check_permit_id($_SESSION['login_id'], $_SESSION['current_id']) == "w") { ?>
		<a class="a_update" href='input.php?id=<?= $rec['id_schedule'] ?>&page=<?= $page ?>&<?= query_from_http_arg_pool($http_arg) ?>'>[概要編集]</a>
		<a class="a_update" href='edit-marker.php?id=<?= $rec['id_schedule'] ?>&page=<?= $page ?>&<?= query_from_http_arg_pool($http_arg) ?>'>[地点編集]</a>
		<?php } ?>
		</p>
<?php		if ($rec['c_place'] <> '') { ?>
		<p class="diary_list_hotel">宿泊：<?= my_htmlspecialchars($rec['c_place']) ?></p>
<?php		} ?>
	</td>
	</tr>
<?php
		$line++;
	}
?>
	</table>
</form>
