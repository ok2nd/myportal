<?php
	require("__include-common.php");
	require("../account/__logincheck.php");
	if (GOOGLE_MAPS_API_VERSION == 'V3') {
		require("__include-maps-v3.php");
	} else {
		require("__include-maps.php");
	}
?>
<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="utf-8">
<meta name="author" content="ok.2nd">
<link rel="stylesheet" href="<?= _STYLE_SHEET_FOLDER_COMMON ?>/common.css?20131130">
<link rel="stylesheet" href="<?= _STYLE_SHEET_BUTTON ?>">
<title>MyHome 旅行記 マップ</title>
<style>
html {
	width: 100%;
	height: 100%;
	overflow: hidden;
}
body {
	width: 100%;
	height: 100%;
}
#form {
	margin: 5px 0 0 5px;
}
#map_frame {
	width: 100%;
	height: 100%;
}
#map3d {
	position: absolute;
	margin-left: 0px;
	top: 30px; left: 0px;
	width: 100%;
}
a { color: blue; }
#side_bar {
	position: absolute; top: 80px; right: 6px; width: 120px; height: 70%;
	border: 1px solid #666; padding: 6px; line-height: 1.4; overflow:scroll;
/*	background: #ffffff; filter: alpha(opacity=75); -moz-opacity:0.75; opacity:0.75; */
	background: url(../images/trans-white.png);
}
#side_bar li {
	white-space: nowrap;
}
#route_navi {
	position: absolute;
	top: 30px; left: 0px; width: 200px; height: 90%;
	border: 1px solid #666; padding: 6px; line-height: 1.4; overflow:scroll;
/*	background: #ffffff; filter: alpha(opacity=75); -moz-opacity:0.75; opacity:0.75; */
	background: url(../images/trans-white.png);
}
#panorama {
	position: absolute; bottom: 15px; right: 40px; width: 45%; height: 45%;
	border: 1px solid #666; padding: 0px; line-height: 1.4; overflow: hidden;
	background: #ffffff;
}
#panowin {
	position: relative; width: 100%; height: 100%;
	border-top: 1px solid #666; padding: 0px;
}
#map_canvas {
	width: 100%;
	height: 100%;
}
@media print {
	#form { display: none; }
	#side_bar { display: none; }
	#route_navi { display: none; }
	#map_canvas { position: absolute; top: 0px; left: 0px; }
}
</style>
<script src="../scripts/jquery.js"></script>
</head>
<body onunload="GUnload()">
<?php
	$con = my_mysqli_connect(_DB_SCHEMA);
	if ($_GET['multi'] <> '') {
		google_map_multi($_GET['multi'], 'full');
	} else {
		$sql = "select * from m_schedule where id_schedule = ".$_GET['id'];
		$rs = my_mysqli_query($sql);
		$rec = mysqli_fetch_array($rs);
		google_map_view($rec['id_schedule'], $rec['c_mapCenterLat'], $rec['c_mapCenterLng'], $rec['c_mapZoomLevel'], '', 'full');
	}
	mysqli_close($con);
?>
</body>
</html>
