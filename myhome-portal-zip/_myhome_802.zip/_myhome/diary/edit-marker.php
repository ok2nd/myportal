<?php
	require("__include-common.php");
	require("../account/__logincheck.php");
	require("../__common__/include-common-mp-list.php");

	$mp_list_arg = array();
	$mp_list_arg['account_id']	= $_SESSION['current_id'];
	$mp_list_arg['table_name_view']	= "m_marker";
	$mp_list_arg['table_name_edit']	= "m_marker";
	$mp_list_arg['id_item']		= "id_marker";
	$mp_list_arg['must_item']	= "c_place";
	$mp_list_arg['input_new']	= "no";
	$mp_list_arg['list_filter']	= "no";
	$mp_list_arg['sql_create_callback']	= "my_mp_list_sql_create";
	if ($_GET['ret'] <> '') {
		$mp_list_arg['update_redirect'] = $_GET['ret'];
	} else {
		$mp_list_arg['update_redirect'] = "list.php";
	}
	$mp_list_arg['add_row_use']	= "no";		// 追加行なし
	$item_tbl = array();
	$item_tbl[] = array(	"表示名"=>"順番", "列名"=>"c_order",
				"type"=>"text", "size"=>5, "ime-mode"=>"disabled", "toInt"=>"Y");
	$item_tbl[] = array(	"表示名"=>"場所", "列名"=>"c_place",
				"type"=>"text", "size"=>40, "ime-mode"=>"active", "文字検索"=>"Y");
	$item_tbl[] = array(	"表示名"=>"種別",	"列名"=>"id_markertype", "http_arg_GET名"=>"type",
				"type"=>"select", "参照テーブル"=>"r_markertype", "参照テーブルユーザー"=>"共有", "filter_c_delete"=>"no",
				"参照テーブル表示列"=>"c_markertype", "参照テーブル表示順"=>"id_markertype");
	$item_tbl[] = array(	"表示名"=>"費用<br>通貨", "列名"=>"c_price",
				"type"=>"text", "size"=>8, "ime-mode"=>"disabled", "toInt"=>"Y", "break"=>"後");
	$item_tbl[] = array(	"表示名"=>"通貨", "列名"=>"c_priceUnit",
				"type"=>"select", "select_options"=>PRICE_UNIT_SELECT, "break"=>"前");
	$caption = explode(",", DIARY_RATING_CAPTION);
	$cap_num = count($caption);
	for ($ix=0; $ix<$cap_num; $ix++) {
			$d_name = $caption[$ix];
			if (strlen($d_name) > 2) {
				$d_name = left($d_name,2).'<br>'.mb_substr($d_name,2);
			}
			$item_tbl[] = array(	"表示名"=>$d_name, "列名"=>"c_rating".$ix,
				"type"=>"select", "select_num_min"=>1, "select_num_max"=>5, "select_space"=>"Y", "toInt"=>"Y");
	}
	$item_tbl[] = array(	"表示名"=>"メモ",	"列名"=>"c_comment",
				"type"=>"textarea", "cols"=>50, "rows"=>3, "文字検索"=>"Y");
	$order_tbl = array();
	$order_tbl[] = array(	"表示名"=>"表示順", "get_order_name"=>"order",
				"order_by"=>"c_order, id_marker asc");		/* default */
	$http_arg = array();
	$http_arg['pl'] = PAGE_LINE_DEFAULT;		// mp_list 必須
	$http_arg['sort'] = '';				// mp_list 必須
	$http_arg['cat'] = '';				// mp_list 必須
	$http_arg['key'] = '';				// mp_list 必須
	if (isset($_POST['登録'])) {
		check_post_account($_POST['login_id'], $_POST['current_id']);
		mp_list_update($mp_list_arg, $item_tbl, $order_tbl, $http_arg);
	} else {
		_GET_to_http_arg_pool($http_arg, $table_name);
		html_header(HTML_TITLE);
		page_header();
		contents_header();
		mp_list_edit($mp_list_arg, $item_tbl, $order_tbl, $http_arg);
		page_footer();
		html_footer();
	}
	exit();
// ****************************************************************
function my_mp_list_sql_create($account_id, $table_name, $item_tbl, $order_tbl, $sortorder, $keystring, $sel_filter, $use_privacy, $add_where="") {
// ****************************************************************
	$sql = "select * from m_marker";
	$sql .= " where id_account = '".$account_id."' and id_schedule = ".intval($_GET['id']);
	$sql .= " and c_delete = 0 order by c_order, id_marker";
	return($sql);
}
?>
