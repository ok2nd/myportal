<?php
	require("__include-common.php");
	if ($_SESSION[SESSION_PREFIX.'_SCRIPT_NAME'] <> '') {
		header("Location: ".$_SESSION[SESSION_PREFIX.'_SCRIPT_NAME']."?".$_SERVER['QUERY_STRING']);
	} else {
		header("Location: list.php?".$_SERVER['QUERY_STRING']);
	}
?>
