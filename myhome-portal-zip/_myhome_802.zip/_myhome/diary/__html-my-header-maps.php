<meta charset="utf-8">
<meta name="author" content="ok.2nd">
<meta name="description" content="Diary">
<meta name="keywords" content="Diary,日記,旅行記">
<link rel="stylesheet" href="<?= _STYLE_SHEET_FOLDER_COMMON ?>/common.css?20131130">
<link rel="stylesheet" href="<?= _STYLE_SHEET_BUTTON ?>">
<link rel="stylesheet" href="<?= _STYLE_SHEET_FOLDER ?>/mp-list.css?20130525">
<link rel="stylesheet" href="<?= _STYLE_SHEET_FOLDER ?>/diary.css?20100131">
<link rel="stylesheet" href="<?= _STYLE_SHEET_FOLDER ?>/calendar.css?20141108">
<style>
#form {
	margin: 5px 0 0 5px;
}
#map_frame {
	position: relative;
	width: <?= DIARY_MAPS_FRAME_WIDTH ?>;
/*	height: <?= DIARY_MAPS_FRAME_HEIGHT ?>;	*/
	margin: 2px 0 0 0;
}
#map_canvas {
	width: 100%;
	height: 100%;
	margin: 0;
	padding: 0;
}
#side_bar {
	position: absolute;
	top: 45px; right: 6px; width: 120px; height: 70%;
	border: 1px solid #666; padding: 6px; line-height: 1.4; overflow:scroll;
/*	background: #ffffff; filter: alpha(opacity=75); -moz-opacity:0.75; opacity:0.75; */
	background: url(../images/trans-white.png);
}
#side_bar li {
	white-space: nowrap;
}
#panorama {
	position: absolute; bottom: 15px; right: 6px; width: 50%; height: 45%;
	border: 1px solid #666; padding: 0px; line-height: 1.4; overflow: hidden;
	background: #ffffff;
}
#panowin {
	position: relative; width: 100%; height: 100%;
	border-top: 1px solid #666; padding: 0px;
}
</style>
<?php if (strstr($_SERVER['HTTP_USER_AGENT'], "MSIE 6.")) { ?>
<script src="../scripts/jquery-1.3.2.js"></script>
<?php } else { ?>
<script src="../scripts/jquery.js"></script>
<?php } ?>
<script src="../scripts/jquery.cookie.js"></script>
<script src="../scripts/ok2nd.js"></script>
