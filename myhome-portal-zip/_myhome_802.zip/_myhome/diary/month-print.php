<?php
	define("CALENDAR_DIARY_MODE", "diary");
	require("../calendar/month-print.php");
?>