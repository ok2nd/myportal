<?php
	require("__include-common.php");
	require("../account/__logincheck.php");
	require("../__common__/include-common-mp-list.php");
	if ($_SESSION['システム管理者'] <> "YES") {
		error_exit("不正アクセス：編集権限がありません。", True);
	}
	$mp_list_arg = array();
	$mp_list_arg['account_id']	= "ALL";		// 共通
	$mp_list_arg['table_name_view']	= "r_markertype";
	$mp_list_arg['table_name_edit']	= "r_markertype";
	$mp_list_arg['id_item']		= "id_markertype";
	$mp_list_arg['must_item']	= "id_markertype";
	$mp_list_arg['input_new']	= "no";
	$mp_list_arg['list_filter']	= "no";
	$mp_list_arg['list_edit_right_add_html']	= "in-block-image.php";
	$mp_list_arg['view_description']	= '※ アイコンファイルは、フォルダ「'.DIARY_MAPS_ICON_FOLDER .'」(<a href="../tools/file-manager.php?path='.urlencode(realpath(DIARY_MAPS_ICON_FOLDER)).'" target="_blank">'.realpath(DIARY_MAPS_ICON_FOLDER).'</a>)を使います。';

	$item_tbl = array();
	$item_tbl[] = array(	"表示名"=>"ID", "列名"=>"id_markertype",
				"type"=>"text", "size"=>5, "ime-mode"=>"disabled", "toInt"=>"Y");
	$item_tbl[] = array(	"表示名"=>"マーカー種別", "列名"=>"c_markertype",
				"type"=>"text", "size"=>20, "ime-mode"=>"active");
	$item_tbl[] = array(	"表示名"=>"アイコンファイル", "列名"=>"c_markericon",
				"イメージ表示列名"=>"c_markericon",
				"type"=>"text", "size"=>40, "ime-mode"=>"inactive");
	$order_tbl = array();
	$order_tbl[] = array(	"表示名"=>"表示順", "get_order_name"=>"cate",
				"order_by"=>"id_markertype asc");		/* default */
	$http_arg = array();
	$http_arg['pl'] = PAGE_LINE_DEFAULT;		// mp_list 必須
	$http_arg['sort'] = '';				// mp_list 必須
	$http_arg['cat'] = '';				// mp_list 必須
	$http_arg['key'] = '';				// mp_list 必須
	if (isset($_POST['登録'])) {
		check_post_account($_POST['login_id'], $_POST['current_id']);
		mp_list_update($mp_list_arg, $item_tbl, $order_tbl, $http_arg);
	} else {
		_GET_to_http_arg_pool($http_arg, $table_name);
		html_header(HTML_TITLE, '', '#ffffff');
		page_header();
		contents_header('off');
		if ($_GET['edit'] == "y") {
			mp_list_edit($mp_list_arg, $item_tbl, $order_tbl, $http_arg);
		} else {
			mp_list_view($mp_list_arg, $item_tbl, $order_tbl, $http_arg);
		}
		page_footer();
		html_footer();
	}
	exit();
?>
