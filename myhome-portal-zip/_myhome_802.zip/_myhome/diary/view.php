<?php
	require("__include-common.php");
	require("../account/__logincheck.php");
	require("../calendar/_my_calendar.php");
	require("__include-view.php");
	if (GOOGLE_MAPS_API_VERSION == 'V3') {
		require("__include-maps-v3.php");
		html_header(HTML_TITLE, '', '', '', '', '__html-my-header-maps.php');
	} else {
		require("__include-maps.php");
		html_header(HTML_TITLE, '', '', ' onunload="GUnload()"', '', '__html-my-header-maps.php');
	}
	page_header();
	contents_header('off');
	view_thread();
	page_footer();
	html_footer();
	exit();
function view_thread() {
	if ($_POST['multi'].'' <> '') {
		$chks = $_POST['check'];
		if (!$chks) {
			error_exit('1件以上、選択してください。', True, False);
		}
		$chk_id = '';
		foreach($chks as $chk){
			if ($chk_id <> '') $chk_id .= ',';
			$chk_id .= $chk;
		}
	} elseif ($_GET['id'].'' <> '') {
		$id = intval($_GET['id']);
	} elseif ($_GET['move'].'' <> '') {
		$move = intval($_GET['move']);
		$id = 0;
	} elseif ($_GET['year'].'' <> '') {
		$year = intval($_GET['year']);
		$month = intval($_GET['month']);
		$day = intval($_GET['day']);
	} else {
		error_exit("不正アクセス。(2)<br>", False);
	}
	if ($_GET['page'].'' <> '') {
		$page = intval($_GET['page']);
	}
	if ($_GET['row'].'' <> '') {
		$row = intval($_GET['row']);
	}
	if ($_GET['pl'].'' <> '') {
		$pageline = intval($_GET['pl']);
	}
	$con = my_mysqli_connect(_DB_SCHEMA);
	if ($chk_id == '' and $id == 0) {
		if (isset($year)) {
			$datestr = date("Y-m-d", mktime(0, 0, 0, $month, $day, $year));
			$sql = "select * from v_schedule where c_date = '".$datestr."' and c_delete = 0";
		} elseif ($_SESSION['diary_list_sql'].'' == '') {
			error_exit("不正アクセス。(3)<br>", False);
		} else {
			$sql = $_SESSION['diary_list_sql'];
		}
		$rs = my_mysqli_query($sql);
		if ($rs) {
			if (empty($year) and $row < $move+1) {
?>
				<div class="view_form">
				<h3 class="s_title">
				<?= CALENDAR_FILTER_TITLE ?>がありません。
				<a class="a_cancel_back" href='list.php?cat=<?= $_GET['cat'] ?>&ac=<?= $_GET['ac'] ?>&del=<?= $_GET['del'] ?>&key=<?= urlencode($_GET['key']) ?>&sort=<?= $_GET['sort'] ?>&page=<?= $page ?>&pl=<?= $pageline ?>'>一覧に戻る</a>
				</h3>
				</div>
<?php
				return;
			}
			mysqli_data_seek($rs, $move);
			$rec = mysqli_fetch_array($rs);
			$id = $rec['id_schedule'];
		}
	}
	if ($chk_id <> '') {
		$sql = "select * from v_schedule where id_schedule in (".$chk_id.')';
	} else {
		$sql = "select * from v_schedule where (id_schedule = ".$id.")";
	}
	$rs = my_mysqli_query($sql);
?>
<div class="view_form">
<?php
	if ($_GET['page'] <> '') {
		$move = intval($_GET['move']);
		$page = ceil(($move+1)/$pageline);
	}
?>
	<table class="view_head" cellspacing=0><tr><td class="view_category">
		<?php	if ($_GET['page']<>'') { ?>
	<span class="view_page"><span class="view_page_num"><?= $move+1 ?></span> / <span class="view_page_num"><?= $row ?></span></span>
	<?php if ($move <> 0) { ?>
	<a class="a_view_move" href="<?= $_SERVER['SCRIPT_NAME'] ?>?move=0&row=<?= $row ?>&cat=<?= $_GET['cat'] ?>&ac=<?= $_GET['ac'] ?>&del=<?= $_GET['del'] ?>&key=<?= urlencode($_GET['key']) ?>&sort=<?= $_GET['sort'] ?>&page=<?= $page ?>&pl=<?= $pageline ?>">[先頭←]</a>
	<a class="a_view_move" href="<?= $_SERVER['SCRIPT_NAME'] ?>?move=<?= $move-1 ?>&row=<?= $row ?>&cat=<?= $_GET['cat'] ?>&ac=<?= $_GET['ac'] ?>&del=<?= $_GET['del'] ?>&key=<?= urlencode($_GET['key']) ?>&sort=<?= $_GET['sort'] ?>&page=<?= $page ?>&pl=<?= $pageline ?>">[前←]</a>
	<?php } else { ?>
	<span class="view_link_off">[←先頭]</span>
	<span class="view_link_off">[←前]</span>
	<?php } ?>
	<?php if ($move < $row-1) { ?>
	<a class="a_view_move" href="<?= $_SERVER['SCRIPT_NAME'] ?>?move=<?= $move+1 ?>&row=<?= $row ?>&cat=<?= $_GET['cat'] ?>&ac=<?= $_GET['ac'] ?>&del=<?= $_GET['del'] ?>&key=<?= urlencode($_GET['key']) ?>&sort=<?= $_GET['sort'] ?>&page=<?= $page ?>&pl=<?= $pageline ?>">[→次]</a>
	<a class="a_view_move" href="<?= $_SERVER['SCRIPT_NAME'] ?>?move=<?= $row-1 ?>&row=<?= $row ?>&cat=<?= $_GET['cat'] ?>&ac=<?= $_GET['ac'] ?>&del=<?= $_GET['del'] ?>&key=<?= urlencode($_GET['key']) ?>&sort=<?= $_GET['sort'] ?>&page=<?= $page ?>&pl=<?= $pageline ?>">[→最後]</a>
	<?php } else { ?>
	<span class="view_link_off">[→次]</span>
	<span class="view_link_off">[→最後]</span>
	<?php } ?>
		<?php	} ?>
	<a class="a_view_move" href="<?= $_SESSION['diary_back_view'] ?>">[<?= $_SESSION['diary_back_view_name'] ?>]</a>
	</td></tr></table>
<?php
	if (VIDEO_PREVIEW == 'YES') {
?>
	<script src="../scripts/JWPlayer/swfobject.js"></script>
	<script src="../scripts/JWPlayer/movie_preview.js"></script>
	<script src="../scripts/JWPlayer/silverlight.js"></script>
	<script src="../scripts/JWPlayer/wmvplayer.js"></script>
<?php
	}
?>
<?php
	if ($chk_id <> '') {
		google_map_multi($chk_id);
		cost_list($chk_id);
		place_list($chk_id, 'multi');
	} elseif ($rec = mysqli_fetch_array($rs)) {
		diary_view($rec, $rec['id_schedule'], $page, $move, $row, $pageline);
		google_map_view($rec['id_schedule'], $rec['c_mapCenterLat'], $rec['c_mapCenterLng'], $rec['c_mapZoomLevel'], $rec['c_mapHeight']);
		cost_list($rec['id_schedule']);
		place_list($rec['id_schedule']);
	}
}
?>
<?php
function diary_view($rec, $id, $page, $move, $row, $pageline) {
?>
<div class="xboxcontent">
	<table class="diary_thread_table" cellspacing=1>
	<tr>
		<th class="diary_thread_subject"><?= my_htmlspecialchars($rec['c_subject']) ?></th>
		<th class="diary_thread_subject_side">
		<?php if (check_permit_id($_SESSION['login_id'], $_SESSION['current_id']) == "w") { ?>
			<a class="a_diary_update" href="input.php?id=<?= $id ?>&move=<?= $move ?>&row=<?= $row ?>&cat=<?= $_GET['cat'] ?>&key=<?= urlencode($_GET['key']) ?>&sort=<?= $_GET['sort'] ?>&page=<?= $page ?>&pl=<?= $pageline ?>&#input">[概要編集]</a>
			<a class="a_diary_update" href="edit-marker.php?id=<?= $id ?>&move=<?= $move ?>&row=<?= $row ?>&cat=<?= $_GET['cat'] ?>&key=<?= urlencode($_GET['key']) ?>&sort=<?= $_GET['sort'] ?>&page=<?= $page ?>&pl=<?= $pageline ?>&ret=view.php&#input">[マーカー地点編集]</a>
		<?php } ?>
		</th>
	</tr>
	<tr class="diary_thread_date">
		<td colspan=2>
		<span class="diary_list_date"><?= date_from_mysql("Y-m-d", $rec['c_date']) ?></span> (<?= day_week_view($rec['c_date']) ?>)
		<?= my_htmlspecialchars($rec['c_categoryName']) ?>
		<?php	if ($rec['c_country'] <> '') { ?>
			<span class="diary_thread_country"><?= my_htmlspecialchars($rec['c_country']) ?></span>
		<?php	} ?>
		<?php	if ($rec['c_currencyUnit'] <> '円') { ?>
			通貨：<span class="diary_thread_currencyUnit"><?= my_htmlspecialchars($rec['c_currencyUnit']) ?></span>
			為替レート：1<?= my_htmlspecialchars($rec['c_currencyUnit']) ?> = <span class="diary_thread_exchangeRate"><?= my_htmlspecialchars($rec['c_exchangeRate']) ?></span>円
		<?php	} ?>
		</td>
	</tr>
	<tr class="diary_thread_body">
		<td class="diary_thread_memo">
		<?php
			$http_arg = http_arg_from_session_pool('calendar_schedule');
		?>
		<p><?= ins_atag_br($rec['c_memo']) ?></p>
		</td>
		<td class="diary_thread_photo">
		<?php
			$filename1 = $rec['c_attachFile1'];
			$filename2 = $rec['c_attachFile2'];
			$filename3 = $rec['c_attachFile3'];
			if ($filename1 <> "" || $filename2 <> "" || $filename3 <> "") {
		?>
			<p>
		<?php
				attach_file_view($rec['id_account'], $filename1, '<br>', VIEW_PHOTO_WIDTH,
					True, True, True, VIDEO_PREVIEW_WIDTH, VIDEO_PREVIEW_HEIGHT);
				attach_file_view($rec['id_account'], $filename2, '<br>', VIEW_PHOTO_WIDTH,
					True, True, True, VIDEO_PREVIEW_WIDTH, VIDEO_PREVIEW_HEIGHT);
				attach_file_view($rec['id_account'], $filename3, '<br>', VIEW_PHOTO_WIDTH,
					True, True, True, VIDEO_PREVIEW_WIDTH, VIDEO_PREVIEW_HEIGHT);
		?>
			</p>
		<?php
			}
		?>
		</td>
	</table>
</div>
<?php
	jquery_highlight('.diary_thread_memo', keystr_and_or(keystr_fix($http_arg['key'])));
?>
<?php
}
?>
