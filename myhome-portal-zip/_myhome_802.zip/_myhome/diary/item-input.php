<?php
	require("__include-common.php");
	require("../account/__logincheck.php");

	ini_set("memory_limit", FILE_UPLOAD_MEMORY_LIMIT);		//メモリサイズ
	ini_set("max_execution_time", FILE_UPLOAD_MAX_EXECUTION_TIME);	//最大実行時間
	if ($_POST) {
// *********************************************************************************
// * max_execution_time
// * post_max_size
// * upload_max_filesizeを越えるとisset($_POST['登録'])がTrueにならない。
// *********************************************************************************
		check_post_account($_POST['login_id'], $_POST['current_id']);
		post_done_proc();
	} else {
		html_header(HTML_TITLE, '', '', ' onload="document.form0.c_place.focus()"');
		page_header();
		input_form();
		page_footer();
		html_footer();
	}
	exit();
?>
<?php
function post_done_proc() {
	if ($_POST['user_id']."" <> "") {
		$user_id = $_POST['user_id'];
	} else {
		error_exit("不正アクセス：ユーザーIDなし。", True);
	}
	if (check_permit_id($_SESSION['login_id'], $user_id) != "w") {
		error_exit("不正アクセス：書き込み権限がありません。", True);
	}
	if ($_POST['update_id']) {
		if (!is_numeric($_POST['update_id'])) {
			error_exit("不正アクセス", True);
		}
		$mid = intval($_POST['update_id']);
	} else {
		$mid = 0;
	}
	if (isset($_POST['削除'])) {
		//	if ($_POST['削除する'] <> "YES") {
		//		error_exit("削除するにチェックしてください。", True);
		//	}
	} elseif ($_POST['c_place'] == "") {
		error_exit("場所なし", True);
	}
	$con = my_mysqli_connect(_DB_SCHEMA);
	if ($mid == 0) {
		error_exit("不正アクセス", True);
	} elseif ($_POST['削除'] <> "") {
		$sql = "update m_marker set";
		$sql .= " c_delete = 999";
		$sql .= ", c_updatetime = '". date("Y/m/d H:i:s") . "'";
		$sql .= " where id_marker = ".$mid;
		$sql .= " and id_account = ".$user_id;
		$ret = my_mysqli_query($sql, "削除できませんでした。");
	} else {
		$sql = "update m_marker set";
		$sql .= " c_place = '".post_to_mysql("c_place")."'";
		$sql .= ", c_comment = '".post_to_mysql("c_comment")."'";
		$sql .= ", c_price = '".post_to_mysql("c_price")."'";
		$sql .= ", id_markertype = '".post_to_mysql("id_markertype")."'";
		$sql .= ", c_priceUnit = '".post_to_mysql("c_priceUnit")."'";
		$sql .= ", c_priceMemo = '".post_to_mysql("c_priceMemo")."'";
		$sql .= ", c_rating0 = '".post_to_mysql("c_rating0")."'";
		$sql .= ", c_rating1 = '".post_to_mysql("c_rating1")."'";
		$sql .= ", c_rating2 = '".post_to_mysql("c_rating2")."'";
		$sql .= ", c_rating3 = '".post_to_mysql("c_rating3")."'";
		$sql .= ", c_rating4 = '".post_to_mysql("c_rating4")."'";
		$sql .= ", c_rating5 = '".post_to_mysql("c_rating5")."'";
		$sql .= ", c_rating6 = '".post_to_mysql("c_rating6")."'";
		$sql .= ", c_rating7 = '".post_to_mysql("c_rating7")."'";
		$sql .= ", c_rating8 = '".post_to_mysql("c_rating8")."'";
		$sql .= ", c_updatetime = '". date("Y/m/d H:i:s") . "'";
		$sql .= " where id_marker = ".$mid;
		$sql .= " and id_account = ".$user_id;
		$ret = my_mysqli_query($sql, "更新できませんでした。");
	}
	// ****** 添付ファイル ******
	if ($mid == 0) {
		$mid = my_mysqli_insert_id();	//直近のINSERTクエリによりAUTO_INCREMENTカラム用に生成されたIDを取得
	}
	$sw = False;
	$sqlupd = "";
	for ($ix=1; $ix<=3; $ix++) {
		// ***** ファイルのアップロード *****
		$attachFile = file_upload("filename".$ix, $mid, ATTACH_FILE_FOLDER_diary_marker, $user_id);
		if ($attachFile <> "") {
			if ($sw) {
				$sqlupd .= ",";
			}
			$sqlupd .= " c_attachFile" . $ix . " = '" . $attachFile . "'";
			$sw = True;
		} else if ($_POST['fileDelete'.$ix] == "YES") {
			if ($sw) {
				$sqlupd .= ",";
			}
			$sqlupd .= " c_attachFile" . $ix . " = ''";
			$sw = True;
		}
	}
	if ($sw) {
		$sql = "update m_marker set";
		$sql .= $sqlupd;
		$sql .= " where id_marker = ".$mid;
		$sql .= " and id_account = '".$user_id."'";
			//echo $sql;
			//exit;
		$ret = my_mysqli_query($sql, "アップロードファイル名DB登録失敗。");
	}
	mysqli_close($con);
	redirect($_POST['return_http']);		// 元のページに戻る
}
function input_form() {
	if ($_GET['mid'] <> "") {
		$mid = $_GET['mid'];
		if ($_GET['page'] <> "") {
			$page = $_GET['page'];
		}
	} else {
		error_exit("不正アクセス", True);
	}
	$con = my_mysqli_connect(_DB_SCHEMA);
	$sql = "select * from v_marker where id_marker = ".$mid." and c_delete = 0";
	$sql .= " and id_account = ".$_SESSION['current_id'];
	$rs = my_mysqli_query($sql);
	$rec = mysqli_fetch_array($rs);

	$sql = "select * from m_schedule where id_schedule = ".$rec['id_schedule'];
	$rs2 = my_mysqli_query($sql);
	$rec2 = mysqli_fetch_array($rs2);
?>
<div class="input_form">
<h3><?= date_from_mysql("Y/m/d", $rec2['c_date']) ?>：<?= $rec2['c_subject'] ?>
<a class="a_cancel_back" href='javascript:history.back();'>戻る</a></h3>
<script>
function formCheck(form) {
	if (form.c_place.value == '') {
		window.alert('場所を入れてください。');
		return false;		// 送信を中止
	}
	return true;	// 送信を実行
}
</script>
<form name="form0" method="POST" action="<?= $_SERVER['SCRIPT_NAME'] ?>?<?= $_SERVER['QUERY_STRING'] ?>" enctype="multipart/form-data" onSubmit="return formCheck(this)">
	<input type="hidden" name="return_http" value="<?= $_SERVER['HTTP_REFERER']?>">
	<input type="hidden" name="user_id" value="<?= $_SESSION['current_id'] ?>">
	<input type="hidden" name="update_id" value="<?= $mid ?>">
	<input type="hidden" name="login_id" value="<?= $_SESSION['login_id'] ?>">
	<input type="hidden" name="current_id" value="<?= $_SESSION['current_id'] ?>">
	<input type="hidden" name="return_php" value="<?= $_GET['ret'] ?>">
<table>
<tr>
	<td>場所</td>
	<td>
		<input class="text" type="text" name="c_place" size=50 value="<?= my_htmlspecialchars($rec['c_place']) ?>">
	</td>
</tr>
<tr>
	<td>種別</td>
	<td class="input_form_td">
		<select name="id_markertype">
		<?php
			$sqlsel = "select * from r_markertype where c_delete = 0 order by id_markertype";
			$rs_sel = my_mysqli_query($sqlsel);
			while ($rec_sel=mysqli_fetch_array($rs_sel)) {
		?>
		<option value="<?= $rec_sel['id_markertype'] ?>"<?= $rec_sel['id_markertype'] == $rec['id_markertype'] ? " selected" : "" ?>>
			<?= my_htmlspecialchars($rec_sel['c_markertype']) ?>
		<?php
			}
		?>
		</select>
	</td>
</tr>
<tr>
	<td>メモ</td>
	<td>
		<div class="block_left">
		<?php
			$str = my_htmlspecialchars($rec['c_comment']);
			$rows = textarea_rows($str, 480) + 1;
			if ($rows < 10) {
				$rows = 10;
			} elseif (strstr($_SERVER['HTTP_USER_AGENT'], "MSIE") and $rows > 30) {
				$rows = 30;
			}
			if (strstr($_SERVER['HTTP_USER_AGENT'], "MSIE")) {
				$textarea_width = 420;
			} else {
				$textarea_width = 450;
			}
		?>
		<textarea id="c_comment" name="c_comment" style="width:<?= $textarea_width ?>px;" rows="<?= $rows ?>" wrap="soft"><?= $str ?></textarea>
		</div>
		<?php	if (strstr($_SERVER['HTTP_USER_AGENT'], "MSIE")) { ?>
			<div class="block_left">
			<input type="button" value="小" OnClick="textareaBigSmall('c_comment','小')"><br>
			<input type="button" value="大" OnClick="textareaBigSmall('c_comment','大')">
			</div>
		<?php	} ?>
	</td>
</tr>
<tr>
	<td>費用</td>
	<td>
		<input class="text" type="text" name="c_price" size=10 value="<?= my_htmlspecialchars($rec['c_price']) ?>" style="ime-mode:disabled;">
		<?php
			select_view_options('', 'c_priceUnit', '', PRICE_UNIT_SELECT, $rec['c_priceUnit']);
		?>
		<input class="text" type="text" name="c_priceMemo" size=50 value="<?= my_htmlspecialchars($rec['c_priceMemo']) ?>">
	</td>
</tr>
<tr>
	<td>評価</td>
	<td>
		<?php
			$caption = explode(",", DIARY_RATING_CAPTION);
			$cap_num = count($caption);
			for ($ix=0; $ix<$cap_num; $ix++) {
				select_view_with_id_with_blank($caption[$ix], 'c_rating'.$ix, '', 1, 5, $rec['c_rating'.$ix]);
			}
		?>
	</td>
</tr>
<tr>
	<td>添付文書</td>
	<td>
<?php	if (VIDEO_PREVIEW == 'YES') { ?>
	<!--<p><span class="alarm_text">ファイル名が英数字以外のFLV,MP4ファイルは動画再生できません。</span></p>-->
<?php	} ?>
<?php if ($rec['c_attachFile1'] <> "" || $rec['c_attachFile2'] <> "" || $rec['c_attachFile3'] <> "") { ?>
	<p><span class="alarm_text">再度添付ファイル名を指定すると登録済ファイルに上書きされます。</span></p>
<?php } ?>
<?php
	for ($ix=1; $ix<=3; $ix++) {
?>
		<div class="block">
		<div class="block_left">(<?= $ix ?>)</div>
		<div class="block_left">
<?php
		if ($rec['c_attachFile'.$ix] <> "") {
			attach_file_view($rec['id_account'], $rec['c_attachFile'.$ix], '', 50,
					True, True, False, 100, 75, ATTACH_FILE_FOLDER_diary_marker);
?>
		<label><input type="checkbox" name="fileDelete<?= $ix ?>" value="YES">削除</label>
		<input type="hidden" name="filenameCurrent<?= $ix ?>" value="<?= $rec['c_attachFile'.$ix] ?>">
<?php
		}
?>
		<input type="file" size=40 name="filename<?= $ix ?>" style="button-font-size:small">
		</div>
		</div>
<?php
	}
?>
	</td>
</tr>
</table>
<?php
	if ($mid == 0) {
?>
	<input class="input_form_button" type="submit" name="登録" value="登録">
<?php
	} else {
?>
	<input class="input_form_button" type="submit" name="登録" value="修正">
	<input class="input_form_button" type="submit" name="削除" value="削除" onClick="return delete_check();" style="margin-left:20px;">
<?php
	}
?>
</form>
<script>
function delete_check() {
	if (window.confirm('このデータを削除しますか？')) {
		return true;
	} else {
		return false;
	}
}
</script>
<?php	if (!strstr($_SERVER['HTTP_USER_AGENT'], "MSIE")) { ?>
<script src="../scripts/autoresize.jquery.min.js"></script>
<script>
$('textarea#c_comment').autoResize({
	onResize : function() {
		$(this).css({opacity:0.8});
	},
	animateCallback : function() {
		$(this).css({opacity:1});
	},
	animateDuration : 300,
	extraSpace : 20
});
$('textarea#c_comment').trigger('change'); // 初期表示時に自動リサイズさせるためchangeイベント実行
</script>
<?php	} ?>
<?
}
function select_view_with_id_with_blank($prefix, $name, $suffix, $first, $end, $now) {
	echo $prefix;
	echo "<select id='".$name."' name='".$name."'>";
	echo "<option value=''>";
	for ($i=$first; $i<=$end; $i++) {
		echo "<option value='".$i."'";
		if ($i == $now) {
			echo " selected";
		}
		echo ">".$i."</option>";
	}
	echo "</select>".$suffix;
}
function select_view_options($prefix, $name, $suffix, $options, $now) {
	$option_ary = explode(",", $options);
	echo $prefix;
	echo "<select id='".$name."' name='".$name."'>";
	foreach ($option_ary as $opt) {
		echo "<option value='".$opt."'";
		if ($opt == $now) {
			echo " selected";
		}
		echo ">".$opt."</option>";
	}
	echo "</select>".$suffix;
}
?>
