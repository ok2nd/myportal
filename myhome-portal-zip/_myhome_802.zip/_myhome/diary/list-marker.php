<?php
	require("__include-common.php");
	require("../account/__logincheck.php");
	require("../__common__/include-common-mp-list.php");
	require("../calendar/_my_calendar.php");

	$table_name_view = "v_marker";
	$table_name = "m_marker";
	$id_item = "id_marker";
	$must_item = "c_place";
	$arg_pool_prefix = "calendar_schedule";

	$mp_list_arg = array();
	$mp_list_arg['account_id']	= $_SESSION['current_id'];
	$mp_list_arg['table_name_view']		= "v_marker";
	$mp_list_arg['table_name_edit']		= "v_marker";
	$mp_list_arg['table_name_update']	= "m_marker";
	$mp_list_arg['id_item']		= "id_marker";
	$mp_list_arg['must_item']	= "c_place";
	$mp_list_arg['add_filter']	= "../calendar/list-my-add-filter.php";
	$mp_list_arg['template_view']	= "list-marker-template.php";
	$mp_list_arg['input_new']	= "no";
	$mp_list_arg['use_privacy']	= "no";
	$mp_list_arg['add_list']	= "no";
	$mp_list_arg['add_row_use']	= "no";		// 追加行なし
	$item_tbl = array();

	$item_tbl[] = array(	"表示名"=>"タイトル", "列名"=>"c_subject",
				"type"=>"no_edit_no_col", "width"=>160, "ime-mode"=>"active", "文字検索"=>"Y");
//	$item_tbl[] = array(	"表示名"=>"順番", "列名"=>"c_order",
//				"type"=>"text", "size"=>3, "ime-mode"=>"disabled", "toInt"=>"Y");
	$item_tbl[] = array(	"表示名"=>"場所", "列名"=>"c_place",
				"type"=>"text", "size"=>30, "ime-mode"=>"active", "文字検索"=>"Y");
	$item_tbl[] = array(	"表示名"=>"種別",	"列名"=>"id_markertype", "http_arg_GET名"=>"type",
				"type"=>"select", "参照テーブル"=>"r_markertype", "参照テーブルユーザー"=>"共有", "filter_c_delete"=>"no",
				"参照テーブル表示列"=>"c_markertype", "参照テーブル表示順"=>"id_markertype");
	$item_tbl[] = array(	"表示名"=>"費用<br>通貨", "列名"=>"c_price", "zero"=>"space",
				"type"=>"text", "size"=>11, "ime-mode"=>"disabled", "break"=>"後");
	$item_tbl[] = array(	"表示名"=>"通貨", "列名"=>"c_priceUnit",
				"type"=>"select", "filter_type"=>"no", "select_options"=>PRICE_UNIT_SELECT, "break"=>"前");
	$item_tbl[] = array(	"表示名"=>"費用備考", "列名"=>"c_priceMemo",
				"type"=>"text", "size"=>20, "ime-mode"=>"active");
	$caption = explode(",", DIARY_RATING_CAPTION);
	$cap_num = count($caption);
	for ($ix=0; $ix<$cap_num; $ix++) {
			$d_name = $caption[$ix];
			if (strlen($d_name) > 2) {
				$d_name = left($d_name,2).'<br>'.mb_substr($d_name,2);
			}
			$item_tbl[] = array(	"表示名"=>$d_name, "列名"=>"c_rating".$ix,
				"type"=>"select", "filter_type"=>"no", "select_num_min"=>1, "select_num_max"=>5, "select_space"=>"Y", "toInt"=>"Y");
	}
	$item_tbl[] = array(	"表示名"=>"メモ",	"列名"=>"c_comment",
				"type"=>"textarea", "width"=>250, "cols"=>50, "rows"=>3, "文字検索"=>"Y");
	$order_tbl = array();
	$order_tbl[] = array(   "表示名"=>"登録最新順", "get_order_name"=>"new",
				"order_by"=>"id_marker desc");		/* default */
	$order_tbl[] = array(   "表示名"=>"日付順(昇順)", "get_order_name"=>"date_a",
				"order_by"=>"c_date, c_order");
	$order_tbl[] = array(   "表示名"=>"日付順(降順)", "get_order_name"=>"date_d",
				"order_by"=>"c_date desc, c_order");
	for ($ix=0; $ix<$cap_num; $ix++) {
			$d_name = $caption[$ix];
			$order_tbl[] = array(   "表示名"=>$d_name, "get_order_name"=>"rating".$ix,
				"order_by"=>"c_rating".$ix." desc");
	}
	$http_arg = array();
	$http_arg['pl'] = PAGE_LINE_DEFAULT;		// mp_list 必須
	$http_arg['sort'] = '';				// mp_list 必須
	$http_arg['cat'] = '';				// mp_list 必須
	$http_arg['key'] = '';				// mp_list 必須
	$http_arg['type'] = '';
	$http_arg['selY'] = '';
	$http_arg['selM'] = '';
	$http_arg['selD'] = '';
	$http_arg['toY'] = '';
	$http_arg['toM'] = '';
	$http_arg['toD'] = '';
	$http_arg['y'] = '';
	$http_arg['m'] = '';

	if (isset($_POST['登録'])) {
		check_post_account($_POST['login_id'], $_POST['current_id']);
		mp_list_update($mp_list_arg, $item_tbl, $order_tbl, $http_arg);
	} else {
		_GET_to_http_arg_pool($http_arg, $arg_pool_prefix, 'selY,selM,selD,toY,toM,toD,sort,key,pl,y,m');
		html_header(HTML_TITLE);
		page_header();
		contents_header();
		if ($_GET['edit'] == "a") {
			$mp_list_arg['sql_for_edit'] = "select * from v_marker where id_marker = 0";
			mp_list_edit($mp_list_arg, $item_tbl, $order_tbl, $http_arg);
		} elseif ($_GET['edit'] == "y") {
			mp_list_edit($mp_list_arg, $item_tbl, $order_tbl, $http_arg);
		} else {
			$_SESSION['diary_back_view'] = $_SERVER['SCRIPT_NAME'].'?'.$_SERVER['QUERY_STRING'];
			$_SESSION['diary_back_view_name'] = '地点一覧に戻る';
			$_SESSION['diary_list_sql'] = mp_list_view($mp_list_arg, $item_tbl, $order_tbl, $http_arg);
		}
		page_footer();
		html_footer();
	}
	exit();
?>
