<?php
	require("__include-common.php");
	require("../account/__logincheck.php");
	if (check_permit_id($_SESSION['login_id'], $_SESSION['current_id']) != "w") {
		exit;	// 書き込み権限なし
	}
	$updateD = date("Y/m/d H:i:s");
	$con = my_mysqli_connect(_DB_SCHEMA);
	$sql = "insert into m_marker (";
	$sql .= "id_account, id_schedule, c_lat, c_lng, c_place, c_comment, c_order";
	$sql .= ", c_updatetime, c_registtime)";
	$sql .= " values (";
	$sql .= "'" . $_SESSION['current_id'] . "'";
	$sql .= ", '" . intval($_POST['pid']) . "'";
	$sql .= ", '" . post_to_mysql('lat') . "'";
	$sql .= ", '" . post_to_mysql('lng') . "'";
	$sql .= ", '" . post_to_mysql('place') . "'";
	$sql .= ", '" . post_to_mysql('comment') . "'";
	$sql .= ", '999'";
	$sql .= ", '" . $updateD . "'";
	$sql .= ", '" . $updateD . "'";
	$sql .= ")";
	mysqli_query($con, $sql);
	$id = my_mysqli_insert_id();
	mysqli_close($con);
	echo $id;
?>
