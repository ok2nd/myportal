<script src="../scripts/calendar.js"></script>
<style>
#map3d img { cursor: crosshair; }
</style>
