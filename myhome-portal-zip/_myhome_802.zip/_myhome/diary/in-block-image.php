<table><tr>
<td>
<?php
	images_print_noprint_ary(IMAGES_FOLDER, 3, array('msmarker.shadow.png'));
?>
</td>
</tr></table>
