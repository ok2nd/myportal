<?php
function cost_list($id) {
	$sql = "select * from v_marker";
	$sql .= " where id_account = '".$_SESSION['current_id']."' and id_schedule in (".$id.")";
	$sql .= " and c_delete = 0 and c_price <> 0 order by c_mdate, id_schedule, c_order, id_marker";
	$rs = my_mysqli_query($sql);
	$row = mysqli_num_rows($rs);
	if ($row == 0) {
		return;
	}
?>
	<table class="diary_cost_table" cellspacing=1>
		<tr class="diary_thread_body">
		<th class="diary_thread_cost_title" colspan=4>費用</th>
		</tr>
<?php
	$cost = 0;
	$gaika = 0;
	while ($rec=mysqli_fetch_array($rs)) {
?>
		<tr class="diary_thread_body">
		<td class="diary_thread_cost"><?= my_htmlspecialchars($rec['c_place']) ?></td>
		<td class="diary_thread_cost"><?= number_format($rec['c_price']) ?> <?= my_htmlspecialchars($rec['c_priceUnit']) ?></td>
		<?php
			if ($rec['c_currencyUnit'] == $rec['c_priceUnit'] and $rec['c_exchangeRate'] <> 0 and $rec['c_price'] <> 0) {
				$yen = $rec['c_price'] * $rec['c_exchangeRate'];
		?>
		<td class="diary_thread_cost">
			<?= number_format($yen) ?> 円
		</td>
		<?php
				$cost += $yen;
				$gaika += $rec['c_price'];
			} else {
				$cost += $rec['c_price'];
			}
		?>
		<?php	if ($rec['c_priceMemo'] <> '') { ?>
		<td class="diary_thread_cost">
			<?= my_htmlspecialchars($rec['c_priceMemo']) ?>
		</td>
		<?php	} ?>
		</tr>
<?php
	}
?>
		<tr class="diary_thread_body">
		<td class="diary_thread_cost">
			<span class="diary_thread_cost_total">合計</span>
		</td>
		<td class="diary_thread_cost">
			<span class="diary_thread_cost_total"><?= number_format($cost) ?> 円</span>
		</td>
		</tr>
	</table>
<?php
}
function place_list($id, $multi='') {
	if ($multi <> '') {
		$sql = "select * from v_marker";
		$sql .= " where id_account = '".$_SESSION['current_id']."' and id_schedule in (".$id.")";
		$sql .= " and c_delete = 0 order by c_mdate, id_schedule, c_order, id_marker";
	} else {
		$sql = "select * from m_marker";
		$sql .= " where id_account = '".$_SESSION['current_id']."' and id_schedule = ".$id;
		$sql .= " and c_delete = 0 order by c_order, id_marker";
	}
	$rs = my_mysqli_query($sql);
	$row = mysqli_num_rows($rs);
	if ($row == 0) {
		return;
	}
?>
	<table class="diary_thread_table" cellspacing=1>
<?php
	while ($rec=mysqli_fetch_array($rs)) {
?>
		<th class="diary_thread_place"<?= ($multi == 'multi') ? ' colspan=2' : '' ?>>
	<?php	if ($multi == 'multi') { ?>
			<p class="diary_thread_place_subject"><?= date_from_mysql("Y-m-d", $rec['c_mdate']) ?> <?= my_htmlspecialchars($rec['c_subject']) ?></p>
	<?php	}	?>
			<?= my_htmlspecialchars($rec['c_place']) ?>
		</th>
	<?php	if ($multi == '' and is_write_permit() == True) {	?>
		<td nowrap>
			<a class="a_diary_update" href="item-input.php?mid=<?= $rec['id_marker'] ?>&id=<?= $rec['id_schedule'] ?>&move=<?= $_GET['move'] ?>&row=<?= $_GET['row'] ?>&page=<?= $_GET['page'] ?>&pl=<?= $_GET['pl'] ?>">[修正]</a>
		</td>
	<?php	}	?>
		</tr>
		<tr class="diary_thread_body">
		<td class="diary_thread_memo">
			<?php
				$http_arg = http_arg_from_session_pool('calendar_schedule');
			?>
			<?= ins_atag_br($rec['c_comment']) ?>
		</td>
		<td class="diary_thread_photo" rowspan=2>
		<?php
			$filename1 = $rec['c_attachFile1'];
			$filename2 = $rec['c_attachFile2'];
			$filename3 = $rec['c_attachFile3'];
			if ($filename1 <> "" || $filename2 <> "" || $filename3 <> "") {
		?>
			<p>
		<?php
				attach_file_view($rec['id_account'], $filename1, '<br>', VIEW_PHOTO_WIDTH,
					True, True, True, VIDEO_PREVIEW_WIDTH, VIDEO_PREVIEW_HEIGHT, ATTACH_FILE_FOLDER_diary_marker);
				attach_file_view($rec['id_account'], $filename2, '<br>', VIEW_PHOTO_WIDTH,
					True, True, True, VIDEO_PREVIEW_WIDTH, VIDEO_PREVIEW_HEIGHT, ATTACH_FILE_FOLDER_diary_marker);
				attach_file_view($rec['id_account'], $filename3, '<br>', VIEW_PHOTO_WIDTH,
					True, True, True, VIDEO_PREVIEW_WIDTH, VIDEO_PREVIEW_HEIGHT, ATTACH_FILE_FOLDER_diary_marker);
		?>
			</p>
		<?php
			}
		?>
		</td>
		</tr>
		<tr class="diary_thread_body">
		<td class="diary_thread_body">
		<?php	if ($rec['c_price'] <> 0) { ?>
				<p>費用： <span class="diary_thread_cost_total"><?= number_format($rec['c_price']) ?></span> <?= my_htmlspecialchars($rec['c_priceUnit']) ?>
				<?php	if ($rec['c_priceMemo'] <> '') { ?>
						(<?= my_htmlspecialchars($rec['c_priceMemo']) ?>)
				<?php	} ?>
				</p>
		<?php	} ?>
		<?php
			$caption = explode(",", DIARY_RATING_CAPTION);
			$cap_num = count($caption);
			for ($ix=0; $ix<$cap_num; $ix++) {
				if ($rec['c_rating'.$ix] <> 0) {
					echo ' '.$caption[$ix].'：<span class="diary_thread_cost_total">'.$rec['c_rating'.$ix].'</span>';
				}
			}
		?>
		</td>
		</tr>
<?php
	}
?>
	</table>
<?php
}
?>
