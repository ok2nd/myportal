<?php
function contents_header($account_menu='on') {
	$menu_item = array();
	$menu_item[] = array("href"=>"list.php", "query"=>"arg=session", "name"=>"一覧");
	$menu_item[] = array("href"=>"input.php", "query"=>"arg=session&uid=".$_SESSION['current_id'], "name"=>"新規");
	$menu_item[] = array("href"=>"month.php", "query"=>"arg=session", "name"=>"月間");
	$menu_item[] = array("href"=>"year.php", "query"=>"arg=session", "name"=>"年間");
	$menu_item[] = array("href"=>"list-marker.php", "query"=>"arg=session", "name"=>"地点一覧");
	$menu_item[] = array("href"=>"category.php", "name"=>"カテゴリ一覧");
	if ($_SESSION['システム管理者'] == "YES") {
		$menu_item[] = array("href"=>"markertype.php", "name"=>"マーカータイプ一覧");
	}
?>
<div id="contents_header">
<?php
	contents_menu($menu_item);
	if ($account_menu == 'on') {
		change_account_menu();
	}
?>
</div><!-- id="contents_header" -->
<?php
}
?>
