<?php
	require("../__common__/__define_common.php");
	require("__define.php");
	require("../__common__/include-common-all.php");
	require("../account/__logincheck.php");
	if (check_permit_id($_SESSION['login_id'], $_SESSION['current_id']) != "w") {
		exit;	// 書き込み権限なし
	}
	if ($_GET['id'] == '') {
		exit;
	}
	$con = my_mysqli_connect(_DB_SCHEMA);
	$sql = "update m_schedule set";
	$sql .= " c_mapCenterLat = '".my_GET('lat')."'";
	$sql .= ", c_mapCenterLng = '".my_GET('lng')."'";
	$sql .= ", c_mapZoomLevel = '".my_GET('zoom')."'";
	$sql .= " where id_schedule  = ".intval($_GET['id']);
	$sql .= " and id_account = ".$_SESSION['current_id'];
	mysqli_query($con, $sql);
	mysqli_close($con);
?>
