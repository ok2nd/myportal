<?php
	require("__include-common.php");
	require("../account/__logincheck.php");
	if (check_permit_id($_SESSION['login_id'], $_SESSION['current_id']) != "w") {
		exit;	// 書き込み権限なし
	}
	if ($_GET['id'] == '') {
		exit;
	}
	$con = my_mysqli_connect(_DB_SCHEMA);
	$sql = "update m_marker set";
	$sql .= " c_lat = '".my_GET('lat')."'";
	$sql .= ", c_lng = '".my_GET('lng')."'";
	$sql .= ", c_updatetime = '". date("Y/m/d H:i:s") . "'";
	$sql .= " where id_marker = ".intval($_GET['id']);
	$sql .= " and id_account = ".$_SESSION['current_id'];
	mysqli_query($con, $sql);
	mysqli_close($con);
?>
