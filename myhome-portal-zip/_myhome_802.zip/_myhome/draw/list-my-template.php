<?php
	if ($_COOKIE['draw_thumbs_width'].'' <> '') {
		$draw_width = $_COOKIE['draw_thumbs_width'];
	} else {
		$draw_width = draw_THUMBS_DEF_WIDTH;
	}
?>
<div>
<script>
var draw_width = <?= $draw_width ?>;
function resizeDrawSize(up_width) {
	setDrawSize(draw_width + up_width);
}
function setDrawSize(width) {
	width = Number(width);
	if (width < <?= draw_THUMBS_MIN_WIDTH ?>) {
		return;
	}
	if (width > <?= draw_THUMBS_MAX_WIDTH ?>) {
		return;
	}
	draw_width = width;
	$("img.draw_img").css("width", width);
	$("#drawWidth").val(width);
	$.cookie('draw_thumbs_width', width, { path:'<?= MY_SESSION_PATH ?>', expires:365 });
}
function selectDrawSize() {
	width = $("#drawWidth").val();
	setDrawSize(width);
}
</script>
サイズ：<select id="drawWidth" onChange="selectDrawSize()">
<?php	for ($size=draw_THUMBS_MIN_WIDTH; $size<=draw_THUMBS_MAX_WIDTH; $size+=draw_THUMBS_UPDOWN_WIDTH) { ?>
<option value="<?= $size ?>"<?= $size == $draw_width ? ' selected' : '' ?>><?= $size ?>
<?php	} ?>
</select>
<input type="button" value="小さく" onClick="resizeDrawSize(-<?= draw_THUMBS_UPDOWN_WIDTH ?>)">
<input type="button" value="大きく" onClick="resizeDrawSize(<?= draw_THUMBS_UPDOWN_WIDTH ?>)">
<input type="button" value="最小" onClick="setDrawSize(<?= draw_THUMBS_MIN_WIDTH ?>)">
<input type="button" value="最大" onClick="setDrawSize(<?= draw_THUMBS_MAX_WIDTH ?>)">
</div>
<?php
	mysqli_data_seek($rs, $startline);
	$line = $startline;
	while ($rec=mysqli_fetch_array($rs) and $line<=$endline) {
?>
	<div class="list_thumb_box" style="">
		<div style="float:left;">
			<a title="<?= my_htmlspecialchars($rec['c_subject']) ?>" href="view.php?id=<?= $rec['id_draw'] ?>&move=<?= $line ?>&row=<?= $rowcnt ?>&page=<?= $page ?>"><img class="draw_img" style="width:<?= $draw_width ?>px; background-image:url(<?= draw_CANVAS_TEXTURE_FOLDER ?>/<?= $rec['c_background'] ?>)" src="<?= str_replace(' ', '+', $rec['c_drawdata']) ?>"></a>
		</div>
		<div class="list_caption">
		<span class="list_subject"><?= $rec['id_draw'] ?>:<?= my_htmlspecialchars($rec['c_subject']) ?></span><br>
		<span class="list_handle">by <a href="list.php?ac=<?= $rec['id_account'] ?>"><?= my_htmlspecialchars($rec['c_handle']) ?></a></span>
		</div>
	</div>
<?php
		$line++;
	}
?>
<?php
function draw_date_view($datetime) {
	$view_date = date_from_mysql("y/m/d H:i:s", $datetime);
	$now_date = date("y/m/d");
	if (left($view_date,8) == $now_date) {
		return '<span class="draw_today">'.$view_date.'</span>';
	} else {
		$before_week = date("y/m/d", mktime(0, 0, 0, intval(date("n")), intval(date("j"))-6, intval(date("Y"))));
		if (left($view_date,8) >= $before_week) {
			return '<span class="draw_recent_day">'.$view_date.'</span>';
		}
	}
	return $view_date;
}
?>
