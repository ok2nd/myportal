<?php
	header("Location: draw.php?".$_SERVER['QUERY_STRING']);
?>
