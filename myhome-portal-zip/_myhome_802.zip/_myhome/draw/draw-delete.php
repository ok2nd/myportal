<?php
	require("__include-common.php");
	require("../account/__logincheck.php");

	$user_id = $_SESSION['login_id'];
	if ($_GET['id'].'' == '' or $_GET['id'] == '0') {
		exit;
	}
	$id = intval($_GET['id']);
	$con = my_mysqli_connect(_DB_SCHEMA);

	$sql = "update m_draw set";
	$sql .= " c_delete = 999";
	$sql .= ", c_updatetime = '". date("Y/m/d H:i:s") . "'";
	$sql .= " where id_draw = ".$id;
	$sql .= " and id_account = ".$user_id;
	$ret = my_mysqli_query($sql, "更新できませんでした。");
	mysqli_close($con);

	redirect("list.php?page=".$_GET['page']);
?>
