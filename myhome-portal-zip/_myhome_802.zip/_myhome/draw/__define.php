<?php
	if (defined("HTML_TITLE_draw")) {
		define("HTML_TITLE", HTML_TITLE_draw);
	} else {
		define("HTML_TITLE", "MyHome ペン画");
	}
	define("SESSION_PREFIX", "draw");

	if (defined("_DB_SCHEMA_draw")) {
		define("_DB_SCHEMA", _DB_SCHEMA_draw);
	} else {
		define("_DB_SCHEMA", "_db_draw");
	}
	if (!defined("draw_THUMBS_DEF_WIDTH")) {
		define("draw_THUMBS_DEF_WIDTH", 150);
		define("draw_THUMBS_MIN_WIDTH", 150);
		define("draw_THUMBS_MAX_WIDTH", 750);
		define("draw_THUMBS_UPDOWN_WIDTH", 75);
	}
	if (!defined("draw_BACKGROUND_COLOR")) {
		define("draw_BACKGROUND_COLOR", "#f8f8f8");
	}
	if (!defined("draw_CANVAS_TEXTURE_FOLDER")) {
		define("draw_CANVAS_TEXTURE_FOLDER", "ghostwriter/css/texture");
	}
	if (!defined("draw_CANVAS_TEXTURE_IMAGES")) {
		define("draw_CANVAS_TEXTURE_IMAGES", "paper3.jpg,canvas.jpg,canvas2.jpg,kabe_getto.jpg,img04.jpg,mc1.jpg,img02.jpg,GAZAI-640.jpg,img05.jpg,p1.jpg,5138821.jpg,white.gif,black.gif");
	}
	if (!defined("draw_CANVAS_TEXTURE_DEFAULT")) {
		define("draw_CANVAS_TEXTURE_DEFAULT", "paper3.jpg");
	}
	if (!defined("draw_COLOR_PALETTE_1")) {
		define("draw_COLOR_PALETTE_1", "FF0000,FF8C00,FFFF00,008000,0000FF,9400D3,000000,FFFFFF");
	}
	if (!defined("draw_COLOR_PALETTE_2")) {
		define("draw_COLOR_PALETTE_2", "FF1493,FF4500,FF6347,FFA500,BC8F8F,B22222,8B4513,B8860B");
	}
	if (!defined("draw_COLOR_PALETTE_3")) {
		define("draw_COLOR_PALETTE_3", "D2691E,808000,6B8E23,9ACD32,32CD32,006400,008080,20B2AA");
	}
	if (!defined("draw_COLOR_PALETTE_4")) {
		define("draw_COLOR_PALETTE_4", "00BFFF,1E90FF,4169E1,7B68EE,9400D3,FF00FF,2F4F4F,DDA0DD");
	}
	if (!defined("draw_CANVAS_COLOR")) {
		define("draw_CANVAS_COLOR", draw_COLOR_PALETTE_1.','.draw_COLOR_PALETTE_2.','.draw_COLOR_PALETTE_3.','.draw_COLOR_PALETTE_4);
	}
	define("PAGE_LINE_SELECT", "5,10,20,50,100,200,500,1000");	//頁内に表示する行数
	define("PAGE_LINE_DEFAULT", "10");				//頁内に表示する行数（デフォルト）
?>
