<?php
	require("__include-common.php");
	require("../account/__logincheck.php");
	$_SESSION['current_permit_type'] = "w";		// is_write_permit()でFalseにならないように
	require("../__common__/include-common-mp-list.php");
?>
<?php
	$table_name_view = "v_draw";
	$table_name = "m_draw";
	$id_item = "id_draw";
	$must_item = "c_subject";

	$mp_list_arg = array();
	$mp_list_arg['account_id']	= "ALL";		// 共通
	$mp_list_arg['table_name_view']	= "v_draw";
	$mp_list_arg['id_item']		= "id_draw";
	$mp_list_arg['must_item']	= "c_subject";
	$mp_list_arg['template_view']	= "list-my-template.php";
	$mp_list_arg['add_filter']	= "list-my-add-filter.php";
	$mp_list_arg['edit_list_all']	= "no";

	$item_tbl = array();
	$item_tbl[] = array(	"表示名"=>"タイトル",	"列名"=>"c_subject",
				"type"=>"text", "size"=>40, "ime-mode"=>"active", "文字検索"=>"Y");

	$order_tbl = array();
	$order_tbl[] = array(   "表示名"=>"投稿最新順", "get_order_name"=>"new",
				"order_by"=>"c_registtime desc");		/* default */
	$order_tbl[] = array(   "表示名"=>"更新最新順", "get_order_name"=>"upnew",
				"order_by"=>"c_updatetime desc");
	$order_tbl[] = array(   "表示名"=>"投稿順", "get_order_name"=>"old",
				"order_by"=>"c_registtime");
	$order_tbl[] = array(   "表示名"=>"タイトル順", "get_order_name"=>"title",
				"order_by"=>"c_subject");

	$http_arg = array();
	$http_arg['pl'] = PAGE_LINE_DEFAULT;		// mp_list 必須
	$http_arg['sort'] = '';				// mp_list 必須
	$http_arg['cat'] = '';				// mp_list 必須
	$http_arg['key'] = '';				// mp_list 必須
	$http_arg['ac'] = '';				// 投稿者フィルタ
	_GET_to_http_arg_pool($http_arg, $table_name, 'sort,key,pl,ac');

	html_header(HTML_TITLE, '', draw_BACKGROUND_COLOR);
	page_header();
//	contents_header();
	$_SESSION['draw_list_sql'] = mp_list_view($mp_list_arg, $item_tbl, $order_tbl, $http_arg);
	page_footer();
	html_footer();
	exit();
?>
