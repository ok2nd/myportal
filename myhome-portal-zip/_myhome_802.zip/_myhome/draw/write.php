<?php
	require("__include-common.php");
	require("../account/__logincheck.php");

	$user_id = $_SESSION['login_id'];
	if (($subject = form_str_adjust($_POST['subj'])) == '') {
		$subject = "(無題)";
	}
	$now_date = date("Y/m/d H:i:s");
	$con = my_mysqli_connect(_DB_SCHEMA);
	if ($_POST['id'].'' == '' or $_POST['id'] == '0') {
		$sql = "insert into m_draw";
		$sql .= " (id_account";
		$sql .= ", c_subject";
		$sql .= ", c_drawdata";
		$sql .= ", c_background";
		$sql .= ", c_registtime";
		$sql .= ", c_updatetime";
		$sql .= ") values ";
		$sql .= "( '".$user_id."'";
		$sql .= ", '".str_for_mysql($subject)."'";
		$sql .= ", '".post_to_mysql('draw')."'";
		$sql .= ", '".post_to_mysql('bg')."'";
		$sql .= ", '".$now_date."'";
		$sql .= ", '".$now_date."'";
		$sql .= ")";
		$ret = mysqli_query($con, $sql);
		if (!$ret) {
			echo '0';
			exit;
		}
		$id = my_mysqli_insert_id();
		mysqli_close($con);
	} else {
		$id = intval($_POST['id']);
		$sql = "update m_draw set";
		$sql .= " c_subject = '".str_for_mysql($subject)."'";
		$sql .= ", c_drawdata = '".post_to_mysql('draw')."'";
		$sql .= ", c_background = '".post_to_mysql('bg')."'";
		$sql .= ", c_updatetime = '".$now_date."'";
		$sql .= " where id_draw = ".$id;
		$sql .= " and id_account = ".$user_id;
		$ret = mysqli_query($con, $sql);
		mysqli_close($con);
	}
	echo $id;
?>
