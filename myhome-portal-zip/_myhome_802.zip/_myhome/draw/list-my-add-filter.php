<?php
function add_where_create($http_arg) {
	$add_where = "";
	if ($http_arg['ac'] <> "") {
		if ($add_where <> "") {
			$add_where .= " and ";
		}
		$add_where .= " id_account = '".$http_arg['ac']."'";
	}
	return ($add_where);
}
function add_my_filter($http_arg) {
?>
<script>
function SelectionAccount(form, sel) {
	for (i = 0; i < sel.options.length; i++) {
		if (sel.options[i].selected == true) {
			window.location.href = "<?= $_SERVER['SCRIPT_NAME'] ?>?ac=" + escape(sel.options[i].value) + "&<?= query_from_http_arg_pool($http_arg, 'ac') ?>";
		}
	}
}
function accountReset() {
	window.location.href = "<?= $_SERVER['SCRIPT_NAME'] ?>?ac=__reset__";
}
</script>
<?php
	$sqlsel = 'SELECT m_account.id_account, m_account.c_handle';
	$sqlsel .= ' FROM (SELECT distinct id_account FROM m_draw) A';
	$sqlsel .= ' JOIN '._DB_ACCOUNT_SCHEMA.'.m_account ON '._DB_ACCOUNT_SCHEMA.'.m_account.id_account = A.id_account';
	$rs_sel = my_mysqli_query($sqlsel);
?>
	投稿者：<select name="account" class="<? if ($http_arg['ac'].'' <> '') echo 'mp_list_filter_true'; ?>" onChange="SelectionAccount(this.form, this)">
		<option value="__reset__" class="mp_list_filter_false">すべて
<?php
		while ($rec_sel=mysqli_fetch_array($rs_sel)) {
?>
		<option value="<?= $rec_sel['id_account'] ?>"<?= $rec_sel['id_account'] == $http_arg['ac'] ? ' selected class="mp_list_filter_true"' : ' class="mp_list_filter_false"' ?>><?= my_htmlspecialchars($rec_sel['c_handle']) ?>
<?php
		}
?>
	</select>
	<input type="button" name="" value="リセット" onClick="accountReset()">
<?php
}
?>
