<meta charset="utf-8">
<meta name="author" content="ok.2nd">
<meta name="description" content="draw edit お絵描き ペン画">
<meta name="keywords" content="draw">
<link rel="stylesheet" href="<?= _STYLE_SHEET_FOLDER_COMMON ?>/common.css?20131130">
<link rel="stylesheet" href="<?= _STYLE_SHEET_BUTTON ?>">
<link rel="stylesheet" href="<?= _STYLE_SHEET_FOLDER ?>/mp-list.css?20130525">
<link rel="stylesheet" href="<?= _STYLE_SHEET_FOLDER ?>/draw.css?20110818">
<script src="../scripts/jquery.js"></script>
<script src="../scripts/jquery.cookie.js"></script>
<script src="../scripts/ok2nd.js"></script>
