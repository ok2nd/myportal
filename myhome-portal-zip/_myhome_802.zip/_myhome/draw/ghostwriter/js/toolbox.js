(function($, ko) {

  $('#toolbox').bind('mouseenter', function(event) {
  
  });

})(jQuery, ko);