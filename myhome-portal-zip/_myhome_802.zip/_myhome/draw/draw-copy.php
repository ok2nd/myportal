<?php
	require("__include-common.php");
	require("../account/__logincheck.php");

	$user_id = $_SESSION['login_id'];
	if ($_GET['id'].'' == '' or $_GET['id'] == '0') {
		exit;
	}
	$id = intval($_GET['id']);
	if (($subject = my_GET('subj')) == '') {
		$subject = "(無題)";
	}
	$con = my_mysqli_connect(_DB_SCHEMA);
	$sql = "select * from m_draw where id_draw = ".$id;
	$rs = my_mysqli_query($sql);
	$rec = mysqli_fetch_array($rs);
	$drawdata = $rec['c_drawdata'];
	$background = $rec['c_background'];
	$now_date = date("Y/m/d H:i:s");

	$sql = "insert into m_draw ";
	$sql .= "(id_account";
	$sql .= ", c_subject";
	$sql .= ", c_drawdata";
	$sql .= ", c_background";
	$sql .= ", c_registtime";
	$sql .= ", c_updatetime";
	$sql .= ") values ";
	$sql .= "( '".$user_id."'";
	$sql .= ", '".str_for_mysql($subject)."'";
	$sql .= ", '".str_for_mysql($drawdata)."'";
	$sql .= ", '".str_for_mysql($background)."'";
	$sql .= ", '".$now_date."'";
	$sql .= ", '".$now_date."'";
	$sql .= ")";
	$ret = my_mysqli_query($sql, "登録できませんでした。");
	$new_id = my_mysqli_insert_id();	//直近のINSERTクエリによりAUTO_INCREMENTカラム用に生成されたIDを取得
	mysqli_close($con);

	redirect("view.php?id=".$new_id."&sort=new&key=__reset__");
?>
