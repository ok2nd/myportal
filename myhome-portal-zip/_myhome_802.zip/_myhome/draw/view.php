<?php
	require("__include-common.php");
	require("../account/__logincheck.php");
	if ($_POST) {
		post_done_proc();
	}
	html_header(HTML_TITLE, '', draw_BACKGROUND_COLOR);
	page_header();
	view_thread();
	page_footer();
	html_footer();
	exit();
?>
<?php
function view_thread() {
	if ($_GET['id'].'' <> '') {
		$id = intval($_GET['id']);
	} else {
		$id = 0;
	}
	if ($_GET['move'].'' <> '') {
		$move = intval($_GET['move']);
	} else {
		$move = -1;
	}
	if ($id == 0 and $move < 0) {
		error_exit("不正アクセス。(1)<br>", False);
	}
	if ($_GET['page'].'' <> '') {
		$page = intval($_GET['page']);
	}
	if ($_GET['row'].'' <> '') {
		$row = intval($_GET['row']);
	}
	if ($_GET['pl'].'' <> '') {
		$pageline = intval($_GET['pl']);
	}
	if ($_GET['ac'].'' <> '') {
		$ac = intval($_GET['ac']);
	}
	$con = my_mysqli_connect(_DB_SCHEMA);
	if ($id == 0) {
		if ($_SESSION['draw_list_sql'].'' == '') {
			error_exit("不正アクセス。(2)<br>", False);
		}
		$rs = my_mysqli_query($_SESSION['draw_list_sql']);
		if ($rs) {
			if (($row = mysqli_num_rows($rs)) == 0) {
				rec_not_found('データがありません。');
				return;
			}
			if ($row < $move+1) {
				rec_not_found('データがありません。');
				return;
			}
			if (!mysqli_data_seek($rs, $move)) {
				rec_not_found('データがありません。');
				return;
			}
			$rec = mysqli_fetch_array($rs);
			$id = $rec['id_draw'];
			$input_id = '&id='.$id;
		}
	} else {
		$sql = "select * from v_draw where id_draw = ".$id;
		$rs = my_mysqli_query($sql);
		if (mysqli_num_rows($rs) == 0) {
			rec_not_found('データがありません。');
			return;
		}
		$rec = mysqli_fetch_array($rs);
	}
?>
<div id="view_body">
	<p>
		<a class="a_view_cancel_back" href='list.php?page=<?= $page ?>'>一覧に戻る</a>
	<?php if ($move <> -1) { ?>
		<span class="view_page"><span class="view_page_num"><?= $move+1 ?></span> / <span class="view_page_num"><?= $row ?></span></span>
		<?php if ($move <> 0) { ?>
		<a class="a_view_move" href="<?= $_SERVER['SCRIPT_NAME'] ?>?move=<?= $move-1 ?>&row=<?= $row ?>&page=<?= $page ?>">[前←]</a>
		<?php } else { ?>
		<span class="view_link_off">[←前]</span>
		<?php } ?>
		<?php if ($move < $row-1) { ?>
		<a class="a_view_move" href="<?= $_SERVER['SCRIPT_NAME'] ?>?move=<?= $move+1 ?>&row=<?= $row ?>&page=<?= $page ?>">[→次]</a>
		<?php } else { ?>
		<span class="view_link_off">[→次]</span>
		<?php } ?>
	<?php } ?>
		<a id="new_button" href="input.php">新規</a>
	</p>
	<p id="view_title">
	<span id="view_no">No.<span id="view_id_draw"><?= $rec['id_draw'] ?></span>:</span>
	<span id="view_subject"><?= $rec['c_subject'] ?></span>
	<span id="view_handle">by <?= $rec['c_handle'] ?></span>
	<span id="view_registtime"><?= $rec['c_registtime'] ?>
		<?php if ($rec['c_registtime'] <> $rec['c_updatetime']) { ?> <span id="view_updatetime"><?= $rec['c_updatetime'] ?></span><?php } ?>
	</span>
	<?php	if ($rec['id_account'] == $_SESSION['login_id']) { ?>
		<input type="button" class="view_func_button" value="修正" onClick="location.href='input.php?id=<?= $rec['id_draw'] ?>&move=<?= $move ?>&row=<?= $row ?>&page=<?= $page ?>'">
	<?php	} ?>
	<input type="button" class="view_func_button" value="コピー" onClick="copy_draw();return false;">
	<?php	if ($rec['id_account'] == $_SESSION['login_id']) { ?>
		<input type="button" class="view_func_button" value="削除" onClick="delete_draw();return false;">
	<?php	} ?>
	</p>
<script>
function copy_draw(){
	if (subj = window.prompt('タイトルを入れてください。', '<?= $rec['c_subject'] ?>')) {
		location.href='draw-copy.php?id=<?= $rec['id_draw'] ?>&subj='+encodeURL(subj);
	}
}
function delete_draw(id){
	if (window.confirm('このデータを削除しますか？')) {
		location.href='draw-delete.php?id=<?= $rec['id_draw'] ?>&page=<?= $_GET['page'] ?>';
	}
}
</script>
	<div id="view_draw_data">
		<img class="draw_img" style="width:750px; height:500px; background-image:url(<?= draw_CANVAS_TEXTURE_FOLDER ?>/<?= $rec['c_background'] ?>)" src="<?= str_replace(' ', '+', $rec['c_drawdata']) ?>">
	</div>
	<div id="comment_area">
	<?php
		$sql = "select * from v_comment where id_draw = ".$id." order by id_comment asc";
		if ($rs_comment = my_mysqli_query($sql)) {
			while ($rec_comment=mysqli_fetch_array($rs_comment)) {
	?>
		<div class="comment">
			<p class="comment_posted">
			<span class="comment_handle"><?= $rec_comment['c_handle'] ?></span>
			<span class="comment_time">(<?= $rec_comment['c_registtime'] ?>)</span>
			</p>
			<p class="comment_message">
			<?= ins_atag_br($rec_comment['c_memo']) ?>
			</p>
		</div>
	<?php
			}
		}
		mysqli_close($con);
	?>
	<div class="comment">
	<a name="comment_new"></a>
	<form id="comment_new" method="POST" action="<?= $_SERVER['SCRIPT_NAME'] ?>?id=<?= $rec['id_draw'] ?>&move=<?= $move ?>&row=<?= $row ?>&page=<?= $page ?>#comment_new">
		<input type="hidden" name="id_draw" value="<?= $id ?>">
		コメント：<br>
		<textarea id="c_memo" name="c_memo" cols=80 rows=5 wrap="soft"></textarea><br>
		<input type="submit" name="登録" value="送信"></font>
	</form>
	</div>
<?php
}
?>
<?php
function post_done_proc() {
	if ($_POST['id_draw'].'' == '') {
		return;
	}
	if (($c_memo = trim($_POST['c_memo'])) == '') {
		return;
	}
	$id_draw = intval($_POST['id_draw']);
	$con = my_mysqli_connect(_DB_SCHEMA);
	$sql = "insert into m_comment";
	$sql .= " (id_account";
	$sql .= ", id_draw";
	$sql .= ", c_memo";
	$sql .= ", c_registtime";
	$sql .= ") values ";
	$sql .= "( '".$_SESSION['login_id']."'";
	$sql .= ", '".intval($_POST['id_draw'])."'";
	$sql .= ", '".post_to_mysql('c_memo')."'";
	$sql .= ", '".date("Y/m/d H:i:s")."'";
	$sql .= ")";
	$ret = my_mysqli_query($sql, "登録できませんでした。");
	mysqli_close($con);
}
?>
<?php
function rec_not_found($msg) {
?>
	<h3 style="margin: 10px;"><?= $msg ?>
	<a class="a_cancel_back" href='list.php?page=<?= $page ?>'>一覧に戻る</a>
	</h3>
<?php
}
?>
