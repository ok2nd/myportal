<?php
	require("__include-common.php");
	require("../account/__logincheck.php");
	if (check_permit_id($_SESSION['login_id'], $_SESSION['current_id']) == "") {
		exit;
	}
	$con = my_mysqli_connect(_DB_SCHEMA);
	$sql = "select id_num, c_name from m_lifeplan";
	$sql .= " where id_account = " . $_SESSION['current_id'] . " order by id_num";
	$rs = my_mysqli_query($sql);
	if ($rs) {
		if (mysqli_num_rows($rs) <> 0) {
			$names = '';
			while ($rec=mysqli_fetch_array($rs)) {
				$names .= $rec['id_num'].':'.$rec['c_name'].',';
			}
			echo $names;
		} else {
			echo 'NoData';
		}
	}
	mysqli_query($con, $sql);
	mysqli_close($con);
?>
