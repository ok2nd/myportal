	<table id="chokin_list_table" cellspacing=0>
	<tr class="chokin_list_header">
	<th><a class="a_field_name" href="?sort=cat&<?= query_from_http_arg_pool($http_arg, 'sort') ?>">金融機関</a></th>
	<th><a class="a_field_name" href="?sort=kouza&<?= query_from_http_arg_pool($http_arg, 'sort') ?>">金融商品名</a></th>
	<th><a class="a_field_name" href="?sort=meigi&<?= query_from_http_arg_pool($http_arg, 'sort') ?>">名義</a></th>
	<th style="text-align:right;">元金</th>
	<th><a class="a_field_name" href="?sort=riritsu&<?= query_from_http_arg_pool($http_arg, 'sort') ?>">利率</a></th>
	<th><a class="a_field_name" href="?sort=shurui&<?= query_from_http_arg_pool($http_arg, 'sort') ?>">種類</a></th>
	<th><a class="a_field_name" href="?sort=keizoku&<?= query_from_http_arg_pool($http_arg, 'sort') ?>">満期時</a></th>
	<th><a class="a_field_name" href="?sort=keiyaku&<?= query_from_http_arg_pool($http_arg, 'sort') ?>">契約日</a></th>
	<th><a class="a_field_name" href="?sort=manki&<?= query_from_http_arg_pool($http_arg, 'sort') ?>">満期日</a></th>
	<th>期間</th>
	<th><a class="a_field_name" href="?sort=mankikin&<?= query_from_http_arg_pool($http_arg, 'sort') ?>">満期額</a></th>
	<th>経過</th>
	<th>残り</th>
	<th style="text-align:right;">現在額</th>
	</tr>
<?php
	$break_key = array();
	$break_key['cat'] = 'c_ginkouName';
	$break_key['kouza'] = 'c_kinyuShohin';
	$break_key['meigi'] = 'c_keiyakuSha';
	$break_key['shurui'] = 'c_shurui';
	$break_key['keizoku'] = 'c_mankitype';
	$break_key['keiyaku'] = 'c_keiyakuYMD';
	$break_key['manki'] = 'c_mankiYMD';
	$old_break_key = '';

	mysqli_data_seek($rs, $startline);
	$line = $startline;
	$keiyakuKinTotal = 0;
	$todayKinTotal = 0;
	$mankiKinTotal = 0;

	$odd = True;
	$fSW = True;
	while ($rec=mysqli_fetch_array($rs) and $line<=$endline) {
		if ($odd) {
			$tr_class = 'chokin_list_odd';
		} else {
			$tr_class = 'chokin_list_even';
		}
		if ($rec['c_mankitype'] == '解約済') {
			$tr_class = 'chokin_list_kaiyaku';
			$kaiyaku = True;
		} else {
			$kaiyaku = False;
		}
		$manki = manki_check($rec['c_mankiYMD'], $printYMD);
		if ($_SESSION['chokin_sub_total'] == 'on') {
			if (!$fSW) {
				if ($_GET['sort'] == 'keiyaku') {
					$new_break_key = date_from_mysql('Y', $rec['c_keiyakuYMD']).'年';
				} elseif ($_GET['sort'] == 'manki') {
					$new_break_key = date_from_mysql('Y', $rec['c_mankiYMD']).'年';
				} else {
					$new_break_key = $rec[$break_key[$_GET['sort']]];
				}
				if ($new_break_key <> $old_break_key) {
	?>
					<tr class="chokin_list_subtotal">
					<td colspan=3><?= $old_break_key ?> 小計</td>
					<td colspan=1 class="kingaku"><?= number_format($keiyakuKinSubT) ?></td>
					<td colspan=7 class="kingaku"><?= number_format($mankiKinSubT) ?></td>
					<td colspan=3 class="kingaku"><?= number_format($todayKinSubT) ?></td>
					</tr>
	<?php
					$keiyakuKinSubT = 0;
					$todayKinSubT = 0;
					$mankiKinSubT = 0;
				}
			} else {
				$fSW = False;
			}
		}
		if ($_GET['sort'] == 'keiyaku') {
			$old_break_key = date_from_mysql('Y', $rec['c_keiyakuYMD']).'年';
		} elseif ($_GET['sort'] == 'manki') {
			$old_break_key = date_from_mysql('Y', $rec['c_mankiYMD']).'年';
		} else {
			$old_break_key = $rec[$break_key[$_GET['sort']]];
		}
		if (!$kaiyaku) {
			if ($rec['c_shurui'] == '月積') {
				$keiyakuKinTotal += $rec['c_keiyakuKin'] * $rec['todayKeikaMonth'];
				$keiyakuKinSubT += $rec['c_keiyakuKin'] * $rec['todayKeikaMonth'];
			} else {
				$keiyakuKinTotal += $rec['c_keiyakuKin'];
				$keiyakuKinSubT += $rec['c_keiyakuKin'];
			}
			$todayKinTotal += $rec['todayKin'];
			$mankiKinTotal += $rec['mankiKin'];
			$todayKinSubT += $rec['todayKin'];
			$mankiKinSubT += $rec['mankiKin'];
		}
?>
	<tr class="<?= $tr_class ?>">
	<td><a href="?cat=<?= $rec['id_ginkou'] ?>&<?= query_string_strip('cat') ?>"><?= $rec['c_ginkouName'] ?></a></td>
	<td><?= $rec['c_kinyuShohin'] ?></td>
	<td><a href="?meigi=<?= $rec['c_keiyakuSha'] ?>&<?= query_string_strip('meigi') ?>"><?= $rec['c_keiyakuSha'] ?></a></td>
	<?php
		if ($rec['c_shurui'] == '月積') {
			$style = 'kingaku_tsukizumi';
			$keikaM = 'x'.$rec['todayKeikaMonth'];
		} else {
			$style = '';
			$keikaM = '';
		}
	?>
		<td class="kingaku <?= $style ?>"><?= number_format($rec['c_keiyakuKin']) ?><?= $keikaM ?></td>
	<td class="ritsu"><?= $rec['c_ritsu'] ?></td>
	<?php
		if ($rec['c_shurui'] == '月積') {
			$style = 'shurui_tsukizumi';
		} else {
			$style = '';
		}
	?>
	<td class="<?= $style ?>"><?= $rec['c_shurui'] ?></td>
	<?php
		if ($rec['c_mankitype'] == '継続') {
			$style = 'mankitype_keizoku';
		} else {
			$style = '';
		}
	?>
	<td class="<?= $style ?>"><?= $rec['c_mankitype'] ?></td>
	<td><?= date_from_mysql('Y.m.d', $rec['c_keiyakuYMD']); ?></td>
	<td><?= $printYMD ?></td>
	<td class="kikan"><?php print_yymm($rec['mankiYear'], $rec['mankiMonth']) ?></td>
	<td class="kingaku"><?= number_format($rec['mankiKin']) ?></td>
	<td class="kikan">
	<?php
		if ($rec['c_mankitype'] == '解約済') {
			echo '解約済';
		} elseif ($rec['c_mankitype'] == '解約' and $manki == '満期') {
			echo '<span class="chokin_manki_go">解約状態</span>';
		} elseif ($rec['c_mankitype'] == '継続' and $manki == '満期') {
			echo '<span class="chokin_manki_go">';
			print_yymm($rec['keikaYear'], $rec['keikaMonth']);
			echo '</span>';
		} else {
			print_yymm($rec['keikaYear'], $rec['keikaMonth']);
		}
	?>
	</td>
	<td class="kikan">
	<?php
		if ($rec['c_mankitype'] == '解約済') {
			echo '---';
		} elseif ($rec['c_mankitype'] == '解約' and $manki == '満期') {
			echo '---';
		} elseif ($rec['c_mankitype'] == '継続' and $manki == '満期') {
			echo '<span class="chokin_manki_go">-';
			print_yymm(-$rec['nokoriYear'], -$rec['nokoriMonth']);
			echo '</span>';
		} else {
			print_yymm($rec['nokoriYear'], $rec['nokoriMonth']);
		}
	?>
	</td>
	<td class="kingaku"><?= number_format($rec['todayKin']) ?></td>
	</tr>
<?php
		$odd = !$odd;
		$line++;
	}
?>
	<tr class="chokin_list_subtotal">
<?php
	if ($_SESSION['chokin_sub_total'] == 'on') {
		if ($_GET['sort'] <> 'new' and $_GET['sort'] <> '') {
?>
			<td colspan=3><?= $old_break_key ?> 小計</td>
			<td colspan=1 class="kingaku"><?= number_format($keiyakuKinSubT) ?></td>
			<td colspan=7 class="kingaku"><?= number_format($mankiKinSubT) ?></td>
			<td colspan=3 class="kingaku"><?= number_format($todayKinSubT) ?></td>
			</tr>
<?php
		}
	}
?>
	<tr class="chokin_list_total">
	<td colspan=3>合計</td>
	<td colspan=1 class="kingaku"><?= number_format($keiyakuKinTotal) ?></td>
	<td colspan=7 class="kingaku"><?= number_format($mankiKinTotal) ?></td>
	<td colspan=3 class="kingaku"><?= number_format($todayKinTotal) ?></td>
	</tr>
	</table>
<?php
function manki_check($mankiYMD, &$printYMD) {
	$manki = date_from_mysql('Y.m.d', $mankiYMD);
	if (date('Y.m.d') >= $manki) {
		$printYMD = '<span class="chokin_manki_go">'.$manki.'</span>';
		return '満期';
	} elseif (date('Y.m.d', strtotime('3 month')) >= $manki) {
		$printYMD = '<span class="chokin_manki_3go">'.$manki.'</span>';
		return '3ヶ月以内満期';
	} else {
		$printYMD = '<span class="chokin_standard">'.$manki.'</span>';
		return False;
	}
}
function print_yymm($yy,$mm) {
	if ($yy <> 0) {
		echo $yy.'年';
	}
	if ($mm <> 0) {
		echo $mm.'月';
	}
	if ($yy == 0 and $mm == 0) {
		echo '0月';
	}
}
?>
