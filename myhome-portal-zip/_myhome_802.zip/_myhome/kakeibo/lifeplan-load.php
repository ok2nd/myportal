<?php
	require("__include-common.php");
	require("../account/__logincheck.php");
	if (check_permit_id($_SESSION['login_id'], $_SESSION['current_id']) == "") {
		exit;
	}
	$updateD = date("Y/m/d H:i:s");
	$con = my_mysqli_connect(_DB_SCHEMA);
	$sql = "select * from m_lifeplan";
	$sql .= " where id_account = " . $_SESSION['current_id'] . " and id_num = " . $_GET['id'];
	$rs = my_mysqli_query($sql);
	if ($rs) {
		if (mysqli_num_rows($rs) <> 0) {
			$rec = mysqli_fetch_array($rs);
			echo $rec['c_json'];
		} else {
			echo 'NoData';
		}
	}
	mysqli_query($con, $sql);
	mysqli_close($con);
?>
