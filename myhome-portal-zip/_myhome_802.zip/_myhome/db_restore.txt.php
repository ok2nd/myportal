<?
/*

:■■■■■ スキーマ削除 ( _db_ )
mysql -u root -pパスワード
drop database _db_account;
drop database _db_index;
drop database _db_calendar;
drop database _db_memo;
drop database _db_zid_mgr_a;
drop database _db_zid_mgr_b;
drop database _db_guide;
drop database _db_bbs;
drop database _db_rss;
drop database _db_chat;
drop database _db_kakeibo;
drop database _db_study;
drop database _db_abook;
drop database _db_diary;
drop database _db_sticky;
drop database _db_photo;
drop database _db_svg;
drop database _db_draw;
drop database _db_psketch;
drop database _db_email;
drop database _db_gpslog;
exit;

:■■■■■ リストア ( _db_ )
mysql -u root -pパスワード
create database _db_account;
create database _db_index;
create database _db_calendar;
create database _db_memo;
create database _db_zid_mgr_a;
create database _db_zid_mgr_b;
create database _db_guide;
create database _db_bbs;
create database _db_rss;
create database _db_chat;
create database _db_kakeibo;
create database _db_study;
create database _db_abook;
create database _db_diary;
create database _db_sticky;
create database _db_photo;
create database _db_svg;
create database _db_draw;
create database _db_psketch;
create database _db_email;
create database _db_gpslog;
exit;

d:
cd "D:\xampp\htdocs\_myhome\z_db_backup"
mysql -u root -pパスワード _db_account < _db_account.bk.txt
mysql -u root -pパスワード _db_index < _db_index.bk.txt
mysql -u root -pパスワード _db_calendar < _db_calendar.bk.txt
mysql -u root -pパスワード _db_memo < _db_memo.bk.txt
mysql -u root -pパスワード _db_zid_mgr_b < _db_zid_mgr_b.bk.txt
mysql -u root -pパスワード _db_zid_mgr_a < _db_zid_mgr_a.bk.txt
mysql -u root -pパスワード _db_guide < _db_guide.bk.txt
mysql -u root -pパスワード _db_bbs < _db_bbs.bk.txt
mysql -u root -pパスワード _db_rss < _db_rss.bk.txt
mysql -u root -pパスワード _db_chat < _db_chat.bk.txt
mysql -u root -pパスワード _db_kakeibo < _db_kakeibo.bk.txt
mysql -u root -pパスワード _db_study < _db_study.bk.txt
mysql -u root -pパスワード _db_abook < _db_abook.bk.txt
mysql -u root -pパスワード _db_diary < _db_diary.bk.txt
mysql -u root -pパスワード _db_sticky < _db_sticky.bk.txt
mysql -u root -pパスワード _db_photo < _db_photo.bk.txt
mysql -u root -pパスワード _db_svg < _db_svg.bk.txt
mysql -u root -pパスワード _db_draw < _db_draw.bk.txt
mysql -u root -pパスワード _db_psketch < _db_psketch.bk.txt
mysql -u root -pパスワード _db_email < _db_email.bk.txt
mysql -u root -pパスワード _db_gpslog < _db_gpslog.bk.txt

:■■■■■ ビュー作成 ( _db_ )
d:
cd "D:\xampp\htdocs\_myhome\z_db_backup"
mysql -u root -pパスワード _db_account < create_view_db_account.txt
mysql -u root -pパスワード _db_index < create_view_db_index.txt
mysql -u root -pパスワード _db_calendar < create_view_db_calendar.txt
mysql -u root -pパスワード _db_memo < create_view_db_memo.txt
mysql -u root -pパスワード _db_zid_mgr_a < create_view_db_zid_mgr_a.txt
mysql -u root -pパスワード _db_guide < create_view_db_guide.txt
mysql -u root -pパスワード _db_bbs < create_view_db_bbs.txt
mysql -u root -pパスワード _db_rss < create_view_db_rss.txt
mysql -u root -pパスワード _db_chat < create_view_db_chat.txt
mysql -u root -pパスワード _db_kakeibo < create_view_db_kakeibo.txt
mysql -u root -pパスワード _db_study < create_view_db_study.txt
mysql -u root -pパスワード _db_abook < create_view_db_abook.txt
mysql -u root -pパスワード _db_diary < create_view_db_diary.txt
mysql -u root -pパスワード _db_svg < create_view_db_svg.txt
mysql -u root -pパスワード _db_draw < create_view_db_draw.txt
mysql -u root -pパスワード _db_psketch < create_view_db_psketch.txt
mysql -u root -pパスワード _db_email < create_view_db_email.txt
mysql -u root -pパスワード _db_gpslog < create_view_db_gpslog.txt

:■■■■■ ユーザーアカウント作成 ( _db_ )
mysql -u root -pパスワード
GRANT USAGE ON *.* TO myhome@localhost IDENTIFIED BY 'pass123';
GRANT SELECT,INSERT,UPDATE,DELETE ON _db_account.* TO myhome@localhost;
GRANT SELECT,INSERT,UPDATE,DELETE ON _db_calendar.* TO myhome@localhost;
GRANT SELECT,INSERT,UPDATE,DELETE ON _db_guide.* TO myhome@localhost;
GRANT SELECT,INSERT,UPDATE,DELETE ON _db_index.* TO myhome@localhost;
GRANT SELECT,INSERT,UPDATE,DELETE ON _db_memo.* TO myhome@localhost;
GRANT SELECT,INSERT,UPDATE,DELETE ON _db_zid_mgr_a.* TO myhome@localhost;
GRANT SELECT,INSERT,UPDATE,DELETE ON _db_zid_mgr_b.* TO myhome@localhost;
GRANT SELECT,INSERT,UPDATE,DELETE ON _db_bbs.* TO myhome@localhost;
GRANT SELECT,INSERT,UPDATE,DELETE ON _db_rss.* TO myhome@localhost;
GRANT SELECT,INSERT,UPDATE,DELETE ON _db_chat.* TO myhome@localhost;
GRANT SELECT,INSERT,UPDATE,DELETE ON _db_kakeibo.* TO myhome@localhost;
GRANT SELECT,INSERT,UPDATE,DELETE ON _db_study.* TO myhome@localhost;
GRANT SELECT,INSERT,UPDATE,DELETE ON _db_abook.* TO myhome@localhost;
GRANT SELECT,INSERT,UPDATE,DELETE ON _db_diary.* TO myhome@localhost;
GRANT SELECT,INSERT,UPDATE,DELETE ON _db_sticky.* TO myhome@localhost;
GRANT SELECT,INSERT,UPDATE,DELETE ON _db_photo.* TO myhome@localhost;
GRANT SELECT,INSERT,UPDATE,DELETE ON _db_svg.* TO myhome@localhost;
GRANT SELECT,INSERT,UPDATE,DELETE ON _db_draw.* TO myhome@localhost;
GRANT SELECT,INSERT,UPDATE,DELETE ON _db_psketch.* TO myhome@localhost;
GRANT SELECT,INSERT,UPDATE,DELETE ON _db_email.* TO myhome@localhost;
GRANT SELECT,INSERT,UPDATE,DELETE ON _db_gpslog.* TO myhome@localhost;
FLUSH PRIVILEGES;
exit;

*/
?>
