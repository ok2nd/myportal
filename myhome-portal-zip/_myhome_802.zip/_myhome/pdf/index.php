<?php
	header("Location: sample.php?".$_SERVER['QUERY_STRING']);
?>
