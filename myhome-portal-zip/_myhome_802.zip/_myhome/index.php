<?php
	header("Location: index/index.php");
?>
