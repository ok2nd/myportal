<?php
	require("__include-common.php");
	require("../account/__logincheck.php");
	require("../__common__/include-common-mp-list.php");

	$table_name_view = "v_email";
	$table_name = "m_email";
	$id_item = "id_email";
	$must_item = "c_name";

	$mp_list_arg = array();
	$mp_list_arg['account_id']	= $_SESSION['current_id'];
	$mp_list_arg['table_name_view']		= "v_email";
	$mp_list_arg['table_name_edit']		= "v_email";
	$mp_list_arg['table_name_update']	= "m_email";
	$mp_list_arg['id_item']		= "id_email";
	$mp_list_arg['must_item']	= "c_name";
	$mp_list_arg['input_new']	= "yes";
	$mp_list_arg['use_privacy']	= "yes";
	$mp_list_arg['add_list']	= "yes";
	$mp_list_arg['edit_button_item'] = "c_name";
	$mp_list_arg['list_edit_right_add_html']	= "../__common__/in-block-color-chart.php";
	$mp_list_arg['view_description'] = "ユーザー名やパスワードは、他のユーザーから閲覧されるリスクがあります。";
	$mp_list_arg['edit_description'] = "ユーザー名やパスワードは、他のユーザーから閲覧されるリスクがあります。";

	$item_tbl = array();
	$item_tbl[] = array(	"表示名"=>"カテゴリ",	"列名"=>"id_category", "http_arg_GET名"=>"cat",
				"type"=>"select", "参照テーブル"=>"m_category", "参照テーブル表示列"=>"c_categoryName",
				"参照テーブル表示順"=>"c_categoryDisplayOrder");
	$item_tbl[] = array(	"表示名"=>"メールBOX名",	"列名"=>"c_name",
				"type"=>"text", "size"=>15, "ime-mode"=>"active", "文字検索"=>"Y",
				"width"=>"140",
				"背景カラー表示列名"=>"c_displayColor");
	$item_tbl[] = array(	"表示名"=>"表示順",	"列名"=>"c_displayOrder",
				"type"=>"text", "size"=>5, "ime-mode"=>"disabled", "toInt"=>"Y");
	$item_tbl[] = array(	"表示名"=>"枠カラー",	"列名"=>"c_displayColor",
				"カラー表示列名"=>"c_displayColor",
				"編集bg反映"=>"c_name",
				"type"=>"text", "size"=>12, "ime-mode"=>"disabled");
	$item_tbl[] = array(	"表示名"=>"POP3ホスト",	"列名"=>"c_host_pop3",
				"type"=>"text", "size"=>26, "ime-mode"=>"inactive", "a_tag"=>"Y");
	$item_tbl[] = array(	"表示名"=>"ポート番号",	"列名"=>"c_port_pop3",
				"type"=>"text", "size"=>6, "ime-mode"=>"inactive", "a_tag"=>"Y");
	$item_tbl[] = array(	"表示名"=>"ユーザー名",	"列名"=>"c_username",
				"type"=>"text", "size"=>18, "ime-mode"=>"inactive", "a_tag"=>"Y");
	$item_tbl[] = array(	"表示名"=>"パスワード",	"列名"=>"c_password",
				"type"=>"text", "size"=>18, "ime-mode"=>"inactive", "a_tag"=>"Y");
	$order_tbl = array();
	$order_tbl[] = array(   "表示名"=>"カテゴリ順", "get_order_name"=>"cat",
				"order_by"=>"c_categoryDisplayOrder, id_category, c_displayOrder, c_name");		/* default */
	$order_tbl[] = array(   "表示名"=>"タイトル順", "get_order_name"=>"title",
				"order_by"=>"c_name asc");

	$http_arg = array();
	$http_arg['pl'] = PAGE_LINE_DEFAULT;		// mp_list 必須
	$http_arg['sort'] = '';				// mp_list 必須
	$http_arg['cat'] = '';				// mp_list 必須
	$http_arg['key'] = '';				// mp_list 必須
	$http_arg['cid'] = '';

	if (isset($_POST['登録'])) {
		check_post_account($_POST['login_id'], $_POST['current_id']);
		mp_list_update($mp_list_arg, $item_tbl, $order_tbl, $http_arg);
	} else {
		_GET_to_http_arg_pool($http_arg, $table_name, 'sort,key,pl');
		html_header(HTML_TITLE);
		page_header();
		contents_header();
		if ($_GET['edit'] == "a") {
			$mp_list_arg['sql_for_edit'] = "select * from v_email where id_email = 0";
			mp_list_edit($mp_list_arg, $item_tbl, $order_tbl, $http_arg);
		} elseif ($_GET['edit'] == "y") {
			mp_list_edit($mp_list_arg, $item_tbl, $order_tbl, $http_arg);
		} else {
			mp_list_view($mp_list_arg, $item_tbl, $order_tbl, $http_arg);
		}
		page_footer();
		html_footer();
	}
	exit();
?>
