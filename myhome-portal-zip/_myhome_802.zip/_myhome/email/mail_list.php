<?php
	require("__include-common.php");
	require("../account/__logincheck.php");
	require("__include-common-email.php");

	html_header(HTML_TITLE);
	page_header();
	contents_header('off');

	$id_email = intval($_GET['id']);
	$con = my_mysqli_connect(_DB_SCHEMA);
	$sql = "select * from m_email where c_delete = 0 and id_account = '" . $_SESSION['current_id'] . "'";
	$sql .= " and id_email = " . $id_email;
	if ($_SESSION['current_id'] != $_SESSION['login_id']) {
		$sql .= " and c_privacy = 0";
	}
	$rs = my_mysqli_query($sql);
	if (!($rec = mysqli_fetch_array($rs))) {
		error_exit('不正ID');
	}
	if ($rec['c_host_pop3'].'' == '')  {
		error_exit('POP3サーバー指定なし');
	}
	$account = array(
		'host' => $rec['c_host_pop3'],
		'port' => $rec['c_port_pop3'],
		'username' => $rec['c_username'],
		'password' => $rec['c_password'],
	);
	if ($_GET['list'] == 'new') {
		$_SESSION['email_get'][$id_email]['get'] = false;
	}
	email_body($rec['c_name'], $account, $id_email);
	page_footer();
	html_footer();
	exit();
function email_body($name, $account, $id_email) {
?>
<script src="../scripts/tristen-tablesort/demo/ender.js"></script>
<script src="../scripts/tristen-tablesort/tablesort.min.js"></script>
<script>
$(document).ready(function () {
	$('table#msg_list').tablesort();
});
</script>
<div id="list_box">
<table><tr>
<th style="color:#0069d3"><?= $name ?></th>
<th style="padding-left:10px;">ユーザー名：</th><td><?= $account['username'] ?></td>
<th style="padding-left:10px;">ホスト名：</th><td><?= $account['host'] ?></td>
<td style="padding-left:10px;"><a class="a_cancel_back" href="index.php?arg=session">戻る</a></td>
</tr></table>
<?php
	if (!$_SESSION['email_get'][$id_email]['get']) {
		if (!email_get_list($account, $id_email, EMAIL_LIST_READ_CNT, EMAIL_LIST_READ_CNT)) {
			return;
		}
	}
	$msg_num = $_SESSION['email_get'][$id_email]['msg_num'];
	$num_limit = $_SESSION['email_get'][$id_email]['num_limit'];
?>
<div id="list_msg_num">
新着メッセージ： <span style="font-weight:bold;"><?= $msg_num ?></span> 件
<?php	if ($msg_num > EMAIL_LIST_READ_CNT) { ?>
(最新の <span style="font-weight:bold;"><?= EMAIL_LIST_READ_CNT ?></span> 件を表示)
<?php	} ?>
<span style="padding-left:15px;">
<button onClick="location.href='?id=<?= $_GET['id'] ?>&list=new'">新着メール再受信</button>
<label><input type="checkbox" onClick="HtmlOnOff(this)" style="margin-left:10px;"<?php if ($_COOKIE['email_body_html'] == 'on') echo ' checked'; ?>>メール本文をHTML表示する</label>
</span>
</div>
<script>
function HtmlOnOff(me) {
	if (me.checked) {
	//	$.cookie("email_body_html","on",{ path:'<?= MY_SESSION_PATH ?>', expires:365 });	// tablesort()と競合?
		saveCookie('email_body_html',"on",365,'<?= MY_SESSION_PATH ?>');
	} else {
	//	$.cookie("email_body_html","",{ path:'<?= MY_SESSION_PATH ?>', expires:365 });	// tablesort()と競合?
		saveCookie('email_body_html',"off",365,'<?= MY_SESSION_PATH ?>');
	}
}
</script>
<table id="msg_list">
<thead>
<tr>
<th>宛先</th>
<th>差出人</th>
<th>件名</th>
<th>送信日時</th>
</tr>
</thead>
<tbody>
<?php
	if ($msg_num > EMAIL_LIST_READ_CNT) {
		$num_limit = $msg_num - EMAIL_LIST_READ_CNT + 1;
	} else {
		$num_limit = 1;
	}
	for ($ix=$msg_num; $ix>=$num_limit; $ix--) {
		$to = $_SESSION['email_get'][$id_email]['to'][$ix];
		$from = $_SESSION['email_get'][$id_email]['from'][$ix];
		$subject = $_SESSION['email_get'][$id_email]['subject'][$ix];
		$date = $_SESSION['email_get'][$id_email]['date'][$ix];
?>
<tr>
		<td class="msg_list_to" style="word-break:break-all;"><?= my_htmlspecialchars($to) ?></td>
		<td class="msg_list_from" style="word-break:break-all;"><?= my_htmlspecialchars($from) ?></td>
		<td class="msg_list_subject"><a href="mail_msg.php?id=<?= $id_email ?>&no=<?= $ix ?>" target="_blank"><?= my_htmlspecialchars($subject) ?></a></td>
		<td class="msg_list_date"><?= date('Y/m/d H:i:s', $date) ?></td>
<?php
?>
</tr>
<?php
	}
?>
</tbody>
</table>
</div>
<?php
}
?>
