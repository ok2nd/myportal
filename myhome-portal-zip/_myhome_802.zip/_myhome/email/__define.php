<?php
	if (defined("HTML_TITLE_email")) {
		define("HTML_TITLE", HTML_TITLE_email);
	} else {
		define("HTML_TITLE", "MyHome Email");
	}
	define("SESSION_PREFIX", "email");

	if (defined("_DB_SCHEMA_email")) {
		define("_DB_SCHEMA", _DB_SCHEMA_email);
	} else {
		define("_DB_SCHEMA", "_db_email");
	}

	if (defined("EMAIL_LIST_VIEW_CNT_email")) {
		define("EMAIL_LIST_VIEW_CNT", EMAIL_LIST_VIEW_CNT_email);
	} else {
		define("EMAIL_LIST_VIEW_CNT", 10);		// Email index.php表示件数(最新より)
	}
	if (defined("EMAIL_LIST_READ_CNT_email")) {
		define("EMAIL_LIST_READ_CNT", EMAIL_LIST_READ_CNT_email);
	} else {
		define("EMAIL_LIST_READ_CNT", 50);		// Email リスト取得件数(最新より)
	}
	if (defined("EMAIL_LIST_TABLE_WIDTH_email")) {
		define("EMAIL_LIST_TABLE_WIDTH", EMAIL_LIST_TABLE_WIDTH_email);
	} else {
		define("EMAIL_LIST_TABLE_WIDTH", 288);		// Email index.php表示テーブル幅(px)
	}
	if (defined("EMAIL_MSG_WIDTH_email")) {
		define("EMAIL_MSG_WIDTH", EMAIL_MSG_WIDTH_email);
	} else {
		define("EMAIL_MSG_WIDTH", 520);			// Email mail_msg.phpメール本文表示幅(px)
	}

	define("PAGE_LINE_SELECT", "5,10,20,50,100,1000");	//頁内に表示する行数
	define("PAGE_LINE_DEFAULT", "100");			//頁内に表示する行数（デフォルト）
?>
