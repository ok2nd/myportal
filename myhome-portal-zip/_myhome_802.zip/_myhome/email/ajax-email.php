<?php
	require("../__common__/__define_common.php");
	require("__define.php");
	require("../__common__/include-common-all.php");
	require("../account/__logincheck.php");
	require("__include-common-email.php");

	mb_language("Japanese");
	mb_internal_encoding('UTF-8');

//	my_session_start();			// session_start()をコールするとブラウザが待ちになる。

	$con = my_mysqli_connect(_DB_SCHEMA);
	$sql = "select * from m_email where c_delete = 0 and id_account = '" . $_COOKIE['current_id'] . "'";
	$sql .= " and id_email = " . intval($_GET['id']);
	if ($_COOKIE['current_id'] != $_COOKIE['login_id']) {
		$sql .= " and c_privacy = 0";
	}
	$rs = my_mysqli_query($sql);
	if ($rec = mysqli_fetch_array($rs)) {
		email_view_list($rec, $_GET['cnt'], $_GET['read']);
	}
?>
