<?php
	require("__include-common.php");
	require("../account/__logincheck.php");

	$id = intval($_GET['id']);
	$con = my_mysqli_connect(_DB_SCHEMA);
	$sql = "select * from m_email where c_delete = 0 and id_account = '" . $_SESSION['current_id'] . "'";
	$sql .= " and id_email = " . $id;
	if ($_SESSION['current_id'] != $_SESSION['login_id']) {
		$sql .= " and c_privacy = 0";
	}
	$rs = my_mysqli_query($sql);
	if (!($rec = mysqli_fetch_array($rs))) {
		error_exit('不正ID');
	}
	$account = array(
		'host' => $rec['c_host_pop3'],
		'port' => $rec['c_port_pop3'],
		'username' => $rec['c_username'],
		'password' => $rec['c_password'],
	);
	html_header(HTML_TITLE);
?>
<div>
<?php
	require_once('Net/POP3.php');
	require_once 'Mail/mimeDecode.php';
	$pop3 = new Net_POP3();
	if (!($pop3->connect($account['host'], $account['port']))) {
		error_msg('メールサーバー接続エラー<br><br>');
		return;
	}
	if (($pop3->login($account['username'], $account['password'])) != 1) {
		error_msg('メールサーバーログインエラー<br><br>');
		return;
	}
	if (!($msg_num = $pop3->numMsg())) {
		error_msg('受信メールはありません。<br><br>');
		return;
	}
	$no = $_GET['no'];
	if ($no > $msg_num) {
		error_msg('該当するメールはありません。<br><br>');
		return;
	}
/*
	$header = $pop3->getParsedHeaders($no);
	$body = $pop3->getBody($no);
	$pop3->disconnect();
	$subject = my_htmlspecialchars(mb_convert_encoding(mb_decode_mimeheader($header['Subject']), 'UTF-8', MB_CONVERT_ENCODING_AUTO));
	$mailfrom = my_htmlspecialchars(mb_decode_mimeheader($header['From']));
	$mailto = my_htmlspecialchars(mb_decode_mimeheader($header['To']));
	$mailcc = my_htmlspecialchars(mb_decode_mimeheader($header['Cc']));
	$mailreplyto = my_htmlspecialchars(mb_decode_mimeheader($header['Reply-To']));
	$maildate = date('Y/m/d H:i:s', strtotime(mb_decode_mimeheader($header['Date'])));
	$mailbody = ins_br(my_htmlspecialchars(strip_tags(mb_convert_encoding($body, 'UTF-8', 'JIS'))));
*/
	$decoder = new Mail_mimeDecode($pop3->getMsg($no));
	$pop3->disconnect();
	$params['include_bodies'] = true;
	$params['decode_bodies'] = true;
	$params['decode_headers'] = true;
	$structure = $decoder->decode($params);
	$subject = my_htmlspecialchars(mb_convert_encoding($structure->headers['subject'], 'UTF-8', MB_CONVERT_ENCODING_AUTO));
	$mailfrom = my_htmlspecialchars(mb_convert_encoding($structure->headers['from'], 'UTF-8', MB_CONVERT_ENCODING_AUTO));
	$mailto = my_htmlspecialchars(mb_convert_encoding($structure->headers['to'], 'UTF-8', MB_CONVERT_ENCODING_AUTO));
	$mailcc = my_htmlspecialchars(mb_convert_encoding($structure->headers['cc'], 'UTF-8', MB_CONVERT_ENCODING_AUTO));
	$mailreplyto = my_htmlspecialchars(mb_convert_encoding($structure->headers['reply-to'], 'UTF-8', MB_CONVERT_ENCODING_AUTO));
	$maildate = date('Y/m/d H:i:s', strtotime($structure->headers['date']));
	preg_match("/<.*>/", $mailfrom, $str);		// 署名付きの場合の処理
	if ($str[0] != '') {
		$str = substr($str[0], 1, strlen($str[0])-2);
		$mailfrom = $str;
	}
	switch (strtolower($structure->ctype_primary)) {
		case 'text':
			$mailbody = $structure->body;
			break;
		case 'multipart':
			foreach($structure->parts as $part){
				switch (strtolower($part->ctype_primary)) {
					case 'text':
						$mailbody = $part->body;
						break;
				}
			}
			break;
	}
	$mailbody = mb_convert_encoding($mailbody, 'UTF-8', MB_CONVERT_ENCODING_AUTO);
	$mailtext = preg_replace('@<script[^>]*?>.*?</script>@si', '', $mailbody);	// javascriptを除去
	$mailtext = preg_replace('@<style[^>]*?>.*?</style>@si', '', $mailtext);	// styleを除去
	$mailtext = strip_tags($mailtext);						// タグ除去
	$mailtext = preg_replace("/\r/", "", $mailtext);
//	$mailtext = preg_replace("/\n\n\n+/", "\n\n", $mailtext);		// 3個以上連続した改行を2個にする
	$mailtext = ins_atag_br($mailtext);
	if (substr_count($mailbody, '<') < 4 or substr_count($mailbody, '>') < 4) {	// HTMLではない
		$mailhtml_v = 'display:none';
	} else if ($_COOKIE['email_body_html'] == 'on') {
		$mailtext_v = 'display:none';
	} else {
		$mailhtml_v = 'display:none';
	}
?>
<div style="margin:10px 0 0 0;">
<label><input type="checkbox" onClick="HtmlOnOff(this)" style="margin-left:10px;"<?php if ($mailtext_v == 'display:none') echo ' checked'; ?>>メール本文をHTML表示する</label>
<script>
function HtmlOnOff(me) {
	if (me.checked) {
		$("#mailtext").css("display","none");
		$("#mailhtml").css("display","");
	} else {
		$("#mailtext").css("display","");
		$("#mailhtml").css("display","none");
	}
}
</script>
</div>
<table id="mail_msg">
	<tr><th>差出人：</th><td class="msg_from"><a href="mailto:<?= $mailfrom ?>"><?= $mailfrom ?></a></td></tr>
	<tr><th>件名：</th><td class="msg_subject"><?= $subject ?></td></tr>
	<tr><th>宛先：</th><td class="msg_to"><?= $mailto ?></td></tr>
<?php	if ($mailcc <> '') { ?>
	<tr><th>CC：</th><td class="msg_to"><?= $mailcc ?></td></tr>
<?php	} ?>
<?php	if ($mailreplyto <> '') { ?>
	<tr><th>Replay-to：</th><td class="msg_to"><a href="mailto:<?= $mailreplyto ?>"><?= $mailreplyto ?></a></td></tr>
<?php	} ?>
	<tr><th>送信日時：</th><td class="msg_date"><?= $maildate ?></td></tr>
	<tr id="mailtext" style="<?= $mailtext_v ?>"><td class="msg_body" colspan="2"><p style="width:<?= EMAIL_MSG_WIDTH ?>px;"><?= $mailtext ?></p></td></tr>
	<tr id="mailhtml" style="<?= $mailhtml_v ?>"><td class="msg_body" colspan="2"><?= $mailbody ?></td></tr>
</table>
</div>
<?php	html_footer();
	exit();
?>
