<?php
function contents_header($account_menu='on') {
	$menu_item = array();
	$menu_item[] = array("href"=>"index.php", "query"=>"arg=session", "name"=>"新着メール");
	$menu_item[] = array("href"=>"list.php", "query"=>"arg=session", "name"=>"メールBOX追加/削除");
	$menu_item[] = array("href"=>"category.php", "name"=>"カテゴリ一覧");
?>
<div id="contents_header">
<?php
	contents_menu($menu_item);
	if ($account_menu == 'on') {
		change_account_menu();
	}
?>
</div><!-- id="contents_header" -->
<?php
}
?>
