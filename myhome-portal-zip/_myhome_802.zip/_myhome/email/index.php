<?php
	require("__include-common.php");
	require("../account/__logincheck.php");
	require("__include-common-email.php");

	my_session_start();
	setcookie('current_id', $_SESSION['current_id'], 0, MY_SESSION_PATH);	// for ajax-email.php
	setcookie('login_id', $_SESSION['login_id'], 0, MY_SESSION_PATH);	// for ajax-email.php

	$table_name = "m_email";
	$http_arg = array();
	$http_arg['cat'] = '';
	_GET_to_http_arg_pool($http_arg, $table_name);

	html_header(HTML_TITLE, "_add_header_index.php");
	page_header();
	contents_header();
	ob_implicit_flush();	//自動フラッシュをオン(出力をバッファリングしない)
	email_body($http_arg, $table_name);
	page_footer();
	html_footer();
	exit();
?>
<?php
function email_body($http_arg, $table_name) {
	$con = my_mysqli_connect(_DB_SCHEMA);
?>
<div id="email_navi_box">
<ul id="email_navi">
<?php
	$sql_cat = "select * from m_category where c_delete = 0";
	$sql_cat .= " and id_account = '" . $_SESSION['current_id'] . "' order by c_categoryDisplayOrder asc";
	$rs_cat = my_mysqli_query($sql_cat);
	$cat_tbl = array();
	$cnt = 0;
	$cat_id = 0;
	while ($rec_cat = mysqli_fetch_array($rs_cat)) {
		if ($cnt == 0 || $rec_cat['id_category'] == intval($http_arg['cat'])) {
			$cat_id = $rec_cat['id_category'];	// カテゴリ選択必須。
		}
		$cat_tbl[] = array($rec_cat['id_category'], my_htmlspecialchars($rec_cat['c_categoryName']));
		$cnt++;
	}
	if ($cnt == 0) {
		echo '<br>メールBOXが未登録です。<br>最初に、カテゴリを登録してください。';
		return;
	}
	$http_arg['cat'] = $cat_id;
	arg_val_to_http_arg_pool($http_arg, $table_name);	// 追加/修正(一覧)で、同じカテゴリで開かせるため。
	foreach ($cat_tbl as $category) {
		$categoryName = my_htmlspecialchars($rec_cat['c_categoryName']);
?>
		<li<?= ($category[0] == $cat_id) ? ' id="email_navi_current"' : ' class="email_navi_tag"' ?> style="width: <?= mb_strwidth($category[1])+4 ?>ex;">
		<a href="<?= $_SERVER['SCRIPT_NAME'] ?>?cat=<?= $category[0] ?>"><?= $category[1] ?></a></li>
<?php
	}
?>
<script>
window.onload=function(){
	if(!NiftyCheck()) return;
	//RoundedTop("div#email_navi li", "transparent", "#404020");
	RoundedTop("li.email_navi_tag", "transparent", "#a9b0e0");
	AddTop(document.getElementById("email_navi_current"), "transparent", "#ff8c00");
}
function ajax_email(id) {
	data = "id="+id+"&width=<?= EMAIL_LIST_TABLE_WIDTH ?>&cnt=<?= EMAIL_LIST_VIEW_CNT ?>&read=<?= EMAIL_LIST_READ_CNT ?>";
	$.ajax({
		type: "GET",
		url: "ajax-email.php",
		data: data,
		async: true,
		success: function(res){
			$("#email_"+id).html(res);
		}
	})
}
</script>
</ul>
</div>
<div style="clear:both;padding:3px 0 0 30px;">
<button onClick="location.href='?cat=<?= $_GET['cat'] ?>&list=new'">新着メール再受信</button>
<label><input type="checkbox" value="on" onClick="chgCookieCheckOnOff(this, 'email_body_html', 'reload')" style="margin-left:10px;"<?php if ($_COOKIE['email_body_html'] == 'on') echo ' checked'; ?>>メール本文をHTML表示する</label>
</div>
<div id="email_body">
<?php
	$sql = "select * from v_email where c_delete = 0 and id_account = '" . $_SESSION['current_id'] . "'";
	$sql .= " and id_category = " . $cat_id;
	if ($_SESSION['current_id'] != $_SESSION['login_id']) {
		$sql .= " and c_privacy = 0";
	}
	$sql .= " order by c_displayOrder, c_name";
	$rs = my_mysqli_query($sql);
	$ajax_get = '';
	while ($rec = mysqli_fetch_array($rs)) {
		if ($_GET['list'] == 'new') {
			$_SESSION['email_get'][$rec['id_email']]['get'] = false;
		}
		$ajax_get .= 'ajax_email('.$rec['id_email'].');';
		email_view_frame($rec, EMAIL_LIST_TABLE_WIDTH);
	}
?>
<script>
$(function(){
	<?= $ajax_get ?>
});
</script>
<?php
}
?>
