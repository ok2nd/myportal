<meta charset="utf-8">
<meta name="author" content="ok.2nd">
<meta name="description" content="Email">
<meta name="keywords" content="email">
<link rel="stylesheet" href="<?= _STYLE_SHEET_FOLDER_COMMON ?>/common.css?20131130">
<link rel="stylesheet" href="<?= _STYLE_SHEET_BUTTON ?>">
<link rel="stylesheet" href="<?= _STYLE_SHEET_FOLDER ?>/email.css?20120805">
<link rel="stylesheet" href="<?= _STYLE_SHEET_FOLDER ?>/mp-list.css?20130525">
<script src="../scripts/jquery.js"></script>
<script src="../scripts/jquery.cookie.js"></script>
<script src="../scripts/ok2nd.js"></script>
