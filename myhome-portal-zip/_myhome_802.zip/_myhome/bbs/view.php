<?php
	require("__include-common.php");
	require("../account/__logincheck.php");
	if ($_POST) {
// *********************************************************************************
// * max_execution_time
// * post_max_size
// * upload_max_filesizeを越えるとisset($_POST['登録'])がTrueにならない。
// *********************************************************************************
		check_post_account($_POST['login_id']);
		post_done_proc();
	} else {
		if (WYSIWYG_EDITOR == 'YUI') {
			html_header(HTML_TITLE, "_add_input_header_YUI.php", '#ffffff', ' class="yui-skin-sam"');
		} else {
			html_header(HTML_TITLE, '', '#ffffff');
		}
		if (VIDEO_PREVIEW == 'YES') {
?>
		<script src="../scripts/JWPlayer/swfobject.js"></script>
		<script src="../scripts/JWPlayer/movie_preview.js"></script>
		<script src="../scripts/JWPlayer/silverlight.js"></script>
		<script src="../scripts/JWPlayer/wmvplayer.js"></script>
<?php
		}
		if (INPUT_DRAW_USE == "YES") { ?>
		<script src="../scripts/inputdraw/swfobject.js"></script>
		<script src="../scripts/inputdraw/inputdraw.js"></script>
<?php
		}
		page_header();
		view_thread();
		page_footer();
		html_footer();
	}
	exit();
?>
<?php
function post_done_proc() {
	if ($_POST['user_id'].'' <> '') {
		$user_id = intval($_POST['user_id']);
	} else {
		error_exit('不正アクセス：ユーザーIDなし', True);
	}
	if ($_POST['update_id'].'' <> '') {
		if (!is_numeric($_POST['update_id'])) {
			error_exit('不正アクセス。(1)', True);
		}
		$id = intval($_POST['update_id']);
	} else {
		$id = 0;
	}
	if (isset($_POST['削除']) or isset($_POST['全削除'])) {
		//	if ($_POST['削除する'] <> 'YES') {
		//		error_exit('削除するにチェックしてください。', True);
		//	}
	} elseif ($_POST['c_subject'].'' == '') {
		error_exit('件名なし', True);
	}
	$con = my_mysqli_connect(_DB_SCHEMA);
	$now_date = date("Y/m/d H:i:s");
	if (stripos($_POST['c_draw'] ,"<path ") === False) {
		$c_draw = '';
	} else {
		$c_draw = post_to_mysql("c_draw");
	}
	if ($id == 0) {
		$new_reply = True;
		$sql = "insert into m_bbs ";
		$sql .= "(id_account";
		$sql .= ", p_id_bbs";
		$sql .= ", c_subject";
		$sql .= ", c_body";
		$sql .= ", c_body_strip_tags";
		$sql .= ", c_draw";
		$sql .= ", c_registtime";
		$sql .= ", c_updatetime";
		$sql .= ") values ";
		$sql .= "( '".$user_id."'";
		$sql .= ", '".post_to_mysql("parent_id")."'";
		$sql .= ", '".post_to_mysql("c_subject")."'";
		$sql .= ", '".post_to_mysql("c_body")."'";
		$sql .= ", '".post_to_mysql_strip_tags("c_body")."'";
		$sql .= ", '".$c_draw."'";
		$sql .= ", '". $now_date . "'";
		$sql .= ", '". $now_date . "'";
		$sql .= ")";
		$ret = my_mysqli_query($sql, "登録できませんでした。");
	} elseif ($_POST['削除'] <> "") {
		$sql = "update m_bbs set";
		$sql .= " c_delete = 444";
		$sql .= ", c_updatetime = '". $now_date . "'";
		$sql .= " where id_bbs = ".$id;
		$sql .= " and id_account = ".$user_id;
		$ret = my_mysqli_query($sql, "削除できませんでした。");
	} elseif ($_POST['全削除'] <> "") {
		$sql = "update m_bbs set";
		$sql .= " c_delete = 888";
		$sql .= ", c_updatetime = '". $now_date . "'";
		$sql .= " where id_bbs = ".$id;
		$sql .= " and id_account = ".$user_id;
		$ret = my_mysqli_query($sql, "削除できませんでした。");
	} else {
		$sql = "update m_bbs set";
		$sql .= " c_subject = '".post_to_mysql("c_subject")."'";
		$sql .= ", c_body = '".post_to_mysql("c_body")."'";
		$sql .= ", c_body_strip_tags = '".post_to_mysql_strip_tags("c_body")."'";
		$sql .= ", c_draw = '".$c_draw."'";
		$sql .= ", c_updatetime = '". $now_date . "'";
		$sql .= ", c_delete = 0";
		$sql .= " where id_bbs = ".$id;
		$sql .= " and id_account = ".$user_id;
		$ret = my_mysqli_query($sql, "更新できませんでした。");
	}
	// ****** 添付ファイル ******
	if ($id == 0) {
		$id = my_mysqli_insert_id();	//直近のINSERTクエリによりAUTO_INCREMENTカラム用に生成されたIDを取得
	}
	$sw = False;
	$sqlupd = "";
	for ($ix=1; $ix<=3; $ix++) {
		// ***** ファイルのアップロード *****
		$attachFile = file_upload("filename".$ix, $id, ATTACH_FILE_FOLDER, $user_id);
		if ($attachFile <> "") {
			if ($sw) {
				$sqlupd .= ",";
			}
			$sqlupd .= " c_attachFile" . $ix . " = '" . $attachFile . "'";
			$sw = True;
		} else if ($_POST['fileDelete'.$ix] == "YES") {
			if ($sw) {
				$sqlupd .= ",";
			}
			$sqlupd .= " c_attachFile" . $ix . " = ''";
			$sw = True;
		}
	}
	if ($sw) {
		$sql = "update m_bbs set";
		$sql .= $sqlupd;
		$sql .= " where id_bbs = ".$id;
		$sql .= " and id_account = '".$user_id."'";
			//echo $sql;
			//exit;
		$ret = my_mysqli_query($sql, "アップロードファイル名DB登録失敗。");
	}
	$parent_id = str_for_mysql($_POST['parent_id']);
	if ($new_reply == True or $_POST['削除'] <> "") {	// 親レコードのc_reply_cnt、c_reply_lasttime更新
		$sql_sel = "select count(id_bbs) as reply_cnt from m_bbs where p_id_bbs = ".$parent_id." and c_delete = 0";
		$rs_upd = my_mysqli_query($sql_sel);
		$rec_upd = mysqli_fetch_array($rs_upd);
		$sql = "update m_bbs set";
		$sql .= " c_reply_cnt = ".$rec_upd['reply_cnt'];
		if ($new_reply == True) {
			$sql .= ", c_reply_lasttime = '".$now_date."'";
		}
		$sql .= " where id_bbs = ".$parent_id;
		$ret = my_mysqli_query($sql, "親レコードのc_reply_cnt、c_reply_lasttime更新失敗。");
	}
	mysqli_close($con);
	if ($_POST['全削除'] <> "") {
		redirect("list.php?cat=".$_GET['cat']."&page=".$_GET['page']);
	} else {
		redirect("view.php?id=".$parent_id."&move=".$_GET['move']."&row=".$_GET['row']."&cat=".$_GET['cat']."&page=".$_GET['page']);
	}
}
function view_thread() {
	if ($_GET['id'].'' <> '') {
		$id = intval($_GET['id']);
	} elseif ($_GET['move'].'' <> '') {
		$move = intval($_GET['move']);
		$id = 0;
	} else {
		error_exit("不正アクセス。(2)<br>", False);
	}
	if ($_GET['re_id'].'' <> '') {
		$re_id = intval($_GET['re_id']);
	} else {
		$re_id = 0;
	}
	if ($_GET['page'].'' <> '') {
		$page = intval($_GET['page']);
	}
	if ($_GET['row'].'' <> '') {
		$row = intval($_GET['row']);
	}
	if ($_GET['pl'].'' <> '') {
		$pageline = intval($_GET['pl']);
	}
	$con = my_mysqli_connect(_DB_SCHEMA);
	if ($id == 0) {
		if ($_SESSION['bbs_list_sql'].'' == '') {
			error_exit("不正アクセス。(3)<br>", False);
		}
		$rs = my_mysqli_query($_SESSION['bbs_list_sql']);
		if ($rs) {
			if ($row < $move+1) {
?>
				<div class="input_form_bbs">
				<h3 class="s_title">
				スレッドがありません。
				<a class="a_cancel_back" href='list.php?cat=<?= $_GET['cat'] ?>&page=<?= $page ?>'>一覧に戻る</a>
				</h3>
				</div>
<?php
				return;
			}
			mysqli_data_seek($rs, $move);
			$rec = mysqli_fetch_array($rs);
			$id = $rec['id_bbs'];
		}
	}
	$sql = "select * from v_bbs where (id_bbs = ".$id." or p_id_bbs = ".$id.")";
	$sql .= " order by id_bbs";
	$rs = my_mysqli_query($sql);
?>
<div class="input_form_bbs">
<?php
	$delete_all = False;
	while ($rec = mysqli_fetch_array($rs)) {
		if ($rec['id_bbs'] == $re_id and $rec['id_account'] <> $_SESSION['login_id']) {
			error_exit("本人以外は修正できません。<br>", False);
		}
		if ($rec['id_bbs'] == $id ) {
			$parent_subject = my_htmlspecialchars($rec['c_subject']);
			$move = intval($_GET['move']);
			$page = ceil(($move+1)/$pageline);
?>
		<table class="view_head" cellspacing=0><tr><td class="view_category"><h3><?= $rec['c_categoryName'] ?></h3></td>
		<td class="view_id_bbs_td">No. <span class="view_id_bbs"><?= $rec['id_bbs'] ?></span></td>
		<td>
		<a class="a_view_cancel_back" href='list.php?cat=<?= $_GET['cat'] ?>&page=<?= $page ?>'>一覧に戻る</a>
		<span class="view_page">スレッド： <span class="view_page_num"><?= $move+1 ?></span> / <span class="view_page_num"><?= $row ?></span></span>
		<?php if ($move <> 0) { ?>
		<a class="a_view_move" href="<?= $_SERVER['SCRIPT_NAME'] ?>?move=<?= $move-1 ?>&row=<?= $row ?>&cat=<?= $_GET['cat'] ?>&page=<?= $page ?>">[前←]</a>
		<?php } else { ?>
		<span class="view_link_off">[←前]</span>
		<?php } ?>
		<?php if ($move < $row-1) { ?>
		<a class="a_view_move" href="<?= $_SERVER['SCRIPT_NAME'] ?>?move=<?= $move+1 ?>&row=<?= $row ?>&cat=<?= $_GET['cat'] ?>&page=<?= $page ?>">[→次]</a>
		<?php } else { ?>
		<span class="view_link_off">[→次]</span>
		<?php } ?>
		</td></tr></table>
<?php
		}
		if ($rec['id_bbs'] == $re_id) {
?>
			<h3 class="s_title">修正<a class="a_cancel_back" href='view.php?id=<?= $_GET['id'] ?>&move=<?= $_GET['move'] ?>&row=<?= $_GET['row'] ?>&page=<?= $_GET['page'] ?>&cat=<?= $_GET['cat'] ?>'>戻る</a></h3>
<?php
			reply_form($rec, $page, $id, $re_id, $move, $row);
		} else {
			bbs_view($rec, $id, $page, $move, $row, $pageline);
		}
		if ($rec['c_delete'] == 888) {
			$delete_all = True;
			break;
		}
	}
	if ($re_id == 0 and $delete_all == False) {
		input_reply($rec, $page, $id, 0, $parent_subject, $move, $row);
	}
}
?>
<?php
function input_reply($rec, $page, $id, $re_id, $parent_subject, $move, $row) {
	$sql = "select * from v_bbs where id_bbs = 0";
	$rs = my_mysqli_query($sql);
	$rec = mysqli_fetch_array($rs);
?>
<h3 class="s_title">返信</h3>
<?
	reply_form($rec, $page, $id, 0, $move, $row, $parent_subject);
}
?>
<?php
function reply_form($rec, $page, $id, $re_id, $move, $row, $parent_subject='') {
	if ($re_id == 0) {
		$c_subject = 'Re: '.$parent_subject;
		$c_body = '';
		$c_draw = '';
	} else {
		$c_subject = my_htmlspecialchars($rec['c_subject']);
		$c_body = $rec['c_body'];
		$c_draw = $rec['c_draw'];
	}
?>
<?php	if (WYSIWYG_EDITOR == 'YUI') {	// ************************************** ?>
<script>
var myEditor;
(function() {
	var Dom = YAHOO.util.Dom,
	Event = YAHOO.util.Event;
	var myConfig = {
		height: '200px',
		width: '600px',
		animate: true,
		dompath: true,
		focusAtStart: false,
		autoHeight: true
	};
	myEditor = new YAHOO.widget.Editor('c_body', myConfig);
	myEditor.render();
})();
function formCheck(form) {
	if (form.c_subject.value == '') {
		window.alert('件名を入れてください。');
		return false;		// 送信を中止
	}
	myEditor.saveHTML();
	document.getElementById('c_body').value = myEditor.get('element').value;
	return true;	// 送信を実行
}
</script>
<?php	} else {			// ************************************** ?>
<script>
function formCheck(form) {
	if (form.c_subject.value == '') {
		window.alert('件名を入れてください。');
		return false;		// 送信を中止
	}
	return true;	// 送信を実行
}
</script>
<script src="../scripts/openwysiwyg/scripts/wysiwyg-ja.js"></script>
<script src="../scripts/openwysiwyg/scripts/wysiwyg-settings-ja.js"></script>
<script>
var mysettings = new WYSIWYG.Settings();
mysettings.ImagesDir = "../scripts/openwysiwyg/images/";
mysettings.PopupsDir = "../scripts/openwysiwyg/popups/";
mysettings.CSSFile = "../scripts/openwysiwyg/styles/wysiwyg.css'";
WYSIWYG.attach('c_body', mysettings); // default setup
</script>
<?php	}				// ************************************** ?>
<form name="form0" method="POST" action="<?= $_SERVER['SCRIPT_NAME'] ?>?<?= $_SERVER['QUERY_STRING'] ?>" enctype="multipart/form-data" onSubmit="return formCheck(this)">
	<input type="hidden" name="user_id" value="<?= $_SESSION['login_id'] ?>">
	<input type="hidden" name="parent_id" value="<?= $id ?>">
	<input type="hidden" name="page" value="<?= $page ?>">
	<input type="hidden" name="update_id" value="<?= $re_id ?>">
	<input type="hidden" name="login_id" value="<?= $_SESSION['login_id'] ?>">
	<input type="hidden" name="current_id" value="<?= $_SESSION['current_id'] ?>">
<table id="bbs_input" cellspacing=1>
<tr class="bbs_input_tr">
	<th class="input_form_th"><a name="input"></a>件名</a></th>
	<td class="input_form_td">
		<input class="text" type="text" name="c_subject" size=50 value="<?= my_htmlspecialchars($c_subject) ?>">
		<?php if ($rec['c_delete'] == 444) echo '<span class="warning">この投稿は削除されています。</font>' ?>
		<?php if ($rec['c_delete'] == 888) echo '<span class="warning">全投稿が削除されています。</font>' ?>
<?php if (INPUT_DRAW_USE == "YES" && $rec['c_delete'] == 0 && $c_draw == '') { ?>
<script>
function draw_display() {
	if (document.getElementById('inputdraw').style.display == 'none') {
		document.getElementById('inputdraw').style.display = '';
		document.getElementById('draw_display_button').value = 'お絵かき キャンセル';
	} else {
		document.getElementById('inputdraw').style.display = 'none';
		document.getElementById('draw_display_button').value = 'お絵かき';
	}
}
</script>
	<input type="button" id="draw_display_button" value="お絵かき" onClick="draw_display()">
<?php } ?>
	</td>
</tr>
<?php if (INPUT_DRAW_USE == "YES") { ?>
	<script>
	var draw1 = new InputDraw("../scripts/inputdraw/inputdraw.swf", "inputdraw_edit", {
	<?php if ($c_draw <> '') { ?>
		src_id: "inputdraw_svg",
	<?php } ?>
		id: "inputdraw_svg",
		width: "<?= INPUT_DRAW_WIDTH ?>",
		height: "<?= INPUT_DRAW_HEIGHT ?>",
		stroke_style: "<?= INPUT_DRAW_STROKE_STYLE ?>"
	});
	</script>
	</div>
	<tr class="bbs_input_tr" id="inputdraw"<?php if ($c_draw == '') { ?> style="display:none;"<?php } ?>>
		<th class="input_form_th">お絵かき</th>
		<td class="input_form_td">
		<div id="drawer_container" style="border:1px solid #e0e0e0; float:left;">
		<div id="inputdraw_edit"></div>
		</div>
		<textarea cols="50" id="inputdraw_svg" name="c_draw" readonly="readonly" rows="4" style="display:none;"><?= $c_draw ?></textarea>
		</td>
	</tr>
<?php } ?>
<tr class="bbs_input_tr">
	<th class="input_form_th">本文</th>
	<td class="input_form_td">
	<textarea id="c_body" name="c_body" cols=80 rows=10 wrap="soft"><?= my_htmlspecialchars($c_body) ?></textarea>
	</td>
</tr>
<tr class="bbs_input_tr">
	<th class="input_form_th">添付文書</th>
	<td class="input_form_td">
<?php	if (VIDEO_PREVIEW == 'YES') { ?>
	<!--<p><span class="alarm_text">ファイル名が英数字以外のFLV,MP4ファイルは動画再生できません。</span></p>-->
<?php	} ?>
<?php if ($rec['c_attachFile1'] <> "" || $rec['c_attachFile2'] <> "" || $rec['c_attachFile3'] <> "") { ?>
	<p><span class="alarm_text">再度添付ファイル名を指定すると登録済ファイルに上書きされます。</span></p>
<?php } ?>
<?php
	for ($ix=1; $ix<=3; $ix++) {
?>
		<div class="block">
		<div class="block_left">(<?= $ix ?>)</div>
		<div class="block_left">
<?php
		if ($rec['c_attachFile'.$ix] <> "") {
			attach_file_view($rec['id_account'], $rec['c_attachFile'.$ix], '', 100);
?>
		<label><input type="checkbox" name="fileDelete<?= $ix ?>" value="YES">削除</label>
		<input type="hidden" name="filenameCurrent<?= $ix ?>" value="<?= $rec['c_attachFile'.$ix] ?>">
<?php
		}
?>
		<input type="file" size=40 name="filename<?= $ix ?>" style="button-font-size:small">
		</div>
		</div>
<?php
	}
?>
	</td>
</tr>
</table>
<?php	if ($rec['c_delete'] == 888) { ?>
	<input class="input_form_button" type="submit" name="登録" value="全投稿を復活する"></font>
<?php	} elseif ($rec['c_delete'] == 444) { ?>
	<input class="input_form_button" type="submit" name="登録" value="投稿を復活する"></font>
	<?php if ($id == $re_id) { ?>
	<input class="input_form_button" type="submit" name="全削除" value="返信も含めてスレッド全体を削除" onClick="return delete_check('返信も含めてスレッド全体を削除しますか？');" style="margin-left:20px;">
	<?php } ?>
<?php	} elseif ($re_id == 0) { ?>
	<input class="input_form_button" type="submit" name="登録" value="返信"></font>
<?php	} elseif ($id == $re_id) { ?>
	<input class="input_form_button" type="submit" name="登録" value="修正">
	<input class="input_form_button" type="submit" name="全削除" value="返信も含めてスレッド全体を削除" onClick="return delete_check('返信も含めてスレッド全体を削除しますか？');" style="margin-left:20px;">
	<input class="input_form_button" type="submit" name="削除" value="この投稿のみ削除" onClick="return delete_check('この投稿のみ削除しますか？');" style="margin-left:20px;">
<?php	} else { ?>
	<input class="input_form_button" type="submit" name="登録" value="修正">
	<input class="input_form_button" type="submit" name="削除" value="削除" onClick="return delete_check('削除しますか？');" style="margin-left:20px;">
<?php	} ?>
</form>
<script>
function delete_check(msg) {
	if (window.confirm(msg)) {
		return true;
	} else {
		return false;
	}
}
</script>
<?
}
?>
<?php
function bbs_view($rec, $id, $page, $move, $row, $pageline) {
	if ($rec['id_bbs'] == $id) {
		$first_or_reply = "first";
	} else {
		$first_or_reply = "reply";
	}
?>
<div class="cornerbox_<?= $first_or_reply ?>">
<b class="xtop"><b class="xb1"></b><b class="xb2"></b><b class="xb3"></b><b class="xb4"></b></b>
<div class="xboxcontent">
	<table class="bbs_thread_table" cellspacing=1>
	<tr>
		<th class="bbs_thread_handle"><?= my_htmlspecialchars($rec['c_handle']) ?></th>
		<th class="bbs_thread_subject">
		<?
		if ($rec['c_delete'] == 444) {
			echo '【この投稿は削除されています。】';
		} elseif ($rec['c_delete'] == 888) {
			echo '【全投稿が削除されています。】';
		} else {
			echo my_htmlspecialchars($rec['c_subject']);
		}
		?>
		<?php if ($rec['id_account'] == $_SESSION['login_id']) { ?>
			<a class="a_bbs_update" href="<?= $_SERVER['SCRIPT_NAME'] ?>?id=<?= $id ?>&re_id=<?= $rec['id_bbs'] ?>&move=<?= $move ?>&row=<?= $row ?>&cat=<?= $_GET['cat'] ?>&page=<?= $page ?>&#input">[修正/削除]</a>
		<?php } ?>
		</th>
	</tr>
	<tr class="bbs_thread_body">
		<td class="bbs_thread_time"><?= date_from_mysql("y/m/d H:i:s", $rec['c_registtime']) ?>
		<?php if ($rec['c_registtime'] <> $rec['c_updatetime']) { ?>
			<br><span class="updatetime"><?= date_from_mysql("y/m/d H:i:s", $rec['c_updatetime']) ?></span>
		<?php } ?>
		</td>
		<td>
		<?php if ($rec['c_delete'] == 0) { ?>
			<?php if (INPUT_DRAW_USE == "YES" && $rec['c_draw'] <> '') { ?>
<script>
var view1 = new InputDraw("../scripts/inputdraw/inputdraw.swf", "inputdraw_<?= $rec['id_bbs'] ?>", {
	src_svg: '<?= $rec['c_draw'] ?>',
	width: "<?= INPUT_DRAW_WIDTH ?>",
	height: "<?= INPUT_DRAW_HEIGHT ?>",
	color: "#ffffff"
});
</script>
<div id="inputdraw_<?= $rec['id_bbs'] ?>"></div>
			<? } ?>
			<p><?= $rec['c_body'] ?></p>
			<?php
				$filename1 = $rec['c_attachFile1'];
				$filename2 = $rec['c_attachFile2'];
				$filename3 = $rec['c_attachFile3'];
				if ($filename1 <> "" || $filename2 <> "" || $filename3 <> "") {
			?>
				<p>
			<?php
					attach_file_view($rec['id_account'], $filename1, '<br>', VIEW_PHOTO_WIDTH,
						True, True, True, VIDEO_PREVIEW_WIDTH, VIDEO_PREVIEW_HEIGHT);
					attach_file_view($rec['id_account'], $filename2, '<br>', VIEW_PHOTO_WIDTH,
						True, True, True, VIDEO_PREVIEW_WIDTH, VIDEO_PREVIEW_HEIGHT);
					attach_file_view($rec['id_account'], $filename3, '<br>', VIEW_PHOTO_WIDTH,
						True, True, True, VIDEO_PREVIEW_WIDTH, VIDEO_PREVIEW_HEIGHT);
			?>
				</p>
			<?php
				}
			?>
		<?php } ?>
		</td>
	</tr>
	</table>
</div>
<b class="xbottom"><b class="xb4"></b><b class="xb3"></b><b class="xb2"></b><b class="xb1"></b></b>
</div>
<?php
}
?>
