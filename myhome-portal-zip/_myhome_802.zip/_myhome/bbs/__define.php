<?php
	if (defined("HTML_TITLE_bbs")) {
		define("HTML_TITLE", HTML_TITLE_bbs);
	} else {
		define("HTML_TITLE", "MyHome 掲示板");
	}
	define("SESSION_PREFIX", "bbs");

	if (defined("_DB_SCHEMA_bbs")) {
		define("_DB_SCHEMA", _DB_SCHEMA_bbs);
	} else {
		define("_DB_SCHEMA", "_db_bbs");
	}
	if (defined("ATTACH_FILE_FOLDER_bbs")) {
		define("ATTACH_FILE_FOLDER", ATTACH_FILE_FOLDER_bbs);
	} else {
		//↓絶対パスにできない？？？
		define("ATTACH_FILE_FOLDER", "../_attach/bbs/");
	}
	if (defined("WYSIWYG_EDITOR_bbs")) {
		define("WYSIWYG_EDITOR", WYSIWYG_EDITOR_bbs);
	} else {
		define("WYSIWYG_EDITOR", "openwysiwyg");
		//define("WYSIWYG_EDITOR", "YUI");
	}
	if (defined("VIEW_PHOTO_WIDTH_bbs")) {
		define("VIEW_PHOTO_WIDTH", VIEW_PHOTO_WIDTH_bbs);
	} else {
		define("VIEW_PHOTO_WIDTH", 400);
	}
	if (defined("VIDEO_PREVIEW_bbs")) {
		define("VIDEO_PREVIEW", VIDEO_PREVIEW_bbs);
		define("VIDEO_PREVIEW_EXT", VIDEO_PREVIEW_EXT_bbs);
		define("VIDEO_PREVIEW_WIDTH", VIDEO_PREVIEW_WIDTH_bbs);
		define("VIDEO_PREVIEW_HEIGHT", VIDEO_PREVIEW_HEIGHT_bbs);
	} else {
		define("VIDEO_PREVIEW", "YES");
		define("VIDEO_PREVIEW_EXT", "flv,mp4,mp3,wmv");
		define("VIDEO_PREVIEW_WIDTH", "400");
		define("VIDEO_PREVIEW_HEIGHT", "300");
	}
	if (defined("INPUT_DRAW_USE_bbs")) {
		define("INPUT_DRAW_USE", INPUT_DRAW_USE_bbs);
		define("INPUT_DRAW_WIDTH", INPUT_DRAW_WIDTH_bbs);
		define("INPUT_DRAW_HEIGHT", INPUT_DRAW_HEIGHT_bbs);
		define("INPUT_DRAW_STROKE_STYLE", INPUT_DRAW_STROKE_STYLE_bbs);
	} else {
		define("INPUT_DRAW_USE", "YES");
		define("INPUT_DRAW_WIDTH", "400");
		define("INPUT_DRAW_HEIGHT", "300");
		define("INPUT_DRAW_STROKE_STYLE", "3 1 rgb(32,32,32)");
	}
	define("PAGE_LINE_SELECT", "5,10,20,50,100,1000");	//頁内に表示する行数
	define("PAGE_LINE_DEFAULT", "10");			//頁内に表示する行数（デフォルト）
	if (!defined("FILE_UPLOAD_MEMORY_LIMIT")) {
		define("FILE_UPLOAD_MEMORY_LIMIT", "32M");	// ファイルアップロード メモリサイズ
	}
	if (!defined("FILE_UPLOAD_MAX_EXECUTION_TIME")) {
		define("FILE_UPLOAD_MAX_EXECUTION_TIME", "60");	// ファイルアップロード 最大実行時間
	}
?>
