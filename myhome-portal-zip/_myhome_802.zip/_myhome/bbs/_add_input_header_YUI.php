<link rel="stylesheet" href="../scripts/yui/build/editor/assets/skins/sam/editor.css" />
<script src="../scripts/yui/build/yahoo-dom-event/yahoo-dom-event.js"></script>
<script src="../scripts/yui/build/element/element-beta-min.js"></script>
<script src="../scripts/yui/build/container/container-min.js"></script>
<script src="../scripts/yui/build/menu/menu-min.js"></script>
<script src="../scripts/yui/build/button/button-min.js"></script>
<script src="../scripts/yui/build/editor/editor-min.js"></script>
