	<table class="bbs_list" cellspacing=1>
	<tr class="bbs_list_head">
	<th>カテゴリ</th><th>投稿者</th><th class="bbs_list_td_id">No.</th><th>件名</th>
	<th class="bbs_list_td_reply_cnt">返信</th><th nowrap>新規投稿日</th><th nowrap>最新返信日</th>
	</tr>
<?php
	mysqli_data_seek($rs, $startline);			//テーブル内の指定行に移動
	$line = $startline;					//$lineに$startlineを代入

	$odd = True;
	while ($rec=mysqli_fetch_array($rs) and $line<=$endline) {
		if ($odd) {
			$tr_class = 'bbs_list_odd';
		} else {
			$tr_class = 'bbs_list_even';
		}
?>
	<tr class="<?= $tr_class ?>">
	<td class="bbs_list_td_category"><?= my_htmlspecialchars($rec['c_categoryName']) ?></td>
	<td class="bbs_list_td_handle"><?= my_htmlspecialchars($rec['c_handle']) ?></td>
	<td class="bbs_list_td_id"><?= $rec['id_bbs'] ?></td>
	<td class="bbs_list_td_subject">
	<?php
		if ($rec['c_delete'] == 888) {
			$class = "a_delete_all";
			$subject = "【全投稿が削除されています。】";
		} elseif ($rec['c_delete'] == 444) {
			$class = "a_delete_one";
			$subject = "【主投稿が削除されています。】";
		} else {
			$class = "";
			$subject = my_htmlspecialchars($rec['c_subject']);
		}
	?>
		<a class="<?= $class ?>" href="view.php?id=<?= $rec['id_bbs'] ?>&move=<?= $line ?>&row=<?= $rowcnt ?>&page=<?= $page ?>&<?= query_from_http_arg_pool($http_arg) ?>"><?= $subject ?></a>
	</td>
	<td class="bbs_list_td_reply_cnt"><?= $rec['c_reply_cnt'] == 0 ? '-' : $rec['c_reply_cnt'] ?></td>
	<td class="bbs_list_td_registtime"><?= bbs_date_view($rec['c_registtime']) ?></td>
	<td class="bbs_list_td_reply_lasttime"><?= bbs_date_view($rec['c_reply_lasttime']) ?></td>
	</tr>
<?php
		$odd = !$odd;
		$line++;
	}
?>
	</table>
<?php
function bbs_date_view($datetime) {
	$view_date = date_from_mysql("y/m/d H:i:s", $datetime);
	$now_date = date("y/m/d");
	if (left($view_date,8) == $now_date) {
		return '<span class="bbs_today">'.$view_date.'</span>';
	} else {
		$before_week = date("y/m/d", mktime(0, 0, 0, intval(date("n")), intval(date("j"))-6, intval(date("Y"))));
		if (left($view_date,8) >= $before_week) {
			return '<span class="bbs_recent_day">'.$view_date.'</span>';
		}
	}
	return $view_date;
}
?>
