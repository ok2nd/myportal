<?php
	require("../__common__/__define_common.php");
	require("__define.php");
	require("../__common__/include-common-all.php");
	require("../__common__/include-common-html.php");
	require("_contents-header.php");

	my_session_start();

	if (isset($_GET['debug'])) {
		$_SESSION['debug'] = $_GET['debug'];
	}
?>
