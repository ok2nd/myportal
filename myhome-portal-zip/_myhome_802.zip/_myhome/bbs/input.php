<?php
	require("__include-common.php");
	require("../account/__logincheck.php");
	ini_set("memory_limit", FILE_UPLOAD_MEMORY_LIMIT);		//メモリサイズ
	ini_set("max_execution_time", FILE_UPLOAD_MAX_EXECUTION_TIME);	//最大実行時間
	if ($_POST) {
// *********************************************************************************
// * max_execution_time
// * post_max_size
// * upload_max_filesizeを越えるとisset($_POST['登録'])がTrueにならない。
// *********************************************************************************
		check_post_account($_POST['login_id']);
		post_done_proc();
	} else {
		if (WYSIWYG_EDITOR == 'YUI') {
			html_header(HTML_TITLE, "_add_input_header_YUI.php", '#ffffff', ' class="yui-skin-sam" onload="document.form0.c_subject.focus()"');
		} else {
			html_header(HTML_TITLE, '', '#ffffff', ' onload="document.form0.c_subject.focus()"');
		}
		page_header();
		input_form();
		page_footer();
		html_footer();
	}
	exit();
?>
<?php
function post_done_proc() {
	if ($_POST['user_id']."" <> "") {
		$user_id = $_POST['user_id'];
	} else {
		error_exit("不正アクセス：ユーザーIDなし", True);
	}
	if ($_POST['update_id']) {
		// ***** input.phpでは修正しない。修正はview.phpで行う。
		error_exit("修正不可", True);
	}
	if ($_POST['c_subject'] == "") {
		error_exit("件名なし", True);
	}
	$con = my_mysqli_connect(_DB_SCHEMA);
	$now_date = date("Y/m/d H:i:s");
	if (stripos($_POST['c_draw'] ,"<path ") === False) {
		$c_draw = '';
	} else {
		$c_draw = post_to_mysql("c_draw");
	}
	$sql = "insert into m_bbs ";
	$sql .= "(id_account";
	$sql .= ", id_category";
	$sql .= ", c_subject";
	$sql .= ", c_body";
	$sql .= ", c_body_strip_tags";
	$sql .= ", c_draw";
	$sql .= ", c_registtime";
	$sql .= ", c_reply_lasttime";
	$sql .= ", c_updatetime";
	$sql .= ") values ";
	$sql .= "( '".$user_id."'";
	$sql .= ", '" . $_POST['id_category'] . "'";
	$sql .= ", '".post_to_mysql("c_subject")."'";
	$sql .= ", '".post_to_mysql("c_body")."'";
	$sql .= ", '".post_to_mysql_strip_tags("c_body")."'";
	$sql .= ", '".$c_draw."'";
	$sql .= ", '". $now_date . "'";
	$sql .= ", '". $now_date . "'";
	$sql .= ", '". $now_date . "'";
	$sql .= ")";
	$ret = my_mysqli_query($sql, "登録できませんでした。");
	$id = my_mysqli_insert_id();	//直近のINSERTクエリによりAUTO_INCREMENTカラム用に生成されたIDを取得

	$sw = False;
	$sqlupd = "";
	for ($ix=1; $ix<=3; $ix++) {
		// ***** ファイルのアップロード *****
		$attachFile = file_upload("filename".$ix, $id, ATTACH_FILE_FOLDER, $user_id);
		if ($attachFile <> "") {
			if ($sw) {
				$sqlupd .= ",";
			}
			$sqlupd .= " c_attachFile" . $ix . " = '" . $attachFile . "'";
			$sw = True;
		} else if ($_POST['fileDelete'.$ix] == "YES") {
			if ($sw) {
				$sqlupd .= ",";
			}
			$sqlupd .= " c_attachFile" . $ix . " = ''";
			$sw = True;
		}
	}
	if ($sw) {
		$sql = "update m_bbs set";
		$sql .= $sqlupd;
		$sql .= " where id_bbs = ".$id;
		$sql .= " and id_account = '".$user_id."'";
			//echo $sql;
			//exit;
		$ret = my_mysqli_query($sql, "アップロードファイル名DB登録失敗。");
	}
	mysqli_close($con);
	redirect("view.php?id=".$id."&key=__reset__&page=".$_GET['page']);
}
function input_form() {
	if ($_GET['id'] <> "") {
		// ***** input.phpでは修正しない。修正はview.phpで行う。
		error_exit("修正不可", True);
	}
?>
<div class="input_form_bbs">
<h3>新規<a class="a_cancel_back" href='list.php?cat=<?= $_GET['cat'] ?>&page=<?= $_GET['page'] ?>'>戻る</a></h3>
<?php	if (WYSIWYG_EDITOR == 'YUI') {	// ************************************** ?>
<script>
var myEditor;
(function() {
	var Dom = YAHOO.util.Dom,
	Event = YAHOO.util.Event;
	var myConfig = {
		height: '200px',
		width: '600px',
		animate: true,
		dompath: true,
		focusAtStart: false,
		autoHeight: true
	};
	myEditor = new YAHOO.widget.Editor('c_body', myConfig);
	myEditor.render();
})();
function formCheck(form) {
	if (form.c_subject.value == '') {
		window.alert('件名を入れてください。');
		return false;		// 送信を中止
	}
	myEditor.saveHTML();
	document.getElementById('c_body').value = myEditor.get('element').value;
	return true;	// 送信を実行
}
</script>
<?php	} else {			// ************************************** ?>
<script>
function formCheck(form) {
	if (form.c_subject.value == '') {
		window.alert('件名を入れてください。');
		return false;		// 送信を中止
	}
	return true;	// 送信を実行
}
</script>
<script src="../scripts/openwysiwyg/scripts/wysiwyg-ja.js"></script>
<script src="../scripts/openwysiwyg/scripts/wysiwyg-settings-ja.js"></script>
<script>
var mysettings = new WYSIWYG.Settings();
mysettings.ImagesDir = "../scripts/openwysiwyg/images/";
mysettings.PopupsDir = "../scripts/openwysiwyg/popups/";
mysettings.CSSFile = "../scripts/openwysiwyg/styles/wysiwyg.css'";
WYSIWYG.attach('c_body', mysettings); // default setup
</script>
<?php	}				// ************************************** ?>
<form name="form0" method="POST" action="<?= $_SERVER['SCRIPT_NAME'] ?>?<?= $_SERVER['QUERY_STRING'] ?>" enctype="multipart/form-data" onSubmit="return formCheck(this)">
	<input type="hidden" name="user_id" value="<?= $_SESSION['login_id'] ?>">
	<input type="hidden" name="login_id" value="<?= $_SESSION['login_id'] ?>">
	<input type="hidden" name="current_id" value="<?= $_SESSION['current_id'] ?>">
<table id="bbs_input" cellspacing=1>
<tr class="bbs_input_tr">
	<th class="input_form_th" nowrap>カテゴリ</th>
	<td class="input_form_td" nowrap>
<?php
	$con = my_mysqli_connect(_DB_SCHEMA);
	$sqlsel = "select * from m_category where c_delete = 0";
	$sqlsel = $sqlsel . " order by c_categoryDisplayOrder";
	$rs_sel = my_mysqli_query($sqlsel);
?>
	<select name="id_category">
<?php
		$category = (int)$_GET['cat'];
		while ($rec_sel=mysqli_fetch_array($rs_sel)) {
?>
		<option value="<?= $rec_sel['id_category'] ?>"<?= $rec_sel['id_category'] == $category ? " selected" : "" ?>><?= my_htmlspecialchars($rec_sel['c_categoryName']) ?>
<?php
		}
?>
	</select>
	</td>
</tr>
<tr class="bbs_input_tr">
	<th class="input_form_th"><a name="input"></a>件名</a></th>
	<td class="input_form_td">
		<input class="text" type="text" name="c_subject" size=50 value="">
<?php if (INPUT_DRAW_USE == "YES") { ?>
<script>
function draw_display() {
	if (document.getElementById('inputdraw').style.display == 'none') {
		document.getElementById('inputdraw').style.display = '';
		document.getElementById('draw_display_button').value = 'お絵かき キャンセル';
	} else {
		document.getElementById('inputdraw').style.display = 'none';
		document.getElementById('inputdraw_svg').value = '';
		document.getElementById('draw_display_button').value = 'お絵かき';
	}
}
</script>
	<input type="button" id="draw_display_button" value="お絵かき" onClick="draw_display()">
<?php } ?>
	</td>
	</tr>
<?php if (INPUT_DRAW_USE == "YES") { ?>
	<script src="../scripts/inputdraw/swfobject.js"></script>
	<script src="../scripts/inputdraw/inputdraw.js"></script>
	<script>
	new InputDraw("../scripts/inputdraw/inputdraw.swf", "inputdraw_place", {
		id: "inputdraw_svg",
		width: "<?= INPUT_DRAW_WIDTH ?>",
		height: "<?= INPUT_DRAW_HEIGHT ?>",
		stroke_style: "<?= INPUT_DRAW_STROKE_STYLE ?>"
	});
	</script>
	<tr class="bbs_input_tr" id="inputdraw" style="display:none;">
		<th class="input_form_th">お絵かき</th>
		<td class="input_form_td">
		<div id="drawer_container" style="border:1px solid #e0e0e0; float:left;">
		<div id="inputdraw_place"></div>
		</div>
		<textarea cols="50" id="inputdraw_svg" name="c_draw" readonly="readonly" rows="4" style="display:none;"></textarea>
		</td>
	</tr>
<?php } ?>
<tr class="bbs_input_tr">
	<th class="input_form_th">本文</th>
	<td class="input_form_td">
	<textarea id="c_body" name="c_body" cols=80 rows=10 wrap="soft"></textarea>
	</td>
</tr>
<tr class="bbs_input_tr">
	<th class="input_form_th">添付文書</th>
	<td class="input_form_td">
<?php	if (VIDEO_PREVIEW == 'YES') { ?>
	<!--<p><span class="alarm_text">ファイル名が英数字以外のFLV,MP4ファイルは動画再生できません。</span></p>-->
<?php	} ?>
<?php
	for ($ix=1; $ix<=3; $ix++) {
?>
		<div class="block">
		<div class="block_left">(<?= $ix ?>)</div>
		<div class="block_left">
		<input type="file" size=40 name="filename<?= $ix ?>" style="button-font-size:small">
		</div>
		</div>
<?php
	}
?>
	</td>
</tr>
</table>
<input class="input_form_button" type="submit" name="登録" value="新規投稿"></font>
</form>
<?
}
?>
