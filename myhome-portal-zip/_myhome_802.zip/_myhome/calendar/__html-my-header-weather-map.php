<meta charset="utf-8">
<meta name="author" content="ok.2nd">
<meta name="description" content="weather">
<meta name="keywords" content="weather,天気出現率,map,日本地図">
<link rel="stylesheet" href="<?= _STYLE_SHEET_FOLDER_COMMON ?>/common.css?20131130">
<link rel="stylesheet" href="<?= _STYLE_SHEET_BUTTON ?>">
<link rel="stylesheet" href="<?= _STYLE_SHEET_FOLDER ?>/map-japan-weather.css?20091208">
<link rel="stylesheet" href="<?= _STYLE_SHEET_FOLDER ?>/weather.css?20120323">
