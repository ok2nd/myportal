<?php
	require("__include-common.php");
	require("../account/__logincheck.php");
	require("_my_calendar.php");
	if ($_GET['wh'] <> '') {
		$_SESSION['calendar_weather_mode'] = $_GET['wh'];
	}
	if (isset($_GET['ken'])) {
		$_SESSION['calendar_ken'] = $_GET['ken'];
	} elseif ($_SESSION['calendar_ken'] == '') {
		$_SESSION['calendar_ken'] = DEFAULT_TODOFUKEN_ID;
	}
	html_header(HTML_TITLE, '', '#ffffff');
	page_header();
	contents_header('off');
	$con = my_mysqli_connect(_DB_SCHEMA);
	weather_graph();
	mysqli_close($con);
	page_footer();
	html_footer();
?>
<?php
function weather_graph() {
?>
<div id="calendar_body">
<div id="filter_mode_change" class="block_left left_mini_margin">
<script>
function SelectionOption(opt, form, sel) {
	for (i = 0; i < sel.options.length; i++) {
		if (sel.options[i].selected == true) {
			window.location.href = "<?= $_SERVER['SCRIPT_NAME'] ?>?" + opt + "=" + escape(sel.options[i].value);
		}
	}
}
function RadioWeatherMode(sel) {
	window.location.href = '<?= $_SERVER['SCRIPT_NAME'] ?>?wh=' + sel;
}
</script>
<label><input type="radio" onClick="RadioWeatherMode('wh')"<?= $_SESSION['calendar_weather_mode'] <> 'tmp' ? ' checked' : '' ?>>天気出現率</label>
<label><input type="radio" onClick="RadioWeatherMode('tmp')"<?= $_SESSION['calendar_weather_mode'] == 'tmp' ? ' checked' : '' ?>>月平均気温</label>
</div>&nbsp;
<?php
	filter_kenmei()
?>
<script src="../scripts/Highcharts/js/highcharts.js"></script>
<!--[if IE]>
	<script src="../scripts/excanvas.compiled.js"></script>
<![endif]-->
<div id="calendar_main">
<?php
	if ($_SESSION['calendar_weather_mode'] == 'tmp') {
		graph_temperature();
	} else {
		graph_weather_ratio();
	}
?>
<div id="map_container"></div>
</div>
<?php
}
function graph_weather_ratio() {
	$sql = "select date_format(c_date,'%m') as mm,";
	$sql .= " floor(avg(c_cloud+0.5)) as cloud, floor(avg(c_rain+0.5)) as rain, floor(avg(c_snow+0.5)) as snow";
	$sql .= " from m_weather where c_kenid = '".$_SESSION['calendar_ken']."'";
	$sql .= " group by mm";

	$s_fine = '';
	$s_cloud = '';
	$s_rain = '';
	$s_snow = '';
	$rs = my_mysqli_query_debug_print($sql);
	while ($rec=mysqli_fetch_array($rs)) {
		$fine = 100-$rec['cloud']-$rec['rain']-$rec['snow'];
		concat_str_with_sep($s_fine, $fine, ', ');
		concat_str_with_sep($s_cloud, $rec['cloud'], ', ');
		concat_str_with_sep($s_rain, $rec['rain'], ', ');
		if ($rec['snow'] == '0') {
			concat_str_with_sep($s_snow, '0.1', ', ');
		} else {
			concat_str_with_sep($s_snow, $rec['snow'], ', ');
		}
	}
?>
<script>
$(document).ready(function() {
	var chart = new Highcharts.Chart({
		colors: [
			'#ffd8d8',
			'#c0c0c0',
			'#c0f0ff',
			'#c0d0ff',
			'#3D96AE',
			'#DB843D',
			'#92A8CD',
			'#A47D7C',
			'#B5CA92'
		],
		chart: {
			renderTo: 'map_container',
			defaultSeriesType: 'column'
		},
		title: {
			text: '天気出現率'
		},
		subtitle: {
			text: '30年間の気象データを基にした天気出現率'
		},
		xAxis: {
			categories: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月']
		},
		yAxis: {
			min: 0,
			title: {
				text: '天気出現率 (%)'
			}
		},
		legend: {
			style: {
				left: 'auto',
				bottom: 'auto',
				right: '50px',
				top: '10px'
			},
			backgroundColor: '#ffffff',
			borderCornerRadius: 0
		},
		tooltip: {
			formatter: function() {
				return '<b>'+ this.x +'</b><br/>'+
					this.series.name +': '+ this.y +'%';
			}
		},
		plotOptions: {
			column: {
				stacking: 'percent'
			}
		},
		series: [{
			name: '晴れ',
			data: [<?= $s_fine ?>]
		}, {
			name: '曇り',
			data: [<?= $s_cloud ?>]
		}, {
			name: '雨',
			data: [<?= $s_rain ?>]
		}, {
			name: '雪',
			data: [<?= $s_snow ?>]
		}]
	});
});
</script>
<?php
}
function graph_temperature() {
	$sql = "select date_format(c_date,'%m') as mm,";
	$sql .= " floor(avg(c_tempMax+0.5)) as tempMax, floor(avg(c_tempAve+0.5)) as tempAve, floor(avg(c_tempMin+0.5)) as tempMin";
	$sql .= " from m_weather where c_kenid = '".$_SESSION['calendar_ken']."'";
	$sql .= " group by mm";

	$s_tempMax = '';
	$s_tempAve = '';
	$s_tempMin = '';
	$rs = my_mysqli_query_debug_print($sql);
	while ($rec=mysqli_fetch_array($rs)) {
		concat_str_with_sep($s_tempMax, $rec['tempMax'], ', ');
		concat_str_with_sep($s_tempAve, $rec['tempAve'], ', ');
		concat_str_with_sep($s_tempMin, $rec['tempMin'], ', ');
	}
?>
<script>
$(document).ready(function() {
	var chart = new Highcharts.Chart({
		colors: [
			'#ffd8d8',
			'#c0c0c0',
			'#c0f0ff',
			'#80699B',
			'#3D96AE',
			'#DB843D',
			'#92A8CD',
			'#A47D7C',
			'#B5CA92'
		],
		chart: {
			renderTo: 'map_container',
			defaultSeriesType: 'line'
		},
		title: {
			text: '月平均気温'
		},
		subtitle: {
			text: '30年間の気象データを基にした気温'
		},
		xAxis: {
			categories: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月']
		},
		yAxis: {
			title: {
				text: '気温 (°C)'
			}
		},
		tooltip: {
			enabled: false,
			formatter: function() {
				return '<b>'+ this.series.name +'</b><br/>'+
					this.x +': '+ this.y +'°C';
			}
		},
		plotOptions: {
			line: {
				dataLabels: {
					enabled: true
				}
			}
		},
		series: [{
			name: '最高気温',
			data: [<?= $s_tempMax ?>]
		}, {
			name: '平均気温',
			data: [<?= $s_tempAve ?>]
		}, {
			name: '最低気温',
			data: [<?= $s_tempMin ?>]
		}]
	});
});
</script>
<?php
}
?>
