<?php
function contents_header($account_menu='on') {
	$menu_item = array();
	$menu_item[] = array("href"=>"month.php", "query"=>"arg=session", "name"=>"月間");
	$menu_item[] = array("href"=>"year.php", "query"=>"arg=session", "name"=>"年間");
	$menu_item[] = array("href"=>"list.php", "query"=>"arg=session", "name"=>"一覧");
	$menu_item[] = array("href"=>"weather-map.php", "query"=>"arg=session", "name"=>"天気出現地図");
	$menu_item[] = array("href"=>"weather-graph.php", "query"=>"arg=session", "name"=>"天気グラフ");
	$menu_item[] = array("href"=>"maps.php", "query"=>"arg=session", "name"=>"マップ");
	$menu_item[] = array("href"=>"maps-alone.php", "query"=>"arg=session", "name"=>"マップ(別窓)", "target"=>"_blank");
	$menu_item[] = array("href"=>"week.php", "query"=>"arg=session", "name"=>"週間(全員)");
	$menu_item[] = array("href"=>"category.php", "name"=>"カテゴリ一覧");
	if (_SCHEDULE_SENDMAIL_USE) {
		$menu_item[] = array("href"=>"send-mail.php", "name"=>"メール送信");
	}
	if (_CALENDAR_SEND_MESSAGE_USE <> 'NO') {
		$menu_item[] = array("href"=>"message.php", "name"=>"伝言");
	}
?>
<div id="contents_header">
<?php
	contents_menu($menu_item);
	if ($account_menu == 'on') {
		change_account_menu();
	}
?>
</div><!-- id="contents_header" -->
<?php
}
?>
