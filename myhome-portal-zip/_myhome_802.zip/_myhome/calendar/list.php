<?php
	require("__include-common.php");
	require("../account/__logincheck.php");
	require("../__common__/include-common-mp-list.php");
	require("_my_calendar.php");

	_account_change($_GET['uid']);

	$arg_pool_prefix = "calendar_schedule";

	$mp_list_arg = array();
	$mp_list_arg['account_id']	= $_SESSION['current_id'];
	$mp_list_arg['table_name_view']	= "v_schedule";
	$mp_list_arg['table_name_edit']	= "m_schedule";
	$mp_list_arg['id_item']		= "id_schedule";
if ($_SESSION['login_friends_cal_sbj_use_'.$_SESSION['current_id']] <> 'NO') {
	$mp_list_arg['must_item']	= "c_subject";
} else {
	$mp_list_arg['must_item']	= "c_memo";
}
	$mp_list_arg['add_filter']	= "list-my-add-filter.php";
	$mp_list_arg['template_view']	= "list-my-template.php";
//	$mp_list_arg['input_new']	= "no";
	$mp_list_arg['use_privacy']	= "yes";
	$mp_list_arg['add_id_account']	= "yes";
	$mp_list_arg['upd_id_account']	= "yes";

	$item_tbl = array();
	$item_tbl[] = array(	"表示名"=>"日付",	"列名"=>"c_date",
				"type"=>"date", "firstYear"=>_CALENDAR_SELECT_FIRST_YEAR, "toYear"=>10, "ime-mode"=>"disabled",
				"date_http_arg_y"=>"selY", "date_http_arg_m"=>"selM", "date_http_arg_d"=>"selD");
	$item_tbl[] = array(	"表示名"=>"時間",	"列名"=>"c_time1",
				"type"=>"time", "ime-mode"=>"disabled");
	$item_tbl[] = array(	"表示名"=>"～",	"列名"=>"c_time2",
				"type"=>"time", "ime-mode"=>"disabled");
	$item_tbl[] = array(	"表示名"=>"カテゴリ",	"列名"=>"id_category", "http_arg_GET名"=>"cat",
				"type"=>"select", "参照テーブル"=>"m_category", "参照テーブル表示列"=>"c_categoryName",
				"select_space"=>"Y",
				"filter_type"=>"callback",
				"参照テーブル表示順"=>"c_categoryDisplayOrder", "参照テーブル表示色"=>"c_categoryDisplayColor");
if ($_SESSION['login_friends_cal_sbj_use_'.$_SESSION['current_id']] <> 'NO') {
	$item_tbl[] = array(	"表示名"=>"件名",	"列名"=>"c_subject",
				"type"=>"text", "size"=>20, "ime-mode"=>"active", "文字検索"=>"Y");
}
	$item_tbl[] = array(	"表示名"=>"スケジュール本文",	"列名"=>"c_memo",
				"type"=>"textarea", "cols"=>50, "rows"=>3, "文字検索"=>"Y", "strip_tags"=>"Y");
	$order_tbl = array();
	$order_tbl[] = array(   "表示名"=>"登録最新順", "get_order_name"=>"new",
				"order_by"=>"id_schedule desc");		/* default */
	$order_tbl[] = array(   "表示名"=>"日付順(昇順)", "get_order_name"=>"date_a",
				"order_by"=>"c_date asc, c_time1 asc");
	$order_tbl[] = array(   "表示名"=>"日付順(降順)", "get_order_name"=>"date_d",
				"order_by"=>"c_date desc, c_time1 asc");

	$http_arg = array();
	$http_arg['pl'] = PAGE_LINE_DEFAULT;		// mp_list 必須
	$http_arg['sort'] = '';				// mp_list 必須
	$http_arg['cat'] = '';				// mp_list 必須
	$http_arg['key'] = '';				// mp_list 必須

	$http_arg['selY'] = '';
	$http_arg['selM'] = '';
	$http_arg['selD'] = '';

	$http_arg['toY'] = '';
	$http_arg['toM'] = '';
	$http_arg['toD'] = '';
	$http_arg['y'] = '';
	$http_arg['m'] = '';

	if (isset($_POST['登録'])) {
		check_post_account($_POST['login_id'], $_POST['current_id']);
		mp_list_update($mp_list_arg, $item_tbl, $order_tbl, $http_arg);
	} else {
		_GET_to_http_arg_pool($http_arg, $arg_pool_prefix, 'selY,selM,selD,toY,toM,toD,sort,key,pl,y,m');
		html_header(HTML_TITLE);
		page_header();
		contents_header();
		if ($_GET['edit'] == "y") {
			mp_list_edit($mp_list_arg, $item_tbl, $order_tbl, $http_arg);
		} else {
			mp_list_view($mp_list_arg, $item_tbl, $order_tbl, $http_arg);
		}
		page_footer();
		html_footer();
	}
	exit();
