<?php
	require("__include-common.php");
	require("../account/__logincheck.php");
	require("_my_calendar.php");
	if (!defined("GOOGLE_API_KEY")) {
		define("GOOGLE_API_KEY", "ABQIAAAA1XbMiDxx_BTCY2_FkPh06RRaGTYH6UMl8mADNa0YKuWNNa8VNxQEerTAUcfkyrr6OwBovxn7TDAH5Q");
	}
	if (!defined("MAPS_FIX_HEIGHT")) {
		define("MAPS_FIX_HEIGHT", 65);
	}
	require("../__common__/include-common-mp-list.php");
	require("list-my-add-filter.php");
	if (GOOGLE_MAPS_API_VERSION == 'V3') {
		require("maps-include-v3.php");
		$onload = ' onload="initialize()"';
	} else {
		require("maps-include.php");
		$onload = ' onload="init()" onunload="GUnload()"';
	}
	if (isset($_GET['all'])) {
		$_SESSION['schedule_maps_all'] = $_GET['all'];
	}
	_account_change($_GET['uid']);
	$arg_pool_prefix = "calendar_schedule";
	$http_arg = array();
	$http_arg['pl'] = PAGE_LINE_DEFAULT;
	$http_arg['cat'] = '';				// mp_list 必須
	$http_arg['key'] = '';				// mp_list 必須
	$http_arg['selY'] = '';
	$http_arg['selM'] = '';
	$http_arg['selD'] = '';
	$http_arg['toY'] = '';
	$http_arg['toM'] = '';
	$http_arg['toD'] = '';
	$http_arg['y'] = '';
	$http_arg['m'] = '';
	$item_tbl[] = array(	"表示名"=>"件名",	"列名"=>"c_subject",
				"type"=>"text", "size"=>20, "ime-mode"=>"active", "文字検索"=>"Y");
	$item_tbl[] = array(	"表示名"=>"スケジュール本文",	"列名"=>"c_memo", "strip_tags"=>"Y",
				"type"=>"textarea", "cols"=>46, "rows"=>3, "文字検索"=>"Y");
	_GET_to_http_arg_pool($http_arg, $arg_pool_prefix, 'selY,selM,selD,toY,toM,toD,y,m', false);
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta charset="utf-8">
<meta name="author" content="ok.2nd">
<meta name="description" content="Calendar">
<meta name="keywords" content="calendar,カレンダー">
<title>MyHome カレンダー マップ</title>
<link rel="stylesheet" href="<?= _STYLE_SHEET_FOLDER_COMMON ?>/common.css?20131130">
<link rel="stylesheet" href="<?= _STYLE_SHEET_BUTTON ?>">
<link rel="stylesheet" href="<?= _STYLE_SHEET_FOLDER ?>/mp-list.css?20130525">
<link rel="stylesheet" href="../scripts/msdropdown/css/dd-myhome.css">
<style>
html {
	width: 100%;
	height: 100%;
	overflow: hidden;
}
body {
	width: 100%;
	height: 100%;
}
#page_body {
	width: 100%;
	height: 100%;
}
#page_contents {
	width: 100%;
	height: 100%;
}
#map3d {
	width: 100%;
	height: 100%;
}
#maps_filter {
	clear: both;
	margin: 0 0 0 10px;
	padding: 0;
}
#maps_filter {
	clear: both;
	margin: 0 0 0 10px;
	padding: 0;
	$side_bar_width = 90;
}
#side_bar {
	position: absolute; top: 100px; right: 6px; width: 90px; height: 70%;
	border: 1px solid #666; padding: 6px; line-height: 1.4; overflow:scroll;
/*	background: #ffffff; filter: alpha(opacity=75); -moz-opacity:0.75; opacity:0.75; */
	background: url(../images/trans-white.png);
}
#side_bar li {
	white-space: nowrap;
}
#panorama {
	position: absolute; bottom: 15px; right: 40px; width: 45%; height: 45%;
	border: 1px solid #666; padding: 0px; line-height: 1.4; overflow: hidden;
	background: #ffffff;
}
#panowin {
	position: relative; width: 100%; height: 100%;
	border-top: 1px solid #666; padding: 0px;
}
.block {
	clear: both;
}
.block_left {
	float: left;
	text-align: left;
	padding: 0;
}
.error_msg { color: red; margin: 20px; padding: 0; }
.noramal_msg { color: #000000; margin: 20px; padding: 0; }
#map_canvas {
	width: 100%;
	height: 100%;
}
@media print {
	#map_canvas { height: 100%; }
	#side_bar { display: none; }
	#route_navi { display: none; }
	#not_found_box { display: none; }
	#maps_filter { display: none; }
	#map_canvas { position: absolute; top: 0px; left: 0px; }
}
</style>
<script src="../scripts/jquery.js"></script>
<script src="../scripts/jquery.cookie.js"></script>
<script src="../scripts/ok2nd.js"></script>
<script src="../scripts/msdropdown/js/jquery.dd.min.js"></script>
</head>
<body <?= $onload ?>>
<?php
	$con = my_mysqli_connect(_DB_SCHEMA);
	maps_proc($http_arg, $item_tbl, 'alone');
?>
</body>
</html>
