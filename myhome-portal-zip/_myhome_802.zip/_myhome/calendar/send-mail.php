<?php
	require("__include-common.php");
	require("../account/__logincheck.php");
	require("_my_calendar.php");
	if (!_SCHEDULE_SENDMAIL_USE) {
		exit();
	}
	if ($_POST) {
		setcookie("calendar_mail_item", $_POST['sendItem'], time() + LOGIN_COOKIE_EXPIRE, MY_SESSION_PATH);
		setcookie("calendar_mail_term", $_POST['schTerm'], time() + LOGIN_COOKIE_EXPIRE, MY_SESSION_PATH);
	}
	html_header(HTML_TITLE);
	page_header();
	contents_header();

	$con = my_mysqli_connect(_DB_ACCOUNT_SCHEMA);
	$sql = "SELECT * FROM m_account WHERE id_account = " . $_SESSION['login_id'] . " and c_delete = 0";
	$rs_account = my_mysqli_query($sql);
	$row = mysqli_num_rows($rs_account);
	if ($row == 0) {
		error_exit("アカウントがみつかりません。", True);
	}
	$rec_account = mysqli_fetch_array($rs_account);
	if ($rec_account['c_email_calendar'] == "") {
		error_exit("スケジュール送信先電子メールアドレスが登録されていませんので、送信できません。", True);
	}
	$email_to = $rec_account['c_email_calendar'];
	mysqli_close($con);

	input_form($email_to);
	if ($_POST) {
		check_post_account($_POST['login_id']);
		if (($error = post_done_proc($email_to, $body)) == '') {
			echo '<p class="noramal_msg">メールを送信しました。</p>';
			echo '<p class="noramal_msg">'.str_replace("\n", '<br>', $body).'</p>';
		} else {
			echo '<p class="error_msg">' . $error . '</p>';
		}
	}
	page_footer();
	html_footer();
	exit();
?>
<?php
function input_form($email_to) {
?>
<div class="input_form">
<!--<h3>ToDo & スケジュール メール送信</h3>-->
<p class="sendmail_msg">
<strong><?= $_SESSION['current_handle'] ?></strong>さんの ToDo & スケジュールを<br>
<strong><?= $email_to ?></strong> 宛てに送信します。
</p>
<form name="form0" method="POST" action="<?= $_SERVER['SCRIPT_NAME'] ?>">
	<input type="hidden" name="login_id" value="<?= $_SESSION['login_id'] ?>">
	<input type="hidden" name="current_id" value="<?= $_SESSION['current_id'] ?>">
<table>
<tr>
<?
	if ($_POST['sendItem'].'' <> '') {
		$sendItem = $_POST['sendItem'];
	} elseif ($_COOKIE['calendar_mail_item'].'' <> '') {
		$sendItem = $_COOKIE['calendar_mail_item'];
	} else {
		$sendItem = 'all';
	}
?>
	<td><label><input type="radio" name="sendItem" value="all"<? if ($sendItem == 'all') echo ' checked' ?>>Todo & スケジュール</label>
	<label><input type="radio" name="sendItem" value="todo"<? if ($sendItem == 'todo') echo ' checked' ?>>Todoのみ</label>
	<label><input type="radio" name="sendItem" value="sche"<? if ($sendItem == 'sche') echo ' checked' ?>>スケジュールのみ</label>
	</td>
</tr>
<tr>
<?
	if ($_POST['sendItem'].'' <> '') {
		$schTerm = $_POST['schTerm'];
	} elseif ($_COOKIE['calendar_mail_term'].'' <> '') {
		$schTerm = $_COOKIE['calendar_mail_term'];
	} else {
		$schTerm = '7';
	}
?>
	<td>スケジュール範囲：今日から
	<label><input type="radio" name="schTerm" value="7"<? if ($schTerm == '7') echo ' checked' ?>>1週間</label>
	<label><input type="radio" name="schTerm" value="14"<? if ($schTerm == '14') echo ' checked' ?>>2週間</label>
	<label><input type="radio" name="schTerm" value="32"<? if ($schTerm == '32') echo ' checked' ?>>1か月</label>
	<label><input type="radio" name="schTerm" value="62"<? if ($schTerm == '62') echo ' checked' ?>>2か月</label>
	<label><input type="radio" name="schTerm" value="0"<? if ($schTerm == '0') echo ' checked' ?>>全て</label>
	</td>
</tr>
</table>
	<input class="input_form_button" type="submit" name="送信" value="送信">
</form>
</div>
<?php
	return(0);
}
?>
<?php
function post_done_proc($email_to, &$body) {
	$con = my_mysqli_connect(_DB_SCHEMA);
	if ($_POST['sendItem'] <> 'sche') {
		$sql = 'select * from m_todo where id_account = ' . $_SESSION['current_id'];
		$sql .= ' and c_delete = 0 order by c_priority desc, id_todo asc';
		$rs = my_mysqli_query($sql);
		$row = mysqli_num_rows($rs);
		$body = "【ToDo】\n";
		if ($row == 0) {
			$body .= "ToDo登録なし\n";
		} else {
			while ($rec=mysqli_fetch_array($rs)) {
				$body .= my_htmlspecialchars($rec['c_todo']) . "\n";
			}
		}
		$body .= "\n";
	}
	if ($_POST['sendItem'] <> 'todo') {
		$sql = 'select * from m_schedule where id_account = ' . $_SESSION['current_id'];
		$date_from = date('Y-m-d');
		$sql .= " and c_date >= '" . $date_from . "'";
		if ($_POST['schTerm'] <> '0') {
			$date_to = date('Y-m-d', mktime(0, 0, 0, date('n'), date('d')+intval($_POST['schTerm']), date('y')));
			$sql .= " and c_date <= '" . $date_to . "'";
		}
		if ($_SESSION['current_id'] != $_SESSION['login_id']) {
			$sql .= " and c_privacy = 0";
		}
		$sql .= " and c_delete = 0 order by c_date, c_time1";
		$rs = my_mysqli_query($sql);
		$row = mysqli_num_rows($rs);
		$body .= "【スケジュール】\n";
		if ($row == 0) {
			$body .= "スケジュール登録なし\n";
		} else {
			$old_date = '';
			while ($rec=mysqli_fetch_array($rs)) {
				if ($old_date <> $rec['c_date']) {
					$body .= '■■ ' . date_from_mysql('Y/m/d', $rec['c_date']) . " ■■\n";
				}
				$body .= '◆ ';
				if ($rec['c_time1'].'' <> '' || $rec['c_time2'].'' <> '') {
					$body .= sch_time_format($rec['c_time1'], $rec['c_time2']) . "\n";
				}
				if ($rec['c_subject'].'' <> '') {
					$body .= "≪" . my_htmlspecialchars($rec['c_subject']) . "≫\n";
				}
				if ($rec['c_memo'].'' <> '') {
					$body .= strip_tags($rec['c_memo']) . "\n";
				}
				$old_date = $rec['c_date'];
			}
		}
	}
	mysqli_close($con);

	$subject =$_SESSION['current_handle'].':';
	if ($_POST['sendItem'] == 'sche') {
		$subject .= 'スケジュール';
	} elseif ($_POST['sendItem'] == 'todo') {
		$subject .= 'ToDo';
	} else {
		$subject .= 'ToDo & スケジュール';
	}
	if ($_POST['sendItem'] != 'todo') {
		$subject .= '('.str_replace('-','/',substr($date_from,2)).'～';
		if ($date_to.'' <> '') {
			$subject .= str_replace('-','/',substr($date_to,2));
		}
		$subject .= ')';
	}
	$header_from = _SENDMAIL_EMAIL_NAME . ' <'._SENDMAIL_EMAIL_ADDR.'>';
	$ret = my_send_mail(_SENDMAIL_EMAIL_ADDR, $header_from, $email_to, $subject, $body, _SENDMAIL_HOST, _SENDMAIL_PORT, _SENDMAIL_AUTH_USE, _SENDMAIL_EMAIL_USER, _SENDMAIL_EMAIL_PASS);
	if ($ret) {
		return '';
	} else {
		return 'メール送信でエラーが発生しました。';
	}
}
?>
