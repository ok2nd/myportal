<?php
	require("__include-common.php");
	require("../account/__logincheck.php");
	require("_my_calendar.php");

	html_header(HTML_TITLE);
	main_proc();
	html_footer();
	exit();
function main_proc() {
	if ($_GET['uid']) {
		$user_id = $_GET['uid'];
	}
	if ($_GET['y']) {
		$year = $_GET['y'];
	}
	if ($_GET['m']) {
		$month = $_GET['m'];
	}
	if ($_GET['d']) {
		$day = $_GET['d'];
	}
	if (check_permit_id($_SESSION['login_id'], $user_id) == "") {
		error_exit("不正アクセス。読み取り権限がありません。", True);
	}
	if (!checkdate($month, $day, $year)) {
		error_exit("日付が不正", True);
	}
	$con = my_mysqli_connect(_DB_SCHEMA);
	view_schedule($user_id, $year, $month, $day);
	mysqli_close($con);
}
function view_schedule($uid, $year, $month, $day) {
?>
<table id="calendar_popup_schedule">
<caption><span class="calendar_caption_ym"><span class='calendar_caption_ym_num'><?= $year ?></span>年 <span class='calendar_caption_ym_num'><?= $month ?></span>月 <span class='calendar_caption_ym_num'><?= $day ?></span>日</span></caption>
<tr>
	<td>
<?php
	schedule_print($year, $month, $day, $uid, "", "", False, True)
?>
	</td>
</tr>
</table>
<?
}
?>
