<?php
	require("__include-common.php");
	require("../account/__logincheck.php");
	if ($_GET['id'].'' == '') {
		exit;
	}
	$con = my_mysqli_connect(_DB_SCHEMA);
	$sql = "delete from m_message where id_message = ".intval($_GET['id']);
	$sql .= ' and ( from_id_account = '.$_SESSION['login_id'].' or to_id_account = '.$_SESSION['login_id'].' )';
	my_mysqli_query($sql);
//	redirect('message.php');
?>
