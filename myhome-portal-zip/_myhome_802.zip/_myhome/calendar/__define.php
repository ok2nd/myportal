<?php
	if (defined("HTML_TITLE_calendar")) {
		define("HTML_TITLE", HTML_TITLE_calendar);
	} else {
		define("HTML_TITLE", "MyHome カレンダー");
	}
	define("SESSION_PREFIX", "calendar");

	if (defined("_DB_SCHEMA_calendar")) {
		define("_DB_SCHEMA", _DB_SCHEMA_calendar);
	} else {
		define("_DB_SCHEMA", "_db_calendar");
	}

	if (defined("ATTACH_FILE_FOLDER_calendar")) {
		define("ATTACH_FILE_FOLDER", ATTACH_FILE_FOLDER_calendar);
	} else {
		//↓絶対パスにできない？？？
		define("ATTACH_FILE_FOLDER", "../_attach/calendar/");
	}
	if (defined("IMAGES_FOLDER_calendar")) {
		define("IMAGES_FOLDER", IMAGES_FOLDER_calendar);
	} else {
		define("IMAGES_FOLDER", "images");
	}
	if (defined("TEXTAREA_HTML_USE_calendar")) {
		define("TEXTAREA_HTML_USE", TEXTAREA_HTML_USE_calendar);
	} else {
		define("TEXTAREA_HTML_USE", "YES");
	}

	define("PAGE_LINE_SELECT", "5,10,20,50,100,1000");	//頁内に表示する行数
	define("PAGE_LINE_DEFAULT", "100");			//頁内に表示する行数（デフォルト）

	if (defined("ALBUM_PHOTO_SIZE_calendar")) {
		define("ALBUM_PHOTO_SIZE", ALBUM_PHOTO_SIZE_calendar);
		define("ALBUM_PHOTO_SIZE_POP", ALBUM_PHOTO_SIZE_POP_calendar);
	} else {
		define("ALBUM_PHOTO_SIZE", 100);
		define("ALBUM_PHOTO_SIZE_POP", 300);
	}

	// スケジュール入力画面カラータグ挿入ボタン定義ファイル
	if (defined("INPUT_COLOR_TAG_caledar")) {
		define("INPUT_COLOR_TAG", INPUT_COLOR_TAG_caledar);
	} else {
		define("INPUT_COLOR_TAG", "__define_color_tag.php");
	}

	// スケジュール入力画面の日付入力補助ポップアップカレンダーの種類
	// デフォルトは、ホームページの素(http://www.kanaya440.com/)の日付入力補助
	if (defined("INPUT_POPUP_CALENDAR_calendar")) {
		define("INPUT_POPUP_CALENDAR", INPUT_POPUP_CALENDAR_calendar);
	} else {
		define("INPUT_POPUP_CALENDAR", "");		// Yahoo! UI Library: Calendar を使う場合: "YUI"
	}

	if (defined("NO_SUBJECT_INPUT_MARK_calendar")) {
		define("NO_SUBJECT_INPUT_MARK", NO_SUBJECT_INPUT_MARK_calendar);
	} else {
		define("NO_SUBJECT_INPUT_MARK", "☆");
	}

	if (defined("TODO_VIEW_USE_calendar")) {
		define("TODO_VIEW_USE", TODO_VIEW_USE_calendar);
	} else {
		define("TODO_VIEW_USE", "YES");			// 月カレンダー右にToDo表示する場合:　"YES"
	}
	if (defined("TODO_VIEW_FRAME_COLOR_calendar")) {
		define("TODO_VIEW_FRAME_COLOR", TODO_VIEW_FRAME_COLOR_calendar);
	} else {
		define("TODO_VIEW_FRAME_COLOR", "#228b22");	// ToDo表示 枠カラー
	}
	if (!defined("DEFAULT_TODOFUKEN_ID")) {
		define("DEFAULT_TODOFUKEN_ID", "08");		// 天気出現率のデフォルトの都道府県：東京都
	}
	if (!defined("WEATHER_RATIO_LEVEL_1")) {
		define("WEATHER_RATIO_LEVEL_1", 70);		// 天気出現率のマーク分岐点(%)
	}
	if (!defined("WEATHER_RATIO_LEVEL_2")) {
		define("WEATHER_RATIO_LEVEL_2", 55);		// 天気出現率のマーク分岐点(%)
	}
	if (!defined("WEATHER_RATIO_LEVEL_3")) {
		define("WEATHER_RATIO_LEVEL_3", 45);		// 天気出現率のマーク分岐点(%)
	}
	if (!defined("WEATHER_TEMP_LEVEL_0")) {
		define("WEATHER_TEMP_LEVEL_0", 30);		// 気温分岐点
	}
	if (!defined("WEATHER_TEMP_LEVEL_1")) {
		define("WEATHER_TEMP_LEVEL_1", 25);		// 気温分岐点
	}
	if (!defined("WEATHER_TEMP_LEVEL_2")) {
		define("WEATHER_TEMP_LEVEL_2", 20);		// 気温分岐点
	}
	if (!defined("WEATHER_TEMP_LEVEL_3")) {
		define("WEATHER_TEMP_LEVEL_3", 15);		// 気温分岐点
	}
	if (!defined("WEATHER_TEMP_LEVEL_4")) {
		define("WEATHER_TEMP_LEVEL_4", 10);		// 気温分岐点
	}
	if (!defined("WEATHER_TEMP_LEVEL_5")) {
		define("WEATHER_TEMP_LEVEL_5", 5);		// 気温分岐点
	}
	if (!defined("WEATHER_TEMP_LEVEL_6")) {
		define("WEATHER_TEMP_LEVEL_6", 0);		// 気温分岐点
	}
	if (!defined("WEATHER_TEMP_LEVEL_7")) {
		define("WEATHER_TEMP_LEVEL_7", -5);		// 気温分岐点
	}
	if (!defined("WEATHER_TEMP_LEVEL_8")) {
		define("WEATHER_TEMP_LEVEL_8", -10);		// 気温分岐点
	}
	if (defined("CALENDAR_FILTER_TITLE_calendar")) {
		define("CALENDAR_FILTER_TITLE", CALENDAR_FILTER_TITLE_calendar);
	} else {
		define("CALENDAR_FILTER_TITLE", "スケジュール");
	}
	if (!defined("FILE_UPLOAD_MEMORY_LIMIT")) {
		define("FILE_UPLOAD_MEMORY_LIMIT", "32M");	// ファイルアップロード メモリサイズ
	}
	if (!defined("FILE_UPLOAD_MAX_EXECUTION_TIME")) {
		define("FILE_UPLOAD_MAX_EXECUTION_TIME", "60");	// ファイルアップロード 最大実行時間
	}
	if (defined("DENGON_VIEW_FRAME_COLOR_index")) {
		define("DENGON_VIEW_FRAME_COLOR", DENGON_VIEW_FRAME_COLOR_index);
	} else {
		define("DENGON_VIEW_FRAME_COLOR", "#ff0000");	// 伝言表示 枠カラー
	}
	if (!defined("CALENDAR_TODAY_SCROLL_ROW")) {
		define("CALENDAR_TODAY_SCROLL_ROW", 4);		// 月カレンダー:当日スクロールアップ行数指定(2以上指定可)
	}
	if (!defined("index_BOX_BORDER_COLOR")) {		// ボックスのボーダー色
		define("index_BOX_BORDER_COLOR", '');		// ボックスタイトルと同じ色
	}
	if (!defined("index_BOX_BORDER_WIDTH")) {		// ボックスのボーダー幅
		define("index_BOX_BORDER_WIDTH", '1px');
	}
	if (!defined("CALENDAR_HANDLE_PRINT_BY")) {		// カレンダーで他人が書き込んだスケジュールに「by ハンドル名」表示しない場合："NO"
		define("CALENDAR_HANDLE_PRINT_BY", '');
	}
	if (!defined("CALENDAR_ALBUM_VIEW_FOLDER_NAME")) {	// カレンダーのアルバムモードでフォルダ名表示："YES"
		define("CALENDAR_ALBUM_VIEW_FOLDER_NAME", '');
	}
?>
