	<table id="calendar_list_table">
<?php
	mysqli_data_seek($rs, $startline);			//テーブル内の指定行に移動
	$line = $startline;					//$lineに$startlineを代入
	$old_date = "";
	while ($rec=mysqli_fetch_array($rs) and $line<=$endline) {
		if ($rec['c_privacy'] == 444) {
		//	$view_day_class = 'calendar_list_table_day_privacy';
		//	$view_day_cont_class = 'calendar_list_table_day_cont_privacy';
			$view_sch_class = 'calendar_list_table_sch_privacy';
			$backg = '';
		} else {
		//	$view_day_class = 'calendar_list_table_day';
		//	$view_day_cont_class = 'calendar_list_table_day_cont';
			$view_sch_class = 'calendar_list_table_sch';
			if (CALENDAR_CATEGORYCOLOR_BACKGROUND <> 'NO') {
				if ($rec['c_categoryDisplayColor'] <> '') {
					$backg = ' style="background:'.$rec['c_categoryDisplayColor'].';"';
				} else {
					$backg = ' style="background:#ffffff;"';
				}
			}
		}
?>
<?php
		if ($line <> $startline) {
?>
	<a name="id_<?= $rec['id_schedule'] ?>"></a>
	</td>
	</tr>
<?php
		}
?>
	<tr>
	<?php if ($old_date <> $rec['c_date']) { ?>
	<td class="calendar_list_table_day">
<?php
		$date = $rec['c_date'];
		$year = date_from_mysql("Y", $date);
		$month = date_from_mysql("n", $date);
		$day = date_from_mysql("d", $date);
		$day_week = mb_substr("日月火水木金土", date_from_mysql("w", $date), 1);
		$holiday = holiday_check($year, $month, $day);
		if ($holiday) {
			$day_class = 'holiday';
			$day_week_view = "<a title='".$holiday."' class='dayweek_".$day_class."'>".$day_week."</a>";
		} else {
			if ($day_week == '日') {
				$day_class = "sunday";
			} elseif ($day_week == '土') {
				$day_class = "saturday";
			} else {
				$day_class = "weekday";
			}
			$day_week_view = "<span class='dayweek_".$day_class."'>".$day_week."</span>";
		}
?>
		<p>
		<a class="<?= $day_class ?>" href="month.php?y=<?= $year ?>&m=<?= $month ?>&cat=<?= $_GET['cat'] ?>"><?= date_from_mysql("Y-m-d", $date) ?></a>
		<?= $day_week_view ?>
		</p>
	</td>
	<?php } else { ?>
	<td class="calendar_list_table_day_cont">
		<br>
	</td>
	<?php } ?>
	<?php $old_date = $rec['c_date'] ?>
	<td class="<?= $view_sch_class ?>"<?= $backg ?>>
	<p>
<?php
	if ($rec['c_time1']."" <> "" || $rec['c_time2']."" <> "") {
		echo '<span class="calendar_time">';
		echo sch_time_format($rec['c_time1'], $rec['c_time2'])."&nbsp;";
		echo '</span>';
	}
	if ($rec['c_iconImage'] <> "") {
		echo "<img src='".IMAGES_FOLDER."/".$rec['c_iconImage']."'/>";
	}
// ***************************************
//				↓↓↓↓　　　& query_from_http_arg_pool($http_arg)
// ***************************************
?>
	<a name="id_<?= $rec['id_schedule'] ?>" class="title" href='input.php?uid=<?= $_SESSION['current_id'] ?>&id=<?= $rec['id_schedule'] ?>&page=<?= $page ?>&<?= query_from_http_arg_pool($http_arg) ?>'><?php
		if ($rec['c_subject'] == '') {
			echo NO_SUBJECT_INPUT_MARK;
		} else {
			echo my_htmlspecialchars($rec['c_subject']);
		}
	?></a>
	<?php
		if ($rec['c_map'] == 1) {
			echo '&nbsp;<a href="http://maps.google.co.jp/maps?q='.urlencode($rec['c_subject']).'" target="_blank" class="map_href">→地図</a>&nbsp;<a href="http://maps.google.co.jp/maps?ie=UTF8&f=d&ttype=dep&dirflg=r&saddr='.urlencode($_SESSION['login_friends_home_address_'.$current_id]).'&daddr='.urlencode($rec['c_subject']).'" target="_blank" class="route_href">→経路</a>';
		}
	?>
	<?php
		if ($rec['c_subject'] <> '' || $rec['c_categoryName'] <> '') {
			?></p><p><?php
		}
	?><span class="memo_body">
	<?php if (TEXTAREA_HTML_USE == "YES") { ?>
		<?= ins_br_strip_script(my_schedule_decorate($rec['c_memo'], $_SESSION['current_id'])) ?>
	<?php } else { ?>
		<?= ins_br(my_htmlspecialchars(icon_to_imgsrc($rec['c_memo']))) ?>
	<?php } ?>
	<?php if ($rec['add_id_account'] <> 0 and $rec['add_id_account'] <> $rec['id_account']) { ?>
		<span style="color:#a0a0a0;">by <?= $rec['add_c_handle'] ?></span>
	<?php } ?>
	</span></p>
	<?php
		$filename1 = $rec['c_attachFile1'];
		$filename2 = $rec['c_attachFile2'];
		$filename3 = $rec['c_attachFile3'];
		if ($filename1 <> "" || $filename2 <> "" || $filename3 <> "") {
	?>
			<p>
	<?php
			attach_file_view($rec['id_account'], $filename1, "<br>");
			attach_file_view($rec['id_account'], $filename2, "<br>");
			attach_file_view($rec['id_account'], $filename3, "<br>");
	?>
			</p>
	<?php
		}
	?>
<?php
		$line++;
	}
?>
	</td>
	</tr>
	</table>
<?php
	jquery_highlight('.memo_body', keystr_and_or($keystring));
?>
