<?php
function add_where_create($http_arg) {
	$add_where = "";
	if ($http_arg['toD'] <> "") {
		$add_where = " (c_date between '".$http_arg['selY']."/".$http_arg['selM']."/".$http_arg['selD']."'";
		$add_where .= " and '".$http_arg['toY']."/".$http_arg['toM']."/".$http_arg['toD']."')";
	} else if ($http_arg['toM'] <> "") {
		$add_where = " (c_date between '".$http_arg['selY']."/".$http_arg['selM']."/1'";
		$add_where .= " and '".$http_arg['toY']."/".$http_arg['toM']."/31')";
	} else {
		if ($http_arg['selY'] <> "") {
			if ($http_arg['toY'] <> "") {
				$add_where = " Year(c_date) >= '".$http_arg['selY']."'";
				$add_where .= " and Year(c_date) <= '".$http_arg['toY']."'";
			} else {
				$add_where = " Year(c_date) = '".$http_arg['selY']."'";
			}
		}
		if ($http_arg['selM'] <> "") {
			if ($add_where <> "") {
				$add_where .= " and ";
			}
			$add_where .= " Month(c_date) = '".$http_arg['selM']."'";
		}
		if ($http_arg['selD'] <> "") {
			if ($add_where <> "") {
				$add_where .= " and ";
			}
			$add_where .= " Day(c_date) = '".$http_arg['selD']."'";
		}
	}
	return ($add_where);
}
function add_my_filter($http_arg) {
?>
	<script>
	function SelectionYMD_Y(name) {
		window.location.href = "?"+name+"="+document.getElementById(name).value+"&cat=<?= $http_arg['cat'] ?>";
	}
	function SelectionYMD(form, sel, name) {
		for (i = 0; i < sel.options.length; i++) {
			if (sel.options[i].selected == true) {
				window.location.href = "?"+name+"="+escape(sel.options[i].value)+"&cat=<?= $http_arg['cat'] ?>";
			}
		}
	}
	function YearUpDown(id, updown) {
		$("#"+id).val(Number($("#"+id).val()) + Number(updown));
		window.location.href = "?"+id+"="+($("#"+id).val())+"&cat=<?= $http_arg['cat'] ?>";
	}
	</script>
	<div>
<?php
	$endYY = date("Y") + 10;
	select_view_with_id("selY", "年", _CALENDAR_SELECT_FIRST_YEAR, $endYY, $http_arg['selY'], $http_arg);
	select_view_with_id("selM", "月", 1, 12, $http_arg['selM'], $http_arg);
	select_view_with_id("selD", "日", 1, 31, $http_arg['selD'], $http_arg);
	echo "～";
	select_view_with_id("toY", "年", _CALENDAR_SELECT_FIRST_YEAR, $endYY, $http_arg['toY'], $http_arg);
	select_view_with_id("toM", "月", 1, 12, $http_arg['toM'], $http_arg);
	select_view_with_id("toD", "日", 1, 31, $http_arg['toD'], $http_arg);
?>
	<script>
	function selYtoday() {
		window.location.href = "<?= $_SERVER['SCRIPT_NAME'] ?>?selY=<?= date("Y") ?>&selM=__reset__&selD=__reset__&toY=__reset__&toM=__reset__&toD=__reset__&<?= query_from_http_arg_pool($http_arg, 'selY,selM,selD,toY,toM,toD') ?>&sort=date_a";
	}
	function selMtoday() {
		window.location.href = "<?= $_SERVER['SCRIPT_NAME'] ?>?selY=<?= date("Y") ?>&selM=<?= date("n") ?>&selD=__reset__&toY=__reset__&toM=__reset__&toD=__reset__&<?= query_from_http_arg_pool($http_arg, 'selY,selM,selD,toY,toM,toD') ?>&sort=date_a";
	}
	function selDtoday() {
		window.location.href = "<?= $_SERVER['SCRIPT_NAME'] ?>?selY=<?= date("Y") ?>&selM=<?= date("n") ?>&selD=<?= date("j") ?>&toY=__reset__&toM=__reset__&toD=__reset__&<?= query_from_http_arg_pool($http_arg, 'selY,selM,selD,toY,toM,toD') ?>&sort=date_a";
	}
	function selWtoday() {
<?php
		$fday = date("j") - date("w");	//週最初の日付
		$fdate = mktime(0, 0, 0, date("n"), $fday, date("Y"));
		$eday = $fday + 6;
		$edate = mktime(0, 0, 0, date("n"), $eday, date("Y"));
?>
		window.location.href = "<?= $_SERVER['SCRIPT_NAME'] ?>?selY=<?= date("Y", $fdate) ?>&selM=<?= date("n", $fdate) ?>&selD=<?= date("j", $fdate) ?>&toY=<?= date("Y", $edate) ?>&toM=<?= date("n", $edate) ?>&toD=<?= date("j", $edate) ?>&<?= query_from_http_arg_pool($http_arg, 'selY,selM,selD,toY,toM,toD') ?>&sort=date_a";
	}
	function selYMDreset() {
		window.location.href = "<?= $_SERVER['SCRIPT_NAME'] ?>?<?= query_from_http_arg_pool($http_arg, 'selY,selM,selD,toY,toM,toD') ?>&selY=__reset__&selM=__reset__&selD=__reset__&toY=__reset__&toM=__reset__&toD=__reset__&sort=date_a";
	}
	function selYMDprev() {
<?php
		$selY = $http_arg['selY'];
		$selM = $http_arg['selM'];
		$selD = $http_arg['selD'];
		$toY = $http_arg['toY'];
		$toM = $http_arg['toM'];
		$toD = $http_arg['toD'];
		if ($selY <> '' && $selM <> '' && $selD <> '') {
			if ($toY <> '' && $toM <> '' && $toD <> '') {
				$sTime = mktime(0, 0, 0, $selM, $selD, $selY);
				$eTime = mktime(0, 0, 0, $toM, $toD, $toY);
				$scopeD = ($eTime - $sTime) / (3600 * 24);
				$chgDate = mktime(0, 0, 0, $selM, $selD-$scopeD-1, $selY);
				$ssY = date("Y", $chgDate);
				$ssM = date("n", $chgDate);
				$ssD = date("j", $chgDate);
				$chgDate = mktime(0, 0, 0, $toM, $toD-$scopeD-1, $toY);
				$ttY = date("Y", $chgDate);
				$ttM = date("n", $chgDate);
				$ttD = date("j", $chgDate);
			} else {
				$chgDate = mktime(0, 0, 0, $selM, $selD-1, $selY);
				$ssY = date("Y", $chgDate);
				$ssM = date("n", $chgDate);
				$ssD = date("j", $chgDate);
				$ttY = "";
				$ttM = "";
				$ttD = "";
			}
		} elseif ($selY <> '' && $selM <> '') {
			if ($toY <> '' && $toM <> '') {
				$sTime = mktime(0, 0, 0, $selM, 1, $selY);
				$eTime = mktime(0, 0, 0, $toM, 1, $toY);
				$scopeD = ($eTime - $sTime) / (3600 * 24);
				$chgDate = mktime(0, 0, 0, $selM-2, 1, $selY);
				$ssY = date("Y", $chgDate);
				$ssM = date("n", $chgDate);
				$ssD = "";
				$chgDate = mktime(0, 0, 0, $selM-2, $scopeD+10, $selY);
				$ttY = date("Y", $chgDate);
				$ttM = date("n", $chgDate);
				$ttD = "";
			} else {
				$chgDate = mktime(0, 0, 0, $selM-1, 1, $selY);
				$ssY = date("Y", $chgDate);
				$ssM = date("n", $chgDate);
				$ssD = "";
				$ttY = "";
				$ttM = "";
				$ttD = "";
			}
		} elseif ($selY <> '') {
			if ($toY <> '') {
				$sTime = mktime(0, 0, 0, 1, 1, $selY);
				$eTime = mktime(0, 0, 0, 1, 1, $toY);
				$scopeD = ($sTime - $eTime) / (3600 * 24);
				$chgDate = mktime(0, 0, 0, 1, 1, $selY-1);
				$ssY = date("Y", $chgDate);
				$ssM = "";
				$ssD = "";
				$chgDate = mktime(0, 0, 0, 1, $scopeD+300, $selY-1);
				$ttY = date("Y", $chgDate);
				$ttM = "";
				$ttD = "";
			} else {
				$chgDate = mktime(0, 0, 0, 1, 1, $selY-1);
				$ssY = date("Y", $chgDate);
				$ssM = "";
				$ssD = "";
				$ttY = "";
				$ttM = "";
				$ttD = "";
			}
		} else {
			$ssY = "";
			$ssM = "";
			$ssD = "";
			$ttY = "";
			$ttM = "";
			$ttD = "";
		}
?>
		window.location.href = "<?= $_SERVER['SCRIPT_NAME'] ?>?selY=<?= $ssY ?>&selM=<?= $ssM ?>&selD=<?= $ssD ?>&toY=<?= $ttY ?>&toM=<?= $ttM ?>&toD=<?= $ttD ?>&<?= query_from_http_arg_pool($http_arg, 'selY,selM,selD,toY,toM,toD') ?>&sort=date_a";
	}
	function selYMDnext() {
<?php
		$selY = $http_arg['selY'];
		$selM = $http_arg['selM'];
		$selD = $http_arg['selD'];
		$toY = $http_arg['toY'];
		$toM = $http_arg['toM'];
		$toD = $http_arg['toD'];
		if ($selY <> '' && $selM <> '' && $selD <> '') {
			if ($toY <> '' && $toM <> '' && $toD <> '') {
				$sTime = mktime(0, 0, 0, $selM, $selD, $selY);
				$eTime = mktime(0, 0, 0, $toM, $toD, $toY);
				$scopeD = ($eTime - $sTime) / (3600 * 24);
				$chgDate = mktime(0, 0, 0, $selM, $selD+$scopeD+1, $selY);
				$ssY = date("Y", $chgDate);
				$ssM = date("n", $chgDate);
				$ssD = date("j", $chgDate);

?>
//window.alert('S:'+<?= $scopeD ?>+'='+<?= $toY ?>+'/'+<?= $toM ?>+'/'+<?= $toD ?>);
<?php
				$chgDate = mktime(0, 0, 0, $toM, $toD+$scopeD+1, $toY);
				$ttY = date("Y", $chgDate);
				$ttM = date("n", $chgDate);
				$ttD = date("j", $chgDate);
			} else {
				$chgDate = mktime(0, 0, 0, $selM, $selD+1, $selY);
				$ssY = date("Y", $chgDate);
				$ssM = date("n", $chgDate);
				$ssD = date("j", $chgDate);
				$ttY = "";
				$ttM = "";
				$ttD = "";
			}
		} elseif ($selY <> '' && $selM <> '') {
			if ($toY <> '' && $toM <> '') {
				$sTime = mktime(0, 0, 0, $selM, 1, $selY);
				$eTime = mktime(0, 0, 0, $toM, 1, $toY);
				$scopeD = ($eTime - $sTime) / (3600 * 24);
				$chgDate = mktime(0, 0, 0, $selM+2, 1, $selY);
				$ssY = date("Y", $chgDate);
				$ssM = date("n", $chgDate);
				$ssD = "";
				$chgDate = mktime(0, 0, 0, $selM+2, $scopeD+10, $selY);
				$ttY = date("Y", $chgDate);
				$ttM = date("n", $chgDate);
				$ttD = "";
			} else {
				$chgDate = mktime(0, 0, 0, $selM+1, 1, $selY);
				$ssY = date("Y", $chgDate);
				$ssM = date("n", $chgDate);
				$ssD = "";
				$ttY = "";
				$ttM = "";
				$ttD = "";
			}
		} elseif ($selY <> '') {
			if ($toY <> '') {
				$sTime = mktime(0, 0, 0, 1, 1, $selY);
				$eTime = mktime(0, 0, 0, 1, 1, $toY);
				$scopeD = ($sTime - $eTime) / (3600 * 24);
				$chgDate = mktime(0, 0, 0, 1, 1, $selY+1);
				$ssY = date("Y", $chgDate);
				$ssM = "";
				$ssD = "";
				$chgDate = mktime(0, 0, 0, 1, $scopeD+300, $selY+1);
				$ttY = date("Y", $chgDate);
				$ttM = "";
				$ttD = "";
			} else {
				$chgDate = mktime(0, 0, 0, 1, 1, $selY+1);
				$ssY = date("Y", $chgDate);
				$ssM = "";
				$ssD = "";
				$ttY = "";
				$ttM = "";
				$ttD = "";
			}
		} else {
			$ssY = "";
			$ssM = "";
			$ssD = "";
			$ttY = "";
			$ttM = "";
			$ttD = "";
		}
?>
		window.location.href = "<?= $_SERVER['SCRIPT_NAME'] ?>?selY=<?= $ssY ?>&selM=<?= $ssM ?>&selD=<?= $ssD ?>&toY=<?= $ttY ?>&toM=<?= $ttM ?>&toD=<?= $ttD ?>&<?= query_from_http_arg_pool($http_arg, 'selY,selM,selD,toY,toM,toD') ?>&sort=date_a";
	}
	</script>
	<input type="button" name="" value="<<" onClick="selYMDprev()">
	<input type="button" name="" value=">>" onClick="selYMDnext()">
	<input type="button" name="" value="今年" onClick="selYtoday()">
	<input type="button" name="" value="今月" onClick="selMtoday()">
	<input type="button" name="" value="今週" onClick="selWtoday()">
	<input type="button" name="" value="今日" onClick="selDtoday()">
	<input type="button" name="" value="リセット" onClick="selYMDreset()">
	</div>
<?php
	//return ($add_where);
}
?>
<?php
function select_view_with_id($name, $suffix, $first, $end, $now, $http_arg) {
	if ($suffix == '年') {
		if (strstr($_SERVER['HTTP_USER_AGENT'], "Chrome")) {
?>
<input type="number" id="<?= $name ?>" name="<?= $name ?>" value="<?= $now ?>" style="width:4em;"<?= $now <> '' ? ' class="mp_list_filter_true"' : '' ?> onChange="SelectionYMD_Y('<?= $name ?>')"><?= $suffix ?>
<?php		} else { ?>

<input type="text" id="<?= $name ?>" name="<?= $name ?>" value="<?= $now ?>" style="width:3em;" class="text<?= $now <> '' ? ' mp_list_filter_true' : '' ?>" onChange="SelectionYMD_Y('<?= $name ?>')"><input type="button" value="▲" style="font-size:10px;margin:0;padding:0;" OnClick="YearUpDown('<?= $name ?>',1)"><input type="button" value="▼" style="font-size:10px;margin:0;padding:0;" OnClick="YearUpDown('<?= $name ?>',-1)"><?= $suffix ?>
<?php		} ?>
<?php	} else { ?>
	<select id="<?= $name ?>" class="<? if ($now.'' <> '') echo 'mp_list_filter_true'; ?>" onChange="SelectionYMD(this.form, this, '<?= $name ?>')">
	<option value="__reset__" class="mp_list_filter_false">
<?php
	for ($i=$first; $i<=$end; $i++) {
?>
	<option value="<?= $i ?>"<?= $i == $now ? ' selected class="mp_list_filter_true"' : ' class="mp_list_filter_false"' ?>><?= $i ?>
<?php
	}
?>
	</select><?= $suffix ?>
<?php
	}
}
?>
