<?php
function weather_ratio_class($kenid, $month, $day) {
	if ($rec = weather_ratio_rec($kenid, $month, $day)) {
		return 'weather_bg_'.weather_ratio_chk($rec);
	} else {
		return 'weather_bg_none';
	}
}
function weather_temp_class($kenid, $month, $day) {
	if ($rec = weather_ratio_rec($kenid, $month, $day)) {
		return 'temp_bg_'.weather_temp_chk($rec);
	} else {
		return 'temp_bg_none';
	}
}
function weather_ratio_print($kenid, $month, $day) {
	if ($rec = weather_ratio_rec($kenid, $month, $day)) {
		$icon = weather_ratio_chk($rec).'.gif';
		echo '<a href="weather-map.php?m='.$month.'&d='.$day.'">';
		echo '<img src="../icon/weather/' . $icon . '" /></a>';
		echo '<span style="vertical-align: top;"><span class="weather_ratio_fine">'.round($rec['c_fine']).'</span>/<span class="weather_ratio_cloud">'.round($rec['c_cloud']).'</span>/<span class="weather_ratio_rain">'.round($rec['c_rain']).'</span>';
		if (round($rec['c_snow']) > 0) {
			echo '/<span class="weather_ratio_snow">'.round($rec['c_snow']).'</span>';
		}
			echo '/<span>';
	}
}
function weather_temp_print($kenid, $month, $day) {
	if ($rec = weather_ratio_rec($kenid, $month, $day)) {
		$temp = weather_temp_chk($rec);
		echo '<a href="weather-map.php?m='.$month.'&d='.$day.'" class="temp_link">';
		echo '<span class="temp_color_'.$temp.'">●</span></a>';
		echo '<span class="weather_temp_max">'.$rec['c_tempMax'].'</span>/<span class="weather_temp_ave">'.$rec['c_tempAve'].'</span>/<span class="weather_temp_min">'.$rec['c_tempMin'].'</span>';
	}
}
function weather_ratio_rec($kenid, $month, $day) {
	global $con;
	$sql = "select * from m_weather where c_kenid = '" . $kenid . "'";
	$sql .= " and c_date = '".date("Y-m-d", mktime(0, 0, 0, $month, $day, 2000))."';";
	if ($rs = mysqli_query($con, $sql)) {
		return mysqli_fetch_array($rs);
	} else {
		return false;
	}
}
function weather_ratio_rec_kenmei($kenmei, $month, $day) {
	global $con;
	$sql = "select * from v_weather where c_kenmei like '" . $kenmei . "%'";
	$sql .= " and c_date = '".date("Y-m-d", mktime(0, 0, 0, $month, $day, 2000))."';";
	if ($rs = mysqli_query($con, $sql)) {
		return mysqli_fetch_array($rs);
	} else {
		return false;
	}
}
function weather_ratio_chk_OLD($rec) {
	if ($rec['c_fine'] >= WEATHER_RATIO_LEVEL_1) {
		return 'fine';
	} elseif ($rec['c_fine'] >= WEATHER_RATIO_LEVEL_2) {
		return 'fine_cloud';
	} elseif ($rec['c_fine'] >= WEATHER_RATIO_LEVEL_3) {
		return 'fine_rain';
	} else  {
		if ($rec['c_cloud'] >= $rec['c_rain']+$rec['c_snow']) {
			return 'cloud';
		} elseif ($rec['c_rain'] > $rec['c_snow']) {
			return 'rain';
		} else {
			return 'snow';
		}
	}
}
function weather_ratio_chk($rec) {
	$max = $rec['c_fine'];
	$max_item = 'fine';
	if ($rec['c_cloud'] > $max) {
		$max = $rec['c_cloud'];
		$max_item = 'cloud';
	}
	if ($rec['c_snow'] > $max) {
		$max = $rec['c_snow'];
		$max_item = 'snow';
	}
	if ($rec['c_rain'] > $max) {
		$max_item = 'rain';
	}
	if ($max_item == 'fine') {
		if ($rec['c_fine'] >= 50) {
			return 'fine';
		} elseif ($rec['c_cloud'] >= ($rec['c_rain'] + $rec['c_snow'])) {
			return 'fine_cloud';
		} else {
			return 'fine_rain';
		}
	}
	return $max_item;
}
function weather_temp_chk($rec) {
	if ($rec['c_temp'.$_SESSION['calendar_temp_mode']] >= WEATHER_TEMP_LEVEL_0) {
		return 'burn';
	} elseif ($rec['c_temp'.$_SESSION['calendar_temp_mode']] >= WEATHER_TEMP_LEVEL_1) {
		return 'vhot';
	} elseif ($rec['c_temp'.$_SESSION['calendar_temp_mode']] >= WEATHER_TEMP_LEVEL_2) {
		return 'hot';
	} elseif ($rec['c_temp'.$_SESSION['calendar_temp_mode']] >= WEATHER_TEMP_LEVEL_3) {
		return 'warm';
	} elseif ($rec['c_temp'.$_SESSION['calendar_temp_mode']] >= WEATHER_TEMP_LEVEL_4) {
		return 'nice';
	} elseif ($rec['c_temp'.$_SESSION['calendar_temp_mode']] >= WEATHER_TEMP_LEVEL_5) {
		return 'cool';
	} elseif ($rec['c_temp'.$_SESSION['calendar_temp_mode']] >= WEATHER_TEMP_LEVEL_6) {
		return 'cold';
	} elseif ($rec['c_temp'.$_SESSION['calendar_temp_mode']] >= WEATHER_TEMP_LEVEL_7) {
		return 'iced';
	} elseif ($rec['c_temp'.$_SESSION['calendar_temp_mode']] >= WEATHER_TEMP_LEVEL_8) {
		return 'freeze';
	} else  {
		return 'pain';
	}
}
?>
