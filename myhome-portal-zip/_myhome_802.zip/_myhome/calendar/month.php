<?php
	require("__include-common.php");
	require("../account/__logincheck.php");
	require("_my_calendar.php");
	// mp_list_filter_key_select()を使うため
	require("../__common__/include-common-mp-list.php");

	_account_change($_GET['uid']);

	if (CALENDAR_DIARY_MODE == 'diary') {
		$_SESSION['diary_back_view'] = $_SERVER['SCRIPT_NAME'].'?'.$_SERVER['QUERY_STRING'];
		$_SESSION['diary_back_view_name'] = '月間カレンダーに戻る';
	}
	if (isset($_GET['mode'])) {
		$_SESSION['calendar_mode'] = $_GET['mode'];
	}
	if ($_GET['wh'] <> '') {
		$_SESSION['calendar_weather_mode'] = $_GET['wh'];
	}
	if ($_GET['tm'] <> '') {
		$_SESSION['calendar_temp_mode'] = $_GET['tm'];
		$_SESSION['calendar_weather_mode'] = 'tmp';
	} elseif ($_SESSION['calendar_temp_mode'] == '') {
		$_SESSION['calendar_temp_mode'] = 'Ave';
	}
	if (isset($_GET['ken'])) {
		$_SESSION['calendar_ken'] = $_GET['ken'];
	} elseif ($_SESSION['calendar_ken'] == '') {
		$_SESSION['calendar_ken'] = DEFAULT_TODOFUKEN_ID;
	}
	$arg_pool_prefix = "calendar_schedule";

	$http_arg = array();
	$http_arg['y'] = '';
	$http_arg['m'] = '';
	$http_arg['d'] = '';

	$http_arg['pl'] = PAGE_LINE_DEFAULT;
	$http_arg['cat'] = '';
	$http_arg['key'] = '';
	$http_arg['sort'] = '';

	$http_arg['selY'] = '';
	$http_arg['selM'] = '';
	$http_arg['selD'] = '';
	$http_arg['toY'] = '';
	$http_arg['toM'] = '';
	$http_arg['toD'] = '';

	_GET_to_http_arg_pool($http_arg, $arg_pool_prefix, 'selY,selM,selD,toY,toM,toD,y,m,key,sort,pl');
	$category = $http_arg['cat'];
	$keystring = keystr_fix($http_arg['key']);

	$year = $http_arg['y'];
	$month = $http_arg['m'];
	if ($year == '') {
		$year = date("Y");
	}
	if ($month == '') {
		$month = date("n");
	}
	html_header(HTML_TITLE);
	page_header();
	contents_header();

	$prev_year_m = $month;
	$prev_year_y = $year - 1;
	$next_year_m = $month;
	$next_year_y = $year + 1;
	if ($month == 1) {
		$prev_month_m = 12;
		$prev_month_y = $year - 1;
		$next_month_m = $month + 1;
		$next_month_y = $year;
	} elseif ($month == 12) {
		$prev_month_m = $month - 1;
		$prev_month_y = $year;
		$next_month_m = 1;
		$next_month_y = $year + 1;
	} else {
		$prev_month_m = $month - 1;
		$prev_month_y = $year;
		$next_month_m = $month + 1;
		$next_month_y = $year;
	}
	$con = my_mysqli_connect(_DB_SCHEMA);
?>
<div id="calendar_body">
<form method="POST" name="filter_form" action="<?= $_SERVER['SCRIPT_NAME'] ?>?<?= query_from_http_arg_pool($http_arg) ?>">
<table><tr><td nowrap>
<span id="calendar_category_select">
<?php
	filter_category_select($category, $_SESSION['current_id'], $http_arg);
?>
</span>
<span id="filter_key_select" class="left_mini_margin">
<?php
	filter_key_select($keystring, $http_arg);
?>
</span>
<span id="filter_mode_change" class="left_mini_margin">
<?php
	filter_mode_change(True);	// 詳細表示有
?>
</span>
</td></tr></table>
</form>
<script>
$(function(){
	$(".calendar_tbl td").dblclick(function(){
		var input_url = $(this).attr("id");
		location.href = input_url;
	});
});
</script>
<div id="calendar_main">
<table>
<tr><td>
<?php
	calendar_month($year, $month, $_SESSION['current_id'], $category, $keystring);
?>
</td><td>
<?php
	if (_CALENDAR_SEND_MESSAGE_USE <> 'NO') {
		message_body();
	}
	if (TODO_VIEW_USE == 'YES') {
		todo_body();
	}
?>
<style>
.calendar_tbl_mini {
	width: 138px;
}
</style>
	<div id="calendar_3_month">
	<table class="year_calendar_frame">
	<?php
		if ($month == 1) {
			$year = $year - 1;
			$month = 12;
		} else {
			$month = $month - 1;
		}
		for ($ix=1; $ix<=3; $ix++) {
	?>
			<tr><td class="year_calendar_frame_month">
	<?php
			calendar_month($year, $month, $_SESSION['current_id'], $category, $keystring, "calendar_tbl_mini");
			if ($month == 12) {
				$year++;
				$month = 1;
			} else {
				$month++;
			}
	?>
			</td></tr>
	<?php
		}
	?>
	</table>
	</div>
</td></tr>
</table>
</div>
<?
	page_footer();
	html_footer();
	exit();
?>
<?php
function todo_body() {
	$sql = 'select * from m_todo where id_account = ' . $_SESSION['current_id'];
	$sql .= ' and c_delete = 0 order by c_priority desc, id_todo asc';
	$rs = my_mysqli_query($sql);
	$rowcnt = mysqli_num_rows($rs);
?>
	<div id="calendar_todo_box">
	<script>;
	$(function(){
		todo_view()
	});
	function todo_view(){
		var d = new Date();	// キャッシュを利用されないため
		$("#todo_list").load("../todo/read-min.php?time="+d.getTime().toString());
	}
	function todo_view_all(){	// ToDo追加子ウインドウからの戻り用。
		todo_view();
	}
	function popup_todo() {
		w01 = window.open("../todo/index.php","","toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes,width=440,height=500");
	}
	</script>
<?php
	if (index_BOX_BORDER_COLOR <> '') {
		$side_border_color = index_BOX_BORDER_COLOR;
	} else {
		$side_border_color = TODO_VIEW_FRAME_COLOR;
	}
?>
	<table class="calendar_todo_table" style="border-color: <?= $side_border_color ?>; border-width: <?= index_BOX_BORDER_WIDTH ?>; background-color: <?= TODO_VIEW_FRAME_COLOR ?>;">
	<tr><th>
	<a href="javascript:popup_todo()">ToDo</a>
	</th></tr>
	<tr><td>
		<div id="todo_list"></div>
	</td></tr>
	</table>
	</div>
<?php
	return;
}
?>
<?php
function message_body() {
	$con = my_mysqli_connect(_DB_SCHEMA_calendar);
	$sql = 'select id_message from m_message where to_id_account = '.$_SESSION['login_id'].' and c_receivedtime < c_registtime';
	$rs = my_mysqli_query($sql);
	if (mysqli_num_rows($rs) <> 0) {
		if (index_BOX_BORDER_COLOR <> '') {
			$side_border_color = index_BOX_BORDER_COLOR;
		} else {
			$side_border_color = DENGON_VIEW_FRAME_COLOR;
		}
?>
	<div class="side_parts">
	<table class="calendar_todo_table" style="border-color: <?= $side_border_color ?>; border-width: <?= index_BOX_BORDER_WIDTH ?>; background-color: <?= DENGON_VIEW_FRAME_COLOR ?>;">
	<tr><th><a href="../calendar/message.php">伝言</a></th></tr>
	<tr><td>
		<ul id="index_dengon_thread_item"><li>
		<a href="../calendar/message.php">★ 未読伝言あり</a>
		</li></ul>
	</td></tr>
	</table>
	</div>
<?php
	}
	mysqli_close($con);
	$con = my_mysqli_connect(_DB_SCHEMA);
	return;
}
?>
