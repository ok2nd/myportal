<?php
	require("../__common__/__define_common.php");
	require("__define.php");
	require("../__common__/include-common-all.php");
	require("../__common__/include-common-html.php");
	require("_contents-header.php");
	require("__include-weather.php");

	my_session_start();

	if (isset($_GET['debug'])) {
		$_SESSION['debug'] = $_GET['debug'];
	}

	// ----- コンテンツ毎にユーザ切り替え -----
	$contents = current_contents_name($_SERVER['SCRIPT_NAME']);
	if ($_SESSION['current_id'.$contents]."" <> "") {
		$_SESSION['current_id'] = $_SESSION['current_id'.$contents];
		$_SESSION['current_handle'] = $_SESSION['current_handle'.$contents];
	}
	// ----- コンテンツ毎にユーザ切り替え -----
?>
