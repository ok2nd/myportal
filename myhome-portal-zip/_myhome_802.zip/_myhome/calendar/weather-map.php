<?php
	require("__include-common.php");
	require("../account/__logincheck.php");
	if ($_GET['m'] <> '') {
		$_SESSION['calendar_weather_map_month'] = $_GET['m'];
	}
	if ($_GET['d'] <> '') {
		$_SESSION['calendar_weather_map_day'] = $_GET['d'];
	}
	if ($_GET['wh'] <> '') {
		$_SESSION['calendar_weather_mode'] = $_GET['wh'];
	}
	if ($_GET['tm'] <> '') {
		$_SESSION['calendar_temp_mode'] = $_GET['tm'];
		$_SESSION['calendar_weather_mode'] = 'tmp';
	} elseif ($_SESSION['calendar_temp_mode'] == '') {
		$_SESSION['calendar_temp_mode'] = 'Ave';
	}
	if ($_SESSION['calendar_weather_map_month'] == '') {
		$_SESSION['calendar_weather_map_month'] = date('n');
	}
	if ($_SESSION['calendar_weather_map_day'] == '') {
		$_SESSION['calendar_weather_map_day'] = date('j');
	}
	if (!checkdate($_SESSION['calendar_weather_map_month'], $_SESSION['calendar_weather_map_day'], 2000)) {
		error_exit("日付が不正", True);
	}
	$table_name = "calendar_schedule";
	$http_arg = http_arg_from_session_pool($table_name);
	$cat = $http_arg['cat'];
	html_header(HTML_TITLE, '', '#ffffff', '', '', '__html-my-header-weather-map.php');
	page_header();
	contents_header('off');
	$con = my_mysqli_connect(_DB_SCHEMA);
	select_date();
	if ($_SESSION['calendar_weather_mode'] == '') {
		$weather_mode = 'wh';
	} else {
		$weather_mode = $_SESSION['calendar_weather_mode'];
	}
	map_japan('year.php', 'mode=sch&wh='.$weather_mode.'&cat='.$cat.'&ken', $_SESSION['calendar_weather_map_month'], $_SESSION['calendar_weather_map_day']);
	mysqli_close($con);
	page_footer();
	html_footer();
?>
<?php
function select_date() {
?>
	<script>
	function SelectionOption(opt, form, sel) {
		for (i = 0; i < sel.options.length; i++) {
			if (sel.options[i].selected == true) {
				window.location.href = "<?= $_SERVER['SCRIPT_NAME'] ?>?" + opt + "=" + escape(sel.options[i].value);
			}
		}
	}
	function RadioWeatherMode(sel) {
		window.location.href = '<?= $_SERVER['SCRIPT_NAME'] ?>?wh=' + sel;
	}
	</script>
	<div id="ymd_filter">
	月日：<?
	select_view_with_id('m', '月', 1, 12, $_SESSION['calendar_weather_map_month']);
	select_view_with_id('d', '日', 1, 31, $_SESSION['calendar_weather_map_day']);
	$mm_pre = mktime(0, 0, 0, $_SESSION['calendar_weather_map_month']-1, $_SESSION['calendar_weather_map_day'],2000);
	$mm_nxt = mktime(0, 0, 0, $_SESSION['calendar_weather_map_month']+1, $_SESSION['calendar_weather_map_day'],2000);
	$dd_pre = mktime(0, 0, 0, $_SESSION['calendar_weather_map_month'], $_SESSION['calendar_weather_map_day']-1,2000);
	$dd_nxt = mktime(0, 0, 0, $_SESSION['calendar_weather_map_month'], $_SESSION['calendar_weather_map_day']+1,2000);
?>
	<input type="button"value="前月"onclick="location.href='?m=<?= date('n', $mm_pre) ?>&d=<?= date('j', $mm_pre) ?>'">
	<input type="button"value="翌月"onclick="location.href='?m=<?= date('n', $mm_nxt) ?>&d=<?= date('j', $mm_nxt) ?>'">
	<input type="button"value="前日"onclick="location.href='?m=<?= date('n', $dd_pre) ?>&d=<?= date('j', $dd_pre) ?>'">
	<input type="button"value="翌日"onclick="location.href='?m=<?= date('n', $dd_nxt) ?>&d=<?= date('j', $dd_nxt) ?>'">
	<input type="button"value="今日"onclick="location.href='?m=<?= date('n') ?>&d=<?= date('j') ?>'">&nbsp;&nbsp;
	<label><input type="radio" onClick="RadioWeatherMode('wh')"<?= $_SESSION['calendar_weather_mode'] <> 'tmp' ? ' checked' : '' ?>>天気出現率</label>
	<input type="radio" onClick="RadioWeatherMode('tmp')"<?= $_SESSION['calendar_weather_mode'] == 'tmp' ? ' checked' : '' ?>>
	<select onChange="SelectionOption('tm', this.form, this)">
		<option value="Max"<?= $_SESSION['calendar_temp_mode'] == 'Max' ? ' selected' : '' ?>>最高気温</option>
		<option value="Ave"<?= $_SESSION['calendar_temp_mode'] == 'Ave' ? ' selected' : '' ?>>平均気温</option>
		<option value="Min"<?= $_SESSION['calendar_temp_mode'] == 'Min' ? ' selected' : '' ?>>最低気温</option>
	</select>
	</div>
<?php
}
function select_view_with_id($name, $suffix, $first, $end, $now) {
	echo '<select onChange="SelectionOption(\''.$name.'\', this.form, this)">';
	for ($i=$first; $i<=$end; $i++) {
		echo '<option value="'.$i.'"';
		if ($i == $now) {
			echo ' selected';
		}
		echo '>'.$i.'</option>';
	}
	echo '</select>'.$suffix;
}
function map_japan($php, $arg, $month, $day) {
?>
<table id="clickable_map" cellspacing="1">
<tr>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td><?php weather_ratio_for_map('稚内', $month, $day, $php, $arg) ?></td>
	<td><?php weather_ratio_for_map('網走', $month, $day, $php, $arg) ?></td>
</tr>
<tr>
	<td colspan=8 rowspan=4 id="caption">
<?php	if ($_SESSION['calendar_weather_mode'] == 'tmp') { ?>
<?php		if ($_SESSION['calendar_temp_mode'] == 'Ave') { ?>
<span class="weather_temp_ave strong">平均気温</span> (30年間の気象データを基にした平均気温) <span class="strong">地図</span><br><br>
<?php		} elseif ($_SESSION['calendar_temp_mode'] == 'Max') { ?>
<span class="weather_temp_max strong">最高気温</span> (30年間の気象データを基にした最高気温) <span class="strong">地図</span><br><br>
<?php		} else { ?>
<span class="weather_temp_min strong">最低気温</span> (30年間の気象データを基にした最低気温) <span class="strong">地図</span><br><br>
<?php		} ?>
<span class="weather_temp_max strong">最高気温(℃)</span>/<span class="weather_temp_ave strong">平均気温(℃)</span>/<span class="weather_temp_min strong">最低気温(℃)</span>
<?php } else { ?>
<span class="strong">天気出現率</span> (30年間の気象データを基にした全国各地の天気出現率) <span class="strong">地図</span><br><br>
<span class="weather_ratio_fine">晴れ(%)</span>/<span class="weather_ratio_cloud">曇り(%)</span>/<span class="weather_ratio_rain">雨(%)</span>/<span class="weather_ratio_snow">雪(%)</span>
<?php } ?>
	</td>
	<td></td>
	<td></td>
	<td><?php weather_ratio_for_map('札幌', $month, $day, $php, $arg) ?></td>
	<td><?php weather_ratio_for_map('旭川', $month, $day, $php, $arg) ?></td>
	<td><?php weather_ratio_for_map('釧路', $month, $day, $php, $arg) ?></td>
</tr>
<tr>
	<td></td>
	<td></td>
	<td><?php weather_ratio_for_map('函館', $month, $day, $php, $arg) ?></td>
	<td></td>
	<td></td>
</tr>
<tr>
	<td colspan=5 style="height: 5px; line-height: 5px;"></td>
</tr>
<tr>
	<td></td>
	<td></td>
	<td></td>
	<td colspan=2 class="colspan_2"><?php weather_ratio_for_map('青森', $month, $day, $php, $arg) ?></td>
</tr>
<tr>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td><?php weather_ratio_for_map('佐渡', $month, $day, $php, $arg) ?></td>
	<td></td>
	<td><?php weather_ratio_for_map('秋田', $month, $day, $php, $arg) ?></td>
	<td><?php weather_ratio_for_map('岩手', $month, $day, $php, $arg) ?></div></a></td>
</tr>
<tr>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td><?php weather_ratio_for_map('輪島', $month, $day, $php, $arg) ?></div></a></td>
	<td></td>
	<td></td>
	<td></td>
	<td><?php weather_ratio_for_map('山形', $month, $day, $php, $arg) ?></div></a></td>
	<td><?php weather_ratio_for_map('宮城', $month, $day, $php, $arg) ?></div></a></td>
</tr>
<tr>
	<td colspan=2 class="colspan_2"><?php weather_ratio_for_map('沖縄', $month, $day, $php, $arg) ?></div></a></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td><?php weather_ratio_for_map('石川', $month, $day, $php, $arg) ?></div></a></td>
	<td></td>
	<td colspan=2 class="colspan_2"><?php weather_ratio_for_map('新潟', $month, $day, $php, $arg) ?></div></a></td>
	<td colspan=2 class="colspan_2"><?php weather_ratio_for_map('福島', $month, $day, $php, $arg) ?></div></a></td>
</tr>
<tr>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td><?php weather_ratio_for_map('福井', $month, $day, $php, $arg) ?></div></a></td>
	<td><?php weather_ratio_for_map('富山', $month, $day, $php, $arg) ?></div></a></td>
	<td rowspan=2 class="rowspan_2"><?php weather_ratio_for_map('長野', $month, $day, $php, $arg) ?></div></a></td>
	<td><?php weather_ratio_for_map('群馬', $month, $day, $php, $arg) ?></div></a></td>
	<td><?php weather_ratio_for_map('栃木', $month, $day, $php, $arg) ?></div></a></td>
	<td><?php weather_ratio_for_map('茨城', $month, $day, $php, $arg) ?></div></a></td>
</tr>
<tr>
	<td></td>
	<td></td>
	<td></td>
	<td><?php weather_ratio_for_map('島根', $month, $day, $php, $arg) ?></div></a></td>
	<td><?php weather_ratio_for_map('鳥取', $month, $day, $php, $arg) ?></div></a></td>
	<td rowspan=2 class="rowspan_2"><?php weather_ratio_for_map('兵庫', $month, $day, $php, $arg) ?></div></a></td>
	<td><?php weather_ratio_for_map('京都', $month, $day, $php, $arg) ?></div></a></td>
	<td><?php weather_ratio_for_map('滋賀', $month, $day, $php, $arg) ?></div></a></td>
	<td><?php weather_ratio_for_map('岐阜', $month, $day, $php, $arg) ?></div></a></td>
	<td><?php weather_ratio_for_map('山梨', $month, $day, $php, $arg) ?></div></a></td>
	<td><?php weather_ratio_for_map('埼玉', $month, $day, $php, $arg) ?></div></a></td>
	<td rowspan=2 class="rowspan_2"><?php weather_ratio_for_map('千葉', $month, $day, $php, $arg) ?></div></a></td>
</tr>
<tr>
	<td></td>
	<td></td>
	<td><?php weather_ratio_for_map('山口', $month, $day, $php, $arg) ?></div></a></td>
	<td><?php weather_ratio_for_map('広島', $month, $day, $php, $arg) ?></div></a></td>
	<td><?php weather_ratio_for_map('岡山', $month, $day, $php, $arg) ?></div></a></td>
	<td><?php weather_ratio_for_map('大阪', $month, $day, $php, $arg) ?></div></a></td>
	<td><?php weather_ratio_for_map('奈良', $month, $day, $php, $arg) ?></div></a></td>
	<td><?php weather_ratio_for_map('愛知', $month, $day, $php, $arg) ?></div></a></td>
	<td><?php weather_ratio_for_map('静岡', $month, $day, $php, $arg) ?></div></a></td>
	<td><?php weather_ratio_for_map('神奈川', $month, $day, $php, $arg) ?></div></a></td>
	<td><?php weather_ratio_for_map('東京', $month, $day, $php, $arg) ?></div></a></td>
</tr>
<tr>
	<td><?php weather_ratio_for_map('佐賀', $month, $day, $php, $arg) ?></div></a></td>
	<td><?php weather_ratio_for_map('福岡', $month, $day, $php, $arg) ?></div></a></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td><?php weather_ratio_for_map('和歌山', $month, $day, $php, $arg) ?></div></a></td>
	<td><?php weather_ratio_for_map('三重', $month, $day, $php, $arg) ?></div></a></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
</tr>
<tr>
	<td><?php weather_ratio_for_map('長崎', $month, $day, $php, $arg) ?></div></a></td>
	<td><?php weather_ratio_for_map('大分', $month, $day, $php, $arg) ?></div></a></td>
	<td></td>
	<td><?php weather_ratio_for_map('愛媛', $month, $day, $php, $arg) ?></div></a></td>
	<td><?php weather_ratio_for_map('香川', $month, $day, $php, $arg) ?></div></a></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td class="chars4"><?php weather_ratio_for_map('伊豆大島', $month, $day, $php, $arg) ?></div></a></td>
	<td></td>
</tr>
<tr>
	<td><?php weather_ratio_for_map('熊本', $month, $day, $php, $arg) ?></div></a></td>
	<td><?php weather_ratio_for_map('宮崎', $month, $day, $php, $arg) ?></div></a></td>
	<td></td>
	<td><?php weather_ratio_for_map('高知', $month, $day, $php, $arg) ?></div></a></td>
	<td><?php weather_ratio_for_map('徳島', $month, $day, $php, $arg) ?></div></a></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
</tr>
<tr>
	<td colspan=2 class="colspan_2"><?php weather_ratio_for_map('鹿児島', $month, $day, $php, $arg) ?></div></a></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
</tr>
</table>
<?php
}
function weather_ratio_for_map($kenmei, $month, $day, $php, $arg) {
	if ($_SESSION['calendar_weather_mode'] == 'tmp') {
		if ($rec = weather_ratio_rec_kenmei($kenmei, $month, $day)) {
?>
			<a href="<?= $php ?>?<?= $arg ?>=<?= $rec['c_kenid'] ?>" class="temp_bg_<?= weather_temp_chk($rec) ?>">
			<span class="weather_temp_kenmei"><?= $kenmei ?><br></span>
			<span class="weather_temp_map">
			<span class="weather_temp_max"><?= $rec['c_tempMax'] ?></span>/<span class="weather_temp_ave"><?= $rec['c_tempAve'] ?></span>/<span class="weather_temp_min"><?= $rec['c_tempMin'] ?></span>
			</span>
			</a>
<?php
		} else {
			echo '';
		}
	} else {
		if ($rec = weather_ratio_rec_kenmei($kenmei, $month, $day)) {
?>
			<a href="<?= $php ?>?<?= $arg ?>=<?= $rec['c_kenid'] ?>" class="weather_bg_<?= weather_ratio_chk($rec) ?>">
			<?= $kenmei ?><img src="../icon/weather/<?= weather_ratio_chk($rec) ?>.gif" /><br>
			<span class="weather_ratio_map">
			<span class="weather_ratio_fine"><?= round($rec['c_fine']) ?></span>/<span class="weather_ratio_cloud"><?= round($rec['c_cloud']) ?></span>/<span class="weather_ratio_rain"><?= round($rec['c_rain']) ?></span><?php if (round($rec['c_snow']) > 0) { ?>/<span class="weather_ratio_snow"><?= round($rec['c_snow']) ?></span><?php } ?>
			</span>
			</a>
<?php
		} else {
			echo '';
		}
	}
}
?>
