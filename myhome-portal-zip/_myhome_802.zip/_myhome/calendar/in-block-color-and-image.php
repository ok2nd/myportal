<p>
	<a href="../__common__/color-chart.php" target="_blank">↑カラーチャート</a>
	<a href="../tools/colorpicker.php" target="_blank" style="margin-left:20px;">↑カラーチャート(+ Color Picker)</a>
</p>
<?php
	require("../__common__/include-color-chart.php");
?>
<table><tr>
<td>
<?php
	images_print(IMAGES_FOLDER, 1);
?>
</td>
<td>
<?php
	if (CALENDAR_CATEGORYCOLOR_BACKGROUND <> 'NO') {
		color_chart_pale();
	} else {
		color_chart_dark();
	}
?>
</td>
</tr></table>
