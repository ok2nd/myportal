<?php
	$color_tbl = array();
	$color_tbl[] = "red";
	$color_tbl[] = "blue";
	$color_tbl[] = "green";
	$color_tbl[] = "Orange";
	$color_tbl[] = "magenta";
	$color_tbl[] = "blueviolet";
	$color_tbl[] = "Dodgerblue";
	$color_tbl[] = "Yellowgreen";
?>
