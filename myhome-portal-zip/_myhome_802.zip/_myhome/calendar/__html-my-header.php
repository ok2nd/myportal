<meta charset="utf-8">
<meta name="author" content="ok.2nd">
<meta name="description" content="Calendar">
<meta name="keywords" content="calendar,カレンダー">
<link rel="stylesheet" href="<?= _STYLE_SHEET_FOLDER_COMMON ?>/common.css?20131130">
<link rel="stylesheet" href="<?= _STYLE_SHEET_BUTTON ?>">
<link rel="stylesheet" href="<?= _STYLE_SHEET_FOLDER ?>/mp-list.css?20130525">
<link rel="stylesheet" href="<?= _STYLE_SHEET_FOLDER ?>/calendar.css?20141108">
<link rel="stylesheet" href="<?= _STYLE_SHEET_FOLDER ?>/weather.css?20120323">
<link rel="stylesheet" href="<?= _STYLE_SHEET_FOLDER ?>/a_tag_color.css?20081017">
<link rel="stylesheet" href="<?= FONT_ICON_STYLE_SHEET_FOLDER ?>/css/font-awesome.css">
<!--[if IE 7]>
<link rel="stylesheet" href="<?= FONT_ICON_STYLE_SHEET_FOLDER ?>/css/font-awesome-ie7.css">
<![endif]-->
<link rel="stylesheet" href="<?= FONT_ICON_STYLE_SHEET_FOLDER ?>/font-icon.css">
<link rel="stylesheet" href="../scripts/msdropdown/css/dd-myhome.css">
<style>
.day_today_mini {
	background-color: <?= CALENDAR_TODAY_MINI_BACKGROUND_COLOR ?>;
}
.day_today_mini a:link { color: <?= CALENDAR_TODAY_MINI_LINK_COLOR ?>; }
.day_today_mini a:visited { color: <?= CALENDAR_TODAY_MINI_LINK_COLOR ?>; }
.day_today_mini a:hover { color: #ff8c00; }
.day_today_mini a:active { color: #ff6347; }
</style>
<script src="../scripts/jquery.js"></script>
<script src="../scripts/jquery.cookie.js"></script>
<script src="../scripts/ok2nd.js"></script>
<script src="../scripts/jquery.cs.ok2nd.js"></script>
<script src="../scripts/msdropdown/js/jquery.dd.min.js"></script>
<script>
function popup_schedule(uid,y,m,d) {
	w01 = window.open("popup-schedule.php?uid=" + uid + "&y=" + y + "&m=" + m+ "&d=" + d,"","toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes,width=400,height=400");
}
</script>
