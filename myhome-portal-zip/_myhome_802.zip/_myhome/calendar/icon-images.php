<?php
	require("__define.php");
	require("../__common__/include-common-all.php");
	require("../__common__/include-common-html.php");
?>
<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="utf-8">
<meta name="author" content="ok.2nd">
<meta name="description" content="Icon Images">
<meta name="keywords" content="icon">
<style>
<!--
body {
	background-color: #ffffff;
	margin: 5px;
	padding: 0px;
	text-align: left;
	overflow: auto;
	_overflow: auto;
}
body { font-size: 84%; }
h1 { font-size: 130%; }
h2 { font-size: 120%; }
h3 { font-size: 108%; }
h4 { font-size: 100%; }
td { text-align: left; vertical-align: top; }
img { border: 0px; }
-->
</style>
<title>Icon Images</title>
</head>
<body>
<?php
	images_print(IMAGES_FOLDER, 3);
?>
</body>
</html>
