<?php
	require("__include-common.php");
	require("../account/__logincheck.php");
	require("_my_calendar.php");
	if (!defined("GOOGLE_API_KEY")) {
		define("GOOGLE_API_KEY", "ABQIAAAA1XbMiDxx_BTCY2_FkPh06RRaGTYH6UMl8mADNa0YKuWNNa8VNxQEerTAUcfkyrr6OwBovxn7TDAH5Q");
	}
	if (!defined("MAPS_FIX_HEIGHT")) {
		define("MAPS_FIX_HEIGHT", 118);
	}
	require("../__common__/include-common-mp-list.php");
	require("list-my-add-filter.php");
	if (GOOGLE_MAPS_API_VERSION == 'V3') {
		require("maps-include-v3.php");
		$onload = ' onload="initialize()"';
	} else {
		require("maps-include.php");
		$onload = ' onload="init()" onunload="GUnload()"';
	}
	if (isset($_GET['all'])) {
		$_SESSION['schedule_maps_all'] = $_GET['all'];
	}
	_account_change($_GET['uid']);
	$arg_pool_prefix = "calendar_schedule";
	$http_arg = array();
	$http_arg['pl'] = PAGE_LINE_DEFAULT;
	$http_arg['cat'] = '';				// mp_list 必須
	$http_arg['key'] = '';				// mp_list 必須
	$http_arg['selY'] = '';
	$http_arg['selM'] = '';
	$http_arg['selD'] = '';
	$http_arg['toY'] = '';
	$http_arg['toM'] = '';
	$http_arg['toD'] = '';
	$http_arg['y'] = '';
	$http_arg['m'] = '';
	$item_tbl[] = array(	"表示名"=>"件名",	"列名"=>"c_subject",
				"type"=>"text", "size"=>20, "ime-mode"=>"active", "文字検索"=>"Y");
	$item_tbl[] = array(	"表示名"=>"スケジュール本文",	"列名"=>"c_memo", "strip_tags"=>"Y",
				"type"=>"textarea", "cols"=>46, "rows"=>3, "文字検索"=>"Y");

	_GET_to_http_arg_pool($http_arg, $arg_pool_prefix, 'selY,selM,selD,toY,toM,toD,y,m');
	html_header(HTML_TITLE, '', '', $onload, '', '__html-my-header-maps.php');
	page_header();
	contents_header();

	maps_proc($http_arg, $item_tbl);

	html_footer();
	exit();
?>
