<?php
	require("__include-common.php");
	require("../account/__logincheck.php");
	require("_my_calendar.php");
	// mp_list_filter_key_select()を使うため
	require("../__common__/include-common-mp-list.php");

	$arg_pool_prefix = "calendar_schedule";

	$http_arg = array();
	$http_arg['pl'] = PAGE_LINE_DEFAULT;		// mp_list 必須
	$http_arg['sort'] = '';				// mp_list 必須
	$http_arg['cat'] = '';				// mp_list 必須
	$http_arg['key'] = '';				// mp_list 必須

	$http_arg['y'] = '';
	$http_arg['m'] = '';
	$http_arg['d'] = '';
	$http_arg['key'] = '';

	_GET_to_http_arg_pool($http_arg, $arg_pool_prefix, 'y,m,d,key,pl');
	$keystring = keystr_fix($http_arg['key']);

	$year = $http_arg['y'];
	$month = $http_arg['m'];
	$day = $http_arg['d'];
	if ($year == '') {
		$year = date("Y");
	}
	if ($month == '') {
		$month = date("n");
	}
	if ($day == '') {
		$day = date("j");
	}

	html_header(HTML_TITLE, '', '#f8f8f8');
	page_header();
	contents_header('off');

	$pw = mktime(0, 0, 0, $month, $day-7, $year);
	$nw = mktime(0, 0, 0, $month, $day+7, $year);

	$con = my_mysqli_connect(_DB_SCHEMA);
?>
<div id="calendar_body" style="padding-top:2px;">
<form method="POST" name="filter_form" action="<?= $_SERVER['SCRIPT_NAME'] ?>?<?= query_from_http_arg_pool($http_arg) ?>">
	<!--	<div id="calendar_category_select" class="block_left"> -->
	<?php
	//	filter_category_select($category, $_SESSION['current_id'], $http_arg);
	?>
	<!--	</div> -->
<div id="filter_key_select" class="block_left left_mini_margin">
<?php
	filter_key_select($keystring, $http_arg);
?>
</div>
<div id="filter_mode_change" class="block_left left_mini_margin">
<?php
	filter_detail_onoff();
?>
</div>
</form>
<script>
$(function(){
	$(".calendar_tbl_week td").dblclick(function(){
		var input_url = $(this).attr("id");
		location.href = input_url;
	});
});
</script>
<div id="calendar_main">
	<table class='calendar_tbl_week'>
<?php
	$time = mktime(0, 0, 0, $month, $day, $year);
	$first_day = $day - date("w", $time);		// 先頭日  date("w",$time):曜日取得(0...6)
	$last_day = $first_day + 6;
	$first_time = mktime(0, 0, 0, $month, $first_day, $year);
	$last_time = mktime(0, 0, 0, $month, $last_day, $year);

//echo $year.$month.$day."<br>";
//echo $first_day."<br>";
//echo date('Y/n/j',$first_time)."---".date('Y/n/j',$last_time)."<br>";

	if (date('n',$first_time) == date('n',$last_time)) {
?>
	<caption><span class="calendar_caption_ym"><span class='calendar_caption_ym_num'><?= $year ?></span>年 <span class='calendar_caption_ym_num'><?= $month ?></span>月</span>
		<span id="calendar_ymd_change">
		<ul>
		<li><a href="<?= $_SERVER['SCRIPT_NAME'] ?>?y=<?= date('Y') ?>&m=<?= date('n') ?>&d=<?= date('j') ?>&key=<?= urlencode($keystring) ?>">今週</a></li>
		<li><a href="<?= $_SERVER['SCRIPT_NAME'] ?>?y=<?= date('Y',$pw) ?>&m=<?= date('n',$pw) ?>&d=<?= date('j',$pw) ?>&key=<?= urlencode($keystring) ?>">←前週</a></li>
		<li><a href="<?= $_SERVER['SCRIPT_NAME'] ?>?y=<?= date('Y',$nw) ?>&m=<?= date('n',$nw) ?>&d=<?= date('j',$nw) ?>&key=<?= urlencode($keystring) ?>">→次週</a></li>
		</ul>
		</span>
		<br /><br style='font-size: 10px;' />
	</caption>
<?php
	} else {
?>
	<caption><span class="calendar_caption_ym"><span class='calendar_caption_ym_num'><?= date('Y',$first_time) ?>年 </span><span class='calendar_caption_ym_num'><?= date('n',$first_time) ?></span>月 ～ <span class='calendar_caption_ym_num'><?= date('Y',$last_time) ?></span>年 <span class='calendar_caption_ym_num'><?= date('n',$last_time) ?></span>月</span>
		<span id="calendar_ymd_change">
		<ul>
		<li><a href="<?= $_SERVER['SCRIPT_NAME'] ?>?y=<?= date('Y') ?>&m=<?= date('n') ?>&d=<?= date('j') ?>&key=<?= urlencode($keystring) ?>">今週</a></li>
		<li><a href="<?= $_SERVER['SCRIPT_NAME'] ?>?y=<?= date('Y',$pw) ?>&m=<?= date('n',$pw) ?>&d=<?= date('j',$pw) ?>&key=<?= urlencode($keystring) ?>">←前週</a></li>
		<li><a href="<?= $_SERVER['SCRIPT_NAME'] ?>?y=<?= date('Y',$nw) ?>&m=<?= date('n',$nw) ?>&d=<?= date('j',$nw) ?>&key=<?= urlencode($keystring) ?>">→次週</a></li>
		</ul>
		<br /><br style='font-size: 10px;' />
		</span>
	</caption>
<?php
	}
	calendar_week_header();
	for ($ix=0; $ix<=$_SESSION['login_friends_number']; $ix++) {
		$friends_id = $_SESSION['login_friends_id_'.$ix];
		calendar_week($year, $month, $day, $friends_id, $_SESSION['login_friends_handle_'.$friends_id], $_SESSION['login_friends_body_background_color_'.$friends_id], $keystring);
	}
?>
	</table>
</div>
</div>
<?
	page_footer();
	html_footer();
	exit();
?>
