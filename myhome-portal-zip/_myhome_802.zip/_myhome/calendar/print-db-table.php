<?php
	require("__include-common.php");
?>
<?php
	$sql = "select * from m_category";

	$sql = "select m_category.id_account, c_categoryName";
	$sql .= " from m_category";

	$sql = "select m_category.id_account, m_category.c_categoryName, m_account.c_account";
	$sql .= " from m_category";
	$sql .= " left join m_account";
	$sql .= " on (m_category.id_account = m_account.id_account)";

	$sql = "select m_category.id_account, m_category.c_categoryName, m_account.id_account";
	$sql .= " from m_category";
	$sql .= " left join db_index.m_account";
	$sql .= " on (m_category.id_account = db_index.m_account.ID)";

	$sql = "select m_schedule.*, m_category.c_categoryName, m_category.c_categoryDisplayColor";
	$sql .= " from m_schedule";
	$sql .= " left join m_category";
	$sql .= " on (m_schedule.id_category = m_category.id_category)";

	html_header("List DB Table");
	page_header();
	main_proc($sql);
	page_footer();
	html_footer();

function main_proc($sql) {
	echo $sql."<br><br>";
	$con = my_mysqli_connect(_DB_SCHEMA);
	$rs = my_mysqli_query($sql);
	$rowcnt = mysqli_num_rows($rs);
	if ($rowcnt > 0) {
		list_table($rs);
	}
}
function list_table($rs) {
	echo "<table class='list_table'>";
	while ($rec=mysqli_fetch_array($rs)) {
		echo "<tr class=''>";
		echo "<td valign='top' width='' align='left'>".$rec['id_account']."</td>";
		echo "<td valign='top' width='' align='left'>".$rec['c_categoryName']."</td>";
		echo "<td valign='top' width='' align='left'>".$rec['c_subject']."</td>";
		echo "</tr>";
	}
	echo "</table>";
}
function list_table_xxx($rs) {
	echo "<table class='list_table'>";
	while ($rec=mysqli_fetch_array($rs)) {
		echo "<tr class=''>";
		echo "<td valign='top' width='' align='left'>".$rec['id_account']."</td>";
		echo "<td valign='top' width='' align='left'>".$rec['id_account']."</td>";
		echo "<td valign='top' width='' align='left'>".$rec['c_categoryName']."</td>";
		echo "</tr>";
	}
	echo "</table>";
}
?>
