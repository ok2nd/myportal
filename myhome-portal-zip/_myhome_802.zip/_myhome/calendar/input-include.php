<?php
function select_view_with_id($name, $suffix, $first, $end, $now) {
	if ($suffix == '年') {
		if (strstr($_SERVER['HTTP_USER_AGENT'], "Chrome")) {
?>
<input type="number" id="<?= $name ?>" name="<?= $name ?>" value="<?= $now ?>" style="width:4em;"><?= $suffix ?>
<?php		} else { ?>
<script>
function YearUpDown(id, updown) {
	$("#"+id).val(Number($("#"+id).val()) + Number(updown));
}
</script>
<input type="text" class="text" id="<?= $name ?>" name="<?= $name ?>" value="<?= $now ?>" style="width:3em;"><input type="button" value="▲" style="font-size:10px;margin:0;padding:0;" OnClick="YearUpDown('<?= $name ?>',1)"><input type="button" value="▼" style="font-size:10px;margin:0;padding:0;" OnClick="YearUpDown('<?= $name ?>',-1)"><?= $suffix ?>
<?php		} ?>
<?php	} else {
		echo "<select id='".$name."' name='".$name."'>";
		for ($i=$first; $i<=$end; $i++) {
			echo "<option value='".$i."'";
			if ($i == $now) {
				echo " selected";
			}
			echo ">".$i."</option>";
		}
		echo "</select>".$suffix;
	}
}
function select_view_with_id_with_blank($name, $suffix, $first, $end, $now) {
	echo "<select id='".$name."' name='".$name."'>";
	echo "<option value=''>";
	for ($i=$first; $i<=$end; $i++) {
		echo "<option value='".$i."'";
		if ($i == $now) {
			echo " selected";
		}
		echo ">".$i."</option>";
	}
	echo "</select>".$suffix;
}
function select_time($hour_name, $minute_name, $hour, $minute) {
	echo "<select name='".$hour_name."'>";
	echo "<option value=''>";
	for ($sel=8; $sel<=23; $sel++) {
		$hh = right("0".$sel,2);
		echo "<option value='".$hh."'";
		if ($hh == $hour) {
			echo " selected";
		}
		echo ">".$hh."</option>";
	}
	for ($sel=0; $sel<=7; $sel++) {
		$hh = right("0".$sel,2);
		echo "<option value='".$hh."'";
		if ($hh == $hour) {
			echo " selected";
		}
		echo ">".$hh."</option>";
	}
	echo "</select>：";
	echo "<select name='".$minute_name."'>";
	for ($sel=0; $sel<=50; $sel+=10) {
		$mm = right("0".$sel,2);
		echo "<option value='".$mm."'";
		if ($mm == $minute) {
			echo " selected";
		}
		echo ">".$mm."</option>";
		if ($sel == 10 or $sel == 40) {
			$mm = right("0".$sel+5,2);
			echo "<option value='".$mm."'";
			if ($mm == $minute) {
				echo " selected";
			}
			echo ">".$mm."</option>";
		}
	}
	echo "</select>";
}
function schedule_get($user_id, $id) {
	$sql = "select * from v_schedule where id_schedule = ".$id." and c_delete = 0";
	$sql .= " and id_account = ".$user_id;
	$rs = my_mysqli_query($sql);
	return mysqli_fetch_array($rs);
}
function view_images_button($rowspan) {
	require(FONT_ICON_CLASS_INCLUDE);	// $font_icons
	if (count($font_icons) > 0) {
?>
	<td rowspan=<?= $rowspan ?>>
	<div class="images_button">
	<?php
		font_icon_button($font_icons, 12);
	?>
	</div>
<?php	} ?>
	</td>
	<td rowspan=<?= $rowspan ?>>
	<div class="images_button">
	<?php
		images_button(IMAGES_FOLDER, 12);
	?>
	</div>
	</td>
<?php
}
function images_button($dir_path, $num_in_coloumn) {
	$file_table = array();
	$file_count = 0;
	if ($dir = opendir($dir_path)) {
		//while (($file = readdir($dir)) !== false) {
		$files = scandir($dir_path);
		foreach ($files as $file) {
			if ($file != "." && $file != ".." && !is_dir($dir_path . "/" . $file) && is_img_filename($file)) {
				$file_table[] = $file;
				$file_count++;
			} elseif (right($file,4) == '.zzz') {
				$file_table[] = 'break';
				$file_count++;
			}
		}
		closedir($dir);
	}
	if ($file_count != 0) {
		images_button_table($dir_path, $num_in_coloumn, $file_table, $file_count);
	}
}
function images_button_table($dir_path, $num_in_coloumn, $file_table, $file_count) {
?>
<table>
<tr><td>
	<table>
<?php
	$cnt = 0;
	foreach ($file_table as $file) {
		if ($file == 'break') {
			$cnt = $num_in_coloumn;
			continue;
		}
		$filePath = $dir_path . "/" . $file;
		$cnt++;
		if ($cnt > $num_in_coloumn) {
?>
	</table>
</td>
<td>
	<table>
<?php
			$cnt = 1;
		}
?>
		<tr><td><input type="button" value="" class="icon_button" style="background: transparent url(<?= $filePath ?>) center center no-repeat;" onClick="enclosePreview('<icon <?= $file ?>>','');return false;"></td></tr>
<?php
	}
?>
	</table>
</td></tr>
</table>
<?php
}
function font_icon_button($font_icons, $num_in_coloumn) {
?>
<table>
<tr><td>
	<table>
<?php
	$cnt = 0;
	foreach ($font_icons as $font_icon) {
		if ($font_icon == '◆') {
			$cnt = $num_in_coloumn;
			continue;
		}
		$filePath = $dir_path . "/" . $file;
		$cnt++;
		if ($cnt > $num_in_coloumn) {
?>
	</table>
</td>
<td>
	<table>
<?php
			$cnt = 1;
		}
?>
		<tr><td><button class="font_icon_button" onClick="enclosePreview('<?= $font_icon ?>','');return false;"><?= $font_icon ?></button></td></tr>
<?php
	}
?>
	</table>
</td></tr>
</table>
<?php
}
?>
