<?php
	require("__include-common.php");
	require("../account/__logincheck.php");

	$GLOBALS['calendar_month_type'] = 'print';

	require("_my_calendar.php");
	$year = $_GET['y'];
	$month = $_GET['m'];
	$con = my_mysqli_connect(_DB_SCHEMA);
	html_header($_GET['y'].'年'.$_GET['m'].'月');
?>
<style>
#calendar_body {
	page-break-after: avoid;
}
.calendar_body {
	clear: both;
	margin: 5px 10px 3px 10px;
	padding: 0;
	page-break-before: always;
	page-break-after: avoid;
}
table.calendar_tbl {
	width: 100% !important;
}
table.calendar_tbl td {
	height: 90px;
	width: 160px !important;
}
</style>
<script>
$(function(){
	$('a').click(function(){
		return false;		// aリンクを無効
	})
});
</script>
<div id="calendar_body">
<div id="calendar_main">
<table>
<tr><td>
<?php
	calendar_month($year, $month, $_SESSION['current_id'], '', '');
?>
</td></tr>
</table>
</div>
</div>
<?php
	if ($_GET['term'].'' <> '') {
		$GLOBALS['calendar_month_print_mode'] = 'second';
		for ($mm = 1; $mm < intval($_GET['term']); $mm++) {
			if ($month == 12) {
				$year++;
				$month = 1;
			} else {
				$month++;
			}
?>
	<div class="calendar_body" style="page-break-before:always;">
	<table>
	<tr><td>
	<?php
		calendar_month($year, $month, $_SESSION['current_id'], '', '');
	?>
	</td></tr>
	</table>
	</div>
<?php
		}
	}
	html_footer();
	exit();
?>
