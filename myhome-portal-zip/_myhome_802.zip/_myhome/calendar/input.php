<?php
	require("__include-common.php");
	require("../account/__logincheck.php");
	require("_my_calendar.php");
	require("input-include.php");
	ini_set("memory_limit", FILE_UPLOAD_MEMORY_LIMIT);		//メモリサイズ
	ini_set("max_execution_time", FILE_UPLOAD_MAX_EXECUTION_TIME);	//最大実行時間
	if ($_POST) {
// *********************************************************************************
// * max_execution_time
// * post_max_size
// * upload_max_filesizeを越えるとisset($_POST['登録'])がTrueにならない。
// *********************************************************************************
		check_post_account($_POST['login_id'], $_POST['current_id']);
		post_done_proc();
	} else {
		if (INPUT_POPUP_CALENDAR == 'YUI') {
			$add_input_header = '_add_input_header_YUI.php';
		} else if (INPUT_POPUP_CALENDAR == 'kanaya') {
			$add_input_header = '_add_input_header-kanaya.php';
		} else {
			$add_input_header = '_add_input_header.php';
		}
		if ($_SESSION['login_friends_cal_sbj_use_'.$_GET['uid']] <> 'NO' ) {
			html_header(HTML_TITLE, $add_input_header, '', ' onload="document.form0.c_subject.focus()"');
		} else {
			html_header(HTML_TITLE, $add_input_header, '', ' onload="document.form0.c_memo.focus()"');
		}
		page_header();
		input_form();
		page_footer();
		html_footer();
	}
	exit();
?>
<?php
function post_done_proc() {
	if ($_POST['user_id']."" <> "") {
		$user_id = $_POST['user_id'];
	} else {
		error_exit("不正アクセス：ユーザーIDなし", True);
	}
	if (check_permit_id($_SESSION['login_id'], $user_id) != "w") {
		error_exit("書き込み権限がありません。", True);
	}
	if ($_POST['update_id']) {
		if (!is_numeric($_POST['update_id'])) {
			error_exit("不正アクセス：ID不正", True);
		}
		$id = intval($_POST['update_id']);
	} else {
		$id = 0;
	}
	if (isset($_POST['削除'])) {
		//	if ($_POST['削除する'] <> "YES") {
		//		error_exit("削除するにチェックしてください。", True);
		//	}
	}
	//if ($_POST['c_subject'] == "") {
	//	error_exit("件名を入れてください。", True);
	//}
	if ($_POST['inputY']) {
		$year = get_post_str("inputY");
	}
	if ($_POST['inputM']) {
		$month = get_post_str("inputM");
	}
	if ($_POST['inputD']) {
		$day = get_post_str("inputD");
	}
	if (!checkdate($month, $day, $year)) {
		error_exit("日付が不正", True);
	}
	$schedule_to_date = '';
	if ($_POST['inputToD'].'' <> '') {
		$to_year = get_post_str("inputToY");
		$to_month = get_post_str("inputToM");
		$to_day = get_post_str("inputToD");
		if (!checkdate($to_month, $to_day, $to_year)) {
			error_exit("日付範囲が不正", True);
		}
		$schedule_to_date = date("Y-m-d", mktime(0, 0, 0, $to_month, $to_day, $to_year));
		$s_date = mktime(0, 0, 0, $month, $day, $year);
		$e_date = mktime(0, 0, 0, $to_month, $to_day, $to_year);
		$scopeDay = ($e_date - $s_date) / (3600 * 24);
		if ($scopeDay < 0) {
			error_exit("日付範囲の前後が逆転", True);
		} elseif ($scopeDay == 0) {
			$schedule_to_date = "";
		} else {
			if ($_POST['repeat_type'] == 'week') {
				if ($scopeDay > 92) error_exit("日付範囲が3ヶ月以上", True);
			} else {
				if ($scopeDay > 31) error_exit("日付範囲が1ヶ月以上", True);
			}
		}
	}
	$schedule_date = date("Y-m-d", mktime(0, 0, 0, $month, $day, $year));
	if ($_POST['hh1'] <> "") {
		$time1 = "'2008-1-1 ".$_POST['hh1'].":".$_POST['mm1'].":00'";
	} else {
		$time1 = "NULL";
	}
	if ($_POST['hh2'] <> "") {
		$time2 = "'2008-1-1 ".$_POST['hh2'].":".$_POST['mm2'].":00'";
	} else {
		$time2 = "NULL";
	}
	$con = my_mysqli_connect(_DB_SCHEMA);
	if ($id == 0) {
		if ($schedule_to_date == "") {
			$sql = "insert into m_schedule ";
			$sql .= "(id_account";
			$sql .= ", c_date";
			$sql .= ", id_category";
			$sql .= ", c_subject";
			$sql .= ", c_memo";
			$sql .= ", c_memo_strip_tags";
			$sql .= ", c_map";
			if ($user_id == $_SESSION['login_id']) {
				$sql .= ", c_privacy";
			}
			$sql .= ", c_time1";
			$sql .= ", c_time2";
			$sql .= ", c_registtime";
			$sql .= ", c_updatetime";
			$sql .= ", add_id_account";
			$sql .= ") values ";
			$sql .= "( '".$user_id."'";
			$sql .= ", '".$schedule_date."'";
			$sql .= ", '" . $_POST['id_category'] . "'";
			$sql .= ", '".post_to_mysql('c_subject')."'";
			$sql .= ", '".post_to_mysql('c_memo')."'";
			$sql .= ", '".post_to_mysql_strip_tags("c_memo")."'";
			$sql .= ", '" . $_POST['c_map'] . "'";
			if ($user_id == $_SESSION['login_id']) {
				if ($_POST['c_privacy'] == '444') {
					$sql .= ", 444";
				} else {
					$sql .= ", 0";
				}
			}
			$sql .= ", ".$time1;
			$sql .= ", ".$time2;
			$sql .= ", '". date("Y/m/d H:i:s") . "'";
			$sql .= ", '". date("Y/m/d H:i:s") . "'";
			$sql .= ", '". $_SESSION['login_id'] . "'";
			$sql .= ")";
			$ret = my_mysqli_query($sql, "登録できませんでした。");
		} else {
			if ($_POST['repeat_type'] == 'week') {
				$rep_add_day = 7;
			} else {
				$rep_add_day = 1;
			}
			for ($dd=0; $dd<=$scopeDay; $dd+=$rep_add_day) {
				$insert_date = date("Y-m-d", mktime(0, 0, 0, $month, $day+$dd, $year));
				$sql = "insert into m_schedule ";
				$sql .= "(id_account";
				$sql .= ", c_date";
				$sql .= ", id_category";
				$sql .= ", id_group";
				$sql .= ", c_subject";
				$sql .= ", c_memo";
				$sql .= ", c_memo_strip_tags";
				$sql .= ", c_map";
				if ($user_id == $_SESSION['login_id']) {
					$sql .= ", c_privacy";
				}
				$sql .= ", c_time1";
				$sql .= ", c_time2";
				$sql .= ", c_registtime";
				$sql .= ", c_updatetime";
				$sql .= ", add_id_account";
				$sql .= ") values ";
				$sql .= "( '".$user_id."'";
				$sql .= ", '".$insert_date."'";
				$sql .= ", '" . $_POST['id_category'] . "'";
				$sql .= ", '".$id."'";
				$sql .= ", '".post_to_mysql('c_subject')."'";
				$sql .= ", '".post_to_mysql('c_memo')."'";
				$sql .= ", '".post_to_mysql_strip_tags('c_memo')."'";
				$sql .= ", '" . $_POST['c_map'] . "'";
				if ($user_id == $_SESSION['login_id']) {
					if ($_POST['c_privacy'] == '444') {
						$sql .= ", 444";
					} else {
						$sql .= ", 0";
					}
				}
				$sql .= ", ".$time1;
				$sql .= ", ".$time2;
				$sql .= ", '". date("Y/m/d H:i:s") . "'";
				$sql .= ", '". date("Y/m/d H:i:s") . "'";
				$sql .= ", '". $_SESSION['login_id'] . "'";
				$sql .= ")";
				$ret = my_mysqli_query($sql, "登録で失敗しました。日付:".$insert_date);

				// ****** 添付ファイル用＆グルーピング用 ******
				if ($id == 0) {
					//直近のINSERTクエリによりAUTO_INCREMENTカラム用に生成されたIDを取得
					$id = my_mysqli_insert_id();
					$sql = "update m_schedule set";
					$sql .= " id_group = '".$id."'";
					$sql .= " where id_schedule = ".$id;
					$ret = my_mysqli_query($sql, "更新(group)できませんでした。");
				}
			}
		}
	} elseif (isset($_POST['削除'])) {
		$sql = "update m_schedule set";
		$sql .= " c_delete = 999";
		$sql .= ", c_updatetime = '". date("Y/m/d H:i:s") . "'";
		$sql .= ", upd_id_account = '". $_SESSION['login_id'] . "'";
		if ($_POST['group_all'] == 'yes' && $_POST['id_group'] <> 0) {
			$sql .= " where id_group = ".$_POST['id_group'];
		} else {
			$sql .= " where id_schedule = ".$id;
		}
		$sql .= " and id_account = ".$user_id;
		$ret = my_mysqli_query($sql, "削除できませんでした。");
	} else {
		if ($_POST['group_all'] == 'yes' && $schedule_date <> date_from_mysql("Y-m-d", $_POST['c_date_current'])) {
			error_exit("一括修正で日付の修正はできません。", True);
		}
		$sql = "update m_schedule set";
		$sql .= " id_category = '".$_POST['id_category']."'";
		if ($_POST['group_all'].'' <> 'yes') {
			$sql .= ", c_date = '".$schedule_date."'";
		}
		$sql .= ", c_subject = '".post_to_mysql("c_subject")."'";
		$sql .= ", c_memo = '".post_to_mysql('c_memo')."'";
		$sql .= ", c_memo_strip_tags = '".post_to_mysql_strip_tags('c_memo')."'";
		$sql .= ", c_map = '".$_POST['c_map']."'";
		if ($user_id == $_SESSION['login_id']) {
			if ($_POST['c_privacy'] == '444') {
				$sql .= ", c_privacy = 444";
			} else {
				$sql .= ", c_privacy = 0";
			}
		}
		$sql .= ", c_time1 = ".$time1;
		$sql .= ", c_time2 = ".$time2;
		$sql .= ", c_updatetime = '". date("Y/m/d H:i:s") . "'";
		$sql .= ", upd_id_account = '". $_SESSION['login_id'] . "'";
		if ($_POST['group_all'] == 'yes' && $_POST['id_group'] <> 0) {
			$sql .= " where id_group = ".$_POST['id_group'];
		} else {
			$sql .= " where id_schedule = ".$id;
		}
		$sql .= " and id_account = ".$user_id;
		$ret = my_mysqli_query($sql, "更新できませんでした。");
	}
	// ****** 添付ファイル ******
	if ($id == 0) {
		$id = my_mysqli_insert_id();	//直近のINSERTクエリによりAUTO_INCREMENTカラム用に生成されたIDを取得
	}
	$sw = False;
	$sqlupd = "";
	for ($ix=1; $ix<=3; $ix++) {
		// ***** ファイルのアップロード *****
		$attachFile = file_upload("filename".$ix, $id, ATTACH_FILE_FOLDER, $user_id);
		if ($attachFile <> "") {
			if ($sw) {
				$sqlupd .= ",";
			}
			$sqlupd .= " c_attachFile" . $ix . " = '" . $attachFile . "'";
			$sw = True;
		} else if ($_POST['fileDelete'.$ix] == "YES") {
			if ($sw) {
				$sqlupd .= ",";
			}
			$sqlupd .= " c_attachFile" . $ix . " = ''";
			$sw = True;
		}
	}
	if ($sw) {
		$sql = "update m_schedule set";
		$sql .= $sqlupd;
		$sql .= " where id_schedule = ".$id;
		if ($schedule_to_date <> "") {
			$sql .= " and id_group = ".$id;			//新規で一括登録
		} else if ($_POST['group_all'] == 'yes' && $_POST['id_group'] <> 0) {
			$sql .= " and id_group = ".$_POST['id_group'];	//修正で一括修正
		} else {
			$sql .= " and id_schedule = ".$id;
		}
		$sql .= " and id_account = '".$user_id."'";
			//echo $sql;
			//exit;
		$ret = my_mysqli_query($sql, "アップロードファイル名DB登録失敗。", NULL, True);
	}
	mysqli_close($con);
	if ($_POST['page']."" <> "") {
		$arg = "pl=".$_GET['pl']."&sort=".$_GET['sort']."&cat=".$_GET['cat']."&key=".urlencode($_GET['key']);
		redirect("list.php?page=".$_POST['page']."&".$arg."#id_".$id);
	} else {
		//redirect("index.php?y=".$year."&m=".$month);		// ******************************
		redirect($_POST['return_http']);			// 元のページに戻る *************
	}
}
function input_form() {
	if ($_GET['uid']."" <> "") {
		$user_id = $_GET['uid'];
	} else {
		error_exit("不正アクセス：ユーザーIDなし。", True);
	}
	if (check_permit_id($_SESSION['login_id'], $user_id) != "w") {
		error_exit("書き込み権限がありません。", True);
	}
	if ($_GET['id']) {
		$id = $_GET['id'];
		if ($_GET['page']) {
			$page = $_GET['page'];
		}
	} else {
		$id = 0;
		if ($_GET['y']) {
			$year = $_GET['y'];
		} elseif ($_GET['selY']) {
			$year = $_GET['selY'];
		} else {
			$year = date('Y');
		}
		if ($_GET['m']) {
			$month = $_GET['m'];
		} elseif ($_GET['selM']) {
			$month = $_GET['selM'];
		} else {
			$month = date('n');
		}
		if ($_GET['d']) {
			$day = $_GET['d'];
		} elseif ($_GET['selD']) {
			$day = $_GET['selD'];
		} else {
			$day = date('j');
		}
		if (!checkdate($month, $day, $year)) {
			error_exit("日付が不正", True);
		}
	}
	$con = my_mysqli_connect(_DB_SCHEMA);
	calendar_input($user_id, $id, $year, $month, $day, $page);
	mysqli_close($con);
}
function calendar_input($user_id, $id, $year, $month, $day, $page) {
	if ($id == 0) {
		$subject = "";
		$memo = "";
		$hh1 = "";
		$mm1 = "";
		$hh2 = "";
		$mm2 = "";
	} else {
		$rec = schedule_get($user_id, $id);
		if (!$rec) {
			error_exit("該当レコードなし", True);
		}
		$year = date_from_mysql("Y", $rec['c_date']);
		$month = date_from_mysql("n", $rec['c_date']);
		$day = date_from_mysql("d", $rec['c_date']);
		$subject = $rec['c_subject'];
		$memo = $rec['c_memo'];
		$updatetime = $rec['c_updatetime'];
		if ($rec['c_time1']) {
			$hh1 = date_from_mysql("H", $rec['c_time1']);
			$mm1 = date_from_mysql("i", $rec['c_time1']);
		} else {
			$hh1 = "";
			$mm1 = "";
		}
		if ($rec['c_time2']) {
			$hh2 = date_from_mysql("H", $rec['c_time2']);
			$mm2 = date_from_mysql("i", $rec['c_time2']);
		} else {
			$hh2 = "";
			$mm2 = "";
		}
	}
	for ($ix=0; $ix<=$_SESSION['login_friends_number']; $ix++) {
		//if ($_SESSION['login_friends_id_'.$ix].'' == $user_id.'') {
		//	$current_handle = $_SESSION['login_friends_handle_'.$ix];
		//}
		$current_handle = $_SESSION['login_friends_handle_'.$user_id];
	}
?>
<?php if (TEXTAREA_HTML_USE == "YES") { ?>
<script src="../scripts/encloseTextArea.js"></script>
<script>
function encloseLink(s, e) {
	if(url = window.prompt("リンク先を入れてください。URL：", "")) {
		encloseTextArea('<a href="' + url + '" target="_blank">', '</a>', 'c_memo');
		htmlPreview();
	}
}
function enclosePreview(s, e) {
	encloseTextArea(s, e, 'c_memo');
	htmlPreview();
}
function htmlPreview() {
	document.getElementById('memo_html').innerHTML = htmlDecode(document.getElementById('c_memo').value).replace(/<icon /ig,"<img src=<?= IMAGES_FOLDER ?>/").replace(/\n/ig,"<br>").replace(/<m>/ig,"<span style=\"color: #008000\">[").replace(/<\/m>/ig,"]</span>");
}
function htmlDecode(str) {
	return str.replace(/&gt;/ig,">").replace(/&lt;/ig,"<").replace(/&nbsp;/ig,"");
}
function categoryIconSet(icon) {
	if (icon == '') {
		document.getElementById('icon_html').innerHTML = '';
	} else {
		document.getElementById('icon_html').innerHTML = '<img src="<?= IMAGES_FOLDER ?>/'+icon+'">';
	}
}
</script>
<?php } ?>
<div class="input_form">
<h3><?= $current_handle ?><a class="a_cancel_back" href='javascript:history.back();'>戻る</a></h3>
<script>
function formCheck(form) {
	//if (form.c_subject.value == '') {
	//	window.alert('件名を入れてください。');
	//	return false;		// 送信を中止
	//}
	return true;	// 送信を実行
}
</script>
<?php	if (strstr($_SERVER['HTTP_USER_AGENT'], "MSIE 6")) { ?>
<style>
.calenPopup {		/* IE6では、z-indexがselectプルダウンには効かないバグ対策。*/
	left: 10px;
	top: 20px;
</style>
<?php	} ?>
<form name="form0" method="POST" action="<?= $_SERVER['SCRIPT_NAME'] ?>?<?= $_SERVER['QUERY_STRING'] ?>" enctype="multipart/form-data" onSubmit="return formCheck(this)">
	<input type="hidden" name="return_http" value="<?= $_SERVER['HTTP_REFERER']?>">
	<input type="hidden" name="user_id" value="<?= $user_id ?>">
	<input type="hidden" name="update_id" value="<?= $id ?>">
	<input type="hidden" name="page" value="<?= $page ?>">
	<input type="hidden" name="updatetime" value="<?= $updatetime ?>">
	<input type="hidden" name="login_id" value="<?= $_SESSION['login_id'] ?>">
	<input type="hidden" name="current_id" value="<?= $_SESSION['current_id'] ?>">
<table class="input_form_table">
<tr>
	<td>日付</td>
	<td nowrap>
		<p>
			<input type="hidden" name="c_date_current" value="<?= $rec['c_date'] ?>">
		<?php
			$endYY = date("Y") + 10;
			select_view_with_id("inputY", "年", _CALENDAR_SELECT_FIRST_YEAR, $endYY, $year);
			select_view_with_id("inputM", "月", 1, 12, $month);
			select_view_with_id("inputD", "日", 1, 31, $day);
		?>
		<?php	if (INPUT_POPUP_CALENDAR == 'YUI') { ?>
			<img src="../images/calendar.png" onclick="YahhoCal.render('inputY', 'inputM', 'inputD');">
		<?php	} else if (INPUT_POPUP_CALENDAR == 'kanaya') { ?>
			<img src="../images/calendar.png" onClick="wrtCalendar(event,document.form0.ymd1,'inputY','inputM','inputD');">
			<input type="hidden" name="ymd1" id="ymd1" value="">
		<?php	} else { ?>
			<a href="javascript:viewCalen(theMonth,'calenArea1','inputY','inputM','inputD'); void(0);"><img src="../images/calendar.png"></a>
			<span id="calenArea1" class="calenBox"></span>
		<?php	} ?>
		<?php
			if ($id == 0) {
		?>
		～
		<?
				$endYY = date("Y") + 10;
				select_view_with_id("inputToY", "年", _CALENDAR_SELECT_FIRST_YEAR, $endYY, $year);
				select_view_with_id("inputToM", "月", 1, 12, $month);
				select_view_with_id_with_blank("inputToD", "日", 1, 31, "");
		?>
		<?php 	if (INPUT_POPUP_CALENDAR == 'YUI') { ?>
			<img src="../images/calendar.png" onclick="YahhoCal.render('inputToY', 'inputToM', 'inputToD');">
		<?php	} else if (INPUT_POPUP_CALENDAR == 'kanaya') { ?>
			<img src="../images/calendar.png" onClick="wrtCalendar(event,document.form0.ymd2,'inputToY','inputToM','inputToD');">
			<input type="hidden" name="ymd2" id="ymd2" value="">
		<?php	} else { ?>
			<a href="javascript:viewCalen(theMonth,'calenArea2','inputToY','inputToM','inputToD'); void(0);"><img src="../images/calendar.png"></a>
			<span id="calenArea2" class="calenBox"></span>
		<?php	} ?>
		</p>
		<p>
			<label><input type="radio" name="repeat_type" value="all" checked>連続(1ヶ月以内)</label>
			<label><input type="radio" name="repeat_type" value="week">同じ曜日のみ(3ヶ月以内)</label>
		</p>
		<?php
			}
		?>
		</div>
	</td>
	<?php
		if (TEXTAREA_HTML_USE == "YES") {
			view_images_button(7);
		}
	?>
</tr>
<tr>
	<td nowrap>時間<br></td>
	<td>
	<?php
			select_time("hh1", "mm1", $hh1, $mm1);
			echo "～";
			select_time("hh2", "mm2", $hh2, $mm2);
	?>
	</td>
</tr>
<?php
	if ($_COOKIE['calendar_bookedOnOff'] == 'none') {
		$bookedOnOff = ' checked';
		$booked_schedule_css = 'display:none;';
		$booked_schedule_none_css = '';
	} else {
		$bookedOnOff = '';
		$booked_schedule_display = 'display:none;';
		$booked_schedule_css = '';
		$booked_schedule_none_css = 'display:none;';
	}
?>
<script>
function bookedOnOff() {
	if ($.cookie("calendar_bookedOnOff") == 'none') {
		$("#booked_schedule").css("display","");
		$("#booked_schedule_none").css("display","none");
		$.cookie("calendar_bookedOnOff","on",{ path:'<?= MY_SESSION_PATH ?>', expires:365 });
	} else {
		$("#booked_schedule").css("display","none");
		$("#booked_schedule_none").css("display","");
		$.cookie("calendar_bookedOnOff","none",{ path:'<?= MY_SESSION_PATH ?>', expires:365 });
	}
}
</script>
<tr>
	<td nowrap>予定済<br>スケジュール<br>
	<label><input type="checkbox" onclick="bookedOnOff('')"<?= $bookedOnOff ?>>非表示</td></label>
	<td><div id="booked_schedule" style="<?= $booked_schedule_css ?>">
	<?php
		schedule_print($year, $month, $day, $user_id, "", "", False, True)
	?>
	</div><div id="booked_schedule_none" style="color:#804040; <?= $booked_schedule_none_css ?>"><br>(非表示)</div></td>
</tr>
<tr>
	<td nowrap>カテゴリ</td>
	<td class="input_form_td">
	<div id="input_category_radio" class="block_left">
	<!-- <ul> 折り返しがおかしい？ -->
	<?php
		$sqlsel = "select * from m_category where id_account = '".$user_id."'";
		$sqlsel = $sqlsel . " and c_delete = 0";
		$sqlsel = $sqlsel . " order by c_categoryDisplayOrder";
		$rs_sel = my_mysqli_query($sqlsel);
		if ($id == 0) {
			$category = (int)$_GET['cat'];
		} else {
			$category = $rec['id_category'];
		}
	?>
	<span><label><input type="radio" name="id_category" value="0"<?= $category == 0 ? " checked" : "" ?> onClick="categoryIconSet('')">(なし)</label></span>
	<?php
		if (!strstr($_SERVER['HTTP_USER_AGENT'], "MSIE")) {
			$nowrap = ' style="white-space:nowrap;"';	// IEではラベル文字が消えてしまう。
		}
		while ($rec_sel=mysqli_fetch_array($rs_sel)) {
	?>
	<span><label<?= $nowrap ?>><input type="radio" name="id_category" value="<?= $rec_sel['id_category'] ?>"<?= $rec_sel['id_category'] == $category ? " checked" : "" ?> onClick="categoryIconSet('<?= my_htmlspecialchars($rec_sel['c_iconImage']) ?>')">
		<?php if ($rec_sel['c_iconImage'] <> "") { ?>
			<img src="<?= IMAGES_FOLDER ?>/<?= my_htmlspecialchars($rec_sel['c_iconImage']) ?>">
		<?php } ?>
		<?= my_htmlspecialchars($rec_sel['c_categoryName']) ?>
	</label></span>
	<?php
		}
	?>
	<!-- </ul> -->
	</div>
	</td>
</tr>
<?php if ($_SESSION['login_friends_cal_sbj_use_'.$user_id] <> 'NO' || $subject <> '') { ?>
<?php
	if ($rec['c_iconImage'].'' <> '') $icon_html = '<img src="'.IMAGES_FOLDER.'/'.my_htmlspecialchars($rec['c_iconImage']).'">';
?>
<tr>
	<td>件名</td>
	<td><span id="icon_html"><?= $icon_html ?></span>
		<input class="text" type="text" name="c_subject" size=40 value="<?= my_htmlspecialchars($subject) ?>">
		<label><input type="checkbox" name="c_map" value="1" <?= $rec['c_map'] == 1 ? ' checked' : '' ?> style="margin-left: 10px;">地図</label>
		<?php if ($user_id == $_SESSION['login_id']) { ?>
			<label><input type="checkbox" name="c_privacy" value="444" <?= $rec['c_privacy'] == 444 ? ' checked' : '' ?> style="margin-left: 8px;">非公開</label>
		<?php } ?>
	</td>
</tr>
<?php } ?>
<tr>
	<td nowrap>スケジュール<br>本文</td>
	<td id="input_memo">
	<?php
		if (TEXTAREA_HTML_USE == "YES") {
			require(INPUT_COLOR_TAG);
			foreach ($color_tbl as $color) {
	?>
		<style>
		#input_memo input[type=button].c_<?= $color ?> {
			background-image: -moz-linear-gradient(top, <?= $color ?>, <?= $color ?>);
			background-image: -ms-linear-gradient(top, <?= $color ?>, <?= $color ?>);
			background-image: -webkit-gradient(linear, 0 0, 0 100%, from(<?= $color ?>), to(<?= $color ?>));
			background-image: -webkit-linear-gradient(top, <?= $color ?>, <?= $color ?>);
			background-image: -o-linear-gradient(top, <?= $color ?>, <?= $color ?>);
			background-image: linear-gradient(top, <?= $color ?>, <?= $color ?>);
			filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='<?= $color ?>', endColorstr='<?= $color ?>', GradientType=0);
		}
		</style>
		<input type="button" class="c_<?= $color ?>" value=" " style="margin: 0; padding: 0; height: 18px; width: 18px; background-color: <?= $color ?>; color: <?= $color ?>;" onClick="enclosePreview('<font color=<?= $color ?>>','</font>');return false;">
	<?php
			}
			if (!strstr($_SERVER['HTTP_USER_AGENT'], "MSIE")) {	//IE以外
				$button_style = 'margin: 0 0 1px 0; padding: 0; line-height: 0.9;';
			}
	?>
		<input type="button" value="Ｂ" style="<?= $button_style ?> height: 18px; width: 18px; font-weight: bold; background-color: #f0f0f0;" onClick="enclosePreview('<b>','</b>');return false;">
		<input type="button" value="Ｉ" style="<?= $button_style ?> height: 18px; width: 18px; font-weight: bold; background-color: #f0f0f0;" onClick="enclosePreview('<i>','</i>');return false;">
		<input type="button" value="Ｓ" style="<?= $button_style ?> height: 18px; width: 18px; font-weight: bold; background-color: #f0f0f0; text-decoration: line-through ;" onClick="enclosePreview('<s>','</s>');return false;">
		<input type="button" value="大" style="<?= $button_style ?> height: 18px; width: 18px; font-weight: bold; background-color: #f0f0f0;" onClick="enclosePreview('<span style=\'font-size:large;\'>','</span>');return false;">
		<input type="button" value="地" style="<?= $button_style ?> height: 18px; width: 22px; font-weight: bold; background-color: #f0f0f0;" onClick="enclosePreview('<m>','</m>');return false;">
		<input type="button" value="Ｌ" style="<?= $button_style ?> height: 18px; width: 18px; font-weight: bold; background-color: #f0f0f0;" onClick="encloseLink();return false;">
	<?php
		}
	?>
		<div class="block_left;clear:left;">
		<?php
			$str = my_htmlspecialchars($memo);
			$rows = textarea_rows($str, 430) + 1;
			if ($rows < 5) {
				$rows = 5;
			} elseif (strstr($_SERVER['HTTP_USER_AGENT'], "MSIE") and $rows > 30) {
				$rows = 30;
			}
		?>
		<?php
			if (strstr($_SERVER['HTTP_USER_AGENT'], "MSIE")) {
				$textarea_width = 410;
			} else {
				$textarea_width = 430;
			}
		?>
	<?php	if (TEXTAREA_HTML_USE == "YES") { ?>
		<textarea id="c_memo" name="c_memo" style="width:<?= $textarea_width ?>px;" rows="<?= $rows ?>" wrap="soft" onkeyup="htmlPreview()"><?= $str ?></textarea>
	<?php	} else { ?>
		<textarea id="c_memo" name="c_memo" style="width:<?= $textarea_width ?>px;" rows="<?= $rows ?>" wrap="soft"><?= $str ?></textarea>
	<?php	} ?>
		</div>
		<?php	if (strstr($_SERVER['HTTP_USER_AGENT'], "MSIE")) { ?>
			<div class="block_left">
			<input type="button" value="小" OnClick="textareaBigSmall('c_memo','小')"><br>
			<input type="button" value="大" OnClick="textareaBigSmall('c_memo','大')"><br>
			</div>
		<?php	} ?>
	<div id="memo_html" class="block">
	<?php	if (TEXTAREA_HTML_USE == "YES") { ?>
		<?= ins_br(my_schedule_decorate_preview($memo)) ?>
	<?php	} ?>
	</div>
	</td>
</tr>
<tr>
	<td nowrap>添付文書</td>
	<td>
<?php if ($rec['c_attachFile1'] <> "" || $rec['c_attachFile2'] <> "" || $rec['c_attachFile3'] <> "") { ?>
	<p><span class="alarm_text">再度添付ファイル名を指定すると登録済ファイルに上書きされます。</span></p>
<?php } ?>
<?php
	for ($ix=1; $ix<=3; $ix++) {
?>
		<div class="block">
		<div class="block_left">(<?= $ix ?>)</div>
		<div class="block_left">
<?php
		if ($rec['c_attachFile'.$ix] <> "") {
			attach_file_view($rec['id_account'], $rec['c_attachFile'.$ix], '', '', False);
?>
		<label><input type="checkbox" name="fileDelete<?= $ix ?>" value="YES">削除</label>
		<input type="hidden" name="filenameCurrent<?= $ix ?>" value="<?= $rec['c_attachFile'.$ix] ?>">
<?php
		}
?>
		<input type="file" size=40 name="filename<?= $ix ?>" style="button-font-size:small">
		</div>
		</div>
<?php
	}
?>
	</td>
</tr>
</table>
<?php
	if ($id == 0) {
?>
	<input class="input_form_button" type="submit" name="登録" value="登録">
<?php
	} else {
?>
	<input class="input_form_button" type="submit" name="登録" value="修正">
	<input class="input_form_button" type="submit" name="削除" value="削除" onClick="return delete_check();" style="margin-left:20px;">
	<?php
		if ($rec['id_group'] <> 0) {
	?>
	<input type="hidden" name="id_group" value="<?= $rec['id_group'] ?>">&nbsp;
	<label><input type="checkbox" name="group_all" value="yes"><span style="color: red">一括修正/削除(日付変更は不可)</span></label>
	<?php
		}
	?>
<?php
	}
?>
</form>
<script>
function delete_check() {
	if (window.confirm('このスケジュールを削除しますか？')) {
		return true;
	} else {
		return false;
	}
}
</script>
<?php	if (!strstr($_SERVER['HTTP_USER_AGENT'], "MSIE")) { ?>
<script src="../scripts/autoresize.jquery.min.js"></script>
<script>
$('textarea#c_memo').autoResize({
	onResize : function() {
		$(this).css({opacity:0.8});
	},
	animateCallback : function() {
		$(this).css({opacity:1});
	},
	animateDuration : 300,
	extraSpace : 20
});
$('textarea#c_memo').trigger('change'); // 初期表示時に自動リサイズさせるためchangeイベント実行
</script>
<?php	} ?>
<?php
}
?>
