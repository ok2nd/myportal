<?php
	require("__include-common.php");
	require("../account/__logincheck.php");
	if ($_GET['sev'] == 'set') {
		require("__include-session-variable.php");
	}
	if ($_SESSION['photo_error'] == 'permission_error') {
		exit('permission_error');
	}
	$open_path = $_SESSION['photo_open_path'];
	$page = $_SESSION['photo_page'];
	if ($_GET['get'] == 'dir') {
		get_target_path_info($open_path);
	}
	if ($_GET['vss'].'' <> '') {
		$_SESSION['video_thumb_ss'] = $_GET['vss'];
		video_thumb_ss_file($open_path, strval($_SESSION['video_thumb_ss']));
	} else {
		$_SESSION['video_thumb_ss'] = video_thumb_ss_file($open_path);
	}
	if ($_SESSION['photo_view_sort_old'] <> $_SESSION['photo_view_sort'] or $_SESSION['photo_view_sort_order_old'] <> $_SESSION['photo_view_sort_order']) {
		sort_order_change();
	}
	if ($_GET['get'] == 'dir') {
		view_photo_dir($open_path, $page);
	} elseif ($_GET['get'] == 'header') {
		change_view_header($_SESSION['photo_view_mode'], $open_path, $page);
		if ($_SESSION['photo_view_mode'] == 's') {
			change_view_slide_option($page, $open_path);
		} else {
			select_page_images_max($_SESSION['photo_imgmax']);
			change_view_thumb_ss($page);
		}
	} elseif ($_GET['get'] == 'chgopt') {
		change_view_chgopt($_SESSION['photo_view_mode'], $open_path, $page);
		if (photo_FOLDER_IMAGE_VIEW <> 'NO') {
			change_folder_img1($page);
		}
	} else {
		if ($_SESSION['photo_view_mode'] == 's') {
			view_photo_slide($open_path, $page);
		} elseif ($_SESSION['photo_view_mode'] == 'b') {
			view_photo_thumbnail_b($open_path, $page);
		} else {
			view_photo_thumbnail($open_path, $page);
		}
	}
?>
<?php
function view_photo_dir($open_path, $page) {
	$up_path = up_folder_path($open_path);
?>
<div id="dir_change_area">
<?php if (isset($_SESSION['up_folder_subdir'])) { // ------------- ?>
<div id="up_folder_subdir" class="photo_dir_change">
	<span id="dir_pos_change"><a href="javascript:dirPosChange()"><img id="m_right" src="../icon/arrow_left.png"><img id="m_left" src="../icon/arrow_right.png"></a></span>
	<br class="dir_sep" />
	<span id="up_folder_subdir_area" style="display:<?= $_COOKIE['photo_up_folder_display'] == 'none' ? 'none' : '' ?>;">
<?php
	$current_folder = substr($open_path,strrpos($open_path,'/')+1);
	$dir_cnt = 0;
	foreach ($_SESSION['up_folder_subdir'] as $subdir) {
		if ($subdir == $current_folder) {
			$class = ' id="current_folder"';
			$current_dir_cnt = $dir_cnt;
		} else {
			$class = '';
		}
		$dir_cnt++;
?>
			<span class="photo_dir_chg_a"><a class="dir_change" href="javascript:void(0);" onClick="javascript:ajax_view_dir_photo('path','<?= escape_squote($up_path.'/'.$subdir) ?>');"<?= $class ?>><?= $subdir ?><br class="dir_sep" /></a></span>
<?php
	}
?>
	<span id="up_folder_subdir_off"><a href="javascript:upfolderOff()">←▲非表示</a></span>
	</span>
	<span id="up_folder_subdir_on" style="display:<?= $_COOKIE['photo_up_folder_display'] == 'none' ? '' : 'none' ?>;"><a href="javascript:upfolderOn()">▼上位フォルダ表示</a></span>
</div>
<?php }  // ------------- ?>
<div id="current_folder_subdir" class="photo_dir_change">
<?php
	if ($_SESSION['photo_folder_img1'] <> 'on') {
		foreach ($_SESSION['photo_subdir'] as $subdir) {
?>
		<span class="photo_dir_chg_a">
		<a class="dir_change" href="javascript:void(0);" onClick="javascript:ajax_view_dir_photo('path','<?= escape_squote($open_path.'/'.$subdir) ?>');"><?= $subdir ?><br class="dir_sep" /></a>
		</span>
<?php
		}
	} else {
?>
<div class="vCenterFolder">
	<ul>
<?php
		foreach ($_SESSION['photo_subdir_img1'] as $imgfile) {
			$dirpath = $open_path.'/'.$imgfile['dir'];
			if ($imgfile['type'] == 'none') {
				$height_size = SMALL_SIZE;
				$frame_size = $height_size + 6;
?>
			<li class="thumbsDir" style="width:<?= $frame_size ?>px; height:<?= $frame_size ?>px; overflow:hidden;">
			<p class="thumbsDir" style="width:<?= $frame_size ?>px; height:<?= $frame_size ?>px; overflow:hidden;">
			<a href="index.php?path=<?= urlencode($dirpath) ?>">
			<span style="width:<?= $height_size ?>px; height:<?= $height_size ?>px; line-height:<?= $height_size ?>px; overflow:hidden;"><?= $imgfile['dir'] ?></span>
			</a>
			</p>
			</li>
<?php
			} else {
				$imgpath = $dirpath.'/'.$imgfile['file'];
				if ($imgfile['type'] == 'video') {
					$width_height = "width";
					$getimg = "video-jpeg.php?file=".urlencode($imgpath)."&ss=".$_SESSION['video_thumb_ss'];
					$height_size = SMALL_SIZE;
					$border_style = VIDEO_THUMBNAIL_BORDER;
				} else {
					get_width_height($imgpath, $width, $height);
					if ($width > $height) {
						$width_height = "width";
					} else {
						$width_height = "height";
					}
					$getimg = "img-view.php?img=".urlencode($imgpath);
					$height_size = SMALL_SIZE;
					$border_style = '';
				}
			$frame_size = $height_size + 6;
?>
			<li class="thumbsDir" style="width:<?= $frame_size ?>px; height:<?= $frame_size ?>px;">
			<p class="thumbsDir" style="width:<?= $frame_size ?>px; height:<?= $frame_size ?>px;">
			<a href="index.php?path=<?= urlencode($dirpath) ?>"><img class="thumbsDir_<?= $width_height ?>" src="<?= $getimg ?>" <?= $width_height ?>=<?= $height_size ?> style="line-height:<?= SMALL_SIZE ?>px;<?= $border_style ?>" alt="<?= $imgfile['dir'] ?>" title="<?= $imgfile['dir'] ?>"/></a>
			</p>
			</li>
<?php
			}
		}
?>
	</ul>
	</div>
<?php
	}
?>
</div>
</div>
<?php
}
?>
<?php
function view_photo_thumbnail($open_path, $page) {
	$img_count = $_SESSION['photo_img_count'];
	$start_count = ($page - 1) * $_SESSION['photo_imgmax'] + 1;		//開始番号を算出
	$end_count = $page * $_SESSION['photo_imgmax'];				//終了番号を算出
	$pagemax = ceil($img_count / $_SESSION['photo_imgmax']);		//取得したファイル数から最終頁を算出
	if ($end_count > $img_count) {
		$end_count = $img_count;
	}
?>
<div id="photo_images_view_box">
<?php
	if ($start_count <= $end_count) {
		photo_page_control($img_count, $page, $pagemax, $open_path);
		for ($idx=$start_count-1; $idx<$end_count; $idx++) {
			$filename = $_SESSION['photo'][$idx]['file'];
			$filepath = $open_path.'/'.$filename;
			if ($_SESSION['photo'][$idx]['type'] == 'video') {
				$getimg = "video-jpeg.php?file=".urlencode($filepath)."&ss=".$_SESSION['video_thumb_ss'];
				$click = "video-view.php?file=".urlencode($filepath);
				$height_size = $_SESSION['photo_thumbs_size'] - 2;
				$border_style = VIDEO_THUMBNAIL_BORDER;
				$width = $height = 0;	// for popupImage
			} else {
				$getimg = "img-view.php?img=".urlencode($filepath);
				$click = $getimg;
				$height_size = $_SESSION['photo_thumbs_size'];
				$border_style = '';
				if (strstr($_SERVER['HTTP_USER_AGENT'], "MSIE")) {
					get_width_height($filepath, $width, $height);
				} else {
					$width = $height = 0;	// for popupImage
				}
			}
?>
			<span class="popup">
			<img class="thumbs" src="<?= $getimg ?>" height="<?= $height_size ?>" style="<?= $border_style ?>" alt="<?= $filename ?>" id="img<?= $idx ?>" title="<?= $filename ?>" align=top onClick="popupImage('<?= $getimg ?>',<?= $width ?>,<?= $height ?>,'img<?= $idx ?>')"/>
			</span>
<?php
		}
	}
?>
</div>
</div>
<script>
var imgsize = <?= $_SESSION['photo_thumbs_size'] ?>;
var bigid = false;
function resizeImage(up_down) {
	setSizeImage(imgsize + (up_down));
}
function setSizeImage(size) {
	if (size < <?= SMALL_SIZE ?>) {
		return;
	}
	imgsize = size;
	$.cookie('photo_thumbs_size',size,{ path:'<?= MY_SESSION_PATH ?>', expires:365 });
	$("img.thumbs").height(size);
}
</script>
<?php
}
function view_photo_thumbnail_b($open_path, $page) {
	$img_count = $_SESSION['photo_img_count'];
	$start_count = ($page - 1) * $_SESSION['photo_imgmax'] + 1;		//開始番号を算出
	$end_count = $page * $_SESSION['photo_imgmax'];				//終了番号を算出
	$pagemax = ceil($img_count / $_SESSION['photo_imgmax']);		//取得したファイル数から最終頁を算出
	if ($end_count > $img_count) {
		$end_count = $img_count;
	}
?>
<div class="vCenter">
	<ul>
<?php
	if ($start_count <= $end_count) {
		photo_page_control($img_count, $page, $pagemax, $open_path);
		for ($idx=$start_count-1; $idx<$end_count; $idx++) {
			$filename = $_SESSION['photo'][$idx]['file'];
			$filepath = $open_path.'/'.$filename;
			if ($_SESSION['photo'][$idx]['type'] == 'video') {
				$width_height = "width";
				$getimg = "video-jpeg.php?file=".urlencode($filepath)."&ss=".$_SESSION['video_thumb_ss'];
			//	$click = "video-view.php?file=".urlencode($filepath);
				$height_size = $_SESSION['photo_thumbs_size'];
				$border_style = VIDEO_THUMBNAIL_BORDER;
			} else {
				get_width_height($filepath, $width, $height);
				if ($width > $height) {
					$width_height = "width";
				} else {
					$width_height = "height";
				}
				$getimg = "img-view.php?img=".urlencode($filepath);
			//	$click = $getimg;
				$height_size = $_SESSION['photo_thumbs_size'];
				$border_style = '';
			}
			$frame_size = $height_size + 6;
?>
			<li class="thumbs" style="width:<?= $frame_size ?>px; height:<?= $frame_size ?>px;">
			<p class="thumbs" style="width:<?= $frame_size ?>px; height:<?= $frame_size ?>px;">
			<a href="javascript:void(0);" onClick="javascript:location.href='?page=<?= $idx+1 ?>&mode=s';"><img class="thumbs thumbs_<?= $width_height ?>" src="<?= $getimg ?>" <?= $width_height ?>=<?= $height_size ?> style="line-height:<?= $_SESSION['photo_thumbs_size'] ?>px;<?= $border_style ?>" alt="<?= $filename ?>" title="<?= $filename ?>"/></a>
			</p>
			</li>
<?php
		}
	}
?>
	</ul>
</div>
</div>
<script>
var imgsize = <?= $_SESSION['photo_thumbs_size'] ?>;
function resizeImage(up_down) {
	setSizeImage(imgsize + (up_down));
}
function setSizeImage(size) {
	if (size < <?= SMALL_SIZE ?>) {
		return;
	}
	$.cookie('photo_thumbs_size',size,{ path:'<?= MY_SESSION_PATH ?>', expires:365 });
	imgsize = size;
	$("img.thumbs_width").width(size);
	$("img.thumbs_height").height(size);
	frame_size = String(size+6)+"px";
	$("li.thumbs").css("width", frame_size)
		      .css("height", frame_size);
	$("p.thumbs").css("width", frame_size)
		     .css("height", frame_size);
}
</script>
<?php
}
function view_photo_slide($open_path, $page) {
	$img_count = $_SESSION['photo_img_count'];
?>
<div id="photo_images_main_view">
<?php
	if ($page <= $img_count) {
		$idx = $page - 1;
		photo_page_control($img_count, $page, $img_count, $open_path, SLIDE_SMALL_NUM, '枚');
		$filename = $_SESSION['photo'][$idx]['file'];
		$filetime = $_SESSION['photo'][$idx]['time'];
		if (VIDEO_PREVIEW == 'YES' && $_SESSION['slide_flv_preview'] == 'on' && is_preview_video_filename($filename) && is_ext_filename_str($filename, VIDEO_PREVIEW_CONVERT)) {
			$filepath = $open_path.'/'.$filename.'.flv';	// JWPlayerは拡張子が.flvでないと駄目なため
		} else {
			$filepath = $open_path.'/'.$filename;
		}
		$filepath_url = urlencode($filepath);
		if ($_SESSION['photo'][$idx]['type'] == 'video') {
			$getimg = "video-jpeg.php?file=".$filepath_url."&ss=".$_SESSION['video_thumb_ss'];
			$click = "video-view.php?file=".$filepath_url;
			$height_size = $_SESSION['slide_main_size'] - 2;
			$border_style = VIDEO_THUMBNAIL_BORDER;
		} else {
			get_width_height($filepath, $width, $height);
			$getimg = "img-view.php?img=".$filepath_url;
			$click = $getimg;
			$height_size = $_SESSION['slide_main_size'];
			$border_style = '';
		}
?>
	<script>
	function movieSizeChange(sel, cookie_name) {
		for (i = 0; i < sel.options.length; i++) {
			if (sel.options[i].selected == true) {
				size = Number(sel.options[i].value);
			}
		}
		$.cookie(cookie_name,size,{ path:'<?= MY_SESSION_PATH ?>', expires:365 });
<?php 		if (is_ext_filename_str($click, VIDEO_PREVIEW_WMV)) { ?>
		wmv_preview("movie_preview", "<?= $click ?>", Math.floor(size*4/3), size);
<?php		} else { ?>
		//movie_preview_withimage("movie_preview", "<?= $click ?>", Math.floor(size*4/3), size, "<?= $getimg ?>");
		movie_preview("movie_preview", "<?= $click ?>", Math.floor(size*4/3), size);
<?php		} ?>
	}
	</script>
		<div style="height:0px;line-height:0px;font-size:0px;clear:both;visibility: hidden;">.</div><!-- IE6対応 -->
		<div id="slide_main_img" style="background-color: <?= SLIDE_MAIN_BG_COLOR ?>;">
<?php
		if ($_SESSION['photo'][$idx]['type'] == 'video' and photo_VIDEO_FFMPEG == 'YES') {
			// 動画の再生時間を取得 (ffmpegのstderrを利用)
			$ret = shell_exec('ffmpeg -i "'.myfile_ENCODE($open_path.'/'.$filename).'" 2>&1');
			$time_play = trim(get_intag($ret, 'duration:', ',', $pos=0));
			$time_ar = explode(":", $time_play);
			$time_sec = (int)$time_ar[0]*3600+(int)$time_ar[1]*60+(int)$time_ar[2];
			$thumb_num = $_SESSION['video_timeline_thumb_num'];
		}
		if ($_SESSION['photo'][$idx]['type'] == 'video' and $_SESSION['video_timeline_thumb'] == 'on') {
?>
		<p id="file_info"><?= $filename ?><span id="file_info_time"><?= $time_play ?></span></p>
		<img id="img_slide_main" height="0" style="display: none; " /><!-- ダミー -->
<?php
			for ($ix=0; $ix<$thumb_num; $ix++) {
				$sec = floor($time_sec / $thumb_num * $ix);
				$getimg = "video-jpeg.php?file=".$filepath_url."&ss=".$sec;
?>
			<a href="<?= $getimg ?>" target="_blank">
			<img class="img_timeline_thumb" class="bicubic" src="<?= $getimg ?>" height=<?= $_SESSION['video_timeline_thumb_size'] ?> style="<?= $border_style ?>" alt="<?= $filename ?>" title="<?= $filename ?>" align=top onDblClick="window.open('<?= $click ?>');return false;" />
			</a>
<?php
			}
		} elseif (VIDEO_PREVIEW == 'YES' && $_SESSION['slide_flv_preview'] == 'on' && is_preview_video_filename($filepath)) {
			if (is_ext_filename_str($click, VIDEO_PREVIEW_WMV)) {
?>
		<div id="movie_preview">the player will be placed here</div>
		<script>
			wmv_preview("movie_preview", "<?= $click ?>", "<?= floor($height_size*4/3) ?>", "<?= $height_size ?>");
		</script>
<?php
			} else {
?>
		<div id="movie_preview">the player will be placed here</div>
		<script>
			movie_preview("movie_preview", "<?= $click ?>", "<?= floor($height_size*4/3) ?>", "<?= $height_size ?>");
		</script>
<?php
			}
?>
		<div class="photo_file_name" style="text-align: center;"><?= $filename ?> (<?= date( 'Y/m/d H:i:s', $filetime) ?>)<span id="file_info_time"><?= $time_play ?></span></div>
<?php
		} else {
?>
		<table style="margin-left: auto; margin-right: auto;"><tr><td><a id="slide_main_img_a" href="<?= $click ?>&enc=no" target="_blank"><img class="img_timeline_thumb" height="0" style="display: none; " /><!-- ダミー --><img id="img_slide_main" class="bicubic" src="<?= $getimg ?>" height="<?= $height_size ?>" style="<?= $border_style ?>" alt="<?= $filename ?>" title="<?= $filename ?>" align=top onDblClick="window.open('<?= $click ?>');return false;" /></a><p class="photo_file_name" style="text-align: center;"><?= $filename ?> (<?= date( 'Y/m/d H:i:s', $filetime) ?>)<span id="file_info_time"><?= $time_play ?></span></p></td>
		<?php if (JIGSAW_PUZZLE_CREATE == 'YES' or ($_SESSION['システム管理者'] == "YES" and is_ext_filename_str($filename,'jpg,jpeg'))) { ?>
		<td>
			<span id="opt_link">
			<a href="imagefilters.php?img=<?= $filepath_url ?>" target="_blank">ImageFilters</a><br><br>
			<a href="imagefilters-ripple.php?img=<?= $filepath_url ?>" target="_blank">さざ波</a><br><br>
			<a href="deviantart.php?background=img-view.php?img=<?= $filepath_url ?>" target="_blank">deviantART</a><br><br>
			<a href="css_filters.php?page=<?= $page ?>" target="_blank">CSSフィルタ</a><br><br>
			<a href="tenbyou.php?img=<?= $filepath_url ?>" target="_blank">点描</a><br><br>
			<a href="swinging.php?page=<?= $page ?>" target="_blank">揺れる</a><br><br>
			<a href="zoom-inout.php?page=<?= $page ?>" target="_blank">拡大縮小</a><br><br>
			<a href="tiltshift.php?page=<?= $page ?>" target="_blank">チルトシフト</a><br><br>
			<a href="rainyday.php?page=<?= $page ?>" target="_blank">雨降り</a><br><br>
			<?php if (JIGSAW_PUZZLE_CREATE == 'YES') { ?>
			<a href="jigsaw.php?img=<?= $filepath_url ?>" target="_blank">ジグソー</a><br><br>
			<?php } ?>
			<?php if ( $_SESSION['システム管理者'] == "YES" and is_ext_filename_str($filepath, 'jpg,jpeg')) { ?>
			<a href="javascript:void(0);" onClick="javascript:popup_win('exif-read.php?path=<?= $filepath_url ?>');">EXIF情報</a><br><br>
			<?php } ?>
			</span>
		</td>
		<?php } ?>
		</tr></table>
<?php
		}
?>
		</div>
<?php
	} else {	// 画像がない場合のJavaScriptで画像サイズ変更用のダミー
?>
		<img id="img_slide_main" height="0" style="display: none; " />
		<img class="img_timeline_thumb" height="0" style="display: none; " />
<?php
	}
?>
</div>
<div id="photo_images_small_view" style="background-color: <?= SLIDE_SMALL_BG_COLOR ?>;">
<?php
	$current_page = $page;
	$end_count = $page + SLIDE_SMALL_NUM - 1;
	if ($end_count > $img_count) {
		$end_count = $img_count;
	}
	if ($end_count == $img_count) {		//残りが10枚数以下の場合、すべて表示
		$page = $end_count - 9;
		if ($page < 1) {
			$page = 1;
		}
	}
	if ($page <= $img_count) {
		for ($idx=$page-1; $idx<$end_count; $idx++) {
			$filename = $_SESSION['photo'][$idx]['file'];
			$filepath = $open_path.'/'.$filename;
			if ($_SESSION['photo'][$idx]['type'] == 'video') {
				$getimg = "video-jpeg.php?file=".urlencode($filepath)."&ss=".$_SESSION['video_thumb_ss'];
				$height_size = SLIDE_SMALL_SIZE - 2;
				$border_style = VIDEO_THUMBNAIL_BORDER;
			} else {
				$getimg = "img-view.php?img=".urlencode($filepath)."&type=thumb";
				$height_size = SLIDE_SMALL_SIZE;
				$border_style = '';
			}
			if ($idx+1 == $current_page) {
				$height_size = SLIDE_SMALL_SIZE - 2;
				$border_style = CURRENT_THUMBNAIL_BORDER;
			}
?>
			<span class="small_img">
			<a href="javascript:void(0);" onClick="javascript:ajax_view_photo('','',<?= $idx+1 ?>,true);"><img class="bicubic" src="<?= $getimg ?>" height=<?= $height_size ?> style="<?= $border_style ?>" alt="<?= $filename ?>" title="<?= $filename ?>" align=top /></a>
			</span>
<?php
		}
	}
?>
</div>
<?php
}
function change_view_thumb_ss($page) {
?>
	動画開始秒：<select onchange="ajax_view_photo('vss',$(this).val(),'',true)">
	<?php
		for ($video_ss=0; $video_ss <= 20; $video_ss+=2) {
	?>
		<option value="<?= $video_ss ?>"<?= $video_ss == $_SESSION['video_thumb_ss'] ? " selected" : "" ?>><?= $video_ss ?>秒
	<?php
		}
	?>
		</select>
<?php
}
function change_folder_img1($page) {
?>
	<input type="checkbox" id="chk_folder_img1" onClick="CheckboxOnOff('fim',this,'dir')"<?= $_SESSION['photo_folder_img1'] == 'on' ? ' checked' : '' ?> style="margin-left:5px;"><label for="chk_folder_img1">フォルダ画像表示</label>
<?php
}
function change_view_slide_option($page, $open_path) {
	$filename = $_SESSION['photo'][$page-1]['file'];
?>
<?php	if ($_SESSION['slide_flv_preview'] == 'on' && is_preview_video_filename($filename)) { ?>
	画像サイズ：<select onchange="movieSizeChange(this, 'slide_main_size')">
<?php	} else { ?>
	画像サイズ：<select onchange="slideSizeChange('#img_slide_main', this, 'slide_main_size')">
<?php	} ?>
	<?php
		$keyary = explode(",", SLIDE_MAIN_SIZE_SELECT);
		foreach ($keyary as $size) {
	?>
		<option value="<?= $size ?>"<?= $size == $_SESSION['slide_main_size'] ? " selected" : "" ?>><?= $size ?> px
	<?php
		}
	?>
		</select>
	<?php	if (photo_VIDEO_FFMPEG == 'YES' and photo_VIDEO_PREVIEW == 'YES') { ?>
	<input type="checkbox" id="chk_flv_preview" onClick="CheckboxOnOff('flv',this,'')"<?= $_SESSION['slide_flv_preview'] == 'on' ? ' checked' : '' ?>><label for="chk_flv_preview">FLV/WMV動画再生</label>
	<?php	} ?>
	<?php	if (photo_VIDEO_FFMPEG == 'YES') { ?>
		<?php
			change_view_thumb_ss($page);
		?>
		<input type="checkbox" id="chk_timeline" onClick="CheckboxOnOff('vst',this,'')"<?= $_SESSION['video_timeline_thumb'] == 'on' ? ' checked' : '' ?>><label for="chk_timeline">動画時間分割</label>
		<?php if ($_SESSION['video_timeline_thumb'] == 'on') { ?>
			分割数：<select onchange="ajax_view_photo('vsn',$(this).val(),'',true)">
			<?php
				$keyary = explode(",", VIDEO_TIMELINE_THUMB_NUM_SELECT);
				foreach ($keyary as $num) {
			?>
				<option value="<?= $num ?>"<?= $num == $_SESSION['video_timeline_thumb_num'] ? " selected" : "" ?>><?= $num ?>
			<?php
				}
			?>
				</select>
			サイズ：<select onchange="slideSizeChange('.img_timeline_thumb', this, 'video_timeline_thumb_size')">
			<?php
				$keyary = explode(",", VIDEO_TIMELINE_THUMB_SIZE_SELECT);
				foreach ($keyary as $size) {
			?>
				<option value="<?= $size ?>"<?= $size == $_SESSION['video_timeline_thumb_size'] ? " selected" : "" ?>><?= $size ?> px
			<?php
				}
			?>
				</select>
		<?php	} ?>
	<?php } ?>
<?php
}
function select_page_images_max($pageline) {
?>
	頁枚数：<select onchange="ajax_view_photo('imgmax',$(this).val(),1,true)">
	<?php
		$keyary = explode(",", IMAGE_MAX_SELECT);
		foreach ($keyary as $keytmp) {
	?>
		<option value="<?= $keytmp ?>"<?= $pageline == $keytmp ? " selected" : "" ?>><?= $keytmp ?>
	<?php
		}
	?>
		</select>
	<span style="padding:5px;">
	<input type="button" value="最小" onClick="setSizeImage(<?= SMALL_SIZE ?>)">
	<input type="button" value="小さく" onClick="resizeImage(-<?= UPDOWN_SIZE ?>)">
	<input type="button" value="大きく" onClick="resizeImage(<?= UPDOWN_SIZE ?>)">
	<input type="button" value="中" onClick="setSizeImage(<?= MID_SIZE ?>)">
	<input type="button" value="大" onClick="setSizeImage(<?= BIG_SIZE ?>)">
	<input type="button" value="最大" onClick="setSizeImage(<?= MAX_SIZE ?>)">
	</span>
<?php
}
function view_sortorder($view_sort) {
	if ($_SESSION['photo_view_sort'] <> $view_sort) {
		echo '<span class="order_mark">　</span>';
	} elseif ($_SESSION['photo_view_sort_order'].'' == 'desc') {
		echo '<span class="order_mark">▼</span>';
	} else {
		echo '<span class="order_mark">▲</span>';
	}
}
function photo_page_control($img_count, $page, $pagemax, $open_path, $skip_num=0, $page_suffix='頁') {
?>
<div class="photo_page_control">
<span class="photo_page_control_info">
	<span id="photo_sort_menu">
		<a href="javascript:void(0);" onClick="javascript:ajax_view_photo('sort','name',1,true);"<?= $_SESSION['photo_view_sort']<>'time' ? ' id="photo_sort_menu_current"' : '' ?>>ファイル名順</a><?php view_sortorder('name') ?>
		<a href="javascript:void(0);" onClick="javascript:ajax_view_photo('sort','time',1,true);"<?= $_SESSION['photo_view_sort']=='time' ? ' id="photo_sort_menu_current"' : '' ?>>更新日時順</a><?php view_sortorder('time') ?>
	<span>
	<span class="choice">枚数：<span class="photo_rowcnt"><?= $img_count ?></span>枚</span>&nbsp;
	<span class="choice"><span class="photo_page"><?= $page ?></span>/<span class="photo_pagemax"><?= $pagemax ?></span><?= $page_suffix ?></span>
<?php
	if ($page_suffix == '頁') { 
		$photo_fst = ($page - 1) * $_SESSION['photo_imgmax'] + 1;
		$photo_end = $photo_fst + $_SESSION['photo_imgmax'] - 1;
		if ($photo_end > $_SESSION['photo_img_count']) {
			$photo_end = $_SESSION['photo_img_count'];
		}
?>
	<span class="choice">(<span class="photo_fst_end"><?= $photo_fst ?></span>～<span class="photo_fst_end"><?= $photo_end ?></span>枚目)</span>
<?php
	}
?>
</span>
<span class="photo_page_control_move">
<?php
	$parm = '&path='.urlencode($open_path).'&mode='.$_SESSION['photo_view_mode'];
	$label = '[←先頭]';
		if ($page > 1) {
			page_move($label, 1, $parm);
		} else {
			page_no_move($label);
		}
		if ($skip_num <> 0) {
	$label = '[←スキップ ('.$skip_num.')]';
			if ($page-$skip_num > 0) {
				page_move($label, $page-$skip_num, $parm);
			} else {
				page_no_move($label);
			}
		}
	$label = '[←前]';
		if ($page > 1) {
			page_move($label, $page-1, $parm);
		} else {
			page_no_move($label);
		}
	$label = '[→次]';
		if ($page < $pagemax) {
			page_move($label, $page+1, $parm);
		} else {
			page_no_move($label);
		}
		if ($skip_num <> 0) {
	$label = '[→スキップ ('.$skip_num.')]';
			if ($page+$skip_num <= $pagemax) {
				page_move($label, $page+$skip_num, $parm);
			} else {
				page_no_move($label);
			}
		}
	$label = '[→最後]';
		if ($page < $pagemax) {
			page_move($label, $pagemax, $parm);
		} else {
			page_no_move($label);
		}
?>
</span>
</div>
<?php
}
function page_move($label, $move_page, $parm) {
?>
	<span><a href="javascript:void(0);" onClick="javascript:page_move(<?= $move_page ?>);"><?= $label ?></a></span>
<?php
}
function page_no_move($label) {
?>
	<span class="link_off"><?= $label ?></span>
<?php
}
function get_width_height($img_file, &$width, &$height) {	// UTF-8
	$resize_SJIS = myfile_ENCODE(resize_filename($img_file, photo_RESIZE_DIR_SMALL));
	if (file_exists($resize_SJIS)) {
		list($width, $height) = getimagesize($resize_SJIS);
	} else {
		list($width, $height) = getimagesize(myfile_ENCODE($img_file));
	}
}
function resize_filename($img_file, $dir) {			// UTF-8
	$resize_dir = up_folder_path($img_file).$dir;
	return ($resize_dir.basename($img_file));
}
function video_thumb_ss_file($open_path, $vss = false) {		// UTF-8
	$thumb_dir = $open_path.photo_RESIZE_DIR_THUMB;
	if (!@opendir(myfile_ENCODE($thumb_dir))) {
		@mkdir(myfile_ENCODE($thumb_dir));
	}
	$vss_file = $thumb_dir.VIDEO_PREVIEW_START_SEC_FILE;
	$vss_file_SJIS = myfile_ENCODE($vss_file);
	if ($vss.'' <> '') {
		$fp = @fopen($vss_file_SJIS, 'w');
		@fwrite($fp, 'vss='.$vss);
		@fclose($fp);
		return $vss.'';
	} elseif (($contents = @file_get_contents($vss_file_SJIS))) {
		return substr($contents,4);
	} else {
		$fp = @fopen($vss_file_SJIS, 'w');
		@fwrite($fp, 'vss='.$_SESSION['video_thumb_ss']);
		@fclose($fp);
		return $_SESSION['video_thumb_ss'];
	}
}
function get_target_path_info($open_path) {
	if (!myfile_is_dir($open_path)) {
		echo '<br>***　フォルダー [ '.$open_path.' ] が見つかりません。 ***<br><br>';
		return;
	}
	get_up_folder_subdir($open_path);
	$path_SJIS = myfile_ENCODE($open_path);
	if (isset($_SESSION['photo'])) {
		unset($_SESSION['photo']);
	}
	if (isset($_SESSION['photo_subdir'])) {
		unset($_SESSION['photo_subdir']);
		unset($_SESSION['photo_subdir_img1']);
	}
	$_SESSION['photo'] = array();
	$_SESSION['photo_subdir'] = array();
	$_SESSION['photo_subdir_img1'] = array();
	if ($dir = opendir($path_SJIS)) {
		$files = scandir($path_SJIS);
		natcasesort($files);
		$order = 0;
		foreach ($files as $file) {
			if ($file != '.' && $file != '..' && $file != PRIVATE_DIR_1 && $file != PRIVATE_DIR_2 && $file != PRIVATE_DIR_3 && $file != PRIVATE_DIR_4) {
				if (is_dir($path_SJIS.'/'.$file)) {
					$_SESSION['photo_subdir'][] = myfile_DECODE($file);
					if (photo_FOLDER_IMAGE_VIEW <> 'NO') {
						$_SESSION['photo_subdir_img1'][] = subdir_img1file($path_SJIS, $file);
					}
				} elseif (is_img_filename($file)) {
					$_SESSION['photo'][] = array(
						'file'=>myfile_DECODE($file),
						'file_low'=>mb_strtolower(myfile_DECODE($file)),
						'type'=>'img',
						'time'=>filemtime($path_SJIS.'/'.$file),
						'name_order'=>++$order);
				} else {
					if (photo_VIDEO_FFMPEG == "YES") {
						if (is_video_filename($file)) {
							$_SESSION['photo'][] = array(
								'file'=>myfile_DECODE($file),
								'file_low'=>mb_strtolower(myfile_DECODE($file)),
								'type'=>'video',
								'time'=>filemtime($path_SJIS.'/'.$file),
								'name_order'=>++$order);
						}
					}
				}
			}
		}
		closedir($dir);
	//	sort_folder_name_lower('photo_subdir');
		sort_order_change();
		$_SESSION['photo_img_count'] = count($_SESSION['photo']);
	} else {
		$_SESSION['photo_img_count'] = 0;
	}
}
function subdir_img1file($path_SJIS, $dir_SJIS) {
	$open_SJIS = $path_SJIS.'/'.$dir_SJIS;
	$dir = opendir($open_SJIS);
	while (($file = readdir($dir)) !== false) {
		if ($file != "." && $file != "..") {
			if (!is_dir($open_SJIS."/".$file)) {
				if (is_img_filename($file)) {
					return array(
						'dir'=>myfile_DECODE($dir_SJIS),
						'file'=>myfile_DECODE($file),
						'type'=>'img');
				} else {
					if (photo_VIDEO_FFMPEG == "YES") {
						if (is_video_filename($file)) {
							return array(
								'dir'=>myfile_DECODE($dir_SJIS),
								'file'=>myfile_DECODE($file),
								'type'=>'video');
						}
					}
				}
			}
		}
	}
	return array(
		'dir'=>myfile_DECODE($dir_SJIS),
		'file'=>NULL,
		'type'=>'none');
}
function sort_order_change() {
	if ($_SESSION['photo_view_sort_order'] == 'desc') {
		$sort_order = SORT_DESC;
	} else {
		$sort_order = SORT_ASC;
	}
	if ($_SESSION['photo_view_sort'] == 'time') {
		$time = array();
		foreach ($_SESSION['photo'] as $photo) $time[] = $photo['time'];
		array_multisort($time, $sort_order, SORT_NUMERIC, $_SESSION['photo']);
	} else {
		// array_multisort()で日本語の順番が乱れる対策としてnatcasesort()の順番を使う
		$name_order = array();
		foreach ($_SESSION['photo'] as $photo) $name_order[] = $photo['name_order'];
		array_multisort($name_order, $sort_order, SORT_NUMERIC, $_SESSION['photo']);
	}
}
function sort_folder_name_lower($folder_name) {
	// array_map('mb_strtolower',)とarray_multisort()の組み合わせでは日本語の順番が乱れるため、この関数は未使用。
	$folders_lowercase = array_map('mb_strtolower', $_SESSION[$folder_name]);
	array_multisort($folders_lowercase, SORT_ASC, SORT_STRING, $_SESSION[$folder_name]);
}
function get_up_folder_subdir($open_path) {
	if (!strstr($open_path,'/')) {
		return;
	}
	if (isset($_SESSION['up_folder_subdir'])) {
		unset($_SESSION['up_folder_subdir']);
	}
	$up_path = up_folder_path($open_path);
	$path_SJIS = myfile_ENCODE($up_path);
	if ($dir = opendir($path_SJIS)) {
		$subdir_count = 0;
		$_SESSION['up_folder_subdir'] = array();
		$files = scandir($path_SJIS);
		natcasesort($files);
		foreach ($files as $file) {
			if ($file != '.' && $file != '..' && $file != PRIVATE_DIR_1 && $file != PRIVATE_DIR_2 && $file != PRIVATE_DIR_3 && $file != PRIVATE_DIR_4) {
				if (is_dir($path_SJIS.'/'.$file)) {
					$_SESSION['up_folder_subdir'][] = myfile_DECODE($file);
				}
			}
		}
		closedir($dir);
	//	sort_folder_name_lower('up_folder_subdir');
	}
}
?>
<?php
function change_view_chgopt($view_mode, $open_path, $page) {
	if ($view_mode == 's') {
		$s_p = $page;
		$t_p = floor(($page - 1) / $_SESSION['photo_imgmax']) + 1;
	} else {
		$t_p = $page;
		$s_p = ($page - 1) * $_SESSION['photo_imgmax'] + 1;
	}
?>
	<input type="radio" name="mode_chg" class="mode_chg" id="mode_chg_t" onClick="RadioViewMode('t', '<?= $t_p ?>')"<?= $view_mode == 't' ? ' checked' : '' ?>><label for="mode_chg_t">サムネイル</label>
	<input type="radio" name="mode_chg" class="mode_chg" id="mode_chg_b" onClick="RadioViewMode('b', '<?= $t_p ?>')"<?= $view_mode == 'b' ? ' checked' : '' ?>><label for="mode_chg_b">サムネイル(B)</label>
	<input type="radio" name="mode_chg" class="mode_chg" id="mode_chg_s" onClick="RadioViewMode('s', '<?= $s_p ?>')"<?= $view_mode == 's' ? ' checked' : '' ?>><label for="mode_chg_s">スライド</label>
<?php
	$current_folder = substr($open_path,strrpos($open_path,'/')+1);
	$first = $_SESSION['up_folder_subdir'][0];
	$last = end($_SESSION['up_folder_subdir']);
	foreach ($_SESSION['up_folder_subdir'] as $subdir) {
		if ($found) {
			$next = $subdir;
			break;
		}
		if ($subdir == $current_folder) {
			$found = true;
		} else {
			$prev = $subdir;
		}
	}
	$up_path = up_folder_path($open_path);
?>
	<span id="folder_move_box">
	<span class="folder_move">
	<?php if ($first.'' <> '' && $first.'' <> $current_folder) { ?>
		<a href="javascript:void(0);" onClick="javascript:ajax_view_dir_photo('path','<?= escape_squote($up_path.'/'.$first) ?>');">|←</a>
	<?php } else { ?>
		<span class="folder_move_none">|←</span>
	<?php } ?>
	</span>
	<span class="folder_move">
	<?php if ($prev.'' <> '') { ?>
		<a href="javascript:void(0);" onClick="javascript:ajax_view_dir_photo('path','<?= escape_squote($up_path.'/'.$prev) ?>');">←</a>
	<?php } else { ?>
		<span class="folder_move_none">←</span>
	<?php } ?>
	</span>
	<span class="folder_move">
	<?php if ($next.'' <> '') { ?>
		<a href="javascript:void(0);" onClick="javascript:ajax_view_dir_photo('path','<?= escape_squote($up_path.'/'.$next) ?>');">→</a>
	<?php } else { ?>
		<span class="folder_move_none">→</span>
	<?php } ?>
	</span>
	<span class="folder_move">
	<?php if ($last.'' <> '' && $last.'' <> $current_folder) { ?>
		<a href="javascript:void(0);" onClick="javascript:ajax_view_dir_photo('path','<?= escape_squote($up_path.'/'.$last) ?>');">→|</a>
	<?php } else { ?>
		<span class="folder_move_none">→|</span>
	<?php } ?>
	</span>
	</span>
<?php
	if (!defined("photo_FOLDER_MOVE_BY_KEYBOARD")) {
		define("photo_FOLDER_MOVE_BY_KEYBOARD", '');
	}
?>
<?php if (photo_FOLDER_MOVE_BY_KEYBOARD <> 'NO') { ?>
<script>
document.onkeydown = keyPress;
function keyPress( e ) {
	e = e || window.event;
	// alert( "キーコード：" + e.keyCode );
	<?php if ($page > 1) { ?>
		if (e.keyCode == 37) {			// ← : ページ移動(前)
			//ajax_view_dir_photo('path','<?= escape_squote($up_path.'/'.$prev) ?>');
			page_move(<?= $page-1 ?>);
			return false;
		}
	<?php } ?>
	<?php
		if ($_SESSION['photo_view_mode'] == 's') {
			$page_max = $_SESSION['photo_img_count'];
		} else {
			$page_max = ceil($_SESSION['photo_img_count'] / $_SESSION['photo_imgmax']);
		}
	?>
	<?php if ($page < $page_max) { ?>
		if (e.keyCode == 39) {			// → : ページ移動(次)
			page_move(<?= $page+1 ?>);
			return false;
		}
	<?php } ?>
	<?php if ($next.'' <> '') { ?>
		if (e.keyCode == 9) {			// Tab : フォルダ移動(次)
			ajax_view_dir_photo('path','<?= escape_squote($up_path.'/'.$next) ?>');
			return false;
		}
	<?php } ?>
	<?php if ($prev.'' <> '') { ?>
		if (e.keyCode == 240) {			// Caps Lock : フォルダ移動(前)
			ajax_view_dir_photo('path','<?= escape_squote($up_path.'/'.$prev) ?>');
			return false;
		}
	<?php } ?>
	<?php	if ($_SESSION['photo_view_mode'] <> 's') { ?>
		if (e.keyCode == 109) {			// 10キー[-] : サムネイル画像サイズ小さく
			resizeImage(-<?= UPDOWN_SIZE ?>);
			return false;
		}
		if (e.keyCode == 107) {			// 10キー[+] : サムネイル画像サイズ大きく
			resizeImage(<?= UPDOWN_SIZE ?>);
			return false;
		}
	<?php	} ?>
	<?php
		if (!defined("photo_MODE_CHANGE_BY_KEYBOARD")) {
			define("photo_MODE_CHANGE_BY_KEYBOARD", '');
		}
	?>
	<?php if (photo_MODE_CHANGE_BY_KEYBOARD <> 'NO') { ?>
	<?php
		if ($_SESSION['photo_view_mode'] == 's') {
			$s_p = $_SESSION['photo_page'];
			$t_p = floor(($_SESSION['photo_page'] - 1) / $_SESSION['photo_imgmax']) + 1;
		} else {
			$t_p = $_SESSION['photo_page'];
			$s_p = ($_SESSION['photo_page'] - 1) * $_SESSION['photo_imgmax'] + 1;
		}
	?>
		if (e.keyCode == 65) {			// A
			RadioViewMode('t', '<?= $t_p ?>');
		}
		if (e.keyCode == 66) {			// B
			RadioViewMode('b', '<?= $t_p ?>');
		}
		if (e.keyCode == 83) {			// S
			RadioViewMode('s', '<?= $s_p ?>');
		}
		if (e.keyCode == 32) {			// [Space]
			location.href='slide.php?path=<?= urlencode($open_path) ?>&page=<?= $s_p ?>';
		}
	<?php	} ?>
	return true;		// その他 (ファンクションキーなどを有効にするため)
}
</script>
<?php } ?>
<?php
}
function change_view_header($view_mode, $open_path, $page) {
	if ($view_mode == 's') {
		$s_p = $page;
		$t_p = floor(($page - 1) / $_SESSION['photo_imgmax']) + 1;
	} else {
		$t_p = $page;
		$s_p = ($page - 1) * $_SESSION['photo_imgmax'] + 1;
	}
?>
	<a href="slide.php?path=<?= urlencode($open_path) ?>&page=<?= $s_p ?>" style="margin: 0 2px;">全画面</a>
	<a href="slide.php?path=<?= urlencode($open_path) ?>&page=<?= $s_p ?>&slidemode=ajax" style="margin: 0 2px;">全画面(Ajax)</a>
	<a href="slide.php?path=<?= urlencode($open_path) ?>&page=<?= $s_p ?>&slidemode=wallpaper" style="margin: 0 2px;">壁紙</a>
	<a href="gallery1.php" style="margin: 0 2px;">ギャラリ1</a>
	<a href="gallery2.php" style="margin: 0 2px;">ギャラリ2</a>
	<a href="gallery3.php" style="margin: 0 2px;">ギャラリ3</a>
	<a href="gallery4.php" style="margin: 0 2px;">ギャラリ4</a>
	<a href="gallery5.php" style="margin: 0 2px;">ギャラリ5</a>
	<a href="gallery6.php" style="margin: 0 2px;">ギャラリ6</a>
<?php
	if (photo_GALLERY_99_USE == 'YES' and photo_JPEG_RESIZE == 'YES' and defined("photo_GALLERY_99_TEMP_DIR") and photo_GALLERY_99_TEMP_DIR.'' <> '') {
?>
	<a href="gallery99.php?page=<?= $s_p - 1 ?>&idxp=<?= $page ?>" style="margin: 0 2px;">ギャラリ99</a>
<?php
	}
	if ($_SESSION['システム管理者'] == "YES") {
		if (photo_JPEG_RESIZE == 'YES') {
	?>
	<a href="img-resize.php?path=<?= urlencode($open_path) ?>" target="_blank" style="margin: 0 2px;">画像一括縮小</a>
	<?php
		}
		if (photo_VIDEO_FFMPEG == 'YES') {
	?>
	<a href="video-convert.php?path=<?= urlencode($open_path) ?>" target="_blank" style="margin: 0 2px;">動画一括変換</a>
	<?php
		}
	}
	if (photo_IMAGEMAGIC == 'YES' and ($_SESSION['システム管理者'] == 'YES' or photo_IMAGEMAGIC_ALLUSER == 'YES')) {
	?>
	<a href="img-convert.php?path=<?= urlencode($open_path) ?>&page=<?= $page ?>" target="_blank" style="margin: 0 2px;">画像処理</a>
	<?php
	}
	if ($_SESSION['システム管理者'] == "YES") {
	?>
	<a href="../tools/file-manager.php?path=<?= urlencode($open_path) ?>" target="_blank" style="margin: 0 2px;">ファイルマネージャ</a>
	<?php
	}
?>
	<br>
<?php
}
?>
