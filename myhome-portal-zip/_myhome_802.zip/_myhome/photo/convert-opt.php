<?php
	require("__include-common.php");
	require("../account/__logincheck.php");
	require("../__common__/include-common-mp-list.php");
	if ($_SESSION['システム管理者'] <> "YES") {
		error_exit("不正アクセス：編集権限がありません。", True);
	}
	$mp_list_arg = array();
	$mp_list_arg['account_id']	= "ALL";		// 共通
	$mp_list_arg['table_name_view']	= "m_convert_opt";
	$mp_list_arg['table_name_edit']	= "m_convert_opt";
	$mp_list_arg['id_item']		= "id_opt";
	$mp_list_arg['must_item']	= "c_name";
	$mp_list_arg['input_new']	= "no";
	$mp_list_arg['list_filter']	= "no";

	$item_tbl = array();
	$item_tbl[] = array(	"表示名"=>"画像処理名", "列名"=>"c_name",
				"type"=>"text", "size"=>20, "ime-mode"=>"active");
	$item_tbl[] = array(	"表示名"=>"コマンドオプション", "列名"=>"c_option",
				"type"=>"text", "size"=>100, "ime-mode"=>"disabled");
	$item_tbl[] = array(	"表示名"=>"表示順", "列名"=>"c_displayOrder",
				"type"=>"text", "size"=>5, "ime-mode"=>"disabled", "toInt"=>"Y");

	$order_tbl = array();
	$order_tbl[] = array(	"表示名"=>"表示順", "get_order_name"=>"view",
				"order_by"=>"c_displayOrder asc");		/* default */
	$order_tbl[] = array(	"表示名"=>"オプション名順", "get_order_name"=>"name",
				"order_by"=>"c_name asc");

	$http_arg = array();
	$http_arg['pl'] = PAGE_LINE_DEFAULT;		// mp_list 必須
	$http_arg['sort'] = '';				// mp_list 必須
	$http_arg['cat'] = '';				// mp_list 必須
	$http_arg['key'] = '';				// mp_list 必須

	if (isset($_POST['登録'])) {
		check_post_account($_POST['login_id'], $_POST['current_id']);
		mp_list_update($mp_list_arg, $item_tbl, $order_tbl, $http_arg);
	} else {
		_GET_to_http_arg_pool($http_arg, $table_name);
		html_header(HTML_TITLE, '', '', '', '', '__html-my-header-convert-opt.php');
		page_header();
		contents_header();
		if ($_GET['edit'] == "y") {
			mp_list_edit($mp_list_arg, $item_tbl, $order_tbl, $http_arg);
		} else {
			mp_list_view($mp_list_arg, $item_tbl, $order_tbl, $http_arg);
		}
		page_footer();
		html_footer();
	}
	exit();
