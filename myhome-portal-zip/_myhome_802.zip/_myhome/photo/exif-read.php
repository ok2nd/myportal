<?php
	require("../__common__/__define_common.php");
	require("__define.php");
	require("../__common__/include-common-all.php");
	require("../__common__/include-common-html.php");
	require("../account/__logincheck.php");
	if ($_SESSION['システム管理者'] <> "YES") {
		exit;
	}
?>
<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="utf-8">
<meta name="author" content="ok.2nd">
<title>JPEG: EXIF情報</title>
<link rel="stylesheet" href="<?= _STYLE_SHEET_FOLDER ?>/tools_common.css?20120406">
<style>
#filename {
	color: #0000ff;
}
#exif p {
	line-height: 1.0;
	border-bottom: 1px solid #ffc080;
}
</style>
</head>
<body>
<?php
	if (($file = my_GET('path')) == '') {
		error_exit('パス指定がありません。');
	}
	echo '<h4>ファイル：<span id="filename">'.$file.'</span></h4>';
	$exif = @exif_read_data(myfile_ENCODE($file));
	if (!$exif) {
		error_exit('EXIF情報がありません。');
	}
	$ort = $exif['Orientation'];
	if (!$ort) {
		echo 'Orientation情報はありません。<br><br>';
	} else {
		echo 'Orientation = <b>'.$ort.'</b> : '.exif_ort_impli($ort).'<br>';
		// echo '<img src="image/exiforientation.jpg"><br>';
		// by http://www.nikep.net/srdpty/index.php?/archives/24-unknown.html
	}
	if ($exif['GPSLatitude'] and $exif['GPSLongitude']) {
		$lat = gps_degree($exif['GPSLatitude'], $exif['GPSLatitudeRef']);
		$lng = gps_degree($exif['GPSLongitude'], $exif['GPSLongitudeRef']);
		if ($lat and $lng) {
			$photo_url = urlencode('http://'.$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF']).'/img-view.php?img='.$_GET['path']);
			echo '<hr>';
			echo '<p><strong>GPS情報：</strong> 緯度＝'.$lat.'、経度＝'.$lng.'</p>';
			echo '<p><a href="http://maps.google.co.jp/maps?q='.$lat.','.$lng.'" target="_blank">Googleマップ</a>';
			echo '<a style="margin-left:10px;" target="_blank" href="../tools/google-maps-earth-v3.php?addr='.$lat.','.$lng;
			echo '&photo='.$photo_url.'">GoogleマップAPI V3</a></p>';
			echo '<hr>';
		}
	}
	echo '<h4>《EXIF 全データ》</h4>';
	echo '<div id="exif">';
	foreach ($exif as $key=>$value) {
		echo '<p>'.$key.'=';
		if ($key == 'FileDateTime') {
			echo date('Y/m/d H:i:s', $value);
		} elseif ($key <> 'MakerNote') {
			if (is_array($value)) {
				echo '(<br>';
				foreach ($value as $k2=>$v2) {
					echo my_encode_UTF8($k2).'='.my_encode_UTF8($v2).'<br>';
				}
				echo ')';
			} else {
				echo my_encode_UTF8($value);
			}
		}
		echo '</p>';
	}
function my_encode_UTF8($str) {
	return mb_convert_encoding($str, 'UTF-8', MB_CONVERT_ENCODING_AUTO);
}
function gps_degree($gps, $ref) {
	if (count($gps) != 3) return false;
	if ($ref == 'S' or $ref == 'W') {
		$pm = -1;
	} else {
		$pm = 1;
	}
	$degree = fraction2number($gps[0])*1;
	$minute = fraction2number($gps[1])*1;
	$second = fraction2number($gps[2])/100;
	return ($degree + $minute/60 + $second/3600) * $pm;
}
function fraction2number($value) {
	$fraction = explode('/', $value);
	if (count($fraction) != 2) return 0;
	return (double)$fraction[0] / (double)$fraction[1];
}
function exif_ort_impli($ort) {
	$ort_impli = array(
		1 => 'nothing',
		2 => 'horizontal flip',
		3 => '180 rotate left',
		4 => 'vertical flip',
		5 => 'vertical flip + 90 rotate right',
		6 => '90 rotate right',
		7 => 'horizontal flip + 90 rotate right',
		8 => '90 rotate left'
		);
	return $ort_impli[$ort];
/*
	$ort	0th　Row	0th Column
	1	top		left side
	2	top		right side
	3	bottom		right side
	4	bottom		left side
	5	left		side top
	6	right		side top
	7	right		side bottom
	8	left		side bottom
	switch($ort) {
		case 1: // nothing
		break;
		case 2: // horizontal flip
			$image->flipImage($public,1);
		break;
		case 3: // 180 rotate left
			$image->rotateImage($public,180);
		break;
		case 4: // vertical flip
			$image->flipImage($public,2);
		break;
		case 5: // vertical flip + 90 rotate right
			$image->flipImage($public, 2);
			$image->rotateImage($public, -90);
		break;
		case 6: // 90 rotate right
			$image->rotateImage($public, -90);
		break;
		case 7: // horizontal flip + 90 rotate right
			$image->flipImage($public,1);	
			$image->rotateImage($public, -90);
		break;
		case 8:	// 90 rotate left
			$image->rotateImage($public, 90);
		break;
	}
*/
}
?>
