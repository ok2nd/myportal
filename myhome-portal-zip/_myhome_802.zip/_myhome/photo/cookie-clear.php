<?php	// cookie 削除 (現在の時間より前を指定)
	setcookie('slide_interval_time', '', time() - 42000);
	setcookie('slide_interval_time', '', time() - 42000, '/');
	setcookie('slide_interval_time', '', time() - 42000, '/_myhome/');
?>
<!DOCTYPE html>
<html lang="ja">
<meta charset="utf-8">
<head>
<title>cookie 削除</title>
</head>
<body>
<div style="margin:20px;">
cookie("slide_interval_time") 削除しました。
</div>
</body>
</html>
