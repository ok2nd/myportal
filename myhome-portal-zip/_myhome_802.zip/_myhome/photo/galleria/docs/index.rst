.. _index:

======================
Galleria Documentation
======================

.. rubric:: Everything you need to know about Galleria.

Contents
========

* :ref:`getting_started`
* :ref:`options`
* :ref:`flickr`
* :ref:`dom`
