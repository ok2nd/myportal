<?php
	require("__include-common.php");
	require("../account/__logincheck.php");
	require("../__common__/include-common-mp-list.php");
	require("_include-list-data.php");

	$table_name_view = "v_homepage";
	$table_name = "m_homepage";
	$id_item = "id_homepage";
	$must_item = "c_title";

	$mp_list_arg = array();
	$mp_list_arg['account_id']	= $_SESSION['current_id'];
	$mp_list_arg['table_name_view']		= "v_homepage";
	$mp_list_arg['table_name_edit']		= "v_homepage";
	$mp_list_arg['table_name_update']	= "m_homepage";
	$mp_list_arg['id_item']		= "id_homepage";
	$mp_list_arg['must_item']	= "c_title";
	$mp_list_arg['input_new']	= "";
	$mp_list_arg['use_privacy']	= "yes";
	$mp_list_arg['add_list']	= "yes";
	$mp_list_arg['list_option_callback']	= "my_option_filter";

	if ($_COOKIE['index_thumbnail'].'' == 'on') {
		$mp_list_arg['template_view']	= "list-my-template-thumbnail.php";
	} else {
		$mp_list_arg['template_view']	= "list-my-template.php";
	}
	$item_tbl = array();
	$item_tbl[] = array(	"表示名"=>"カテゴリ",	"列名"=>"id_category", "http_arg_GET名"=>"cat",
				"type"=>"select", "参照テーブル"=>"m_category", "参照テーブル表示列"=>"c_categoryName",
				"参照テーブル表示順"=>"c_categoryDisplayColumn, c_categoryDisplayOrder", "参照テーブル表示色"=>"c_categoryDisplayColor");
	$item_tbl[] = array(	"表示名"=>"タイトル",	"列名"=>"c_title",
				"type"=>"text", "size"=>30, "ime-mode"=>"active", "文字検索"=>"Y");
	$item_tbl[] = array(	"表示名"=>"URL(URI)",	"列名"=>"c_url",
				"type"=>"text", "size"=>50, "ime-mode"=>"inactive", "a_tag"=>"Y");
	$item_tbl[] = array(	"表示名"=>"表示順",	"列名"=>"c_displayOrder",
				"type"=>"text", "size"=>5, "ime-mode"=>"disabled", "toInt"=>"Y");
	$item_tbl[] = array(	"表示名"=>"HTML(ブログパーツ)",	"列名"=>"c_html",
				"type"=>"textarea", "cols"=>50, "rows"=>3, "htmlScript"=>"Y");
	$order_tbl = array();
	$order_tbl[] = array(   "表示名"=>"表示順", "get_order_name"=>"cat",
				"order_by"=>"c_categoryDisplayColumn asc, c_categoryDisplayOrder, c_displayOrder, id_category, c_title");		/* default */
	$order_tbl[] = array(   "表示名"=>"タイトル順", "get_order_name"=>"title",
				"order_by"=>"c_title asc");
	$order_tbl[] = array(   "表示名"=>"最新順", "get_order_name"=>"new",
				"order_by"=>"id_homepage desc");

	$http_arg = array();
	$http_arg['pl'] = PAGE_LINE_DEFAULT;		// mp_list 必須
	$http_arg['sort'] = '';				// mp_list 必須
	$http_arg['cat'] = '';				// mp_list 必須
	$http_arg['key'] = '';				// mp_list 必須
	$http_arg['cid'] = '';

	if (isset($_POST['登録'])) {
		check_post_account($_POST['login_id'], $_POST['current_id']);
		mp_list_update($mp_list_arg, $item_tbl, $order_tbl, $http_arg);
	} else {
		_GET_to_http_arg_pool($http_arg, $table_name, 'sort,key,pl');
		html_header(HTML_TITLE);
		page_header();
		contents_header();
		if ($_GET['edit'] == "a") {
			$mp_list_arg['sql_for_edit'] = "select * from v_homepage where id_homepage = 0";
			mp_list_edit($mp_list_arg, $item_tbl, $order_tbl, $http_arg);
		} else if ($_GET['edit'] == "y") {
			mp_list_edit($mp_list_arg, $item_tbl, $order_tbl, $http_arg);
		} else {
			mp_list_view($mp_list_arg, $item_tbl, $order_tbl, $http_arg);
			popup_edit();
		}
		page_footer();
		html_footer();
	}
	exit();
// ****************************************************************
function popup_edit() {
?>
<script>
function popup_edit(id) {
	w01 = window.open("edit.php?id="+id,"","toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes,width=630,height=300");
}
function popup_delete(id, title) {
	if (window.confirm('「'+title+'」を削除しますか？')) {
		$.ajax({
			type: "GET",
			url: "delete.php?id="+id,
			async: false,
			success: function(res){
				$('#tb_'+id).html(res);
			}
		});
	}
}
</script>
<?php
}
// ****************************************************************
function my_option_filter($http_arg) {
?>
<script>
function CheckboxThumbnail(onOff) {
	if (onOff == 'on') {
		$.cookie("index_thumbnail","",{ path:'<?= MY_SESSION_PATH ?>', expires:365 });
	} else {
		$.cookie("index_thumbnail","on",{ path:'<?= MY_SESSION_PATH ?>', expires:365 });
	}
	window.location.href = "?<?= query_from_http_arg_pool($http_arg) ?>";
}
function ListCaptureOnOff(chk){
	if (chk.checked == true) {
		$.cookie("index_list_capture","none",{ path:'<?= MY_SESSION_PATH ?>', expires:365 });
	} else {
		$.cookie("index_list_capture","",{ path:'<?= MY_SESSION_PATH ?>', expires:365 });
	}
	window.location.href = "?<?= query_from_http_arg_pool($http_arg) ?>";
}
</script>
<?php
?>
	<label><input type="checkbox" value="on" onClick="CheckboxThumbnail('<?= $_COOKIE['index_thumbnail'] ?>')"<?= $_COOKIE['index_thumbnail'] == 'on' ? ' checked' : '' ?>>サムネイル</label>
<?php if ($_COOKIE['index_thumbnail'] <> 'on') { ?>
	<label><input type="checkbox" onClick="ListCaptureOnOff(this)"<?= $_COOKIE['index_list_capture'] == 'none' ? ' checked' : '' ?>>キャプチャ非表示</label>
<?php	} ?>
<?php
}
?>
