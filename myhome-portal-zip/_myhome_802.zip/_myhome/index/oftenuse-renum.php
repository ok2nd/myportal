<?php
	require("__include-common.php");
	require("../account/__logincheck.php");
	if (check_permit_id($_SESSION['login_id'], $_SESSION['current_id']) != "w") {
		error_exit("不正アクセス：書き込み権限がありません。", True);
	}
	if ($_GET['ids'].'' == '') {
		return;
	}
	$con = my_mysqli_connect(_DB_SCHEMA);
	$ids = explode(',', $_GET['ids']);
	$order = 100;
	$cnt = 0;
	foreach ($ids as $id) {
		if (++$cnt == 7) {
			$order += 50;
			$cnt = 1;
		} else {
			$order += 10;
		}
		$sql = "update m_oftenuse set";
		$sql .= " c_displayOrder = '".$order."'";
		$sql .= " where id_oftenuse = ".intval($id);
		$sql .= " and id_account = ".$_SESSION['current_id'];
		$ret = my_mysqli_query($sql, "修正できませんでした。");
	}
	mysqli_close($con);
	redirect('oftenuse.php');
?>
