<script>
function wopen(url) {
	if (loadCookie("index_jump_targettype") == "_blank") {
		w01 = window.open(url,"","");				// 新しいウインドウで開く
	} else {
		top.location.href = url;
	}
}
function sp2han(str) {
	return(str.replace(/　/g, ' '));
}
function sp2plus(str) {
	return(str.replace(/ /g, '+').replace(/　/g, '+'));
}
function sp2comma(str) {
	return(str.replace(/ /g, ',').replace(/　/g, ','));
}
function MyIndexSch() {
	url = "list.php?key=";
	url += encodeURL(sp2han(document.getElementById('search_str').value));
	top.location.href = url;
}
function MyMemoSch() {
	url = "../memo/list.php?key=";
	url += encodeURL(sp2han(document.getElementById('search_str').value));
	top.location.href = url;
}
function MyCalendarSch() {
	url = "../calendar/list.php?key=";
	url += encodeURL(sp2han(document.getElementById('search_str').value));
	top.location.href = url;
}
function GoogleSch() {
	url = "http://www.google.com/search?q=";
	url += encodeURL(sp2han(document.getElementById('search_str').value));
	wopen(url);
}
function YahooSch() {
	url = "http://search.yahoo.co.jp/search?p=";
	url += encodeURL(sp2han(document.getElementById('search_str').value));
	wopen(url);
}
function BaiduSch() {
	url = "http://www.baidu.jp/s?tn=baidujp&ie=utf-8&wd=";
	url += encodeURL(sp2han(document.getElementById('search_str').value));
	wopen(url);
}
function NaverMatomeSch() {
	url = "http://matome.naver.jp/search?q=";
	url += encodeURL(sp2han(document.getElementById('search_str').value));
	wopen(url);
}
function BingSch() {
	url = "http://www.bing.com/search?q=";
	url += encodeURL(sp2han(document.getElementById('search_str').value));
	wopen(url);
}
function FresheyeSch() {
	url = "http://kotochu.fresheye.com/search/?kw=";
	url += encodeURL(sp2han(document.getElementById('search_str').value));
	wopen(url);
}
function MarsSch() {
	url = "http://www.marsflag.com/search.x?phrase=";
	url += encodeURL(sp2han(document.getElementById('search_str').value));
	wopen(url);
}
function GoogleBooksSch() {
	url = "https://www.google.co.jp/search?hl=ja&tbo=p&tbm=bks&gws_rd=cr,ssl&q=";
	url += encodeURL(sp2han(document.getElementById('search_str').value));
	wopen(url);
}
function NewsSch() {
	url = "http://www.google.com/search?tbm=nws&q=";
	url += encodeURL(sp2han(document.getElementById('search_str').value));
	wopen(url);
}
function NewsSch_OLD() {
	url = "http://news.google.co.jp/news?q=";
	url += encodeURL(sp2han(document.getElementById('search_str').value));
	wopen(url);
}
function TrainTimeSch() {
	url = "http://timetable.ekitan.com/train/TimeSearch?SFNAME=";
	str = document.getElementById('search_str').value;
	if (str != "") {
		url += EscapeSJIS(str);
	} else {
		url += EscapeSJIS("<?= $_SESSION['login_friends_home_station_'.$_SESSION['login_id']] ?>");
	}
	wopen(url);
}
function TrainChangeSch() {
	url = "http://transit.ekitan.com/norikae/NorikaeSearch?SFNAME=";
	saddr = "<?= $_SESSION['login_friends_home_station_'.$_SESSION['login_id']] ?>";
	str = sp2han(document.getElementById('search_str').value);
	key = str.split(" ");
	if (key.length == 2) {
		url += EscapeSJIS(key[0]) + "&STNAME=" + EscapeSJIS(key[1]);
	} else if ((key.length == 1) && (saddr != "")) {
		url += EscapeSJIS(saddr) + "&STNAME=" + EscapeSJIS(key[0]);
	} else {
		window.alert('乗車駅と下車駅をスペースで区切って入れてください。');
		return false;
	}
	wopen(url);
}
function TrainChangeYahoo() {
	url = "http://transit.yahoo.co.jp/search/result";
	saddr = "<?= $_SESSION['login_friends_home_station_'.$_SESSION['login_id']] ?>";
	str = sp2han(document.getElementById('search_str').value);
	key = str.split(" ");
	if (key.length == 2) {
		url += "?from=" + encodeURL(key[0]) + "&to=" + encodeURL(key[1]);
	} else if ((key.length == 1) && (saddr != "")) {
		url += "?from=" + encodeURL(saddr) + "&to=" + encodeURL(key[0]);
	} else {
		window.alert('乗車駅と下車駅をスペースで区切って入れてください。');
		return false;
	}
	wopen(url);
}
function TrainChangeGoogle() {
	url = "http://maps.google.co.jp/maps?ie=UTF8&f=d&ttype=dep&dirflg=r";
	saddr = "<?= $_SESSION['login_friends_home_address_'.$_SESSION['login_id']] ?>";
	str = sp2han(document.getElementById('search_str').value);
	key = str.split(" ");
	if (key.length == 2) {
		url += "&saddr=" + encodeURL(key[0]) + "&daddr=" + encodeURL(key[1]);
	} else if ((key.length == 1) && (saddr != "")) {
		url += "&saddr=" + encodeURL(saddr) + "&daddr=" + encodeURL(key[0]);
	} else {
		window.alert('出発地と目的地をスペースで区切って入れてください。');
		return false;
	}
	wopen(url);
}
function DicAlcSch() {
	url = "http://eow.alc.co.jp/";
	url += encodeURL(sp2han(document.getElementById('search_str').value));
	wopen(url);
}
function DicYahooSch() {
	url = "http://dic.search.yahoo.co.jp/search?ei=UTF-8&p=";
	url += encodeURL(sp2han(document.getElementById('search_str').value));
	wopen(url);
}
function WikipediaSch() {
	url = "http://ja.wikipedia.org/wiki/";
	url += encodeURL(sp2han(document.getElementById('search_str').value));
	wopen(url);
}
function WeblioSch() {
	url = "http://www.weblio.jp/content/";
	url += encodeURL(sp2han(document.getElementById('search_str').value));
	wopen(url);
}
function Yahoo100Sch() {
	url = "http://100.yahoo.co.jp/search?p=";
	url += encodeURL(sp2han(document.getElementById('search_str').value));
	wopen(url);
}
function MapSch() {
	url = "http://maps.google.co.jp/maps?q=";
	url += encodeURL(sp2han(document.getElementById('search_str').value));
	wopen(url);
}
function MyMapSch() {
<?php	if (GOOGLE_MAPS_API_VERSION == 'V3') { ?>
		url = "../tools/google-maps-earth-v3.php?addr=";
<?php	} else { ?>
		url = "../tools/google-maps-earth.php?addr=";
<?php	} ?>
	url += encodeURL(sp2plus(document.getElementById('search_str').value));
	wopen(url);
}
function ZipSch() {
	url = "http://postcode.goo.ne.jp/search/q/";
	url += encodeURL(sp2han(document.getElementById('search_str').value)) + "/";
	wopen(url);
}
function PhoneSch() {
	url = "http://search.loco.yahoo.co.jp/search?p=";
	url += encodeURL(sp2han(document.getElementById('search_str').value));
	wopen(url);
}
function GoogleBlogSch() {
	url = "http://blogsearch.google.com/blogsearch?q=";
	url += encodeURL(sp2han(document.getElementById('search_str').value)) + "&um=1&ie=UTF-8&sa=N&hl=ja&tab=wb";
	wopen(url);
}
function TenkiSch() {
	url = "http://weather.yahoo.co.jp/weather/search/?p=";
	url += encodeURL(sp2han(document.getElementById('search_str').value));
	wopen(url);
}
function CookpadSch() {
	url = "http://cookpad.com/search/";
	url += encodeURL(sp2han(document.getElementById('search_str').value));
	wopen(url);
}
function KikkomanSch() {
	url = "http://www.kikkoman.co.jp/homecook/search/select_search.php?free_word=";
	url += encodeURL(sp2han(document.getElementById('search_str').value));
	wopen(url);
}
function googleRecipeSch() {
	url = "http://www.google.com/search?q=";
	url += encodeURL(sp2han(document.getElementById('search_str').value));
	url += "&tbs=lr:lang_1ja,rcp:1";
	wopen(url);
}
function KakakuSch() {
	url = "http://kakaku.com/search_results/";
	url += EscapeSJIS(sp2han(document.getElementById('search_str').value)) + "/";
	wopen(url);
}
function ShoppingSch() {
	url = "https://www.google.co.jp/search?tbm=shop&q=";
	url += encodeURL(sp2han(document.getElementById('search_str').value)) + "&gws_rd=ssl";
	wopen(url);
}
function RakutenSch() {
	url = "http://search.rakuten.co.jp/search/mall/";
	url += encodeURL(sp2han(document.getElementById('search_str').value)) + "/";
	wopen(url);
}
function AmazonSch() {
	url = "http://www.amazon.co.jp/s/ref=nb_sb_noss?field-keywords=";
	url += encodeURL(sp2han(document.getElementById('search_str').value));
	wopen(url);
}
function YodobashiSch() {
	url = "http://www.yodobashi.com/ec/category/index.html?word=";
	url += encodeURL(sp2han(document.getElementById('search_str').value));
	wopen(url);
}
function YahooShopping() {
	url = "http://search.shopping.yahoo.co.jp/search?p=";
	url += encodeURL(sp2han(document.getElementById('search_str').value));
	wopen(url);
}
function YahooAuctions() {
	url = "http://auctions.search.yahoo.co.jp/search?p=";
	url += encodeURL(sp2han(document.getElementById('search_str').value));
	wopen(url);
}
function YoutubeSch() {
	url = "http://www.youtube.com/results?search_query=";
	url += encodeURL(sp2han(document.getElementById('search_str').value));
	wopen(url);
}
function TwitterSch() {
	url = "https://twitter.com/search?f=realtime&q=";
	url += encodeURL(sp2han(document.getElementById('search_str').value));
	wopen(url);
}
function TwitterGoogle() {
	url = "http://www.google.com/search?tbs=mbl:1&hl=ja&num=100&q=";
	url += encodeURL(sp2han(document.getElementById('search_str').value));
	wopen(url);
}
function YahooRealtimeSch() {
	url = "http://realtime.search.yahoo.co.jp/search?p=";
	url += encodeURL(sp2han(document.getElementById('search_str').value));
	wopen(url);
}
function search_enter(keyCode) {
	if (keyCode === 13) {
		GoogleSch();
	}
}
</script>
<table id="index_search"><tr><td nowrap>
	<div class="search_button_box">
		<a id="suggest_on" class="suggest_onoff" href="javascript:suggest('off');" style="color:#EACC8F;<?= $_SESSION['suggest_on'] ?>">●</a><a id="suggest_off" class="suggest_onoff" href="javascript:suggest('on');" style="color:#EACC8F;<?= $_SESSION['suggest_off'] ?>">○</a><input class="text" type="text" id="search_str" value="<?= $keystring ?>" onkeypress="search_enter(event.keyCode);">
		<input type="button" value="Google" class="btn-yellow" onClick="GoogleSch()">
		<input type="button" value="Yahoo" class="btn-yellow" onClick="YahooSch()">
		<input type="button" value="Bing" class="btn-yellow" onClick="BingSch()">
		<input type="button" value="Fresh" class="btn-yellow" onClick="FresheyeSch()">
		<input type="button" value="まとめ" class="btn-yellow" onClick="NaverMatomeSch()">
	</div>
	<div class="search_button_box">
		<input type="button" value="MyIndex" class="btn-white" onClick="MyIndexSch()">
		<input type="button" value="Myメモ" class="btn-white" onClick="MyMemoSch()"">
		<input type="button" value="Myカレンダー" class="btn-white" onClick="MyCalendarSch()">
		<input type="button" value="ニュース" class="btn-blue" onClick="NewsSch()">
		<input type="button" value="天気" class="btn-blue" onClick="TenkiSch()">
		<input type="button" value="時刻表" class="btn-orange" onClick="TrainTimeSch()">
		<input type="button" value="乗換(駅探)" class="btn-orange" onClick="TrainChangeSch()">
		<input type="button" value="乗換(Yahoo)" class="btn-orange" onClick="TrainChangeYahoo()">
		<input type="button" value="経路(Google)" class="btn-orange" onClick="TrainChangeGoogle()">
	</div>
	<div class="search_button_box">
		<input type="button" value="辞書Alc" class="btn-yellow" onClick="DicAlcSch()">
		<input type="button" value="辞書Yahoo" class="btn-yellow" onClick="DicYahooSch()">
		<input type="button" value="Wikipedia" class="btn-yellow" onClick="WikipediaSch()">
		<input type="button" value="百科Weblio" class="btn-yellow" onClick="WeblioSch()">
		<input type="button" value="書籍" class="btn-yellow" onClick="GoogleBooksSch()">
		<input type="button" value="地図" class="btn-blue" onClick="MapSch()">
		<input type="button" value="●" class="btn-blue" onClick="MyMapSch()">
		<input type="button" value="〒番号" class="btn-yellow" onClick="ZipSch()">
		<input type="button" value="電話帳" class="btn-yellow" onClick="PhoneSch()">
	</div>
	<div class="search_button_box">
		<input type="button" value="料理(ク)" class="btn-pink" onClick="CookpadSch()">
		<input type="button" value="料理(キ)" class="btn-pink" onClick="KikkomanSch()">
		<input type="button" value="価格" class="btn-blue" onClick="KakakuSch()">
		<input type="button" value="Amazon" class="btn-orange" onClick="AmazonSch()">
		<input type="button" value="楽天" class="btn-orange" onClick="RakutenSch()">
		<input type="button" value="ヨドバシ" class="btn-orange" onClick="YodobashiSch()">
		<input type="button" value="ヤフーShop" class="btn-orange" onClick="YahooShopping()">
		<input type="button" value="ヤフオク" class="btn-orange" onClick="YahooAuctions()">
		<input type="button" value="YouTube" class="btn-blue" onClick="YoutubeSch()">
		<input type="button" value="Twitter" class="btn-blue" onClick="TwitterSch()">
		<input type="button" value="リアルタイム" class="btn-blue" onClick="YahooRealtimeSch()">
	</div>
</td></tr></table>
