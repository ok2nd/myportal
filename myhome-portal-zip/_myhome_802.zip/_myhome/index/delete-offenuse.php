<?php
	require("__include-common.php");
	require("../account/__logincheck.php");

	if (check_permit_id($_SESSION['login_id'], $_SESSION['current_id']) != "w") {
		error_exit("不正アクセス：書き込み権限がありません。", True);
	}
	if ($_GET['id'].'' == '') {
		return;
	}
	$id = intval($_GET['id']);
	$con = my_mysqli_connect(_DB_SCHEMA);
	$sql = "update m_oftenuse set";
	$sql .= " c_delete = 999";
	$sql .= ", c_updatetime = '". date("Y/m/d H:i:s") . "'";
	$sql .= " where id_oftenuse = ".$id;
	$sql .= " and id_account = ".$_SESSION['current_id'];
	$ret = my_mysqli_query($sql, "削除できませんでした。");
	mysqli_close($con);
	redirect('oftenuse.php');
?>
