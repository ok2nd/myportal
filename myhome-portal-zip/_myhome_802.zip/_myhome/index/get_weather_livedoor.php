<?php
	$url ="http://weather.livedoor.com/forecast/webservice/rest/v1?city=".$_GET['city']."&day=".$_GET['day'];
	$contents = file_get_contents($url);

	header("Content-type: text/xml");
	header("Cache-Control: no-cache");
	echo $contents;
?>
