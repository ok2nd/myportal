<style>
#mp_list_main input[type=button].google {
	background-image: -moz-linear-gradient(top, #d0d0c0, #d0d0c0);
	background-image: -ms-linear-gradient(top, #d0d0c0, #d0d0c0);
	background-image: -webkit-gradient(linear, 0 0, 0 100%, from(#d0d0c0), to(#d0d0c0));
	background-image: -webkit-linear-gradient(top, #d0d0c0, #d0d0c0);
	background-image: -o-linear-gradient(top, #d0d0c0, #d0d0c0);
	background-image: linear-gradient(top, #d0d0c0, #d0d0c0);
	filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#d0d0c0', endColorstr='#d0d0c0', GradientType=0);
}
#mp_list_main input[type=button].blog {
	background-image: -moz-linear-gradient(top, #e0e0d8, #e0e0d8);
	background-image: -ms-linear-gradient(top, #e0e0d8, #e0e0d8);
	background-image: -webkit-gradient(linear, 0 0, 0 100%, from(#e0e0d8), to(#e0e0d8));
	background-image: -webkit-linear-gradient(top, #e0e0d8, #e0e0d8);
	background-image: -o-linear-gradient(top, #e0e0d8, #e0e0d8);
	background-image: linear-gradient(top, #e0e0d8, #e0e0d8);
	filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#e0e0d8', endColorstr='#e0e0d8', GradientType=0);
}
#mp_list_main input[type=button].realtime {
	background-image: -moz-linear-gradient(top, #f0f0e8, #f0f0e8);
	background-image: -ms-linear-gradient(top, #f0f0e8, #f0f0e8);
	background-image: -webkit-gradient(linear, 0 0, 0 100%, from(#f0f0e8), to(#f0f0e8));
	background-image: -webkit-linear-gradient(top, #f0f0e8, #f0f0e8);
	background-image: -o-linear-gradient(top, #f0f0e8, #f0f0e8);
	background-image: linear-gradient(top, #f0f0e8, #f0f0e8);
	filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#f0f0e8', endColorstr='#f0f0e8', GradientType=0);
}
</style>
<?php
	while ($rec = mysqli_fetch_array($rs)) {
		$keywords = preg_replace('/\s\s+/', ' ', $rec['c_keyword']);
		$keywords = my_htmlspecialchars($keywords);
		if ($rec['id_andor'] == 50) {
			$keywords = str_replace(' ', ' OR ', $keywords);
		}
?>
<style>
#mp_list_main input[type=button].c<?= $rec['id_mynews'] ?> {
	background-image: -moz-linear-gradient(top, <?= $rec['c_button_color'] ?>, <?= $rec['c_button_color'] ?>);
	background-image: -ms-linear-gradient(top, <?= $rec['c_button_color'] ?>, <?= $rec['c_button_color'] ?>);
	background-image: -webkit-gradient(linear, 0 0, 0 100%, from(<?= $rec['c_button_color'] ?>), to(<?= $rec['c_button_color'] ?>));
	background-image: -webkit-linear-gradient(top, <?= $rec['c_button_color'] ?>, <?= $rec['c_button_color'] ?>);
	background-image: -o-linear-gradient(top, <?= $rec['c_button_color'] ?>, <?= $rec['c_button_color'] ?>);
	background-image: linear-gradient(top, <?= $rec['c_button_color'] ?>, <?= $rec['c_button_color'] ?>);
	filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='<?= $rec['c_button_color'] ?>', endColorstr='<?= $rec['c_button_color'] ?>', GradientType=0);
}
</style>
	<p>ニュース検索：<input class="c<?= $rec['id_mynews'] ?>" type="button" value="<?= $keywords ?>" onClick="NewsSch('<?= $keywords ?>')">
	<input type="button" class="google" value="Google" onClick="GoogleSch('<?= $keywords ?>','')">
	<input type="button" class="google" value="Google:24時間" onClick="GoogleSch('<?= $keywords ?>','d')">
	<input type="button" class="google" value="Google:1週間" onClick="GoogleSch('<?= $keywords ?>','w')">
	<input type="button" class="blog" value="ブログ:24時間" onClick="GoogleBlogSch('<?= $keywords ?>','d')">
	<input type="button" class="blog" value="ブログ:1週間" onClick="GoogleBlogSch('<?= $keywords ?>','w')">
	<input type="button" class="realtime" value="Yahoo:リアルタイム" onClick="YahooRealtimeSch('<?= $keywords ?>')">
	</p>
<?php
	}
?>
<script>
function NewsSch(keywords, where) {
	var url = "http://www.google.co.jp/search?tbm=nws&q=";
	if (where == 'title') {
		url += "allintitle: ";
	}
	url += encodeURL(keywords);
	window.open(url,"","");
}
function GoogleSch(keywords, span) {
	var url = "http://www.google.com/search?q=";
	url += encodeURL(keywords);
	url += "&tbs=qdr:" + span;
	window.open(url,"","");
}
function GoogleBlogSch(keywords, span) {
	var url = "http://www.google.com/search?q=";
	url += encodeURL(keywords);
	url += "&tbm=blg&tbs=qdr:" + span;
	window.open(url,"","");
}
function YahooRealtimeSch(keywords) {
	var url = "http://realtime.search.yahoo.co.jp/search?p=";
	url += encodeURL(keywords);
	url += "&ei=UTF-8";
	window.open(url,"","");
}
</script>
