<?php
	require("../__common__/__define_common.php");
	require("../__common__/include-common-all.php");
	require("../tools/__include-common-code-file.php");
	my_session_start();
	require("../account/__logincheck.php");
	if ($_SESSION['システム管理者'] <> "YES") {
		exit;
	}
	if ($_GET['ret'].'' == '') {
		$ret_php = 'list-url.php';
	} else {
		$ret_php = $_GET['ret'];
	}
	if ($_GET['path'].'' == '') {
		error_simple_html('エラー', 'パス指定がありません。');
	}
	if ($_GET['path'] == '.' || $_GET['path'] == '..') {
		error_simple_html('エラー', 'フォルダ名が不正です。');
	}
	$path = my_GET('path');
	$path = right_slash_strip($path);
	if (@delete_folder($path) == False) {
		error_simple_html('フォルダ削除エラー', 'フォルダ削除に失敗しました。');
	}
	header("Location: ".$ret_php."?path=".urlencode(up_folder_path($path)));
function delete_folder($path) {
	if (myfile_is_dir($path) && ($fp = myfile_opendir($path))) {
		while ($file = readdir($fp)) {
			$file = myfile_DECODE($file);
			if ($file == '.' || $file == '..') {
				continue;
			}
			$subpath = $path.'/'.$file;
			if (myfile_is_dir($subpath)) {
				delete_folder($subpath);
			} else {
				myfile_unlink($subpath);
			}
		}
		closedir($fp);
		myfile_rmdir($path);
		return true;
	} else {
		return false;
	}
}
