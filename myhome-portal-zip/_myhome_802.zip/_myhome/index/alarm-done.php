<?php
	require("__include-common.php");
	require("../account/__logincheck.php");
	$con = my_mysqli_connect(_DB_SCHEMA_index);
	$no = intval($_GET['no']);
	$rec = mysqli_fetch_array($rs);
	$sql = "update m_alarm set";
	$sql .= " c_done = '".date('Y-m-d')."'";
	$sql .= " where id_account = ".$_SESSION['login_id']." and id_num = ".$no;
	$ret = my_mysqli_query($sql, "更新できませんでした。");
?>
