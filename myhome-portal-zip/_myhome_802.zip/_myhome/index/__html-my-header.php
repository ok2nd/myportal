<meta charset="utf-8">
<meta name="author" content="ok.2nd">
<meta name="description" content="Index">
<meta name="keywords" content="index">
<link rel="stylesheet" href="<?= _STYLE_SHEET_FOLDER_COMMON ?>/common.css?20131130">
<link rel="stylesheet" href="<?= _STYLE_SHEET_BUTTON ?>">
<link rel="stylesheet" href="<?= _STYLE_SHEET_FOLDER ?>/calendar.css?20141108">
<link rel="stylesheet" href="<?= _STYLE_SHEET_FOLDER ?>/index.css?20140103">
<link rel="stylesheet" href="<?= _STYLE_SHEET_FOLDER ?>/mp-list.css?20130525">
<link rel="stylesheet" href="<?= FONT_ICON_STYLE_SHEET_FOLDER ?>/css/font-awesome.css">
<!--[if IE 7]>
<link rel="stylesheet" href="<?= FONT_ICON_STYLE_SHEET_FOLDER ?>/css/font-awesome-ie7.css">
<![endif]-->
<link rel="stylesheet" href="<?= FONT_ICON_STYLE_SHEET_FOLDER ?>/font-icon.css">
<style>
.day_today_mini {
	background-color: <?= CALENDAR_TODAY_MINI_BACKGROUND_COLOR ?>;
}
.day_today_mini a:link { color: <?= CALENDAR_TODAY_MINI_LINK_COLOR ?>; }
.day_today_mini a:visited { color: <?= CALENDAR_TODAY_MINI_LINK_COLOR ?>; }
.day_today_mini a:hover { color: #ff8c00; }
.day_today_mini a:active { color: #ff6347; }
</style>
<script src="../scripts/ecl_new.js"></script>
<script src="../scripts/jquery.js"></script>
<script src="../scripts/jquery.cookie.js"></script>
<script src="../scripts/ok2nd.js"></script>
