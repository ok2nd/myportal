<?php
//	http://weather.livedoor.com/weather_hacks/webservice.html
//	http://weather.livedoor.com/forecast/rss/forecastmap.xml

	define("WEATHER_MY_CITY_NO", 63);

	$city_tbl = array();
	$city_tbl[] = array("札幌", 4);
	$city_tbl[] = array("青森", 17);
	$city_tbl[] = array("仙台", 25);
	$city_tbl[] = array("新潟", 50);
	$city_tbl[] = array("東京", 63);
	$city_tbl[] = array("名古屋", 38);
	$city_tbl[] = array("大阪", 81);
	$city_tbl[] = array("福岡", 110);
	$city_tbl[] = array("鹿児島", 132);
	$city_tbl[] = array("那覇", 136);
?>
