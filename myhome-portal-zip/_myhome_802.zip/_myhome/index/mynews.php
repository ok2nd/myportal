<?php
	require("__include-common.php");
	require("../account/__logincheck.php");
	require("../__common__/include-common-mp-list.php");

	$mp_list_arg = array();
	$mp_list_arg['account_id']	= $_SESSION['current_id'];
	$mp_list_arg['table_name_view']	= "v_mynews";
	$mp_list_arg['table_name_edit']	= "m_mynews";
	$mp_list_arg['id_item']		= "id_mynews";
	$mp_list_arg['must_item']	= "c_keyword";
	$mp_list_arg['input_new']	= "no";
	$mp_list_arg['list_filter']	= "no";
	$mp_list_arg['add_list']	= "yes";
	$mp_list_arg['template_view']	= "list-my-template-mynews.php";
	$mp_list_arg['list_edit_right_add_html']	= "../__common__/in-block-color-chart-pale.php";

	$item_tbl = array();
	$item_tbl[] = array(	"表示名"=>"キーワード", "列名"=>"c_keyword",
				"背景カラー表示列名"=>"c_button_color",
				"文字表示色"=>"#000000",
				"type"=>"text", "size"=>60, "ime-mode"=>"active", "文字検索"=>"Y");
	$item_tbl[] = array(	"表示名"=>"検索条件", "列名"=>"id_andor", "filter_c_delete"=>"no",
				"type"=>"select", "参照テーブル"=>"r_andor",
				"参照テーブル表示列"=>"c_andor",
				"参照テーブル表示順"=>"id_andor");
	$item_tbl[] = array(	"表示名"=>"ボタンカラー", "列名"=>"c_button_color", "初期値"=>"#FFFFFF",
				"編集bg反映"=>"c_keyword",
				"type"=>"text", "size"=>14, "ime-mode"=>"disabled");
	$item_tbl[] = array(	"表示名"=>"表示順", "列名"=>"c_displayOrder",
				"type"=>"text", "size"=>7, "ime-mode"=>"disabled", "toInt"=>"Y");

	$order_tbl = array();
	$order_tbl[] = array(	"表示名"=>"表示順", "get_order_name"=>"order",
				"order_by"=>"c_displayOrder, c_keyword, id_andor");
	$order_tbl[] = array(	"表示名"=>"キーワード順", "get_order_name"=>"key",
				"order_by"=>"c_keyword, id_andor");
	$order_tbl[] = array(	"表示名"=>"最新順", "get_order_name"=>"new",
				"order_by"=>"id_mynews desc");

	$http_arg = array();
	$http_arg['pl'] = PAGE_LINE_DEFAULT;		// mp_list 必須
	$http_arg['sort'] = '';				// mp_list 必須
	$http_arg['cat'] = '';				// mp_list 必須
	$http_arg['key'] = '';				// mp_list 必須

	if (isset($_POST['登録'])) {
		check_post_account($_POST['login_id'], $_POST['current_id']);
		mp_list_update($mp_list_arg, $item_tbl, $order_tbl, $http_arg);
	} else {
		_GET_to_http_arg_pool($http_arg, '');
		html_header(HTML_TITLE);
		page_header();
		contents_header();
		if ($_GET['edit'] == "a") {
			$mp_list_arg['sql_for_edit'] = "select * from v_mynews where id_mynews = 0";
			mp_list_edit($mp_list_arg, $item_tbl, $order_tbl, $http_arg);
		} elseif ($_GET['edit'] == "y") {
			mp_list_edit($mp_list_arg, $item_tbl, $order_tbl, $http_arg);
		} else {
			mp_list_view($mp_list_arg, $item_tbl, $order_tbl, $http_arg);
		}
		page_footer();
		html_footer();
	}
	exit();
