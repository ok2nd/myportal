<?php
	require("__include-common.php");
	require("../account/__logincheck.php");
	require("_include-list-data.php");

	html_header(HTML_TITLE, '', '', ' onload="document.form0.c_title.focus()"');
	input_form();
	html_footer();
	exit();
function input_form() {
	if ($_GET['id'].'' == '') {
		return;
	}
	$id = intval($_GET['id']);
	$con = my_mysqli_connect(_DB_SCHEMA);
	$sql = "select * from v_homepage where id_homepage = ".$id." and c_delete = 0";
	$sql .= " and id_account = ".$_SESSION['current_id'];
	$rs = my_mysqli_query($sql);
	$rec = mysqli_fetch_array($rs);
?>
<div class="input_form">
<h3><?= $_SESSION['current_handle'] ?><a class="a_cancel_back" href='javascript:window.close();'>キャンセル</a></h3>
<script>
function formCheck(form) {
	if (form.c_title.value == '') {
		window.alert('タイトルを入れてください。');
		return false;		// 送信を中止
	}
	return true;	// 送信を実行
}
$(function(){
	$('#edit_form').submit(function() {
		if ($('#c_title').val() != '') {
			$.ajax({
				type: "POST",
				url: "update.php",
				data: $(this).serialize(),
				async: false,
				success: function(res){
					window.opener.$('#tb_<?= $id ?>').html(res);
					window.close();
				}
			});
		}
		return false;
	});
});
</script>
<form name="form0" id="edit_form" method="POST" onSubmit="return formCheck(this)">
	<input type="hidden" name="user_id" value="<?= $_SESSION['current_id'] ?>">
	<input type="hidden" name="update_id" value="<?= $id ?>">
	<input type="hidden" name="login_id" value="<?= $_SESSION['login_id'] ?>">
	<input type="hidden" name="current_id" value="<?= $_SESSION['current_id'] ?>">
<table>
<tr>
	<td nowrap>カテゴリ</td>
	<td nowrap>
<?php
	$sqlsel = "select * from m_category where id_account = '".$_SESSION['current_id']."'";
	$sqlsel = $sqlsel . " and c_delete = 0";
	$sqlsel = $sqlsel . " order by c_categoryDisplayColumn, c_categoryDisplayOrder";
	$rs_sel = my_mysqli_query($sqlsel);
?>
	<select name="id_category">
<?php
		if ($id == 0) {
			$category = (int)$_GET['cat'];
		} else {
			$category = $rec['id_category'];
		}
		while ($rec_sel=mysqli_fetch_array($rs_sel)) {
?>
		<option value="<?= $rec_sel['id_category'] ?>"<?= $rec_sel['id_category'] == $category ? " selected" : "" ?>><?= my_htmlspecialchars($rec_sel['c_categoryName']) ?>
<?php
		}
?>
	</select>
	<?php if ($_SESSION['current_id'] == $_SESSION['login_id']) { ?>
		&nbsp;&nbsp;<label><input type="checkbox" name="c_privacy" value="444" <?= $rec['c_privacy'] == 444 ? ' checked' : '' ?>>非公開</label>
	<?php } ?>
	</td>
</tr>
<tr>
	<td>タイトル</td>
	<td>
		<input class="text" type="text" name="c_title" value="<?= my_htmlspecialchars($rec['c_title']) ?>" style="width:480px;">
	</td>
</tr>
<tr>
	<td>URL</td>
	<td>
		<input class="text" type="text" name="c_url" value="<?= my_htmlspecialchars($rec['c_url']) ?>" style="width:480px;">
	</td>
</tr>
<tr>
	<td>表示順</td>
	<td>
		<input class="text" type="text" name="c_displayOrder" value="<?= my_htmlspecialchars($rec['c_displayOrder']) ?>" style="width:50px;">
	</td>
</tr>
	<tr>
	<td>HTML<br>(ブログパーツ)</td>
	<td>
		<textarea id="c_html" name="c_html" style="width:480px;" rows="5" wrap="soft"><?= my_htmlspecialchars($rec['c_html']) ?></textarea>
	</td>
</tr>
</table>
<input class="input_form_button" type="submit" name="登録" value="修正">
</form>
<?
}
?>
