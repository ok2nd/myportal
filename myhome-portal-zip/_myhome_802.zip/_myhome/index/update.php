<?php
	require("__include-common.php");
	require("../account/__logincheck.php");
	require("_include-list-data.php");

	if ($_POST['user_id']."" <> "") {
		$user_id = $_POST['user_id'];
	} else {
		error_exit("不正アクセス：ユーザーIDなし", True);
	}
	if (check_permit_id($_SESSION['login_id'], $user_id) != "w") {
		error_exit("不正アクセス：書き込み権限がありません。", True);
	}
	if ($_POST['update_id']) {
		if (!is_numeric($_POST['update_id'])) {
			error_exit("不正アクセス", True);
		}
		$id = intval($_POST['update_id']);
	} else {
		$id = 0;
	}
	if ($_POST['c_title'] == "") {
		error_exit("タイトルなし", True);
	}
	$con = my_mysqli_connect(_DB_SCHEMA);
	if ($_POST['削除'] <> "") {
		$sql = "update m_homepage set";
		$sql .= " c_delete = 999";
		$sql .= ", c_updatetime = '". date("Y/m/d H:i:s") . "'";
		$sql .= " where id_homepage = ".$id;
		$sql .= " and id_account = ".$user_id;
		$ret = my_mysqli_query($sql, "削除できませんでした。");
	} else {
		$sql = "update m_homepage set";
		$sql .= " id_category = '".$_POST['id_category']."'";
		$sql .= ", c_title = '".post_to_mysql("c_title")."'";
		$sql .= ", c_url = '".post_to_mysql("c_url")."'";
		$sql .= ", c_displayOrder = '".post_to_mysql("c_displayOrder")."'";
		$sql .= ", c_html = '".post_to_mysql("c_html")."'";
		if ($_SESSION['current_id'] == $_SESSION['login_id']) {
			if ($_POST['c_privacy'] == '444') {
				$sql .= ", c_privacy = 444";
			} else {
				$sql .= ", c_privacy = 0";
			}
		}
		$sql .= ", c_updatetime = '". date("Y/m/d H:i:s") . "'";
		$sql .= " where id_homepage = ".$id;
		$sql .= " and id_account = ".$user_id;
		$ret = my_mysqli_query($sql, "更新できませんでした。");
	}

	$sql = "select * from v_homepage where id_homepage = ".$id." and c_delete = 0";
	$rs = my_mysqli_query($sql);
	$rec = mysqli_fetch_array($rs);
	if ($rec) {
		list_data($rec);
	} elseif ($_POST['削除']) {
		echo '<tr><td colspan=3 style="color:red;">削除しました。</td></tr>';
	} else {
		echo 'Error: Not Founds';
	}
?>
