	<table id="index_list_table">
<?php
	mysqli_data_seek($rs, $startline);			//テーブル内の指定行に移動
	$line = $startline;					//$lineに$startlineを代入
	while ($rec=mysqli_fetch_array($rs) and $line<=$endline) {
?>
	<tbody id="tb_<?= $rec['id_homepage'] ?>">
<?php
		list_data($rec);
?>
	</tbody>
<?php
		$line++;
	}
?>
	</table>
