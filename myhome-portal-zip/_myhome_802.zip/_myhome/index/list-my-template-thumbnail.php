	<div>
	<ul class="index_thumbnail">
<?php
	mysqli_data_seek($rs, $startline);			//テーブル内の指定行に移動
	$line = $startline;					//$lineに$startlineを代入
	while ($rec=mysqli_fetch_array($rs) and $line<=$endline) {
		if ($rec['c_url'] <> '') {
?>
		<li>
		<p class="index_thumbnail_title"><a href="<?= my_htmlspecialchars($rec['c_url']) ?>" target="_blank"><?= my_htmlspecialchars(mb_strimwidth($rec['c_title'], 0, 21, "..")) ?></a></p>

		<a href="<?= my_htmlspecialchars($rec['c_url']) ?>" title="<?= my_htmlspecialchars($rec['c_title']) ?>" target="_blank"><img src="<?= index_CAPTURE_CREATE_SITE ?><?= my_htmlspecialchars($rec['c_url']) ?>"></a>

		</li>
<?php
		}
		$line++;
	}
?>
	</ul>
	</div>
