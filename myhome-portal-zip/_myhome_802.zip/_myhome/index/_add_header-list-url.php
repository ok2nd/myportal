<style>
div#header {
	margin: 5px 5px 0 5px;
}
div#body {
	margin: 0px;
}
div#footer {
	margin: 5px;
}
div#print_dir {
	margin: 5px 0 5px 10px;
}
div#print_file {
	margin: 5px;
}
div#change_file_type {
	margin: 5px;
}
#selected_type {
	background-color: #ffc080;
}
.file_list {
	font-family: arial,sans-serif;
}
.file_list a:link { color: #101010; }
.file_list a:visited { color: #101010; }
.file_list a:hover { color: #ff0000; }
.file_list a:active { color: #ff0000; }
.file_url a:link { color: #2128e0; }
.file_url a:visited { color: #2128e0; }
.file_url a:hover { color: #ff0000; }
.file_url a:active { color: #ff0000; }
td.file_list {
	padding-left: 10px;
}
td.file_size {
	padding: 1px 0 1px 10px;
	text-align: right;
}
td.file_time {
	padding: 1px 0 1px 10px;
}
th.file_list {
	padding-left: 34px;
	background-color: #e0e0ff;
}
th.file_size {
	padding: 1px 0 1px 10px;
	text-align: right;
	color: #101010;
	background-color: #e0e0ff;
}
th.file_time {
	padding: 1px 0 1px 10px;
	background-color: #e0e0ff;
}
th a:link { color: #101010; font-weight: bold;}
th a:visited { color: #101010; font-weight: bold;}
th a:hover { color: #ff0000; font-weight: bold;}
th a:active { color: #ff0000; font-weight: bold;}
.order_mark {
	font-size: 80%;
	color: #808080;
	padding-left: 2px;
}
.file_folder {
	background-image: url(icon/folder.gif);
	background-repeat: no-repeat;
	background-position: top left;
	list-style: none;
	list-style-type: none;
	margin: 2px 0 2px 0;
	padding-left: 24px;
}
p#file_name_box {
	margin: 2px 0 2px 0;
}
span#file_name {
	text-decoration: underline;
	background-color: #e0f0ff;
	border: 0px;
	padding: 1px 4px 1px 4px;
}
span#file_encode {
	background-color: #fff0e0;
	border: 0px;
	padding: 1px 4px 1px 4px;
}
.list_filter_true {
	background-color: #ffe0c0;
}
#filemanager_body input[type="button"], x:-moz-any-link {	/* Firefox */
	height: 1.4em;
}
html>/**/body #filemanager_body input[type="button"] {	/* IE以外 */
	padding: 0 2px;
	line-height: 1em;
}
*+html #filemanager_body input[type="button"] {	/* IE */
	height: 1.3em;
}
*html #filemanager_body input[type="button"]) {	/* IE6 */
	height: 1.3em;
}
</style>
<script>
function rename_file(path, fname){
	fname = window.prompt("新しいファイル名を入れてください。", fname);
//	window.alert(fname);
	location.href='file-rename.php?path='+encodeURL(path)+'&new='+encodeURL(fname);
}
function delete_file(path){
	fname = path.substring(path.lastIndexOf('/')+1);
	if (window.confirm('ファイル「'+fname+'」を削除しますか？')) {
		location.href='file-delete.php?path='+encodeURL(path);
	} else {
		//window.alert('キャンセルされました');
	}
}
function rename_folder(path, fname){
	fname = window.prompt("新しいフォルダ名を入れてください。", fname);
//	window.alert(fname);
	location.href='folder-rename.php?path='+encodeURL(path)+'&new='+encodeURL(fname);
}
function delete_folder(path){
	fname = path.substring(path.lastIndexOf('/')+1);
	if (window.confirm('フォルダ「'+fname+'」を削除しますか？')) {
		location.href='folder-delete.php?path='+encodeURL(path);
	} else {
		//window.alert('キャンセルされました');
	}
}
</script>
