<?php
function contents_header() {
	$menu_item = array();
	$menu_item[] = array("href"=>"index.php", "query"=>"arg=session", "name"=>"INDEXトップ");
	$menu_item[] = array("href"=>"list.php", "query"=>"arg=session", "name"=>"一覧");
	$menu_item[] = array("href"=>"category.php", "name"=>"カテゴリ一覧");
	$menu_item[] = array("href"=>"oftenuse.php", "name"=>"ピックアップ編集");
	if ($_SESSION['システム管理者'] == "YES") {
		$menu_item[] = array("href"=>"list-url.php", "name"=>"ブックマーク");
	}
	$menu_item[] = array("href"=>"mynews.php", "name"=>"Myニュース");
?>
<div id="contents_header">
<?php
	contents_menu($menu_item);
	change_account_menu();
?>
</div><!-- id="contents_header" -->
<?php
}
?>
