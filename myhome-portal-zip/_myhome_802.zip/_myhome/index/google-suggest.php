<?php
	require("__include-common.php");
/*	// Google Suggest API JSON廃止
	$url = 'http://www.google.com/complete/search?hl=ja&json&q='.urlencode($_GET['q']);
	$json = my_file_get_contents($url);
	$json = mb_convert_encoding($json, 'UTF-8', "auto");
	$json_array = json_decode($json, true);
	foreach ($json_array as $words) {
		foreach ($words as $word) {
			echo $word."\n";
		}
	}
*/
	// XML
/*
<?xml version="1.0"?>
<toplevel>
	<CompleteSuggestion>
		<suggestion data="トヨタ"/>
		<num_queries int="87400000"/>
	</CompleteSuggestion>
	<CompleteSuggestion>
		<suggestion data="東京電力"/>
		<num_queries int="20600000"/>
	</CompleteSuggestion>
	........
</toplevel>
*/
	$url = 'http://www.google.com/complete/search?hl=ja&output=toolbar&q='.urlencode($_GET['q']);
	$xml = my_file_get_contents($url);
	$xml = mb_convert_encoding($xml, 'UTF-8', "auto");
	$xml_array = simplexml_load_string($xml);
	foreach ($xml_array->CompleteSuggestion as $CompleteSuggestion) {
		echo $CompleteSuggestion->suggestion['data']."\n";
	}
?>