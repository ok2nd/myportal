<?php
	if (defined("HTML_TITLE_index")) {
		define("HTML_TITLE", HTML_TITLE_index);
	} else {
		define("HTML_TITLE", "MyHome INDEX");
	}
	define("SESSION_PREFIX", "index");

	if (defined("_DB_SCHEMA_index")) {
		define("_DB_SCHEMA", _DB_SCHEMA_index);
	} else {
		define("_DB_SCHEMA", "_db_index");
	}
	if (defined("DENGON_VIEW_FRAME_COLOR_index")) {
		define("DENGON_VIEW_FRAME_COLOR", DENGON_VIEW_FRAME_COLOR_index);
	} else {
		define("DENGON_VIEW_FRAME_COLOR", "#ff0000");	// 伝言表示 枠カラー
	}
	if (defined("CHAT_VIEW_FRAME_COLOR_index")) {
		define("CHAT_VIEW_FRAME_COLOR", CHAT_VIEW_FRAME_COLOR_index);
	} else {
		define("CHAT_VIEW_FRAME_COLOR", "#87cefa");	// チャット(Chat)表示 枠カラー
	}
	if (defined("BBS_VIEW_FRAME_COLOR_index")) {
		define("BBS_VIEW_FRAME_COLOR", BBS_VIEW_FRAME_COLOR_index);
	} else {
		define("BBS_VIEW_FRAME_COLOR", "#228b22");	// 掲示板スレッド表示 枠カラー
	}
	if (defined("TODO_VIEW_FRAME_COLOR_index")) {
		define("TODO_VIEW_FRAME_COLOR", TODO_VIEW_FRAME_COLOR_index);
	} else {
		define("TODO_VIEW_FRAME_COLOR", "#228b22");	// ToDo表示 枠カラー
	}
	if (defined("SCHEDULE_VIEW_FRAME_COLOR_index")) {
		define("SCHEDULE_VIEW_FRAME_COLOR", SCHEDULE_VIEW_FRAME_COLOR_index);
	} else {
		define("SCHEDULE_VIEW_FRAME_COLOR", "#ff8c00");	// スケジュール表示 枠カラー
	}
	if (defined("CHAT_READ_CHECK_INTERVAL_index")) {
		define("CHAT_READ_CHECK_INTERVAL", CHAT_READ_CHECK_INTERVAL_index);
	} else {
		define("CHAT_READ_CHECK_INTERVAL", 1000);	// チャットAjax読取間隔 (ミリセカンド)
	}
	if (defined("BBS_VIEW_THREAD_index")) {
		define("BBS_VIEW_THREAD", BBS_VIEW_THREAD_index);
	} else {
		define("BBS_VIEW_THREAD", 3);			// 掲示板スレッド表示 件数
	}
	if (defined("BBS_VIEW_INTERVAL_DAY_index")) {
		define("BBS_VIEW_INTERVAL_DAY", BBS_VIEW_INTERVAL_DAY_index);
	} else {
		define("BBS_VIEW_INTERVAL_DAY", 7);		// 掲示板スレッド表示 表示日数 (n日以内の投稿があれば表示)
	}
	if (defined("CHAT_LOG_VIEW_CNT_MIN_index")) {
		define("CHAT_LOG_VIEW_CNT_MIN", CHAT_LOG_VIEW_CNT_MIN_index);
	} else {
		define("CHAT_LOG_VIEW_CNT_MIN", 3);		// INDEXトップページ チャット表示 件数
	}
	if (defined("TODO_VIEW_CNT_MIN_index")) {
		define("TODO_VIEW_CNT_MIN", TODO_VIEW_CNT_MIN_index);
	} else {
		define("TODO_VIEW_CNT_MIN", 3);			// INDEXトップページ ToDo表示 件数
	}
	if (defined("SCHEDULE_VIEW_DAY_index")) {
		define("SCHEDULE_VIEW_DAY", SCHEDULE_VIEW_DAY_index);
	} else {
		define("SCHEDULE_VIEW_DAY", 3);			// スケジュール表示 日数
	}
	if (defined("CALENDAR_VIEW_MONTH_index")) {
		define("CALENDAR_VIEW_MONTH", CALENDAR_VIEW_MONTH_index);
	} else {
		define("CALENDAR_VIEW_MONTH", 3);		// カレンダー表示 月数
	}
	if (defined("CALENDAR_VIEW_FIRST_index")) {
		define("CALENDAR_VIEW_FIRST", CALENDAR_VIEW_FIRST_index);
	} else {
		define("CALENDAR_VIEW_FIRST", -1);		// カレンダー表示 先頭月(-1:前月,0:今月)
	}

	define("PAGE_LINE_SELECT", "5,10,20,50,100,1000");	//頁内に表示する行数
	define("PAGE_LINE_DEFAULT", "100");			//頁内に表示する行数（デフォルト）

	// カレンダー用
	if (defined("ATTACH_FILE_FOLDER_calendar")) {
		define("ATTACH_FILE_FOLDER", ATTACH_FILE_FOLDER_calendar);
	} else {
		//↓絶対パスにできない？？？
		define("ATTACH_FILE_FOLDER", "../_attach/calendar/");
	}
	if (defined("IMAGES_FOLDER_calendar")) {
		define("IMAGES_FOLDER", "../calendar/".IMAGES_FOLDER_calendar);
		define("IMAGES_FOLDER_ORIGINAL", IMAGES_FOLDER_calendar);
	} else {
		define("IMAGES_FOLDER", "../calendar/images");
		define("IMAGES_FOLDER_ORIGINAL", "images");
	}
	if (defined("TEXTAREA_HTML_USE_calendar")) {
		define("TEXTAREA_HTML_USE", TEXTAREA_HTML_USE_calendar);
	} else {
		define("TEXTAREA_HTML_USE", "YES");
	}

	// livedoor天気ガジェット：表示有無
	if (defined("GADGET_WEATHER_USE_index")) {
		define("GADGET_WEATHER_USE", GADGET_WEATHER_USE_index);
	} else {
		define("GADGET_WEATHER_USE", "");		// 表示する場合:　"YES"
	}
	// 天気ガジェット：都市プルダウン定義ファイル
	if (defined("WEATHER_CITY_DEFINE_index")) {
		define("WEATHER_CITY_DEFINE", WEATHER_CITY_DEFINE_index);
	} else {
		define("WEATHER_CITY_DEFINE", "__define_weather_city.php");
	}
	// 天気ガジェット：リンク天気予報サイト
	if (defined("LINK_WEATHER_SITE_index")) {
		define("LINK_WEATHER_SITE", LINK_WEATHER_SITE_index);
	} else {
		define("LINK_WEATHER_SITE", "http://weathernews.jp/");
	}

	// ブログパーツ：ディレクトリ
	if (defined("BLOG_PARTS_FOLDER_index")) {
		define("BLOG_PARTS_FOLDER", BLOG_PARTS_FOLDER_index);
	} else {
		define("BLOG_PARTS_FOLDER", "../blog-parts/");
	}
	// ブログパーツ：HTMLファイル				// HTMLファイルはUTF-8でお願いします。
	if (defined("BLOG_PARTS_SCRIPT_TOP1_index")) {					// 右カレンダーの上
		define("BLOG_PARTS_SCRIPT_TOP1", BLOG_PARTS_SCRIPT_TOP1_index);
	} else {
		define("BLOG_PARTS_SCRIPT_TOP1", "");
	}
	if (defined("BLOG_PARTS_SCRIPT_TOP2_index")) {					// 右カレンダーの上
		define("BLOG_PARTS_SCRIPT_TOP2", BLOG_PARTS_SCRIPT_TOP2_index);
	} else {
		define("BLOG_PARTS_SCRIPT_TOP2", "");
	}
	if (defined("BLOG_PARTS_SCRIPT_BOTTOM1_index")) {				// 右カレンダーの下
		define("BLOG_PARTS_SCRIPT_BOTTOM1", BLOG_PARTS_SCRIPT_BOTTOM1_index);
	} else {
		define("BLOG_PARTS_SCRIPT_BOTTOM1", "");
	}
	if (defined("BLOG_PARTS_SCRIPT_BOTTOM2_index")) {				// 右カレンダーの下
		define("BLOG_PARTS_SCRIPT_BOTTOM2", BLOG_PARTS_SCRIPT_BOTTOM2_index);
	} else {
		define("BLOG_PARTS_SCRIPT_BOTTOM2", "");
	}
	if (defined("BLOG_PARTS_SCRIPT_RIGHT1_index")) {				// 右カレンダーの右
		define("BLOG_PARTS_SCRIPT_RIGHT1", BLOG_PARTS_SCRIPT_RIGHT1_index);
	} else {
		define("BLOG_PARTS_SCRIPT_RIGHT1", "");
	}
	if (defined("BLOG_PARTS_SCRIPT_RIGHT2_index")) {				// 右カレンダーの右
		define("BLOG_PARTS_SCRIPT_RIGHT2", BLOG_PARTS_SCRIPT_RIGHT2_index);
	} else {
		define("BLOG_PARTS_SCRIPT_RIGHT2", "");
	}
	if (defined("BLOG_PARTS_SCRIPT_RIGHT3_index")) {				// 右カレンダーの右
		define("BLOG_PARTS_SCRIPT_RIGHT3", BLOG_PARTS_SCRIPT_RIGHT3_index);
	} else {
		define("BLOG_PARTS_SCRIPT_RIGHT3", "");
	}
	if (defined("BLOG_PARTS_SCRIPT_RIGHT4_index")) {				// 右カレンダーの右
		define("BLOG_PARTS_SCRIPT_RIGHT4", BLOG_PARTS_SCRIPT_RIGHT4_index);
	} else {
		define("BLOG_PARTS_SCRIPT_RIGHT4", "");
	}

	if (defined("NO_SUBJECT_INPUT_MARK_calendar")) {
		define("NO_SUBJECT_INPUT_MARK", NO_SUBJECT_INPUT_MARK_calendar);
	} else {
		define("NO_SUBJECT_INPUT_MARK", "☆");
	}

	if (!defined("index_BOX_BORDER_COLOR")) {		// ボックスのボーダー色
		define("index_BOX_BORDER_COLOR", '');		// ボックスタイトルと同じ色
	//	define("index_BOX_BORDER_COLOR", '#b0b0b0;');	// 全ボックスを同じ色にする場合
	}
	if (!defined("index_BOX_BORDER_WIDTH")) {		// ボックスのボーダー幅
		define("index_BOX_BORDER_WIDTH", '1px');
	}
	if (!defined("index_CAPTURE_CREATE_SITE")) {		// キャプチャ画像作成サービス
		define("index_CAPTURE_CREATE_SITE", 'http://capture.heartrails.com/130x130/cool?');
	}

/*	Ver.4.09で廃止。
	if (defined("SEARCH_FORM_INPUT_TEXT_NAME_index")) {
		define("SEARCH_FORM_INPUT_TEXT_NAME", SEARCH_FORM_INPUT_TEXT_NAME_index);
	} else {
		define("SEARCH_FORM_INPUT_TEXT_NAME", "q");	// 検索フォーム優先サイト NAME属性 (Google)
	}
*/
	if (!defined("OFTENUSE_URL_BGCOLOR_index")) {
		define("OFTENUSE_URL_BGCOLOR_index","Mediumblue,Deepskyblue,Dodgerblue,Cornflowerblue,Royalblue,Mediumslateblue,Slateblue,Mediumpurple,Steelblue,Blueviolet,Darkviolet,Mediumorchid,Orchid,Crimson,Red,Orangered,Tomato,Coral,Lightsalmon,Darkorange,Orange,Gold,Chocolate,Peru,DarkGoldenrod,Goldenrod,Darkkhaki,Burlywood,Tan,Olive,Darkolivegreen,Olivedrab,Yellowgreen,Limegreen,Mediumseagreen,Forestgreen,Green,Darkgreen,Teal,Darkcyan,Cadetblue,Lightseagreen,Darkturquoise,Mediumturquoise,Turquoise,Magenta,Plum,Deeppink,Hotpink,Pink,Lightpink,LightCoral,Darkseagreen,Lightskyblue,Lightsteelblue,Skyblue,Darkslateblue,Navy,Silver,DarkSlategray,Slategray,Dimgray,Gray,Black");		// INDEX ピックアップ 背景色
	}
?>
