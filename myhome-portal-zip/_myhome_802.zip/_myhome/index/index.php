<?php
	require("__include-common.php");
	require("../account/__logincheck.php");
	require("../calendar/_my_calendar.php");
	if (!defined('BLOG_PARTS_SCRIPT_TOP1')) {
		define('BLOG_PARTS_SCRIPT_TOP1', '');
	}
	if (!defined('BLOG_PARTS_SCRIPT_TOP2')) {
		define('BLOG_PARTS_SCRIPT_TOP2', '');
	}
	if (!defined('BLOG_PARTS_SCRIPT_BOTTOM1')) {
		define('BLOG_PARTS_SCRIPT_BOTTOM1', '');
	}
	if (!defined('BLOG_PARTS_SCRIPT_BOTTOM2')) {
		define('BLOG_PARTS_SCRIPT_BOTTOM2', '');
	}
	if (!defined('BLOG_PARTS_SCRIPT_RIGHT1')) {
		define('BLOG_PARTS_SCRIPT_RIGHT1', '');
	}
	if (!defined('BLOG_PARTS_SCRIPT_RIGHT2')) {
		define('BLOG_PARTS_SCRIPT_RIGHT2', '');
	}
	if (!defined('BLOG_PARTS_SCRIPT_RIGHT3')) {
		define('BLOG_PARTS_SCRIPT_RIGHT3', '');
	}
	if (!defined('BLOG_PARTS_SCRIPT_RIGHT4')) {
		define('BLOG_PARTS_SCRIPT_RIGHT4', '');
	}
	if (!defined('BLOG_PARTS_SCRIPT_RIGHT21_index')) {
		define('BLOG_PARTS_SCRIPT_RIGHT21_index', '');
	}
	if (!defined('BLOG_PARTS_SCRIPT_RIGHT22_index')) {
		define('BLOG_PARTS_SCRIPT_RIGHT22_index', '');
	}
	if (!defined('BLOG_PARTS_SCRIPT_RIGHT23_index')) {
		define('BLOG_PARTS_SCRIPT_RIGHT23_index', '');
	}
	if (!defined('BLOG_PARTS_SCRIPT_RIGHT24_index')) {
		define('BLOG_PARTS_SCRIPT_RIGHT24_index', '');
	}
?>
<?php
	$_SESSION[SESSION_PREFIX.'_SCRIPT_NAME'] = $_SERVER['SCRIPT_NAME'];	// index.php redirect用
/*
	if (isset($_GET["t"])) {
		$target_type = $_GET["t"];
		setcookie("index_jump_targettype", $target_type, time() + LOGIN_COOKIE_EXPIRE, MY_SESSION_PATH);
	} else {
		if (isset($_COOKIE["index_jump_targettype"])) {
			$target_type = $_COOKIE["index_jump_targettype"];
		} else {
			$target_type = "_blank";
			setcookie("index_jump_targettype", $target_type, time() + LOGIN_COOKIE_EXPIRE, MY_SESSION_PATH);
		}
	}
*/
	if ($_COOKIE['index_suggestOnOff'] == 'off') {
		$_SESSION['suggest_on'] = ' display:none;';
		$_SESSION['suggest_off'] = '';
	} else {
		$_SESSION['suggest_on'] = '';
		$_SESSION['suggest_off'] = ' display:none;';
	}
	$onFocus = "document.getElementById('search_str').focus()";
	if (GADGET_WEATHER_USE == 'YES') {
		html_header(HTML_TITLE, '_add_header-index.php', '', ' onload="weatherSet();'.$onFocus.'"');
		require("__include-weather.php");				// 	天気予報
	} else {
		html_header(HTML_TITLE, '_add_header-index.php', '', ' onload="'.$onFocus.'"');
	}
	page_header(False);		//ログイン表示なし
	contents_header();
?>
<!--[if IE ]>
<style>
.search_button_box input[type="button"] {
	padding: 1px 2px\9;	/* IE */
}
</style>
<![endif]-->
<script>
var suggest_sw = '<?= $_COOKIE['index_suggestOnOff'] ?>';
</script>
<script>
$(function(){
	if ($.cookie('index_jump_targettype') != '') {
		target_change($.cookie('index_jump_targettype'));
	}
});
function target_change(target) {
	$("a[href^='http://']").attr("target",target);
	$("a[href^='https://']").attr("target",target);
	$.cookie('index_jump_targettype',target,{path: '<?= MY_SESSION_PATH ?>', expires:365});
	$(".target"+target+"_on").css("display","");
	$(".target"+target+"_off").css("display","none");
}
</script>
<?php
	if ($_SESSION['login_friends_body_background_img_'.$_SESSION['current_id']].'' <> '') {
		$bg_img = 'background-image: url('.ATTACH_FILE_FOLDER_account.$_SESSION['login_friends_body_background_img_'.$_SESSION['current_id']].');';
	}
?>
<div style="<?= $bg_img ?>">
<table id="body_table">
<tr>
<td>
	<?php
		search_body();
	?>
	<?php
		if ($_SESSION['login_id'] <> '') {
			index_body();
		}
	?>
</td>
<td class="side_box">
	<?php
		if (GADGET_WEATHER_USE == 'YES') {
			echo '<div class="side_parts">';
			gadget_weather();
			echo '</div>';
		}
		if (BLOG_PARTS_SCRIPT_TOP1 <> '') {
			echo '<div class="side_parts">';
			require(BLOG_PARTS_FOLDER.BLOG_PARTS_SCRIPT_TOP1);
			echo '</div>';
		}
		if (BLOG_PARTS_SCRIPT_TOP2 <> '') {
			echo '<div class="side_parts">';
			require(BLOG_PARTS_FOLDER.BLOG_PARTS_SCRIPT_TOP2);
			echo '</div>';
		}
		if ($_SESSION['login_id'] <> '') {
			if (_CALENDAR_SEND_MESSAGE_USE <> 'NO') {
				message_body();
			}
			if (CHAT_LOG_VIEW_CNT_MIN > 0) {
				echo '<div class="side_parts">';
				chat_body();
				echo '</div>';
			}
			if (BBS_VIEW_THREAD > 0) {
				echo '<div class="side_parts">';
				bbs_body();
				echo '</div>';
			}
			if (TODO_VIEW_CNT_MIN > 0) {
				echo '<div class="side_parts">';
				todo_body();
				echo '</div>';
			}
			if (SCHEDULE_VIEW_DAY > 0 || CALENDAR_VIEW_MONTH > 0) {
				echo '<div class="side_parts">';
				calendar_body();
				echo '</div>';
			}
		}
		if (BLOG_PARTS_SCRIPT_BOTTOM1 <> '') {
			echo '<div class="side_parts">';
			require(BLOG_PARTS_FOLDER.BLOG_PARTS_SCRIPT_BOTTOM1);
			echo '</div>';
		}
		if (BLOG_PARTS_SCRIPT_BOTTOM2 <> '') {
			echo '<div class="side_parts">';
			require(BLOG_PARTS_FOLDER.BLOG_PARTS_SCRIPT_BOTTOM2);
			echo '</div>';
		}
	?>
</td>
<td class="side_box">
	<?php
		if (BLOG_PARTS_SCRIPT_RIGHT1 <> '') {
			echo '<div class="side_parts">';
			require(BLOG_PARTS_FOLDER.BLOG_PARTS_SCRIPT_RIGHT1);
			echo '</div>';
		}
		if (BLOG_PARTS_SCRIPT_RIGHT2 <> '') {
			echo '<div class="side_parts">';
			require(BLOG_PARTS_FOLDER.BLOG_PARTS_SCRIPT_RIGHT2);
			echo '</div>';
		}
		if (BLOG_PARTS_SCRIPT_RIGHT3 <> '') {
			echo '<div class="side_parts">';
			require(BLOG_PARTS_FOLDER.BLOG_PARTS_SCRIPT_RIGHT3);
			echo '</div>';
		}
		if (BLOG_PARTS_SCRIPT_RIGHT4 <> '') {
			echo '<div class="side_parts">';
			require(BLOG_PARTS_FOLDER.BLOG_PARTS_SCRIPT_RIGHT4);
			echo '</div>';
		}
	?>
</td>
<td class="side_box">
	<?php
		if (BLOG_PARTS_SCRIPT_RIGHT21_index <> '') {
			echo '<div class="side_parts">';
			require(BLOG_PARTS_FOLDER.BLOG_PARTS_SCRIPT_RIGHT21_index);
			echo '</div>';
		}
		if (BLOG_PARTS_SCRIPT_RIGHT22_index <> '') {
			echo '<div class="side_parts">';
			require(BLOG_PARTS_FOLDER.BLOG_PARTS_SCRIPT_RIGHT22_index);
			echo '</div>';
		}
		if (BLOG_PARTS_SCRIPT_RIGHT23_index <> '') {
			echo '<div class="side_parts">';
			require(BLOG_PARTS_FOLDER.BLOG_PARTS_SCRIPT_RIGHT23_index);
			echo '</div>';
		}
		if (BLOG_PARTS_SCRIPT_RIGHT24_index <> '') {
			echo '<div class="side_parts">';
			require(BLOG_PARTS_FOLDER.BLOG_PARTS_SCRIPT_RIGHT24_index);
			echo '</div>';
		}
	?>
</td>
</tr>
</table>
</div>
<?php
	page_footer();
	html_footer();
	exit();
?>
<?php
function search_body() {
?>
<div id="search_body">
<?php
if (defined("_DEFINE_INDEX_SEARCH_MY") && _DEFINE_INDEX_SEARCH_MY <> '') {
	require(_DEFINE_INDEX_SEARCH_MY);
} else {
	require(_DEFINE_INDEX_SEARCH);
}
?>
</div><!-- id="search_body" -->
<?php
}
?>
<?php
function oftenuse($con) {
	$sql = 'select * from m_oftenuse where id_account = '.$_SESSION['current_id'];
	if ($_SESSION['current_id'] != $_SESSION['login_id']) {
		$sql .= " and c_privacy = 0";
	}
	$sql .= ' and c_delete = 0 order by c_displayOrder';
	$rs = my_mysqli_query($sql);
	if (mysqli_num_rows($rs) == 0) return;
?>
	<table id="oftenuse"><tr>
<?php
	$cnt = 0;
	while ($rec=mysqli_fetch_array($rs)) {
?>
	<td class="oftenuse_block">
		<table class="often"><tr><td style="background-color:<?= $rec['c_bgcolor'] ?>">
		<a href="<?= $rec['c_url'] ?>"><?= $rec['c_title1'] ?><br><?= $rec['c_title2'] ?><br></a></td></tr>
		</table>
	</td>
<?php
		$cnt++;
		if (floor($cnt / 6) * 6 == $cnt) echo '</tr><tr>';
	}
?>
	</tr></table>
<?php
}
function index_body() {
?>
	<div id="index_body">
<?php
	$con = my_mysqli_connect(_DB_SCHEMA);
	oftenuse($con);
	//カテゴリのみでホームページ登録なしを抽出
	$sql_no_hp = "SELECT m_category.id_category, m_category.c_categoryName, m_category.c_categoryDisplayColumn,";
	$sql_no_hp .= " m_category.c_categoryDisplayOrder, m_category.c_categoryDisplayColor";
	$sql_no_hp .= " FROM m_category";
	$sql_no_hp .= " LEFT JOIN (SELECT id_category FROM m_homepage WHERE c_delete = 0) T1";
	$sql_no_hp .= " ON m_category.id_category = T1.id_category";
	$sql_no_hp .= " WHERE T1.id_category is NULL";
	$sql_no_hp .= " AND m_category.id_account = '".$_SESSION['current_id']."'";
	$sql_no_hp .= " AND m_category.c_delete = 0";
?>
		<table id="index_main">
		<tr>
	<?php
		$sqlsel = "select * from v_homepage where id_account = '" . $_SESSION['current_id'] . "'";
		for ($ix=1; $ix<=4; $ix++) {
			$sql = $sqlsel . " and c_categoryDisplayColumn = " . $ix;
			if ($_SESSION['current_id'] != $_SESSION['login_id']) {
				$sql .= " and c_privacy = 0";
			}
			$sql .= " order by c_categoryDisplayOrder, id_category, c_displayOrder, c_title";
			$rs = my_mysqli_query($sql);
			$sql = $sql_no_hp . " and c_categoryDisplayColumn = " . $ix;
			$rs_no_hp = my_mysqli_query($sql);
			list_my_index($rs, $rs_no_hp);
		}
	?>
		</tr>
		</table>
	</div><!-- id="index_body" -->
	<div id="index_target_change">
		リンク先を
		[ 
		<span class="target_self_on target_blank_off target_select">●</span>
		<span class="target_self_off target_blank_on" style="display:none;">○</span>
		<a style="color: #0000ff" href="javascript:target_change('_self');">同じタブ</A> ]
		[ 
		<span class="target_blank_on target_self_off target_select" style="display:none;">●</span>
		<span class="target_blank_off target_self_on">○</span>
		<a style="color: #0000ff" href="javascript:target_change('_blank');">新しいタブ</A> ]
		で開く。
	</div><!-- id="index_target_change" -->
<?php
	mysqli_close($con);
}
?>
<?php
function message_body() {
	$con = my_mysqli_connect(_DB_SCHEMA_calendar);
	$sql = 'select id_message from m_message where to_id_account = '.$_SESSION['login_id'].' and c_receivedtime < c_registtime';
	$rs = my_mysqli_query($sql);
	if (mysqli_num_rows($rs) <> 0) {
?>
	<div class="side_parts">
<?php
	if (index_BOX_BORDER_COLOR <> '') {
		$side_border_color = index_BOX_BORDER_COLOR;
	} else {
		$side_border_color = DENGON_VIEW_FRAME_COLOR;
	}
?>
	<table class="index_side_table" style="border-color: <?= $side_border_color ?>; border-width: <?= index_BOX_BORDER_WIDTH ?>; background-color: <?= DENGON_VIEW_FRAME_COLOR ?>;">
	<tr><th><a href="../calendar/message.php">伝言</a></th></tr>
	<tr><td>
		<ul id="index_dengon_thread_item"><li>
		<a href="../calendar/message.php">★ 未読伝言あり</a>
		</li></ul>
	</td></tr>
	</table>
	</div>
<?php
	}
	mysqli_close($con);
	return;
}
?>
<?php
function chat_body() {
?>
	<script>
	$(function(){
		chat_view();
	});
	function chat_view(){
		var d = new Date();	// キャッシュを利用されないため
		$("#chat_log").load("../chat/read-min.php?time="+d.getTime().toString());
		setTimeout('chat_view()', <?= CHAT_READ_CHECK_INTERVAL ?>);
	}
	function popup_chat() {
		w01 = window.open("../chat/index.php","","toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes,width=440,height=500");
	}
	</script>
<?php
	if (index_BOX_BORDER_COLOR <> '') {
		$side_border_color = index_BOX_BORDER_COLOR;
	} else {
		$side_border_color = CHAT_VIEW_FRAME_COLOR;
	}
?>
	<table class="index_side_table" style="border-color: <?= $side_border_color ?>; border-width: <?= index_BOX_BORDER_WIDTH ?>; background-color: <?= CHAT_VIEW_FRAME_COLOR ?>;">
	<tr><th><a href="javascript:popup_chat()">チャット</a></th></tr>
	<tr><td>
		<div id="chat_log"></div>
	</td></tr>
	</table>
<?php
	return;
}
?>
<?php
function todo_body() {
	$con = my_mysqli_connect(_DB_SCHEMA_calendar);
	$sql = 'select * from m_todo where id_account = ' . $_SESSION['current_id'];
	$sql .= ' and c_delete = 0 order by c_priority desc, id_todo asc';
	$rs = my_mysqli_query($sql);
	$rowcnt = mysqli_num_rows($rs);
?>
	<script>;
	$(function(){
		todo_view()
	});
	function todo_view(){
		var d = new Date();	// キャッシュを利用されないため
		$("#todo_list").load("../todo/read-min.php?cn=<?= TODO_VIEW_CNT_MIN ?>&time="+d.getTime().toString());
	}
	function todo_view_all(){	// ToDo追加子ウインドウからの戻り用。ToDo全件表示。
		var d = new Date();	// キャッシュを利用されないため
		$("#todo_list").load("../todo/read-min.php?cn=<?= TODO_VIEW_CNT_MIN ?>&v=all&time="+d.getTime().toString());
	}
	function todo_display(){
		if ($(".todo_onoff").css("display") == "none") {
			$(".todo_onoff").css("display","");
		} else {
			$(".todo_onoff").css("display","none");
		}
	}
	function popup_todo() {
		w01 = window.open("../todo/index.php","","toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes,width=440,height=500");
	}
	</script>
<?php
	if (index_BOX_BORDER_COLOR <> '') {
		$side_border_color = index_BOX_BORDER_COLOR;
	} else {
		$side_border_color = TODO_VIEW_FRAME_COLOR;
	}
?>
	<table class="index_side_table" style="border-color: <?= $side_border_color ?>; border-width: <?= index_BOX_BORDER_WIDTH ?>; background-color: <?= TODO_VIEW_FRAME_COLOR ?>;">
	<tr><th><a href="javascript:popup_todo()">ToDo</a>
	<input type="button" onclick="javascript:todo_display()" id="todo_onoff_button" value="△▽">
	</th></tr>
	<tr><td>
		<div id="todo_list"></div>
	</td></tr>
	</table>
<?php
	mysqli_close($con);
	return;
}
?>
<?php
function bbs_body() {
	if (index_BOX_BORDER_COLOR <> '') {
		$side_border_color = index_BOX_BORDER_COLOR;
	} else {
		$side_border_color = BBS_VIEW_FRAME_COLOR;
	}
?>
	<table class="index_side_table" style="border-color: <?= $side_border_color ?>; border-width: <?= index_BOX_BORDER_WIDTH ?>; background-color: <?= BBS_VIEW_FRAME_COLOR ?>;">
	<tr><th><a href="../bbs/">掲示板</a></th></tr>
	<tr><td>
	<ul id="index_bbs_thread_item">
<?php
	$con = my_mysqli_connect(_DB_SCHEMA_bbs);
	$sql = 'select * from m_bbs where p_id_bbs = 0 and c_delete = 0';
	$sql .= ' and ADDDATE(c_reply_lasttime, INTERVAL ' . BBS_VIEW_INTERVAL_DAY .' DAY) > NOW()';
	$sql .= ' order by c_reply_lasttime desc';
	$_SESSION['bbs_list_sql'] = $sql;
	$rs = my_mysqli_query($sql);
	$rowcnt = mysqli_num_rows($rs);
	if ($rowcnt > 0) {
		$ix=0;
		while ($rec=mysqli_fetch_array($rs) and $ix<BBS_VIEW_THREAD) {
?>
		<li>
		<a href="../bbs/view.php?id=<?= $rec['id_bbs'] ?>&move=<?= $ix ?>&row=<?= $rowcnt ?>&del=off&key=__reset__&pl=10&page=1"><?= my_htmlspecialchars($rec['c_subject']) ?></a><?= $rec['c_reply_cnt'] <> 0 ? '<span class="index_bbs_repcnt">&nbsp;('.$rec['c_reply_cnt'].')</span>' : '' ?>
		</li>
<?php
			$ix++;
		}
?>
		</ul>
<?php
	}
	mysqli_close($con);
?>
	</td></tr>
	</table>
<?php
	return;
}
?>
<?php
function calendar_body() {
	$year = date("Y");
	$month = date("n");
	$day = date("j");
	$con = my_mysqli_connect(_DB_SCHEMA_calendar);
	if (SCHEDULE_VIEW_DAY > 0) {
		if (index_BOX_BORDER_COLOR <> '') {
			$side_border_color = index_BOX_BORDER_COLOR;
		} else {
			$side_border_color = SCHEDULE_VIEW_FRAME_COLOR;
		}
?>
	<script>
	function popup_schedule(uid,y,m,d) {
		w01 = window.open("../calendar/popup-schedule.php?uid=" + uid + "&y=" + y + "&m=" + m+ "&d=" + d,"","toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes,width=400,height=400");
	}
	</script>
	<script>
	$(function(){
		$("#index_side_calendar td").dblclick(function(){
			var input_url = $(this).attr("id");
			location.href = input_url;
		});
	});
	</script>
	<table class="index_side_table" id="index_side_calendar" style="border-color: <?= $side_border_color ?>; border-width: <?= index_BOX_BORDER_WIDTH ?>; background-color: <?= SCHEDULE_VIEW_FRAME_COLOR ?>;">
		<tr><th><a href="../calendar/">カレンダー</a>
		<label style="color:#fff;font-weight:normal;"><input type="checkbox" value="on" onClick="ajax_schedule_reload(this, 'index_schedule_detail')"<?= $_COOKIE['index_schedule_detail'] == 'on' ? ' checked' : '' ?>> 詳細</label>
		</th></tr>
		<tbody id="schedule">
		</tbody>
	</table>
<script>
$(function(){
	ajax_schedule();
});
function ajax_schedule() {
	$.ajax({
		type: "GET",
		url: "ajax-calendar.php",
		async: true,
		success: function(res){
			$("#schedule").html(res);
		}
	})
}
function ajax_schedule_reload(me, cookie_name) {
	chgCookieCheckOnOff(me, cookie_name);
	ajax_schedule();
}
</script>
<?php
	}
	$year = date("Y");
	$month = date("n");
	$day = date("j");
	if (CALENDAR_VIEW_MONTH > 0) {
		if (CALENDAR_VIEW_FIRST == -1) {
			if ($month == 1) {
				$year = date("Y") - 1;
				$month = 12;
			} else {
				$year = date("Y");
				$month = date("n") - 1;
			}
		}
		for ($ix=1; $ix<=CALENDAR_VIEW_MONTH; $ix++) {
			calendar_month($year, $month, $_SESSION['current_id'], "", "", "calendar_tbl_mini", "schedule");
			if ($month == 12) {
				$year++;
				$month = 1;
			} else {
				$month++;
			}
		}
	}
?>
<?php
	mysqli_close($con);
	return;
}
?>
<?php
function list_my_index($rs, $rs_no_hp) {
	$cate = 0;
	$cnt = 0;
?>
	<td>
<?php
	while ($rec = mysqli_fetch_array($rs)) {
		if ($rec['id_category'] <> $cate) {
			if ($cnt <> 0) {
?>
		</td></tr>
		</table>
<?php
			}
			if ($rec['c_categoryDisplayColor'].'' <> '') {
				$box_category_color = $rec['c_categoryDisplayColor'];
			} else {
				$box_category_color = '#b0b0b0';
			}
			if (index_BOX_BORDER_COLOR <> '') {
				$side_border_color = index_BOX_BORDER_COLOR;
			} else {
				$side_border_color = $box_category_color;
			}
?>
		<table class="index_category_box" style="border-color: <?= $side_border_color ?>; border-width: <?= index_BOX_BORDER_WIDTH ?>; background-color: <?= $box_category_color ?>;">
		<tr><th class="index_category">
			<a href="list.php?cat=<?= $rec['id_category'] ?>" target="_self"><?= my_htmlspecialchars($rec['c_categoryName']) ?></a>
<?php
			$cate = $rec['id_category'];
?>
		</th></tr>
		<tr><td class="index_mylink"><ul>
<?php
		}
		if ($rec['c_url'].'' <> '') {
?>
		<li>
			<a href="<?= $rec['c_url'] ?>"><?= mb_substr(my_htmlspecialchars($rec['c_title']),0,20) ?></a>
		</li>
<?php
		}
		if ($rec['c_html'].'' <> '') {
?>
		<li class="blog_parts">
			<?= str_replace("＼", chr(0x5c), $rec['c_html']) ?>
		</li>
<?php
		}
		$cnt++;
	}
	if ($cnt <> 0) {
?>
		</ul></td></tr>
		</table>
<?php
	}
?>
<?php
	while ($rec = mysqli_fetch_array($rs_no_hp)) {	//カテゴリのみでホームページ登録なし
			if ($rec['c_categoryDisplayColor'].'' <> '') {
				$box_category_color = $rec['c_categoryDisplayColor'];
			} else {
				$box_category_color = '#b0b0b0';
			}
			if (index_BOX_BORDER_COLOR <> '') {
				$side_border_color = index_BOX_BORDER_COLOR;
			} else {
				$side_border_color = $box_category_color;
			}
?>
		<table class="index_category_box" style="border-color: <?= $side_border_color ?>; border-width: <?= index_BOX_BORDER_WIDTH ?>; background-color: <?= $box_category_color ?>;">
		<tr><th class="index_category">
			<a href="list.php?cat=<?= $rec['id_category'] ?>" target="_self"><?= my_htmlspecialchars($rec['c_categoryName']) ?></a>
		</th></tr>
		</table>
<?php
	}
?>
	</td>
<?php
}
?>
