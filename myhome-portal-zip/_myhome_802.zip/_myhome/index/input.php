<?php
	require("__include-common.php");
	require("../account/__logincheck.php");
	if ($_POST) {
		check_post_account($_POST['login_id'], $_POST['current_id']);
		post_done_proc();
	} else {
		html_header(HTML_TITLE, '', '', ' onload="document.form0.c_title.focus()"');
		page_header();
		input_form();
		page_footer();
		html_footer();
	}
	exit();
?>
<?php
function post_done_proc() {
	if ($_POST['user_id']."" <> "") {
		$user_id = $_POST['user_id'];
	} else {
		error_exit("不正アクセス：ユーザーIDなし", True);
	}
	if (check_permit_id($_SESSION['login_id'], $user_id) != "w") {
		error_exit("不正アクセス：書き込み権限がありません。", True);
	}
	if ($_POST['update_id']) {
		if (!is_numeric($_POST['update_id'])) {
			error_exit("不正アクセス", True);
		}
		$id = intval($_POST['update_id']);
	} else {
		$id = 0;
	}
	if ($_POST['c_title'] == "") {
		error_exit("タイトルなし", True);
	}
	$con = my_mysqli_connect(_DB_SCHEMA);
	if ($id == 0) {
		$sql = "insert into m_homepage ";
		$sql .= "(id_account";
		$sql .= ", id_category";
		$sql .= ", c_title";
		$sql .= ", c_url";
		$sql .= ", c_displayOrder";
		$sql .= ", c_html";
		if ($_SESSION['current_id'] == $_SESSION['login_id']) {
			$sql .= ", c_privacy";
		}
		$sql .= ", c_registtime";
		$sql .= ", c_updatetime";
		$sql .= ") values ";
		$sql .= "( '".$user_id."'";
		$sql .= ", '" . $_POST['id_category'] . "'";
		$sql .= ", '".post_to_mysql("c_title")."'";
		$sql .= ", '".post_to_mysql("c_url")."'";
		$sql .= ", '".post_to_mysql("c_displayOrder")."'";
		$sql .= ", '".post_to_mysql("c_html")."'";
		if ($_SESSION['current_id'] == $_SESSION['login_id']) {
			if ($_POST['c_privacy'] == '444') {
				$sql .= ", 444";
			} else {
				$sql .= ", 0";
			}
		}
		$sql .= ", '". date("Y/m/d H:i:s") . "'";
		$sql .= ", '". date("Y/m/d H:i:s") . "'";
		$sql .= ")";
		$ret = my_mysqli_query($sql, "登録できませんでした。");
	} elseif ($_POST['削除'] <> "") {
		$sql = "update m_homepage set";
		$sql .= " c_delete = 999";
		$sql .= ", c_updatetime = '". date("Y/m/d H:i:s") . "'";
		$sql .= " where id_homepage = ".$id;
		$sql .= " and id_account = ".$user_id;
		$ret = my_mysqli_query($sql, "削除できませんでした。");
	} else {
		$sql = "update m_homepage set";
		$sql .= " id_category = '".$_POST['id_category']."'";
		$sql .= ", c_title = '".post_to_mysql("c_title")."'";
		$sql .= ", c_url = '".post_to_mysql("c_url")."'";
		$sql .= ", c_displayOrder = '".post_to_mysql("c_displayOrder")."'";
		$sql .= ", c_html = '".post_to_mysql("c_html")."'";
		if ($_SESSION['current_id'] == $_SESSION['login_id']) {
			if ($_POST['c_privacy'] == '444') {
				$sql .= ", c_privacy = 444";
			} else {
				$sql .= ", c_privacy = 0";
			}
		}
		$sql .= ", c_updatetime = '". date("Y/m/d H:i:s") . "'";
		$sql .= " where id_homepage = ".$id;
		$sql .= " and id_account = ".$user_id;
		$ret = my_mysqli_query($sql, "更新できませんでした。");
	}
	mysqli_close($con);
	redirect("list.php?cat=".$_GET['cat']."&sort=new");
}
function input_form() {
	if ($_GET['id'] <> "") {
		$id = $_GET['id'];
		if ($_GET['page'] <> "") {
			$page = $_GET['page'];
		}
	} else {
		$id = 0;
	}
	$con = my_mysqli_connect(_DB_SCHEMA);
	$sql = "select * from v_homepage where id_homepage = ".$id." and c_delete = 0";
	$sql .= " and id_account = ".$_SESSION['current_id'];
	$rs = my_mysqli_query($sql);
	$rec = mysqli_fetch_array($rs);

	if ($rec['c_title'] <> '') {
		$c_title = my_htmlspecialchars($rec['c_title']);
	} elseif ($_GET['title'] <> '') {
		$c_title = my_htmlspecialchars($_GET['title']);
	} else {
		$c_title = '';
	}
	if ($rec['c_url'] <> '') {
		$c_url = my_htmlspecialchars($rec['c_url']);
	} elseif ($_GET['url'] <> '') {
		$c_url = my_htmlspecialchars($_GET['url']);
	} else {
		$c_url = '';
	}
?>
<div class="input_form">
<h3><?= $_SESSION['current_handle'] ?><a class="a_cancel_back" href='list.php?cat=<?= $_GET['cat'] ?>&page=<?= $_GET['page'] ?>'>戻る</a></h3>
<script>
function formCheck(form) {
	if (form.c_title.value == '') {
		window.alert('タイトルを入れてください。');
		return false;		// 送信を中止
	}
	return true;	// 送信を実行
}
</script>
<form name="form0" method="POST" action="<?= $_SERVER['SCRIPT_NAME'] ?>?<?= $_SERVER['QUERY_STRING'] ?>" onSubmit="return formCheck(this)">
	<input type="hidden" name="user_id" value="<?= $_SESSION['current_id'] ?>">
	<input type="hidden" name="update_id" value="<?= $id ?>">
	<input type="hidden" name="login_id" value="<?= $_SESSION['login_id'] ?>">
	<input type="hidden" name="current_id" value="<?= $_SESSION['current_id'] ?>">
<table>
<tr>
	<td nowrap>カテゴリ</td>
	<td nowrap>
<?php
	$sqlsel = "select * from m_category where id_account = '".$_SESSION['current_id']."'";
	$sqlsel = $sqlsel . " and c_delete = 0";
	$sqlsel = $sqlsel . " order by c_categoryDisplayColumn, c_categoryDisplayOrder";
	$rs_sel = my_mysqli_query($sqlsel);
?>
	<select name="id_category">
<?php
		if ($id == 0) {
			$category = (int)$_GET['cat'];
		} else {
			$category = $rec['id_category'];
		}
		while ($rec_sel=mysqli_fetch_array($rs_sel)) {
?>
		<option value="<?= $rec_sel['id_category'] ?>"<?= $rec_sel['id_category'] == $category ? " selected" : "" ?>><?= my_htmlspecialchars($rec_sel['c_categoryName']) ?>
<?php
		}
?>
	</select>
	<?php if ($_SESSION['current_id'] == $_SESSION['login_id']) { ?>
		&nbsp;&nbsp;<label><input type="checkbox" name="c_privacy" value="444" <?= $rec['c_privacy'] == 444 ? ' checked' : '' ?>>非公開</label>
	<?php } ?>
	</td>
</tr>
<tr>
	<td>タイトル</td>
	<td>
		<input class="text" type="text" name="c_title" value="<?= $c_title ?>" style="width:480px;">
	</td>
</tr>
<tr>
	<td>URL</td>
	<td>
		<input class="text" type="text" name="c_url" value="<?= $c_url ?>" style="width:480px;">
	</td>
</tr>
<tr>
	<td>表示順</td>
	<td>
		<input class="text" type="text" name="c_displayOrder" value="<?= my_htmlspecialchars($rec['c_displayOrder']) ?>" style="width:50px;">
	</td>
</tr>
	<tr>
	<td>HTML<br>(ブログパーツ)</td>
	<td>
		<textarea id="c_html" name="c_html" style="width:480px;" rows="10" wrap="soft"><?= my_htmlspecialchars($rec['c_html']) ?></textarea>
	</td>
</tr>
</table>
<?php
	if ($id == 0) {
?>
	<input class="input_form_button" type="submit" name="登録" value="登録">
<?php
	} else {
?>
	<input class="input_form_button" type="submit" name="登録" value="修正">
	<input class="input_form_button" type="submit" name="削除" value="削除" onClick="return delete_check();" style="margin-left:20px;">
<?php
	}
?>
</form>
<p style="margin-top:10px; width:550px; text-indent: -1.3em; margin-left: 1.4em;">
※ 以下のようなブックマークレットをブラウザに登録しておくことで、表示しているホームページのタイトルとURLを自動入力した登録画面を開くことができます。
</p>
<div style="border:solid 1px #808080; width:500px; margin-left: 1.4em;">
javascript:(function(){window.open('http://<?= $_SERVER['HTTP_HOST'] ?>/<?= MY_SESSION_NAME ?>/index/input.php?title='+encodeURIComponent(document.title)+'&url='+encodeURIComponent(document.URL))})();
</div>
<p style="margin-top:10px;">
<a href="javascript:(function(){window.open('http://<?= $_SERVER['HTTP_HOST'] ?>/<?= MY_SESSION_NAME ?>/index/input.php?title='+encodeURIComponent(document.title)+'&url='+encodeURIComponent(document.URL))})();">▲Book</a> ←このリンクをブックマークバーにドラッグすると登録できます。
</p>
<script>
function delete_check() {
	if (window.confirm('このデータを削除しますか？')) {
		return true;
	} else {
		return false;
	}
}
</script>
<?
}
?>
