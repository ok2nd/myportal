<?php
	require("__include-common.php");
	require("../account/__logincheck.php");

	if (check_permit_id($_SESSION['login_id'], $_SESSION['current_id']) != "w") {
		error_exit("不正アクセス：書き込み権限がありません。", True);
	}
	if ($_GET['id'].'' == '') {
		return;
	}
	$id = intval($_GET['id']);
	$con = my_mysqli_connect(_DB_SCHEMA);
	$sql = "update m_homepage set";
	$sql .= " c_delete = 999";
	$sql .= ", c_updatetime = '". date("Y/m/d H:i:s") . "'";
	$sql .= " where id_homepage = ".$id;
	$sql .= " and id_account = ".$_SESSION['current_id'];
	$ret = my_mysqli_query($sql, "削除できませんでした。");
	mysqli_close($con);
	echo '<tr class="index_list"><td colspan=3 style="color:red;"><p style="margin:7px 40px;">削除しました。</p</td></tr>';
?>
