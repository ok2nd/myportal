<?php
	require("__include-common.php");
	require("../account/__logincheck.php");
	require("../__common__/include-common-mp-list.php");
	if ($_POST) {
		check_post_account($_POST['login_id'], $_POST['current_id']);
		post_done_proc();
	} else {
		html_header(HTML_TITLE, '', '', ' onload="document.form0.c_title1.focus()"');
		page_header();
		contents_header();
		$con = my_mysqli_connect(_DB_SCHEMA);
		main_proc();
		if (check_permit_id($_SESSION['login_id'], $_SESSION['current_id']) == "w") {
			input_form();
		}
		mysqli_close($con);
		page_footer();
		html_footer();
	}
	exit();
?>
<?php
function main_proc() {
global $con;
$con = my_mysqli_connect(_DB_SCHEMA);
?>
	<div id="often_body">
	<span id="often_edit_header"><?= $_SESSION['current_handle'] ?>&nbsp;&nbsp;<span id="often_edit_title">ピックアップ編集</span></span>
	<?php if (check_permit_id($_SESSION['login_id'], $_SESSION['current_id']) == "w") { ?>
	<span id="often_new"><a class="often_new_edit" href="<?= $_SERVER['SCRIPT_NAME'] ?>">[新規登録]</a></span>
	<span style="margin-left:30px;color:red;">↓↓↓　ドラッグ＆ドロップで順番を入れ替えできます。</span>
	<?php } ?>
<?php
	$sql = 'select * from m_oftenuse where id_account = '.$_SESSION['current_id'];
	if ($_SESSION['current_id'] != $_SESSION['login_id']) {
		$sql .= " and c_privacy = 0";
	}
	$sql .= ' and c_delete = 0 order by c_displayOrder';
	$rs = mysqli_query($con, $sql);
	if (mysqli_num_rows($rs) == 0) return;
?>
	<div id="oftenuse">
<?php
	$cnt = 0;
	while ($rec=mysqli_fetch_array($rs)) {
?>
	<div class="oftenuse_block" id="<?= $rec['id_oftenuse'] ?>"><span class="oftenuse_id" style="display:none;"><?= $rec['id_oftenuse'] ?></span>
		<table class="often"><tr><td style="background-color:<?= $rec['c_bgcolor'] ?>">
		<a href="<?= $rec['c_url'] ?>" target="_blank"><?= $rec['c_title1'] ?><br><?= $rec['c_title2'] ?><br></a></td></tr>
		</table>
		<span class="often_order"><?= $rec['c_displayOrder'] ?></span>
		<?php if (check_permit_id($_SESSION['login_id'], $_SESSION['current_id']) == "w") { ?>
		<span class="often_edit"><a class="often_new_edit" href="<?= $_SERVER['SCRIPT_NAME'] ?>?id=<?= $rec['id_oftenuse'] ?>">[修正]</a>
		<a class="often_new_edit" href="javascript:delete_check('<?= $rec['id_oftenuse'] ?>','<?= my_htmlspecialchars($rec['c_title1'].' '.$rec['c_title2']) ?>');">[削除]</a></span>
		<?php } ?>
	</div>
<?php
		$cnt++;
		if (floor($cnt / 6) * 6 == $cnt) echo '</tr><tr>';
	}
?>
	</div>
<?php
}
?>
<?php
function post_done_proc() {
	if ($_POST['user_id']."" <> "") {
		$user_id = $_POST['user_id'];
	} else {
		error_exit("不正アクセス：ユーザーIDなし", True);
	}
	if (check_permit_id($_SESSION['login_id'], $user_id) != "w") {
		error_exit("不正アクセス：書き込み権限がありません。", True);
	}
	if ($_POST['update_id']) {
		if (!is_numeric($_POST['update_id'])) {
			error_exit("不正アクセス", True);
		}
		$id = intval($_POST['update_id']);
	} else {
		$id = 0;
	}
	if (isset($_POST['削除'])) {
		//	if ($_POST['削除する'] <> "YES") {
		//		error_exit("削除するにチェックしてください。", True);
		//	}
	} elseif ($_POST['c_title1'] == "") {
		error_exit("タイトルなし", True);
	}
	$con = my_mysqli_connect(_DB_SCHEMA);
	if ($id == 0) {
		$sql = "insert into m_oftenuse ";
		$sql .= "(id_account";
		$sql .= ", c_title1";
		$sql .= ", c_title2";
		$sql .= ", c_url";
		$sql .= ", c_bgcolor";
		$sql .= ", c_displayOrder";
		if ($_SESSION['current_id'] == $_SESSION['login_id']) {
			$sql .= ", c_privacy";
		}
		$sql .= ", c_registtime";
		$sql .= ", c_updatetime";
		$sql .= ") values ";
		$sql .= "( '".$user_id."'";
		$sql .= ", '".post_to_mysql("c_title1")."'";
		$sql .= ", '".post_to_mysql("c_title2")."'";
		$sql .= ", '".post_to_mysql("c_url")."'";
		$sql .= ", '".post_to_mysql("c_bgcolor")."'";
		$sql .= ", '".toInt($_POST['c_displayOrder'])."'";
		if ($_SESSION['current_id'] == $_SESSION['login_id']) {
			if ($_POST['c_privacy'] == '444') {
				$sql .= ", 444";
			} else {
				$sql .= ", 0";
			}
		}
		$sql .= ", '". date("Y/m/d H:i:s") . "'";
		$sql .= ", '". date("Y/m/d H:i:s") . "'";
		$sql .= ")";
		$ret = my_mysqli_query($sql, "登録できませんでした。");
	} elseif ($_POST['削除'] <> "") {
		$sql = "update m_oftenuse set";
		$sql .= " c_delete = 999";
		$sql .= ", c_updatetime = '". date("Y/m/d H:i:s") . "'";
		$sql .= " where id_oftenuse = ".$id;
		$sql .= " and id_account = ".$user_id;
		$ret = my_mysqli_query($sql, "削除できませんでした。");
	} else {
		$sql = "update m_oftenuse set";
		$sql .= " c_title1 = '".post_to_mysql("c_title1")."'";
		$sql .= ", c_title2 = '".post_to_mysql("c_title2")."'";
		$sql .= ", c_url = '".post_to_mysql("c_url")."'";
		$sql .= ", c_bgcolor = '".post_to_mysql("c_bgcolor")."'";
		$sql .= ", c_displayOrder = '".toInt($_POST['c_displayOrder'])."'";
		if ($_SESSION['current_id'] == $_SESSION['login_id']) {
			if ($_POST['c_privacy'] == '444') {
				$sql .= ", c_privacy = 444";
			} else {
				$sql .= ", c_privacy = 0";
			}
		}
		$sql .= ", c_updatetime = '". date("Y/m/d H:i:s") . "'";
		$sql .= " where id_oftenuse = ".$id;
		$sql .= " and id_account = ".$user_id;
		$ret = my_mysqli_query($sql, "更新できませんでした。");
	}
	mysqli_close($con);
	redirect($_SERVER['SCRIPT_NAME']);
}
function input_form() {
	if ($_GET['id'] <> "") {
		$id = $_GET['id'];
		if ($_GET['page'] <> "") {
			$page = $_GET['page'];
		}
		$title = '<span style="color:#ff8000;font-size: 14px;">修正</span>';
	} else {
		$id = 0;
		$title = '新規登録';
	}
	$sql = "select * from m_oftenuse where id_oftenuse = ".$id." and c_delete = 0";
	$sql .= " and id_account = ".$_SESSION['current_id'];
	$rs = my_mysqli_query($sql);
	$rec = mysqli_fetch_array($rs);
	if ($rec['c_title1'] <> '') {
		$title1 = my_htmlspecialchars($rec['c_title1']);
	} elseif ($_GET['title'] <> '') {
		$title1 = my_htmlspecialchars($_GET['title']);
	} else {
		$title1 = '';
	}
	if ($rec['c_url'] <> '') {
		$c_url = my_htmlspecialchars($rec['c_url']);
	} elseif ($_GET['url'] <> '') {
		$c_url = my_htmlspecialchars($_GET['url']);
	} else {
		$c_url = '';
	}
?>
<script src="../scripts/jquery-ui.min.js"></script>
<script>
$("#oftenuse").sortable({stop: function(event, ui) {
	id_nums = $("#oftenuse").sortable("toArray");
	location.href='oftenuse-renum.php?ids='+id_nums;
}});
/* 以下の方法でも動作する。
$('#oftenuse').sortable({
	stop: function(event, ui) {
		var id_nums = '';
			jQuery('.oftenuse_id').map( function() {
			if (id_nums != '') id_nums += ',';
				id_nums += jQuery(this).text();
			});
		location.href='oftenuse-renum.php?ids='+id_nums;
	}
});
*/
</script>
<div class="input_form" style="float:left;margin-top:16px;">
<script src="../scripts/valueconvertor.js"></script>
<script>
function formCheck(form) {
	if (form.c_title1.value == '') {
		window.alert('タイトルを入れてください。');
		return false;		// 送信を中止
	}
	return true;	// 送信を実行
}
function delete_check(id, title) {
	if (window.confirm('「'+title+'」を削除しますか？')) {
		location.href="delete-offenuse.php?id="+id;
	}
}
</script>
<h4 id="often_edit_sub_title"><?= $title ?></h4>
<form name="form0" method="POST" action="<?= $_SERVER['SCRIPT_NAME'] ?>?<?= $_SERVER['QUERY_STRING'] ?>" onSubmit="return formCheck(this)">
	<input type="hidden" name="user_id" value="<?= $_SESSION['current_id'] ?>">
	<input type="hidden" name="update_id" value="<?= $id ?>">
	<input type="hidden" name="login_id" value="<?= $_SESSION['login_id'] ?>">
	<input type="hidden" name="current_id" value="<?= $_SESSION['current_id'] ?>">
<table>
	</tr>
	<tr>
		<td nowrap>タイトル</td>
		<td>1段目<input class="text" type="text" name="c_title1" value="<?= $title1 ?>" style="ime-mode:active; width:500px;"><br>
		2段目<input class="text" type="text" name="c_title2" value="<?= my_htmlspecialchars($rec['c_title2']) ?>" style="ime-mode:active; width:100px;">
		<?php if ($_SESSION['current_id'] == $_SESSION['login_id']) { ?>
		&nbsp;&nbsp;<label><input type="checkbox" name="c_privacy" value="444" <?= $rec['c_privacy'] == 444 ? ' checked' : '' ?>>非公開</label>
		<?php } ?>
		</td>
	</tr>
	<tr>
		<td nowrap>URL</td>
		<td><input class="text" type="text" name="c_url" value="<?= $c_url ?>" style="ime-mode: inactive; width:500px;"></td>
	</tr>
	<tr>
		<td nowrap>背景色</td>
		<td nowrap>
		<?php
		$bgcolor = explode(",", OFTENUSE_URL_BGCOLOR_index);
		if ($rec['c_bgcolor'].'' == '') $rec['c_bgcolor'] = $bgcolor[0];
		for ($ix = 0; $ix < count($bgcolor); $ix++) {
		?>
			<label><input type=radio name="c_bgcolor" value="<?= $bgcolor[$ix] ?>"<? if ($rec['c_bgcolor'] == $bgcolor[$ix]) echo ' checked' ?>><span style="font-size: 130%; color: <?= $bgcolor[$ix] ?>">■</span></label>
		<?php
			if (floor(($ix+1)/16) == ($ix+1)/16) {
				echo '<br>';
			}
		}
		?>
		</td>
	</tr>
	<tr>
		<td nowrap>表示順序</td>
		<td><input class="text ascii" type="text" name="c_displayOrder" value="<?= $rec['c_displayOrder'] ?>" size=10 style="ime-mode: disabled;"></td>
	</tr>
</table>
<?php
	if ($id == 0) {
?>
	<input class="input_form_button" type="submit" name="登録" value="登録">
<?php
	} else {
?>
	<input class="input_form_button" type="submit" name="登録" value="修正">
<?php
	}
?>
</form>
<p style="margin-top:10px; width:550px; text-indent: -1.3em; margin-left: 1.4em;">
※ 以下のようなブックマークレットをブラウザに登録しておくことで、表示しているホームページのタイトルとURLを自動入力した登録画面を開くことができます。
</p>
<div style="border:solid 1px #808080; width:500px; margin-left: 1.4em;">
javascript:(function(){window.open('http://<?= $_SERVER['HTTP_HOST'] ?>/<?= MY_SESSION_NAME ?>/index/oftenuse.php?title='+encodeURIComponent(document.title)+'&url='+encodeURIComponent(document.URL))})();
</div>
<p style="margin-top:10px;">
<a href="javascript:(function(){window.open('http://<?= $_SERVER['HTTP_HOST'] ?>/<?= MY_SESSION_NAME ?>/index/oftenuse.php?title='+encodeURIComponent(document.title)+'&url='+encodeURIComponent(document.URL))})();">▲Pick</a> ←このリンクをブックマークバーにドラッグすると登録できます。
</p>
<?
}
?>
