<?php	// Ajax カレンダ
	require("__include-common.php");
	require("../account/__logincheck.php");
	require("../calendar/_my_calendar.php");
	$year = date("Y");
	$month = date("n");
	$day = date("j");
	$con = my_mysqli_connect(_DB_SCHEMA_calendar);
	for ($ix=1; $ix<=SCHEDULE_VIEW_DAY; $ix++) {
		$date = str_for_mysql($year.'/'.$month.'/'.$day);
		$week = date_from_mysql("w", $date);
		if ($week == 0) {
			$day_class = "day_sunday";
		} elseif ($week == 6) {
			$day_class = "day_saturday";
		} else {
			$day_class = "day_weekday";
		}
		$holiday = holiday_check($year, $month, $day);
		if ($holiday) {
			$day_class = "day_holiday";
		}
		$day_class = $day_class . " index_today_schedule";
		$dblclick = '../calendar/input.php?uid='.$_SESSION['current_id'].'&y='.$year.'&m='.$month.'&d='.$day;
?>
	<tr><td id="<?= $dblclick ?>" class="<?= $day_class ?>" style="border-color: <?= $side_border_color ?>;">
	<p><a href='../calendar/input.php?uid=<?= $_SESSION['current_id'] ?>&y=<?= $year ?>&m=<?= $month ?>&d=<?= $day ?>' class='calendar_day'><?= $month ?>/<?= $day ?></a>&nbsp;<?= day_week_view($date) ?>&nbsp;<a href='javascript:popup_schedule("<?= $_SESSION['current_id'] ?>", "<?= $year ?>", "<?= $month ?>", "<?= $day ?>")' class='popup_sch_link'>↑</a>&nbsp;<span class='holiday_name'><?= $holiday ?></span></p>
<?php
		if ($_COOKIE['index_schedule_detail'] == 'on') {
			schedule_print($year, $month, $day, $_SESSION['current_id'], "", "", True, True, IMAGES_FOLDER, IMAGES_FOLDER_ORIGINAL);
		} else {
			schedule_print($year, $month, $day, $_SESSION['current_id'], "", "", True, False, IMAGES_FOLDER, IMAGES_FOLDER_ORIGINAL);
		}
		$nextday = mktime(0, 0, 0, $month, ++$day, $year);
		$year = date('Y', $nextday);
		$month = date('n', $nextday);
		$day = date('j', $nextday);
?>
	</td></tr>
<?php
	}
?>