<?php
	require("__include-common.php");
	require("../account/__logincheck.php");
	if (!defined('TIMER_ALARM_MAXNUM')) {
		define('TIMER_ALARM_MAXNUM', 10);
	}
	$con = my_mysqli_connect(_DB_SCHEMA);
	for ($ix=1; $ix<=TIMER_ALARM_MAXNUM; $ix++) {
		$sql = "select * from m_alarm where id_account = ".$_SESSION['login_id']." and id_num = ".$ix;
		$rs = my_mysqli_query($sql);
		if (mysqli_num_rows($rs) == 0) {
			$sql = "insert into m_alarm ";
			$sql .= "(id_account";
			$sql .= ", id_num";
			$sql .= ", c_updatetime";
			$sql .= ", c_hour";
			$sql .= ", c_min";
			$sql .= ", c_day";
			$sql .= ", c_week";
			$sql .= ", c_message";
			$sql .= ", c_valid";
			$sql .= ") values (";
			$sql .= "'".$_SESSION['login_id']."'";
			$sql .= ", '".$ix."'";
			$sql .= ", '".date("Y/m/d H:i:s")."'";
			$sql .= ", '".post_to_mysql("hour".$ix)."'";
			$sql .= ", '".post_to_mysql("min".$ix)."'";
			$sql .= ", '".post_to_mysql("day".$ix)."'";
			$sql .= ", '".post_to_mysql("week".$ix)."'";
			$sql .= ", '".post_to_mysql("message".$ix)."'";
			$sql .= ", '".post_to_mysql("valid".$ix)."'";
			$sql .= ")";
			$ret = my_mysqli_query($sql, "登録できませんでした。");
		} else {
			$rec = mysqli_fetch_array($rs);
			$sql = "update m_alarm set";
			$sql .= " c_updatetime = '".date("Y/m/d H:i:s")."'";
			$sql .= ", id_num = '".$ix."'";
			$sql .= ", c_hour = '".post_to_mysql("hour".$ix)."'";
			$sql .= ", c_min = '".post_to_mysql("min".$ix)."'";
			$sql .= ", c_day = '".post_to_mysql("day".$ix)."'";
			$sql .= ", c_week = '".post_to_mysql("week".$ix)."'";
			$sql .= ", c_message = '".post_to_mysql("message".$ix)."'";
			$sql .= ", c_valid = '".post_to_mysql("valid".$ix)."'";
			$sql .= " where id_account = ".$_SESSION['login_id']." and id_num = ".$ix;
			$ret = my_mysqli_query($sql, "更新できませんでした。");
			// --- 時間が過ぎていないものは、実行済日付(c_done)をクリア
			$sql = "update m_alarm set";
			$sql .= " c_done = ''";
			$sql .= " where id_account = ".$_SESSION['login_id']."";
			$sql .= " and c_hour*60+c_min > '".(intval(date("G"))*60+intval(date("i")))."'";
			$ret = my_mysqli_query($sql, "更新エラー。");
		}
	}
	redirect("alarm.php");
?>
