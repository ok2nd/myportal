<?php
	require("../__common__/__define_common.php");
?>
<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="utf-8">
<title>週間天気予報 地点設定</title>
<style>
img { border: 0; }
a { text-decoration: underline; font-weight: normal; }
a:link { color: #2128e0; font-weight: normal; }
a:visited { color: #2128e0; font-weight: normal; }
a:hover { color: #f43316; font-weight: normal; background-color: #ffffc0; }
a:active { color: #f43316; font-weight: normal; background-color: #ffffc0; }
body {
	margin: 10px;
	background: #fff;
}
* {
	font-size: 12px;
}
h1 {
	font-size: 16px;
}
.grayOut {
	display: none;
}
table {
	margin: 0;
	padding: 0;
	border-spacing: 0px;
	border-collapse: collapse;
}
th {
	text-align: center;
	font-size: 12px;
	background: #eee;
	padding: 4px;
	border: solid 1px #A0A0A0;
}
td {
	text-align: center;
	font-size: 12px;
	padding: 4px;
	border: solid 1px #A0A0A0;
}
p {
	margin: 2px 0 0 0;
	padding: 0;
	text-align: left;
}
#tenki_area td label {
	padding: 5px 4px 4px 0;
}
input {
	vertical-align: -2px;
}
input, x:-moz-any-link {	/* Firefox */
	vertical-align: middle;
}
.chihou {
	display: none;
}
</style>
<script src="../scripts/jquery.js"></script>
<script src="../scripts/jquery.cookie.js"></script>
<script src="../scripts/ok2nd.js"></script>
<script>
$(function(){
	var city_list = $.cookie('tenki_yohou_city_list')+'';
	var city_id = city_list.split(',');
	$("#tenki_area :checkbox").each(function() {
		for (var ix in city_id) {
			if (this.value == city_id[ix]) {
				$(this).attr('checked', true);
				$(this).parent().css({'background':'#ffeb89','color':'red'});
			}
		}
	});
	$("#tenki_area :checkbox").click(function() {
		if($(this).attr('checked') == true) {
			$(this).parent().css({'background':'#ffeb89','color':'red'});
		} else {
			$(this).parent().css({'background':'','color':''});
		}
	});
});
function city_set() {
	var city_id = '';
	$("[name='area']:checked").each(function(){
		city_id = city_id + this.value + ',';
	});
	if (city_id == '') {
		alert('地点が選択されていません。');
		return false;
	}
	$.cookie('tenki_yohou_city_list',city_id,{ path:'<?= MY_SESSION_PATH ?>', expires:365 });
	location.href = 'tenki.php';
}
</script>
</head>
<body>
<h1><a href="javascript:window.close()"><img src="../icon/weather_sun.png" style="margin:0;border:0;"></a>
週間天気予報 地点設定
<span style="margin-left:20px;font-size:12px;color:red;font-weight:normal;">設定はブラウザのCookieに保存されます。再設定すると表示順はリセットされます。</span>
<a style="margin-left:20px;" href="tenki.php">戻る</a><h1>
<button onclick="city_set();">設定</button>
<table id="tenki_area">
<tr>
<th abbr="北海道" rowspan="4"><label class="1">北海道</label></th>
<th>
<label class="1">道北</label>
</th>
<td>
<p>
<label><input type="checkbox" name="area" value="1">宗谷(稚内)</label><span class="grayOut">ｌ</span>
<label><input type="checkbox" name="area" value="2">上川(旭川)</label><span class="grayOut">ｌ</span>
<label><input type="checkbox" name="area" value="3">留萌</label>
</p>
</td>
<tr>
<th>
<label class="3">道東</label>
</th>
<td>
<p>
<label><input type="checkbox" name="area" value="7">網走</label><span class="grayOut">ｌ</span>
<label><input type="checkbox" name="area" value="8">北見</label><span class="grayOut">ｌ</span>
<label><input type="checkbox" name="area" value="9">紋別</label><span class="grayOut">ｌ</span>
<label><input type="checkbox" name="area" value="10">根室</label><span class="grayOut">ｌ</span>
<label><input type="checkbox" name="area" value="11">釧路</label><span class="grayOut">ｌ</span>
<label><input type="checkbox" name="area" value="12">十勝(帯広)</label>
</p>
</td>
</tr>
<tr>
<th>
<label class="2">道央</label>
</th>
<td>
<p>
<label><input type="checkbox" name="area" value="4">石狩(札幌)</label><span class="grayOut">ｌ</span>
<label><input type="checkbox" name="area" value="5">空知(岩見沢)</label><span class="grayOut">ｌ</span>
<label><input type="checkbox" name="area" value="6">後志(倶知安)</label>
</p>
</td>
</tr>
<tr>
<th>
<label class="4">道南</label>
</th>
<td>
<p>
<label><input type="checkbox" name="area" value="13">胆振(室蘭)</label><span class="grayOut">ｌ</span>
<label><input type="checkbox" name="area" value="14">日高(浦河)</label><span class="grayOut">ｌ</span>
<label><input type="checkbox" name="area" value="15">渡島(函館)</label><span class="grayOut">ｌ</span>
<label><input type="checkbox" name="area" value="16">檜山(江差)</label>
</p>
</td>
</tr>
</tr>
<tr>
<th abbr="東北" rowspan="6"><label class="2">東北</label></th>
<th>
<label class="5">青森</label>
</th>
<td>
<p>
<label><input type="checkbox" name="area" value="17">津軽(青森)</label><span class="grayOut">ｌ</span>
<label><input type="checkbox" name="area" value="18">下北(むつ)</label><span class="grayOut">ｌ</span>
<label><input type="checkbox" name="area" value="19">三八上北(八戸)</label>
</p>
</td>
<tr>
<th>
<label class="6">岩手</label>
</th>
<td>
<p>
<label><input type="checkbox" name="area" value="22">内陸(盛岡)</label><span class="grayOut">ｌ</span>
<label><input type="checkbox" name="area" value="23">沿岸北部(宮古)</label><span class="grayOut">ｌ</span>
<label><input type="checkbox" name="area" value="24">沿岸南部(大船渡)</label>
</p>
</td>
</tr>
<tr>
<th>
<label class="7">宮城</label>
</th>
<td>
<p>
<label><input type="checkbox" name="area" value="25">東部(仙台)</label><span class="grayOut">ｌ</span>
<label><input type="checkbox" name="area" value="26">西部(白石)</label>
</p>
</td>
</tr>
<tr>
<th>
<label class="8">秋田</label>
</th>
<td>
<p>
<label><input type="checkbox" name="area" value="20">沿岸(秋田)</label><span class="grayOut">ｌ</span>
<label><input type="checkbox" name="area" value="21">内陸(横手)</label>
</p>
</td>
</tr>
<tr>
<th>
<label class="9">山形</label>
</th>
<td>
<p>
<label><input type="checkbox" name="area" value="27">村山(山形)</label><span class="grayOut">ｌ</span>
<label><input type="checkbox" name="area" value="28">置賜(米沢)</label><span class="grayOut">ｌ</span>
<label><input type="checkbox" name="area" value="29">庄内(酒田)</label><span class="grayOut">ｌ</span>
<label><input type="checkbox" name="area" value="30">最上(新庄)</label>
</p>
</td>
</tr>
<tr>
<th>
<label class="10">福島</label>
</th>
<td>
<p>
<label><input type="checkbox" name="area" value="31">中通り(福島)</label><span class="grayOut">ｌ</span>
<label><input type="checkbox" name="area" value="32">浜通り(小名浜)</label><span class="grayOut">ｌ</span>
<label><input type="checkbox" name="area" value="33">会津(若松)</label>
</p>
</td>
</tr>
</tr>
<tr>
<th abbr="関東・甲信" rowspan="9"><label class="3">関東・甲信</label></th>
<th>
<label class="16">東京</label>
</th>
<td>
<p>
<label><input type="checkbox" name="area" value="63">東京</label><span class="grayOut">ｌ</span>
<label><input type="checkbox" name="area" value="64">伊豆諸島北部(大島)</label><span class="grayOut">ｌ</span>
<label><input type="checkbox" name="area" value="65">伊豆諸島南部(八丈島)</label><span class="grayOut">ｌ</span>
<label><input type="checkbox" name="area" value="66">小笠原諸島</label>
</p>
</td>
<tr>
<th>
<label class="17">神奈川</label>
</th>
<td>
<p>
<label><input type="checkbox" name="area" value="70">東部(横浜)</label><span class="grayOut">ｌ</span>
<label><input type="checkbox" name="area" value="71">西部(小田原)</label>
</p>
</td>
</tr>
<tr>
<th>
<label class="14">埼玉</label>
</th>
<td>
<p>
<label><input type="checkbox" name="area" value="60">南部(さいたま)</label><span class="grayOut">ｌ</span>
<label><input type="checkbox" name="area" value="61">北部(熊谷)</label><span class="grayOut">ｌ</span>
<label><input type="checkbox" name="area" value="62">秩父</label>
</p>
</td>
</tr>
<tr>
<th>
<label class="15">千葉</label>
</th>
<td>
<p>
<label><input type="checkbox" name="area" value="67">北西部(千葉)</label><span class="grayOut">ｌ</span>
<label><input type="checkbox" name="area" value="68">北東部(銚子)</label><span class="grayOut">ｌ</span>
<label><input type="checkbox" name="area" value="69">南部(館山)</label>
</p>
</td>
</tr>
<tr>
<th>
<label class="11">茨城</label>
</th>
<td>
<p>
<label><input type="checkbox" name="area" value="54">北部(水戸)</label><span class="grayOut">ｌ</span>
<label><input type="checkbox" name="area" value="55">南部(土浦)</label>
</p>
</td>
</tr>
<tr>
<th>
<label class="12">栃木</label>
</th>
<td>
<p>
<label><input type="checkbox" name="area" value="56">南部(宇都宮)</label><span class="grayOut">ｌ</span>
<label><input type="checkbox" name="area" value="57">北部(大田原)</label>
</p>
</td>
</tr>
<tr>
<th>
<label class="13">群馬</label>
</th>
<td>
<p>
<label><input type="checkbox" name="area" value="58">南部(前橋)</label><span class="grayOut">ｌ</span>
<label><input type="checkbox" name="area" value="59">北部(みなかみ)</label>
</p>
</td>
</tr>
<tr>
<th>
<label class="22">山梨</label>
</th>
<td>
<p>
<label><input type="checkbox" name="area" value="75">中・西部(甲府)</label><span class="grayOut">ｌ</span>
<label><input type="checkbox" name="area" value="76">東部・富士五湖(河口湖)</label>
</p>
</td>
</tr>
<tr>
<th>
<label class="23">長野</label>
</th>
<td>
<p>
<label><input type="checkbox" name="area" value="72">北部(長野)</label><span class="grayOut">ｌ</span>
<label><input type="checkbox" name="area" value="73">中部(松本)</label><span class="grayOut">ｌ</span>
<label><input type="checkbox" name="area" value="74">南部(飯田)</label>
</p>
</td>
</tr>
</tr>
<tr>
<th abbr="北陸" rowspan="4"><label class="4">北陸</label></th>
<th>
<label class="18">新潟</label>
</th>
<td>
<p>
<label><input type="checkbox" name="area" value="50">下越(新潟)</label><span class="grayOut">ｌ</span>
<label><input type="checkbox" name="area" value="51">中越(長岡)</label><span class="grayOut">ｌ</span>
<label><input type="checkbox" name="area" value="52">上越(高田)</label><span class="grayOut">ｌ</span>
<label><input type="checkbox" name="area" value="53">佐渡(相川)</label>
</p>
</td>
<tr>
<th>
<label class="19">富山</label>
</th>
<td>
<p>
<label><input type="checkbox" name="area" value="44">東部(富山)</label><span class="grayOut">ｌ</span>
<label><input type="checkbox" name="area" value="45">西部(伏木)</label>
</p>
</td>
</tr>
<tr>
<th>
<label class="20">石川</label>
</th>
<td>
<p>
<label><input type="checkbox" name="area" value="46">加賀(金沢)</label><span class="grayOut">ｌ</span>
<label><input type="checkbox" name="area" value="47">能登(輪島)</label>
</p>
</td>
</tr>
<tr>
<th>
<label class="21">福井</label>
</th>
<td>
<p>
<label><input type="checkbox" name="area" value="48">嶺北(福井)</label><span class="grayOut">ｌ</span>
<label><input type="checkbox" name="area" value="49">嶺南(敦賀)</label>
</p>
</td>
</tr>
</tr>
<tr>
<th abbr="東海" rowspan="4"><label class="5">東海</label></th>
<th>
<label class="26">愛知</label>
</th>
<td>
<p>
<label><input type="checkbox" name="area" value="38">西部(名古屋)</label><span class="grayOut">ｌ</span>
<label><input type="checkbox" name="area" value="39">東部(豊橋)</label>
</p>
</td>
<tr>
<th>
<label class="24">岐阜</label>
</th>
<td>
<p>
<label><input type="checkbox" name="area" value="40">美濃(岐阜)</label><span class="grayOut">ｌ</span>
<label><input type="checkbox" name="area" value="41">飛騨(高山)</label>
</p>
</td>
</tr>
<tr>
<th>
<label class="25">静岡</label>
</th>
<td>
<p>
<label><input type="checkbox" name="area" value="34">中部(静岡)</label><span class="grayOut">ｌ</span>
<label><input type="checkbox" name="area" value="35">伊豆(網代)</label><span class="grayOut">ｌ</span>
<label><input type="checkbox" name="area" value="36">東部(三島)</label><span class="grayOut">ｌ</span>
<label><input type="checkbox" name="area" value="37">西部(浜松)</label>
</p>
</td>
</tr>
<tr>
<th>
<label class="27">三重</label>
</th>
<td>
<p>
<label><input type="checkbox" name="area" value="42">北中部(津)</label><span class="grayOut">ｌ</span>
<label><input type="checkbox" name="area" value="43">南部(尾鷲)</label>
</p>
</td>
</tr>
</tr>
<tr>
<th abbr="近畿" rowspan="6"><label class="6">近畿</label></th>
<th>
<label class="30">大阪</label>
</th>
<td>
<p>
<label><input type="checkbox" name="area" value="81">大阪</label>
</p>
</td>
<tr>
<th>
<label class="31">兵庫</label>
</th>
<td>
<p>
<label><input type="checkbox" name="area" value="82">南部(神戸)</label><span class="grayOut">ｌ</span>
<label><input type="checkbox" name="area" value="83">北部(豊岡)</label>
</p>
</td>
</tr>
<tr>
<th>
<label class="29">京都</label>
</th>
<td>
<p>
<label><input type="checkbox" name="area" value="79">南部(京都)</label><span class="grayOut">ｌ</span>
<label><input type="checkbox" name="area" value="80">北部(舞鶴)</label>
</p>
</td>
</tr>
<tr>
<th>
<label class="28">滋賀</label>
</th>
<td>
<p>
<label><input type="checkbox" name="area" value="77">南部(大津)</label><span class="grayOut">ｌ</span>
<label><input type="checkbox" name="area" value="78">北部(彦根)</label>
</p>
</td>
</tr>
<tr>
<th>
<label class="32">奈良</label>
</th>
<td>
<p>
<label><input type="checkbox" name="area" value="84">北部(奈良)</label><span class="grayOut">ｌ</span>
<label><input type="checkbox" name="area" value="85">南部(風屋)</label>
</p>
</td>
</tr>
<tr>
<th>
<label class="33">和歌山</label>
</th>
<td>
<p>
<label><input type="checkbox" name="area" value="86">北部(和歌山)</label><span class="grayOut">ｌ</span>
<label><input type="checkbox" name="area" value="87">南部(潮岬)</label>
</p>
</td>
</tr>
</tr>
<tr>
<th abbr="中国" rowspan="5"><label class="7">中国</label></th>
<th>
<label class="34">鳥取</label>
</th>
<td>
<p>
<label><input type="checkbox" name="area" value="95">東部(鳥取)</label><span class="grayOut">ｌ</span>
<label><input type="checkbox" name="area" value="96">中・西部(米子)</label>
</p>
</td>
<tr>
<th>
<label class="35">島根</label>
</th>
<td>
<p>
<label><input type="checkbox" name="area" value="92">東部(松江)</label><span class="grayOut">ｌ</span>
<label><input type="checkbox" name="area" value="93">西部(浜田)</label><span class="grayOut">ｌ</span>
<label><input type="checkbox" name="area" value="94">隠岐(西郷)</label>
</p>
</td>
</tr>
<tr>
<th>
<label class="36">岡山</label>
</th>
<td>
<p>
<label><input type="checkbox" name="area" value="88">南部(岡山)</label><span class="grayOut">ｌ</span>
<label><input type="checkbox" name="area" value="89">北部(津山)</label>
</p>
</td>
</tr>
<tr>
<th>
<label class="37">広島</label>
</th>
<td>
<p>
<label><input type="checkbox" name="area" value="90">南部(広島)</label><span class="grayOut">ｌ</span>
<label><input type="checkbox" name="area" value="91">北部(庄原)</label>
</p>
</td>
</tr>
<tr>
<th>
<label class="38">山口</label>
</th>
<td>
<p>
<label><input type="checkbox" name="area" value="97">西部(下関)</label><span class="grayOut">ｌ</span>
<label><input type="checkbox" name="area" value="98">中部(山口)</label><span class="grayOut">ｌ</span>
<label><input type="checkbox" name="area" value="99">東部(柳井)</label><span class="grayOut">ｌ</span>
<label><input type="checkbox" name="area" value="100">北部(萩)</label>
</p>
</td>
</tr>
</tr>
<tr>
<th abbr="四国" rowspan="4"><label class="8">四国</label></th>
<th>
<label class="39">徳島</label>
</th>
<td>
<p>
<label><input type="checkbox" name="area" value="101">北部(徳島)</label><span class="grayOut">ｌ</span>
<label><input type="checkbox" name="area" value="102">南部(日和佐)</label>
</p>
</td>
<tr>
<th>
<label class="40">香川</label>
</th>
<td>
<p>
<label><input type="checkbox" name="area" value="103">高松</label>
</p>
</td>
</tr>
<tr>
<th>
<label class="41">愛媛</label>
</th>
<td>
<p>
<label><input type="checkbox" name="area" value="104">中予(松山)</label><span class="grayOut">ｌ</span>
<label><input type="checkbox" name="area" value="105">東予(新居浜)</label><span class="grayOut">ｌ</span>
<label><input type="checkbox" name="area" value="106">南予(宇和島)</label>
</p>
</td>
</tr>
<tr>
<th>
<label class="42">高知</label>
</th>
<td>
<p>
<label><input type="checkbox" name="area" value="107">中部(高知)</label><span class="grayOut">ｌ</span>
<label><input type="checkbox" name="area" value="108">東部(室戸岬)</label><span class="grayOut">ｌ</span>
<label><input type="checkbox" name="area" value="109">西部(清水)</label>
</p>
</td>
</tr>
</tr>
<tr>
<th abbr="九州" rowspan="7"><label class="9">九州</label></th>
<th>
<label class="43">福岡</label>
</th>
<td>
<p>
<label><input type="checkbox" name="area" value="110">福岡</label><span class="grayOut">ｌ</span>
<label><input type="checkbox" name="area" value="111">北九州(八幡)</label><span class="grayOut">ｌ</span>
<label><input type="checkbox" name="area" value="112">筑豊(飯塚)</label><span class="grayOut">ｌ</span>
<label><input type="checkbox" name="area" value="113">筑後(久留米)</label>
</p>
</td>
<tr>
<th>
<label class="44">佐賀</label>
</th>
<td>
<p>
<label><input type="checkbox" name="area" value="122">南部(佐賀)</label><span class="grayOut">ｌ</span>
<label><input type="checkbox" name="area" value="123">北部(伊万里)</label>
</p>
</td>
</tr>
<tr>
<th>
<label class="45">長崎</label>
</th>
<td>
<p>
<label><input type="checkbox" name="area" value="118">南部(長崎)</label><span class="grayOut">ｌ</span>
<label><input type="checkbox" name="area" value="119">北部(佐世保)</label><span class="grayOut">ｌ</span>
<label><input type="checkbox" name="area" value="120">壱岐・対馬(厳原)</label><span class="grayOut">ｌ</span>
<label><input type="checkbox" name="area" value="121">五島(福江)</label>
</p>
</td>
</tr>
<tr>
<th>
<label class="46">熊本</label>
</th>
<td>
<p>
<label><input type="checkbox" name="area" value="124">熊本</label><span class="grayOut">ｌ</span>
<label><input type="checkbox" name="area" value="125">阿蘇(阿蘇乙姫)</label><span class="grayOut">ｌ</span>
<label><input type="checkbox" name="area" value="126">天草・芦北(牛深)</label><span class="grayOut">ｌ</span>
<label><input type="checkbox" name="area" value="127">球磨(人吉)</label>
</p>
</td>
</tr>
<tr>
<th>
<label class="47">大分</label>
</th>
<td>
<p>
<label><input type="checkbox" name="area" value="114">中部(大分)</label><span class="grayOut">ｌ</span>
<label><input type="checkbox" name="area" value="115">北部(中津)</label><span class="grayOut">ｌ</span>
<label><input type="checkbox" name="area" value="116">西部(日田)</label><span class="grayOut">ｌ</span>
<label><input type="checkbox" name="area" value="117">南部(佐伯)</label>
</p>
</td>
</tr>
<tr>
<th>
<label class="48">宮崎</label>
</th>
<td>
<p>
<label><input type="checkbox" name="area" value="128">南部平野部(宮崎)</label><span class="grayOut">ｌ</span>
<label><input type="checkbox" name="area" value="129">北部平野部(延岡)</label><span class="grayOut">ｌ</span>
<label><input type="checkbox" name="area" value="130">南部山沿い(都城)</label><span class="grayOut">ｌ</span>
<label><input type="checkbox" name="area" value="131">北部山沿い(高千穂)</label>
</p>
</td>
</tr>
<tr>
<th>
<label class="49">鹿児島</label>
</th>
<td>
<p>
<label><input type="checkbox" name="area" value="132">薩摩(鹿児島)</label><span class="grayOut">ｌ</span>
<label><input type="checkbox" name="area" value="133">大隅(鹿屋)</label><span class="grayOut">ｌ</span>
<label><input type="checkbox" name="area" value="134">種子島・屋久島</label><span class="grayOut">ｌ</span>
<label><input type="checkbox" name="area" value="135">奄美(名瀬)</label>
</p>
</td>
</tr>
</tr>
<tr>
<th abbr="沖縄" ><label class="10">沖縄</label></th>
<th>
<label class="50">沖縄</label>
</th>
<td>
<p>
<label><input type="checkbox" name="area" value="136">本島中南部(那覇)</label><span class="grayOut">ｌ</span>
<label><input type="checkbox" name="area" value="137">本島北部(名護)</label><span class="grayOut">ｌ</span>
<label><input type="checkbox" name="area" value="138">久米島</label><span class="grayOut">ｌ</span>
<label><input type="checkbox" name="area" value="139">大東島</label><span class="grayOut">ｌ</span>
<label><input type="checkbox" name="area" value="140">宮古島</label><span class="grayOut">ｌ</span>
<label><input type="checkbox" name="area" value="141">石垣島</label><span class="grayOut">ｌ</span>
<label><input type="checkbox" name="area" value="142">与那国島</label>
</p>
</td>
</tr>
</table>
<button onclick="city_set();">設定</button>
<div id="page_footer" style="clear:left;margin:20px 0;">
<a href="http://ok2nd.web.fc2.com/" target="_blank" style="color:#8080ff; font-size: 12px;">Powered by ok.2nd</a>
</div>
</body>
</html>
