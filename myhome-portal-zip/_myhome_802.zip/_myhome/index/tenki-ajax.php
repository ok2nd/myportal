<?php
	require("../__common__/__define_common.php");
	require("../__common__/include-common-all.php");
	$city = $_GET['city'];
/*
	<item>
	<title>[ 01日（日）の天気 ] 東京 - 晴れ - 最高気温33℃ - 6月1日(日)</title>
	<link>
	http://weather.livedoor.com/area/forecast/130010?r=rss20140601
	</link>
	<category>天気予報</category>
	<day>Sunday</day>
	<image>
	<title/>
	<link>
	http://weather.livedoor.com/area/forecast/130010?r=rss20140601
	</link>
	<url>http://weather.livedoor.com/img/icon/1.gif</url>
	<width>50</width>
	<height>31</height>
	</image>
	<description>01日（日）の天気は晴れ、最高気温は33℃ でしょう。</description>
	<pubDate>Sun, 01 Jun 2014 05:00:00 +0900</pubDate>
	</item>
*/
	$url = 'http://weather.livedoor.com/forecast/rss/area/'.$city.'.xml';
	$rss = my_simplexml_load_file($url);
	$row1 = '';
	$row2 = '';
	$row3 = '';
	$ix = false;
	foreach ($rss->channel->item as $item) {
		if ($ix) {		// PRスキップ
			$title = explode(' ', $item->title);
			$date = explode('の', $title[1]);
			$ondo = get_intag($item->title, '最高気温', '℃', $pos=0);
			$saitei_kion = get_intag($item->description, '最低気温は', '℃', $pos=0);
			if ($saitei_kion == '') {
				$saitei_kion = '---';
			} else {
				$saitei_kion .= '℃';
			}
			$row1 .= '<th>'.$date[0].'</th>';
			$row2 .= '<td><img src="'.$item->image->url.'"></td>';
			$row3 .= '<td><span class="high">'.$ondo.'℃</span> <span class="low">'.$saitei_kion.'</span></td>';
		}
		$ix = true;
	}
?>
<table class="tenki_city">
	<tr><?= $row1 ?></tr>
	<tr><?= $row2 ?></tr>
	<tr><?= $row3 ?></tr>
</table>
