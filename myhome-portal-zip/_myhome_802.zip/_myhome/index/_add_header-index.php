<script src="../scripts/jquery.autocomplete_my.js"></script>
<script src="../scripts/addclear.js"></script>
<link rel="stylesheet" href="../scripts/jquery.autocomplete.css?20110824">
<script>
function suggest(sw) {
	suggest_sw = sw;
	$.cookie("index_suggestOnOff",sw,{ path:'<?= MY_SESSION_PATH ?>', expires:365 });
	if (sw == 'off') {
		alt_sw = 'on';
	} else {
		alt_sw = 'off';
	}
	$("#suggest_"+sw).css("display","");
	$("#suggest_"+alt_sw).css("display","none");
	document.getElementById("search_str").focus();
}
$(document).ready(function(){
	$('#search_str').autocomplete('google-suggest.php');
	$('#search_str').addClear();
});
</script>
