<?php
	require("../__common__/__define_common.php");
	require("../__common__/include-common-all.php");
	require("../tools/__include-common-code-file.php");
	my_session_start();
	require("../account/__logincheck.php");
	if ($_SESSION['システム管理者'] <> "YES") {
		exit;
	}
	if ($_GET['ret'].'' == '') {
		$ret_php = 'list-url.php';
	} else {
		$ret_php = $_GET['ret'];
	}
	if ($_GET['path'].'' == '') {
		error_simple_html('エラー', 'パス指定がありません。');
	}
	$src_path = my_GET('path');
	$src_path = right_slash_strip($src_path);
	if (myfile_is_dir($src_path)) {
		$dst_path = copy_folder_name($src_path);
		if (@copy_folder($src_path, $dst_path) == False) {
			error_simple_html('フォルダコピーエラー', 'フォルダ['.$src_path.']のコピーに失敗しました。');
		}
	}
	header("Location: ".$ret_php."?path=".urlencode(up_folder_path($src_path)));
function copy_folder_name($src_path, $num='') {
	$dst_path = $src_path.'-COPY'.strval($num);
	if (myfile_is_dir($dst_path)) {
		if ($num == '') $num = 1;
		$dst_path = copy_folder_name($src_path, ++$num);
	}
	return $dst_path;
}
function copy_folder($src_path, $dst_path) {
	if (myfile_is_dir($src_path) && ($fp = myfile_opendir($src_path))) {
		if (!myfile_is_dir($dst_path)) myfile_mkdir($dst_path);
		if ($fp = myfile_opendir($src_path)) {
			while ($file = readdir($fp)) {
				if ($file != '.' && $file != '..') {
					$srcfile = $src_path.'/'.myfile_DECODE($file);
					$dstfile = $dst_path.'/'.myfile_DECODE($file);
					if (myfile_is_file($srcfile)) {
						myfile_copy($srcfile, $dstfile);
					} else if (myfile_is_dir($srcfile)) {
						copy_folder($srcfile, $dstfile);
					}
				}
			}
			closedir($fp);
		}
		return true;
	} else {
		return false;
	}
}
?>
