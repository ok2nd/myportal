<?php
function list_data($rec) {
?>
	<tr class="index_list<?= $rec['c_privacy'] == 444 ? ' index_list_privacy' : '' ?>">
	<td class="index_list_category" style="color: <?= $rec['c_categoryDisplayColor'] ?>;">
		<?= $rec['c_categoryName'] ?>
	</td>
<?php	if ($_COOKIE['index_list_capture'] <> 'none') { ?>
	<td class="index_list_capture">
	<?php	if ( $rec['c_url'] <> '') { ?>
		<a href="<?= my_htmlspecialchars($rec['c_url']) ?>" target="_blank"><img src="<?= index_CAPTURE_CREATE_SITE ?><?= my_htmlspecialchars($rec['c_url']) ?>"></a>
	<?php	} ?>
	</td>
<?php	} ?>
	<td class="index_list_homepage">
		<p class="index_list_title"><a href="<?= my_htmlspecialchars($rec['c_url']) ?>" target="_blank"><?= my_htmlspecialchars($rec['c_title']) ?></a>
		<? if (check_permit_id($_SESSION['login_id'], $_SESSION['current_id']) == "w") { ?>
		<a class="a_update_form" href="javascript:popup_edit('<?= $rec['id_homepage'] ?>')">[修正]</a>
		<a class="a_update_form" href="javascript:popup_delete('<?= $rec['id_homepage'] ?>','<?= my_htmlspecialchars($rec['c_title']) ?>')">[削除]</a>
		<? } ?>
</p>
		<p class="index_list_url"><?= my_htmlspecialchars($rec['c_url']) ?></p>
	<?php if ($rec['c_html'] <> '') { ?>
		<div style="float: left;"><?= $rec['c_html'] ?></div>
	<?php } ?>
	</td>
	</tr>
<?php
}
?>
