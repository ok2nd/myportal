<?php
	require("__include-common.php");
	require("../account/__logincheck.php");
	$con = my_mysqli_connect(_DB_SCHEMA);
	$sql = "select * from m_memo where id_account = ".$_SESSION['login_id']."";
	$rs = my_mysqli_query($sql);
	if (mysqli_num_rows($rs) == 0) {
		$sql = "insert into m_memo ";
		$sql .= "(id_account";
		$sql .= ", c_memo";
		$sql .= ") values (";
		$sql .= "'".$_SESSION['login_id']."'";
		$sql .= ", '".post_to_mysql("c_memo")."'";
		$sql .= ")";
		$ret = my_mysqli_query($sql, "登録できませんでした。");
	} else {
		$rec = mysqli_fetch_array($rs);
		$sql = "update m_memo set";
		$sql .= " c_memo = '".post_to_mysql("c_memo")."'";
		$sql .= ", c_updatetime = '". date("Y/m/d H:i:s") . "'";
		$sql .= " where id_account = ".$_SESSION['login_id']."";
		$ret = my_mysqli_query($sql, "更新できませんでした。");
	}
?>
