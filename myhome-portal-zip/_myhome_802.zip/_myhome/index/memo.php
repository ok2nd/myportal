<?php
	require("__include-common.php");
	require("../account/__logincheck.php");
	if (!defined('simple_memo_FONT_SIZE_SELECT')) {
		define('simple_memo_FONT_SIZE_SELECT', '10,11,12,13,14,15,16,18,20,24,28,30,36,48');
		define('simple_memo_FONT_SIZE_DEFAULT', '14');
	}
	if (!defined('simple_memo_FONT_FAMILY_SELECT')) {
		define('simple_memo_FONT_FAMILY_SELECT', 'ＭＳ Ｐゴシック,ＭＳ ゴシック,ＭＳ Ｐ明朝,ＭＳ 明朝,MS UI Gothic,メイリオ');
		define('simple_memo_FONT_FAMILY_DEFAULT', 'ＭＳ Ｐゴシック');
	}
	if ($_COOKIE['simple_memo_fontSize'].'' <> '') {
		$fontSize = $_COOKIE['simple_memo_fontSize'];
	} else {
		$fontSize = simple_memo_FONT_SIZE_DEFAULT;
	}
	if ($_COOKIE['simple_memo_fontFamily'].'' <> '') {
		$fontFamily = $_COOKIE['simple_memo_fontFamily'];
	} else {
		$fontFamily = simple_memo_FONT_FAMILY_DEFAULT;
	}
	$con = my_mysqli_connect(_DB_SCHEMA);
	$sql = "select * from m_memo where id_account = ".$_SESSION['login_id']."";
	$rs = my_mysqli_query($sql);
	if (mysqli_num_rows($rs) > 0) {
		$rec = mysqli_fetch_array($rs);
		$memo = my_htmlspecialchars($rec['c_memo']);
	} else {
		$memo = '';
	}
?>
<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="utf-8">
<meta name="author" content="ok.2nd">
<meta name="description" content="Memo">
<meta name="keywords" content="memo">
<style>
body {
	font-family: "MS PGothic",Osaka,Arial,sans-serif;
	font-size: 12px;
	background: #e8e8e8;
}
form#memo_form {
	width: 95%;
}
a.return_index { font-size: 12px; text-decoration: none; font-weight: normal; }
a.return_index:link { color: #808080; }
a.return_index:visited { color: #808080; }
a.return_index:hover { color: #ffc080; }
a.return_index:active { color: #ffc080; }
a.popup_suggest { color: #ff8c00; font-weight: normal; font-size: 72%; margin: 0 2px; }
</style>
<style>
textarea, .textareaClone {
	margin: 3px 0 3px 5px;
	min-height: 40em;
	width: 100%;
	font-size: <?= $fontSize ?>px;
	font-family: "ＭＳ Ｐゴシック","Osaka",sans-serif;
	padding: 5px;
}
</style>
<link rel="stylesheet" href="../scripts/jquery.autocomplete.css?20110824">
<script src="../scripts/jquery.js"></script>
<script src="../scripts/jquery.cookie.js"></script>
<script src="../scripts/jquery.textarea.js"></script>
<script src="../scripts/ExpandingTextareas/expanding.js"></script>
<script src="../scripts/jquery.autocomplete_my.js"></script>
<script>
function MemoSave() {
	var memo = $('#c_memo').val();
	$('#c_memo_save').val($('#c_memo').val());
	var data = {c_memo:memo};
	$.ajax({
		type: "POST",
		url: "memo-update.php",
		data: data,
		async: false
	});
}
function MemoReset() {
	$('#c_memo').val($('#c_memo_save').val());
}
function fontSizeChange() {
	var fontSize = $("#fontSize").val();
	$("#c_memo").css("font-size", fontSize+"px");
	$.cookie("simple_memo_fontSize",fontSize,{path:'<?= MY_SESSION_PATH ?>', expires:365});
}
function fontFamilyChange() {
	var fontFamily = $("#fontFamily").val();
	$("#c_memo").css("font-family", fontFamily+',Osaka,sans-serif');
	$.cookie("simple_memo_fontFamily",fontFamily,{path:'<?= MY_SESSION_PATH ?>', expires:365});
}
</script>
<script>
var suggest_sw = 'on';
$(document).ready(function(){
	$('#search_str').autocomplete('google-suggest.php');
});
</script>
<script>
$(function() {
	$('textarea#c_memo').tabby();
});
</script>
<script>
function popup_suggest() {
	w01 = window.open("popup-suggest.php","","toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes,width=270,height=280");
}
</script>
<title>Simple Memo</title>
</head>
<body onload="document.form0.c_memo.focus()">
<form name="form0" id="memo_form">
<a href="javascript:window.close()"><img src="../icon/pencil.png" style="height:11px;margin-left:5px;border:0;"></a>
<input type="button" value="保存" onClick="MemoSave()" style="margin-left:10px;">
<input type="button" value="保存後の状態にリセット" onClick="MemoReset()" style="margin:0 5px;">
予測変換：<a href='javascript:popup_suggest()' class='popup_suggest'>↑</a><input class="text" type="text" id="search_str" style="width:180px;margin-right:5px;">
フォントサイズ：<select id="fontSize" onchange="fontSizeChange()">
<?php
	$keyary = explode(",", simple_memo_FONT_SIZE_SELECT);
	foreach ($keyary as $keytmp) {
?>
	<option value="<?= $keytmp ?>"<?= $fontSize == $keytmp ? " selected" : "" ?>><?= $keytmp ?>ポイント
<?php
	}
?>
	</select>
フォント種類：<select id="fontFamily" onchange="fontFamilyChange()">
<?php
	$keyary = explode(",", simple_memo_FONT_FAMILY_SELECT);
	foreach ($keyary as $keytmp) {
?>
	<option value="<?= $keytmp ?>"<?= $fontFamily == $keytmp ? " selected" : "" ?>><?= $keytmp ?>
<?php
	}
?>
	</select>
<textarea id="c_memo" class="expanding" wrap="soft"><?= $memo ?></textarea><br>
<input type="button" value="保存" onClick="MemoSave()" style="margin-left:20px;">
<input type="button" value="保存後の状態にリセット" onClick="MemoReset()" style="margin:0 10px;">
&nbsp;<br>
<input id="c_memo_save" type="hidden" value="<?= $memo ?>">
</form>
</body>
</html>
