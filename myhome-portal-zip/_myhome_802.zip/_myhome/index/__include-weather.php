<?php
function gadget_weather() {
	require(WEATHER_CITY_DEFINE);
?>
<script src="../scripts/prototype.js"></script>
<form>
	<a href="<?= LINK_WEATHER_SITE ?>" target="_blank">天気</a>：</font>
	<div id="tenkiCity" style="display:inline;">
		<select id="cityNo" onchange="weatherSet()">
	<?php
		foreach ($city_tbl as $city) {
	?>
			<option value="<?= $city[1] ?>"<?= $city[1] == WEATHER_MY_CITY_NO ? ' selected' : '' ?>><?= $city[0] ?>
	<?php
		}
	?>
		</select>
	</div>
	<div id="tenki" style="display:inline;">
		<table id="weather_box">
		<tr>
			<td>今日</td>
			<td>明日</td>
			<td>明後日</td>
		</tr>
		<tr>
			<td><img src="../images/none.gif" id="todayP"></td>
			<td><img src="../images/none.gif" id="tomorrowP"></td>
			<td><img src="../images/none.gif" id="dayafterP"></td>
		</tr>
		</table>
	</div>
</form>
<?php
}
?>
<script>
function weatherSet() {
	getWeather("today","todayP");
	getWeather("tomorrow","tomorrowP");
	getWeather("dayaftertomorrow","dayafterP");
}
function getWeather(aDay, pData) {
	city = $("cityNo").value;
	//sURL = "http://weather.livedoor.com/forecast/webservice/rest/v1?city="+city+"&day="+aDay;
	sURL = "get_weather_livedoor.php?city="+city+"&day="+aDay;
	new Ajax.Request(sURL, { method: "get", onComplete:
		function(httpObj)
		{
			XML = httpObj.responseXML;
			var imgTag = XML.getElementsByTagName("image")[0];
			$(pData).src = imgTag.getElementsByTagName("url")[0].firstChild.nodeValue;
		}
	});
}
</script>
