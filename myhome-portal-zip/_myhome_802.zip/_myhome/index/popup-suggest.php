<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="utf-8">
<meta name="author" content="ok.2nd">
<style>
body {
	margin: 10px;
	font-family: "MS PGothic",Osaka,Arial,sans-serif;
	font-size: 12px;
	background: #fff;
}
</style>
<link rel="stylesheet" href="../scripts/jquery.autocomplete.css?20110824">
<script src="../scripts/jquery.js"></script>
<script src="../scripts/jquery.autocomplete_my.js"></script>
<script>
var suggest_sw = 'on';
$(document).ready(function(){
	$('#search_str').autocomplete('google-suggest.php');
});
</script>
<title>予測変換</title>
</head>
<body onload="document.form0.text.focus()">
<form name="form0" id="memo_form">
<input class="text" type="text" name="text" id="search_str" style="width:240px;">
</form>
</body>
</html>
