<?php
	require("../__common__/__define_common.php");
	require("../__common__/include-common-all.php");
	if (!defined("TENKI_TYPHOON_IMAGE")) {
		define("TENKI_TYPHOON_IMAGE", "http://az416740.vo.msecnd.net/static-images/typhoon/recent_entry/japan_near-large.jpg");	// 台風画像
	}
	if ($_COOKIE['tenki_yohou_city_list'].'' == '') {
		redirect('tenki-set.php');
	}
	$city_list = $_COOKIE['tenki_yohou_city_list'];
	$city_name = array();
	$city_name[1] = array('道北 宗谷地方', '稚内', '011000');
	$city_name[2] = array('道北 上川地方', '旭川', '012010');
	$city_name[3] = array('道北 留萌地方', '留萌', '012020');
	$city_name[4] = array('道央 石狩地方', '札幌', '016010');
	$city_name[5] = array('道央 空知地方', '岩見沢', '016020');
	$city_name[6] = array('道央 後志地方', '倶知安', '016030');
	$city_name[7] = array('道東 網走地方', '網走', '013010');
	$city_name[8] = array('道東 北見地方', '北見', '013020');
	$city_name[9] = array('道東 紋別地方', '紋別', '013030');
	$city_name[10] = array('道東 根室地方', '根室', '014010');
	$city_name[11] = array('道東 釧路地方', '釧路', '014020');
	$city_name[12] = array('道東 十勝地方', '帯広', '014030');
	$city_name[13] = array('道南 胆振地方', '室蘭', '015010');
	$city_name[14] = array('道南 日高地方', '浦河', '015020');
	$city_name[15] = array('道南 渡島地方', '函館', '017010');
	$city_name[16] = array('道南 檜山地方', '江差', '017020');
	$city_name[17] = array('青森県 津軽', '青森', '020010');
	$city_name[18] = array('青森県 下北', 'むつ', '020020');
	$city_name[19] = array('青森県 三八上北', '八戸', '020030');
	$city_name[20] = array('秋田県 沿岸', '秋田', '050010');
	$city_name[21] = array('秋田県 内陸', '横手', '050020');
	$city_name[22] = array('岩手県 内陸', '盛岡', '030010');
	$city_name[23] = array('岩手県 沿岸北部', '宮古', '030020');
	$city_name[24] = array('岩手県 沿岸南部', '大船渡', '030030');
	$city_name[25] = array('宮城県 東部', '仙台', '040010');
	$city_name[26] = array('宮城県 西部', '白石', '040020');
	$city_name[27] = array('山形県 村山', '山形', '060010');
	$city_name[28] = array('山形県 置賜', '米沢', '060020');
	$city_name[29] = array('山形県 庄内', '酒田', '060030');
	$city_name[30] = array('山形県 最上', '新庄', '060040');
	$city_name[31] = array('福島県 中通り', '福島', '070010');
	$city_name[32] = array('福島県 浜通り', '小名浜', '070020');
	$city_name[33] = array('福島県 会津', '若松', '070030');
	$city_name[34] = array('静岡県 中部', '静岡', '220010');
	$city_name[35] = array('静岡県 伊豆', '網代', '220020');
	$city_name[36] = array('静岡県 東部', '三島', '220030');
	$city_name[37] = array('静岡県 西部', '浜松', '220040');
	$city_name[38] = array('愛知県 西部', '名古屋', '230010');
	$city_name[39] = array('愛知県 東部', '豊橋', '230020');
	$city_name[40] = array('岐阜県 美濃地方', '岐阜', '210010');
	$city_name[41] = array('岐阜県 飛騨地方', '高山', '210020');
	$city_name[42] = array('三重県 北中部', '津', '240010');
	$city_name[43] = array('三重県 南部', '尾鷲', '240020');
	$city_name[44] = array('富山県 東部', '富山', '160010');
	$city_name[45] = array('富山県 西部', '伏木', '160020');
	$city_name[46] = array('石川県 加賀', '金沢', '170010');
	$city_name[47] = array('石川県 能登', '輪島', '170020');
	$city_name[48] = array('福井県 嶺北', '福井', '180010');
	$city_name[49] = array('福井県 嶺南', '敦賀', '180020');
	$city_name[50] = array('新潟県 下越', '新潟', '150010');
	$city_name[51] = array('新潟県 中越', '長岡', '150020');
	$city_name[52] = array('新潟県 上越', '高田', '150030');
	$city_name[53] = array('新潟県 佐渡', '相川', '150040');
	$city_name[54] = array('茨城県 北部', '水戸', '080010');
	$city_name[55] = array('茨城県 南部', '土浦', '080020');
	$city_name[56] = array('栃木県 南部', '宇都宮', '090010');
	$city_name[57] = array('栃木県 北部', '大田原', '090020');
	$city_name[58] = array('群馬県 南部', '前橋', '100010');
	$city_name[59] = array('群馬県 北部', 'みなかみ', '100020');
	$city_name[60] = array('埼玉県 南部', 'さいたま', '110010');
	$city_name[61] = array('埼玉県 北部', '熊谷', '110020');
	$city_name[62] = array('埼玉県 秩父地方', '秩父', '110030');
	$city_name[63] = array('東京都 東京地方', '東京', '130010');
	$city_name[64] = array('東京都 伊豆諸島北部', '大島', '130020');
	$city_name[65] = array('東京都 伊豆諸島南部', '八丈島', '130030');
	$city_name[66] = array('東京都 小笠原諸島', '父島', '130040');
	$city_name[67] = array('千葉県 北西部', '千葉', '120010');
	$city_name[68] = array('千葉県 北東部', '銚子', '120020');
	$city_name[69] = array('千葉県 南部', '館山', '120030');
	$city_name[70] = array('神奈川県 東部', '横浜', '140010');
	$city_name[71] = array('神奈川県 西部', '小田原', '140020');
	$city_name[72] = array('長野県 北部', '長野', '200010');
	$city_name[73] = array('長野県 中部', '松本', '200020');
	$city_name[74] = array('長野県 南部', '飯田', '200030');
	$city_name[75] = array('山梨県 中・西部', '甲府', '190010');
	$city_name[76] = array('山梨県 東部・富士五湖', '河口湖', '190020');
	$city_name[77] = array('滋賀県 南部', '大津', '250010');
	$city_name[78] = array('滋賀県 北部', '彦根', '250020');
	$city_name[79] = array('京都府 南部', '京都', '260010');
	$city_name[80] = array('京都府 北部', '舞鶴', '260020');
	$city_name[81] = array('大阪府 大阪', '大阪', '270000');
	$city_name[82] = array('兵庫県 南部', '神戸', '280010');
	$city_name[83] = array('兵庫県 北部', '豊岡', '280020');
	$city_name[84] = array('奈良県 北部', '奈良', '290010');
	$city_name[85] = array('奈良県 南部', '風屋', '290020');
	$city_name[86] = array('和歌山県 北部', '和歌山', '300010');
	$city_name[87] = array('和歌山県 南部', '潮岬', '300020');
	$city_name[88] = array('岡山県 南部', '岡山', '330010');
	$city_name[89] = array('岡山県 北部', '津山', '330020');
	$city_name[90] = array('広島県 南部', '広島', '340010');
	$city_name[91] = array('広島県 北部', '庄原', '340020');
	$city_name[92] = array('島根県 東部', '松江', '320010');
	$city_name[93] = array('島根県 西部', '浜田', '320020');
	$city_name[94] = array('島根県 隠岐', '西郷', '320030');
	$city_name[95] = array('鳥取県 東部', '鳥取', '310010');
	$city_name[96] = array('鳥取県 中・西部', '米子', '310020');
	$city_name[97] = array('山口県 西部', '下関', '350010');
	$city_name[98] = array('山口県 中部', '山口', '350020');
	$city_name[99] = array('山口県 東部', '柳井', '350030');
	$city_name[100] = array('山口県 北部', '萩', '350040');
	$city_name[101] = array('徳島県 北部', '徳島', '360010');
	$city_name[102] = array('徳島県 南部', '日和佐', '360020');
	$city_name[103] = array('香川県 高松', '高松', '370000');
	$city_name[104] = array('愛媛県 中予', '松山', '380010');
	$city_name[105] = array('愛媛県 東予', '新居浜', '380020');
	$city_name[106] = array('愛媛県 南予', '宇和島', '380030');
	$city_name[107] = array('高知県 中部', '高知', '390010');
	$city_name[108] = array('高知県 東部', '室戸岬', '390020');
	$city_name[109] = array('高知県 西部', '清水', '390030');
	$city_name[110] = array('福岡県 福岡地方', '福岡', '400010');
	$city_name[111] = array('福岡県 北九州地方', '八幡', '400020');
	$city_name[112] = array('福岡県 筑豊地方', '飯塚', '400030');
	$city_name[113] = array('福岡県 筑後地方', '久留米', '400040');
	$city_name[114] = array('大分県 中部', '大分', '440010');
	$city_name[115] = array('大分県 北部', '中津', '440020');
	$city_name[116] = array('大分県 西部', '日田', '440030');
	$city_name[117] = array('大分県 南部', '佐伯', '440040');
	$city_name[118] = array('長崎県 南部', '長崎', '420010');
	$city_name[119] = array('長崎県 北部', '佐世保', '420020');
	$city_name[120] = array('長崎県 壱岐・対馬', '厳原', '420030');
	$city_name[121] = array('長崎県 五島', '福江', '420040');
	$city_name[122] = array('佐賀県 南部', '佐賀', '410010');
	$city_name[123] = array('佐賀県 北部', '伊万里', '410020');
	$city_name[124] = array('熊本県 熊本地方', '熊本', '430010');
	$city_name[125] = array('熊本県 阿蘇地方', '阿蘇乙姫', '430020');
	$city_name[126] = array('熊本県 天草・芦北地方', '牛深', '430030');
	$city_name[127] = array('熊本県 球磨地方', '人吉', '430040');
	$city_name[128] = array('宮崎県 南部平野部', '宮崎', '450010');
	$city_name[129] = array('宮崎県 北部平野部', '延岡', '450020');
	$city_name[130] = array('宮崎県 南部山沿い', '都城', '450030');
	$city_name[131] = array('宮崎県 北部山沿い', '高千穂', '450040');
	$city_name[132] = array('鹿児島県 薩摩地方', '鹿児島', '460010');
	$city_name[133] = array('鹿児島県 大隅地方', '鹿屋', '460020');
	$city_name[134] = array('鹿児島県 種子島・屋久島地方', '種子島', '460030');
	$city_name[135] = array('鹿児島県 奄美地方', '名瀬', '460040');
	$city_name[136] = array('沖縄県 本島中南部', '那覇', '471010');
	$city_name[137] = array('沖縄県 本島北部', '名護', '471020');
	$city_name[138] = array('沖縄県 久米島', '久米島', '471030');
	$city_name[139] = array('沖縄県 大東島地方', '南大東島', '472000');
	$city_name[140] = array('沖縄県 宮古島地方', '宮古島', '473000');
	$city_name[141] = array('沖縄県 石垣島地方', '石垣島', '474010');
	$city_name[142] = array('沖縄県 与那国島地方', '与那国島', '474020');
?>
<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="utf-8">
<meta name="author" content="ok.2nd">
<meta name="description" content="週間天気予報">
<link rel="shortcut icon" href="icon/tenki.ico" type="image/ico">
<style>
img { border: 0; }
a { text-decoration: underline; font-weight: normal; }
a:link { color: #2128e0; font-weight: normal; }
a:visited { color: #2128e0; font-weight: normal; }
a:hover { color: #f43316; font-weight: normal; background-color: #ffffc0; }
a:active { color: #f43316; font-weight: normal; background-color: #ffffc0; }
body {
	margin: 10px;
	background: #fff;
}
h1 {
	font-size: 16px;
}
table#list_box {
	border-spacing: 0px;
	border-collapse: collapse;
	margin: 0;
	padding: 0;
}
td.city_name {
	padding: 4px;
	text-align: right;
	vertical-align: middle;
	font-size: 12px;
	border: none;
}
td.tenki_yohou {
	margin: 0px;
	padding: 4px;
}
table.tenki_city {
	margin: 0;
	padding: 0;
	border-spacing: 0px;
	border-collapse: collapse;
}
table.tenki_city th {
	text-align: center;
	font-size: 12px;
	background: #eee;
	padding: 4px 2px;
	border: solid 1px #a0a0a0;
}
table.tenki_city td {
	width: 60px;
	text-align: center;
	font-size: 12px;
	padding: 2px;
	border: solid 1px #a0a0a0;
}
span.high {
	color: #f00;
}
span.low {
	color: #1e90ff;
}
</style>
<script src="../scripts/jquery.js"></script>
<script src="../scripts/jquery.cookie.js"></script>
<script src="../scripts/jquery-ui.min.js"></script>
<script src="../scripts/ok2nd.js"></script>
<title>週間天気予報</title>
</head>
<body>
<h1><a href="javascript:window.close()"><img src="../icon/weather_sun.png" style="margin:0;border:0;"></a>
週間天気予報 by <a href="http://weather.livedoor.com/weather_hacks/rss_feed_list" target="_blank">livedoor</a>
<a href="tenki-set.php" style="margin-left:20px;font-size:14px;">地点設定</a>
<h1>
<script>
$(function(){
	$("#list_box").sortable({stop: function(event, ui) {
		var city_id = $("#list_box").sortable("toArray");
		$.cookie('tenki_yohou_city_list',city_id,{ path:'<?= MY_SESSION_PATH ?>', expires:365 });
	}});
});
function ajax_rss(city, xmlno) {
	data = "city="+xmlno;
	$.ajax({
		type: "GET",
		url: "tenki-ajax.php",
		data: data,
		async: true,
		success: function(res){
			$("#tenki_"+city).html(res);
		}
	})
}
</script>
<table><tr><td style="vertical-align:top;">
<table id="list_box">
<?php
	$city_nums = explode(',', $city_list);
	$ajax_get = '';
	foreach ($city_nums as $city) {
		if ($city <> '') {
			$ajax_get .= 'ajax_rss('.$city.',"'.$city_name[$city][2].'");';
?>
<tbody id="<?= $city ?>">
<tr>
	<td class="city_name">
	<a href="http://tenki.jp/forecast/city-<?= $city ?>.html" target="_blank"><?= $city_name[$city][0] ?><br><?= $city_name[$city][1] ?></a>
	</td>
	<td class="tenki_yohou" id="tenki_<?= $city ?>"></td>
</tr>
</tbody>
<?php
		}
	}
?>
</table>
</td><td style="vertical-align:top;" rowspan=2>
<div style="clear:left;">
<script type="text/javascript" charset="utf-8" src="http://tenki.jp/blog/script/parts/forecast/?type=top&color=0&size=large"></script>
</div>
<div style="clear:left;">
<script type="text/javascript" charset="utf-8" src="http://tenki.jp/blog/script/parts/rader/?type=top&color=0&size=large"></script>
</div>
<?php
	$typhoon = my_file_get_contents('http://bousai.tenki.jp/bousai/typhoon/japan_near');
	if (!strstr($typhoon, 'no_typhoon_no_str_japan_near.jpg')) {	// 台風が発生している場合
		// japan_near-small.jpgには、最後の台風情報が残るため
?>
	<div style="clear:left;">
	<a href="http://bousai.tenki.jp/bousai/typhoon/japan_near" target="_blank"><img src="<?= TENKI_TYPHOON_IMAGE ?>?<?= date('YmdHis') // キャッシュを利用されないため ?>" style="width:200px;"><a>
	</div>
<?php
	} else {
?>
	<div style="clear:left;font-size:12px;font-weight:normal;padding-top:30px;width:200px;text-align:center;">
		<a href="http://bousai.tenki.jp/bousai/typhoon/japan_near" target="_blank" style="color:#888;text-decoration:none;">現在、台風は発生していません。</a>
	</div>
<?php
	}
?>
</td></tr>
<tr><td style="vertical-align:top;text-align:center;">
	<div><a href="http://weather.goo.ne.jp/himawari/" target="_blank"><img src="http://weather.goo.ne.jp/weather/img/u/himawari/hima<?= date('H', strtotime('-30 minute')) ?>.jpg" name="animation" width="480" alt="衛星画像(日本付近)"></a></div>
	<p><a href="http://tenki.jp/satellite/?satellite_type=japan_near" target="_blank" style="font-size:12px;">tenki.jp 気象衛星（日本付近）</a></p>
	<p><a href="http://bousai.tenki.jp/bousai/earthquake/" target="_blank" style="font-size:12px;">tenki.jp 地震情報</a></p>
</td></tr>
</table>
<script>
$(function(){
	<?= $ajax_get ?>
});
</script>
<div id="page_footer" style="margin-top:20px;">
<a href="http://ok2nd.web.fc2.com/" target="_blank" style="color:#8080ff;font-size:12px;">Powered by ok.2nd</a>
</div>
</body>
</html>
