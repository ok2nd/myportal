<?php
	require("../__common__/__define_common.php");
	require("../__common__/include-common-all.php");
	require("../tools/__include-common-code-file.php");
	my_session_start();
	require("../account/__logincheck.php");
	if ($_SESSION['システム管理者'] <> "YES") {
		exit;
	}
	if ($_GET['ret'].'' == '') {
		$ret_php = 'list-url.php';
	} else {
		$ret_php = $_GET['ret'];
	}
	if ($_GET['path'].'' == '' or $_GET['new'].'' == '') {
		error_simple_html('エラー', 'パス指定がありません。');
	}
	if ($_GET['new'] == '.' || $_GET['new'] == '..') {
		error_simple_html('エラー', 'フォルダ名が不正です。');
	}
	$path = my_GET('path');
	$new = my_GET('new');
	if (myfile_is_dir($path)) {
		$new_path = substr($path, 0, strrpos($path, '/')).'/'.$new;
		if (myfile_is_dir($new_path)) {
			error_simple_html('フォルダリネームエラー', 'リネーム先のフォルダ['.$new.']が存在します。');
		}
		if (@myfile_rename($path, $new_path) == False) {
			error_simple_html('フォルダリネームエラー', 'リネーム['.$new.']に失敗しました。');
		}
	}
	header("Location: ".$ret_php."?path=".urlencode(up_folder_path($path)));
?>
