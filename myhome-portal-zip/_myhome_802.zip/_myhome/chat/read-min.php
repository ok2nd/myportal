<?php
	require("__include-common.php");
define("LOGINCHECK_SESSION_URL", "NO");		// URLをSESSION変数にセットしない。
	require("../account/__logincheck.php");

	$con = my_mysqli_connect(_DB_SCHEMA);
	$sql = 'select * from v_messages where ADDDATE(c_registtime, INTERVAL '.CHAT_LOG_VIEW_INTERVAL_MIN.' MINUTE) > NOW() order by id_messages asc';
	$rs = my_mysqli_query($sql);
	$row = mysqli_num_rows($rs);
	if ($row == 0) {
		exit;
	}
	if ($row > CHAT_LOG_VIEW_CNT_MIN) {
		$startline = $row - CHAT_LOG_VIEW_CNT_MIN;
	} else {
		$startline = 0;
	}
?>
	<ul class="index_chat_message_area">
<?php
	$GLOBALS['URL_2_ATAG_SHORT_LEN'] = 28;
	mysqli_data_seek($rs, $startline);
	$fsw = true;
	while ($rec=mysqli_fetch_array($rs)) {
		if ($rec['c_body_background_color'] <> '') {
			$bgcolor = $rec['c_body_background_color'];
		} else {
			$bgcolor = '#ffffff';
		}
		If ($fsw) {
			$fsw = false;
		} else {
			$border = 'border-top: dotted 1px #a0a0a0;';
		}
?>
		<li class="index_chat_message" style="background-color:<?= $bgcolor ?>;<?= $border ?>";><span class="index_chat_handle"><?= my_htmlspecialchars($rec['c_handle']) ?></span><span class="index_chat_time"><?= date_from_mysql("H:i:s", $rec['c_registtime']) ?></span><br><?= ins_atag_br_short($rec['c_message']) ?>
		</li>
<?php
	}
?>
	</ul>
<?php
	mysqli_close($con);
?>
