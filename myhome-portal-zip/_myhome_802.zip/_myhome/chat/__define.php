<?php
	if (defined("HTML_TITLE_chat")) {
		define("HTML_TITLE", HTML_TITLE_chat);
	} else {
		define("HTML_TITLE", "MyHome チャット");
	}
	define("SESSION_PREFIX", "chat");

	if (defined("_DB_SCHEMA_chat")) {
		define("_DB_SCHEMA", _DB_SCHEMA_chat);
	} else {
		define("_DB_SCHEMA", "_db_chat");
	}
	if (defined("CHAT_READ_CHECK_INTERVAL_chat")) {
		define("CHAT_READ_CHECK_INTERVAL", CHAT_READ_CHECK_INTERVAL_chat);
	} else {
		define("CHAT_READ_CHECK_INTERVAL", 1000);		// チャットAjax読取間隔 (ミリセカンド)
	}
	if (defined("CHAT_LOG_VIEW_CNT_SELECT_chat")) {
		define("CHAT_LOG_VIEW_CNT_SELECT", CHAT_LOG_VIEW_CNT_SELECT_chat);
	} else {
		define("CHAT_LOG_VIEW_CNT_SELECT", "5,10,20,50,100");
	}
	if (defined("CHAT_LOG_VIEW_CNT_SELECT_INIT_chat")) {
		define("CHAT_LOG_VIEW_CNT_SELECT_INIT", CHAT_LOG_VIEW_CNT_SELECT_INIT_chat);
	} else {
		define("CHAT_LOG_VIEW_CNT_SELECT_INIT", "10");		// CHAT_LOG_VIEW_CNT_SELECT 初期値
	}
	if (defined("CHAT_LOG_VIEW_INTERVAL_SELECT_chat")) {
		define("CHAT_LOG_VIEW_INTERVAL_SELECT", CHAT_LOG_VIEW_INTERVAL_SELECT_chat);
	} else {
		define("CHAT_LOG_VIEW_INTERVAL_SELECT", "1:1時間,2:2時間,6:6時間,12:12時間,24:1日,168:1週間,720:30日,0:制限なし");
	}
	if (defined("CHAT_LOG_VIEW_INTERVAL_SELECT_INIT_chat")) {
		define("CHAT_LOG_VIEW_INTERVAL_SELECT_INIT", CHAT_LOG_VIEW_INTERVAL_SELECT_INIT_chat);
	} else {
		define("CHAT_LOG_VIEW_INTERVAL_SELECT_INIT", "1");	// CHAT_LOG_VIEW_INTERVAL_SELECT 初期値
	}

	if (defined("CHAT_LOG_VIEW_CNT_MIN_index")) {
		define("CHAT_LOG_VIEW_CNT_MIN", CHAT_LOG_VIEW_CNT_MIN_index);
	} else {
		define("CHAT_LOG_VIEW_CNT_MIN", 3);		// INDEXトップページ チャット表示 件数
	}
	if (defined("CHAT_LOG_VIEW_INTERVAL_MIN_index")) {
		define("CHAT_LOG_VIEW_INTERVAL_MIN", CHAT_LOG_VIEW_INTERVAL_MIN_index);
	} else {
		define("CHAT_LOG_VIEW_INTERVAL_MIN", 30);	// INDEXトップページ チャット表示 経過時間 (分)
	}
?>
