<?php
	require("__include-common.php");
define("LOGINCHECK_SESSION_URL", "NO");		// URLをSESSION変数にセットしない。
	require("../account/__logincheck.php");

	if ($_POST["message"].'' == '') {
		exit;
	}
	$con = my_mysqli_connect(_DB_SCHEMA);
	$sql = "insert into m_messages (id_account,c_message,c_registtime)";
	$sql .= " values ('" . $_SESSION['login_id'] . "','" . str_for_mysql(form_str_adjust($_POST["message"])) . "','" . date("Y/m/d H:i:s") ."')";
	my_mysqli_query($sql);
	mysqli_close($con);
?>
