<?php
	require("__include-common.php");
define("LOGINCHECK_SESSION_URL", "NO");		// URLをSESSION変数にセットしない。
	require("../account/__logincheck.php");

	$con = my_mysqli_connect(_DB_SCHEMA);

	if ($_GET['it'] <> '0') {
		$sql = 'select * from v_messages where ADDDATE(c_registtime, INTERVAL '.$_GET['it'].' HOUR) > NOW() order by id_messages asc';
	} else {
		$sql = 'select * from v_messages order by id_messages asc';
	}
	$rs = my_mysqli_query($sql);
	$row = mysqli_num_rows($rs);
	if ($row == 0) {
		exit;
	}
	if ($row > $_GET['cn']) {
		$startline = $row - $_GET['cn'];
	} else {
		$startline = 0;
	}
?>
	<table id="chat_view_table" cellspacing=0>
<?php
	$GLOBALS['URL_2_ATAG_SHORT_LEN'] = 50;
	mysqli_data_seek($rs, $startline);
	while ($rec=mysqli_fetch_array($rs)) {
?>
		<tr>
		<td class="chat_view_image" rowspan=2>
		<?php if ($rec['c_profile_image'] <> '') { ?>
			<img src="<?= ATTACH_FILE_FOLDER_account.($rec['c_profile_image']) ?>" style="width:<?= PROFILE_ICON_IMAGE_SIZE ?>px; height:<?= PROFILE_ICON_IMAGE_SIZE ?>px;" />
		<?php } ?>
		</td>
		<td class="chat_view_handle"><?= my_htmlspecialchars($rec['c_handle']) ?></td>
		<td class="chat_view_time"><?= date_from_mysql("n/j H:i:s", $rec['c_registtime']) ?></td>
		</tr>
		<tr>
		<td class="chat_view_message" colspan=2><?= ins_atag_br_short($rec['c_message']) ?></td>
		</tr>

<?php
	}
?>
	</table>
<?php
	mysqli_close($con);
?>
