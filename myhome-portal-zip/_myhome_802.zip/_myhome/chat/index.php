<?php
	require("__include-common.php");
	require("../account/__logincheck.php");
?>
<?php
	if ($_GET['cn'].'' <> '') {
		$view_cnt = $_GET['cn'];
		setcookie('chat_log_view_cnt', $_GET['cn'], time() + LOGIN_COOKIE_EXPIRE, MY_SESSION_PATH);
	} elseif (isset($_COOKIE['chat_log_view_cnt'])) {
		$view_cnt = $_COOKIE['chat_log_view_cnt'];
	} else {
		$view_cnt = CHAT_LOG_VIEW_CNT_SELECT_INIT;
		setcookie('chat_log_view_cnt', $view_cnt, time() + LOGIN_COOKIE_EXPIRE, MY_SESSION_PATH);
	}
	if ($_GET['it'].'' <> '') {
		$int_time = $_GET['it'];
		setcookie('chat_log_view_int_time', $_GET['it'], time() + LOGIN_COOKIE_EXPIRE, MY_SESSION_PATH);
	} elseif (isset($_COOKIE['chat_log_view_int_time'])) {
		$int_time = $_COOKIE['chat_log_view_int_time'];
	} else {
		$int_time = CHAT_LOG_VIEW_INTERVAL_SELECT_INIT;
		setcookie('chat_log_view_int_time', $int_time, time() + LOGIN_COOKIE_EXPIRE, MY_SESSION_PATH);
	}
?>
<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="utf-8">
<meta name="author" content="ok.2nd">
<meta name="description" content="Chat">
<meta name="keywords" content="chat">
<link rel="stylesheet" href="<?= _STYLE_SHEET_FOLDER_COMMON ?>/common.css?20131130">
<link rel="stylesheet" href="<?= _STYLE_SHEET_BUTTON ?>">
<link rel="stylesheet" href="<?= _STYLE_SHEET_FOLDER ?>/chat.css?20111031">
<script src="../scripts/jquery.js"></script>
<script>
$(function(){
	chat_view();
	$("#chat_form").submit(function(){
		message = document.chat_form.message.value;
		$.post('write.php', {message:message});
		document.chat_form.message.value="";
		document.chat_form.message.focus();
		return false;
	});
});
function chat_view(){
	var d = new Date();	// キャッシュを利用されないため
	$("#chat_log").load("read.php?cn=<?= $view_cnt ?>&it=<?= $int_time ?>&time="+d.getTime().toString());
	setTimeout('chat_view()', <?= CHAT_READ_CHECK_INTERVAL ?>);
}
</script>
<script>
function SelectionVal(form, sel, name) {
	for (i = 0; i < sel.options.length; i++) {
		if (sel.options[i].selected == true) {
			window.location.href = '?' + name + '=' + escape(sel.options[i].value);
		}
	}
}
</script>
<title>MyHome チャット</title>
</head>
<body onload="document.chat_form.message.focus();">
<div id="main_body">
<h4>MyHome チャット</h4>
表示件数：<select name="" onchange="SelectionVal(this.form, this, 'cn')">
	<?php
		$view_cnt_ary = explode(',', CHAT_LOG_VIEW_CNT_SELECT);
		foreach ($view_cnt_ary as $sel) {
	?>
		<option value="<?= $sel ?>"<?= $sel == $view_cnt ? " selected" : "" ?>><?= $sel ?>件
	<?php
		}
	?>
</select>&nbsp;
経過時間：<select name="" onchange="SelectionVal(this.form, this, 'it')">
	<?php
		$int_time_ary = explode(',', CHAT_LOG_VIEW_INTERVAL_SELECT);
		foreach ($int_time_ary as $sels) {
			$sel = explode(':', $sels);
	?>
		<option value="<?= $sel[0] ?>"<?= $sel[0] == $int_time ? " selected" : "" ?>><?= $sel[1] ?>
	<?php
		}
	?>
</select>
<div id="chat_log"></div>
<form name="chat_form" id="chat_form">
<textarea name="message" id="message" style="width:400px;" rows=4 wrap="soft"></textarea><br>
<input type="submit" value="送信">
</form>
</div>
<div id="footer">
<a href="http://ok2nd.web.fc2.com/" target="_blank" style="color:#8080ff;">Powered by ok.2nd</a>
</div>
</div>
</body>
</html>
