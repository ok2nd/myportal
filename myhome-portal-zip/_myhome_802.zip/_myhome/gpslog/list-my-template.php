<style>
.mp_list_table_head th {
	white-space: nowrap;
}
</style>
<script>
function checkOnAll() {
	$("input:checkbox[name^='check']").attr('checked', true);
	return false;
}
function checkOffAll() {
	$("input:checkbox[name^='check']").attr('checked', false);
	return false;
}
</script>
<form id="diary_form" name="frm0" method="POST" action="maps-gpslog-v3.php?<?= $_SERVER['QUERY_STRING'] ?>" target="_blank">
<input class="" type="button" onClick="return checkOnAll()" value="全てチェック">
<input class="" type="button" onClick="return checkOffAll()" value="チェッククリア">
<input class="" type="submit" name="multi" value="一覧マップ">
	<table id="gpslog_list_table">
	<tr class="mp_list_table_head">
	<th></th><th style="text-align:center;">日付</th><th><br></th><th>名前</th><th style="text-align:center;">距離</th><th style="text-align:center;">出発<br>時間</th><th style="text-align:center;">到着<br>時間</th><th style="text-align:center;">所要<br>時間</th><th style="text-align:center;">平均<br>速度</th><th style="text-align:center;">最高<br>速度</th><th style="text-align:center;">最高<br>地点</th><th style="text-align:center;">最低<br>地点</th><th>写真フォルダ</th>
	</tr>
<?php
	mysqli_data_seek($rs, $startline);			//テーブル内の指定行に移動
	$line = $startline;					//$lineに$startlineを代入
	$old_date = "";
	while ($rec=mysqli_fetch_array($rs) and $line<=$endline) {
?>
<?php
		if ($line <> $startline) {
?>
	<a name="id_<?= $rec['id_gpslog'] ?>"></a>
	</td>
	</tr>
<?php
		}
?>
	<tr>
	<td class="gpslog_list_td a_check">
		<input type="checkbox" name="check[]" value="<?= $rec['id_gpslog'] ?>">
	</td>
	<?php if ($old_date <> $rec['c_date']) { ?>
	<td class="gpslog_list_table_day" style="white-space: nowrap;">
<?php
		$date = $rec['c_date'];
		$year = date_from_mysql("Y", $date);
		$month = date_from_mysql("n", $date);
		$day = date_from_mysql("d", $date);
		$day_week = mb_substr("日月火水木金土", date_from_mysql("w", $date), 1);
		$holiday = holiday_check($year, $month, $day);
		if ($holiday) {
			$day_class = 'holiday';
			$day_week_view = "<a title='".$holiday."' class='dayweek_".$day_class."'>".$day_week."</a>";
		} else {
			if ($day_week == '日') {
				$day_class = "sunday";
			} elseif ($day_week == '土') {
				$day_class = "saturday";
			} else {
				$day_class = "weekday";
			}
			$day_week_view = "<span class='dayweek_".$day_class."'>".$day_week."</span>";
		}
?>
		<p>
		<a class="<?= $day_class ?>" href="?selY=<?= $year ?>&selM=<?= $month ?>&selD=<?= $day ?>"><?= date_from_mysql("Y-m-d", $date) ?></a>
		<?= $day_week_view ?>
		</p>
	</td>
	<?php } else { ?>
	<td class="gpslog_list_table_day_cont">
		<br>
	</td>
	<?php } ?>
	<?php $old_date = $rec['c_date'] ?>
	<td style="white-space: nowrap;">
	<span class="category" style="background-color:<?= $rec['c_categoryDisplayColor'].'' <> '' ? $rec['c_categoryDisplayColor'] : '#b0b0b0' ?>;font-size:10px;color:#fff;padding:2px;"><?= $rec['c_categoryName'] ?></span>
	</td>
	<td class="<?= $view_sch_class ?>" style="width:240px;">
	<p>
<?php
	if ($rec['c_time1']."" <> "" || $rec['c_time2']."" <> "") {
		echo '<span class="calendar_time">';
		echo sch_time_format($rec['c_time1'], $rec['c_time2'])."&nbsp;";
		echo '</span>';
	}
	if ($rec['c_iconImage'] <> "") {
		echo "<img src='".IMAGES_FOLDER."/".$rec['c_iconImage']."'/>";
	}
// ***************************************
//				↓↓↓↓　　　& query_from_http_arg_pool($http_arg)
// ***************************************
?>
	<a name="id_<?= $rec['id_gpslog'] ?>" class="title" href='view.php?id=<?= $rec['id_gpslog'] ?>&move=<?= $line ?>&row=<?= $rowcnt ?>&page=<?= $page ?>&<?= query_from_http_arg_pool($http_arg) ?>'><?php
		if ($rec['c_name'] == '') {
			echo NO_SUBJECT_INPUT_MARK;
		} else {
			echo my_htmlspecialchars($rec['c_name']);
		}
	?></a>
	<?php if (check_permit_id($_SESSION['login_id'], $_SESSION['current_id']) == "w") { ?>
	<a class="a_update" style="margin-left:5px;color:#ff8000;font-size:10px;" href='edit.php?id=<?= $rec['id_gpslog'] ?>&page=<?= $page ?>&<?= query_from_http_arg_pool($http_arg) ?>'>[修正]</a>
	<?php } ?>
	<?php
		if ($rec['c_name'] <> '') {
			?></p><p><?php
		}
	?><span class="memo_body">
		<?= ins_br(my_htmlspecialchars($rec['c_description'])) ?>
	</span></p>
	</td>
	<td style="text-align:right;padding:0 4px;"><?= number_format($rec['c_distance'],3) ?>km</td>
	<td style="text-align:center;padding:0 4px;"><?= date_from_mysql('H:i:s', $rec['c_starttime']) ?></td>
	<td style="text-align:center;padding:0 4px;"><?= date_from_mysql('H:i:s', $rec['c_stoptime']) ?></td>
	<td style="text-align:center;padding:0 4px;"><?= date_from_mysql('H:i:s', $rec['c_taketime']) ?></td>
	<td style="text-align:right;padding:0 4px;"><?= number_format($rec['c_speed_ave'],2) ?>km/h<br>
	<td style="text-align:right;padding:0 4px;"><?= number_format($rec['c_speed_max'],2) ?>km/h<br>
	<td style="text-align:right;padding:0 4px;"><?= $rec['c_height_max'] ?>m<br>
	<td style="text-align:right;padding:0 4px;"><?= $rec['c_height_min'] ?>m<br>
	<td style="text-align:left;padding:0 4px;"><?= $rec['c_photo_folder'] ?><br>
<?php
		$line++;
	}
?>
	</td>
	</tr>
	</table>
</form>
<?php
	jquery_highlight('.memo_body', keystr_and_or($keystring));
?>
