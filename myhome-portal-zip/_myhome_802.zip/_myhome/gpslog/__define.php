<?php
	if (defined("HTML_TITLE_gpslog")) {
		define("HTML_TITLE", HTML_TITLE_gpslog);
	} else {
		define("HTML_TITLE", "MyHome GPSログ");
	}
	define("SESSION_PREFIX", "gpslog");
	if (defined("_DB_SCHEMA_gpslog")) {
		define("_DB_SCHEMA", _DB_SCHEMA_gpslog);
	} else {
		define("_DB_SCHEMA", "_db_gpslog");
	}
	if (defined("ATTACH_FILE_FOLDER_gpslog")) {
		define("ATTACH_FILE_FOLDER", ATTACH_FILE_FOLDER_gpslog);
	} else {
		define("ATTACH_FILE_FOLDER", "../_attach/gpslog/");
	}
	if (!defined("gpslog_CALENDAR_SELECT_FIRST_YEAR")) {
		define("gpslog_CALENDAR_SELECT_FIRST_YEAR", 2000);
	}
	if (defined("INPUT_POPUP_CALENDAR_calendar")) {
		define("INPUT_POPUP_CALENDAR", INPUT_POPUP_CALENDAR_calendar);
	} else {
		define("INPUT_POPUP_CALENDAR", "");		// Yahoo! UI Library: Calendar を使う場合: "YUI"
	}
	define("PAGE_LINE_SELECT", "5,10,20,50,100,1000");	//頁内に表示する行数
	define("PAGE_LINE_DEFAULT", "10");			//頁内に表示する行数（デフォルト）
?>
