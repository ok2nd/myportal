<?php
function contents_header() {
	$menu_item = array();
	$menu_item[] = array("href"=>"list.php", "query"=>"arg=session", "name"=>"GPSログ 一覧");

	$menu_item[] = array("href"=>"category.php", "name"=>"カテゴリ一覧");


?>
<div id="contents_header">
<?php
	contents_menu($menu_item);
	change_account_menu();
?>
</div><!-- id="contents_header" -->
<?php
}
?>
